# Fase 20 — caché del timestamp numérico en Historial

## Cambio
- Cada registro de la línea de tiempo calcula `timestampMs` al reconstruirse el conjunto base.
- El ordenamiento, los filtros por fecha y el diagnóstico de solo lectura reutilizan ese valor, evitando repetir `Date.parse()` por cada render/filtro.
- La exportación CSV reutiliza la fecha y hora ya formateadas del registro.

## Seguridad y alcance
- No cambia datos persistidos, APIs, sincronización, colas ni cursores.
- No recorta registros ni modifica el detalle de las operaciones.
- Se conserva el límite visual de 100 registros iniciales y el botón para cargar más.

## Verificación
- Pendiente de ejecutar compilación completa y prueba en navegador; el ZIP es código fuente, no un paquete listo para subir directamente a DirectAdmin.
