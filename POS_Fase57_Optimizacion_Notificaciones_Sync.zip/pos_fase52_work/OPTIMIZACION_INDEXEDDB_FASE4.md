# Optimización POS — Fase 4: preparación segura de IndexedDB

## Alcance
- Se agrega `src/services/indexedDbLedgerMigration.ts` como herramienta de copia y verificación para los historiales voluminosos.
- La copia incluye ventas, compras, movimientos de cuentas corrientes, turnos y movimientos de caja, auditoría y ventas de servicios externos.
- Cada clave se copia como JSON sin transformar y se vuelve a leer para comparar el contenido exacto.
- Los originales en `localStorage` no se modifican ni se borran, incluso ante errores de cuota o de verificación.
- La función de limpieza elimina solo las copias del almacén IndexedDB de prueba.
- Se conserva el endpoint de vinculación `pairing-redeem` y el mecanismo actual de sincronización.

## Por qué no se activa automáticamente
`StorageService` todavía ofrece operaciones síncronas y la aplicación, el contexto global, el sistema de sincronización y las pantallas usan ese contrato. Migrar lecturas/escrituras de manera parcial puede dejar ventas, stock, caja o cola offline desincronizados. Por eso esta fase prepara y valida la copia sin cambiar el origen de verdad ni borrar datos.

## Estado de la fase
Esta es una etapa de preparación, no la migración definitiva ni una solución inmediata al límite de `localStorage`. La herramienta no está conectada al arranque de la aplicación. Antes de usarla en producción, hay que integrarla en una pantalla administrativa protegida y probar con una copia de datos reales, validar permisos/cuota del navegador y decidir la migración completa de la API de almacenamiento.

## Pruebas pendientes
- Compilación completa de Vite/TypeScript.
- Ejecutar copia/verificación en Chrome con volumen de datos real.
- Comparar conteos y totales de ventas, caja y cuentas corrientes.
- Probar ventas offline, reconexión, sincronización entre terminales, POSNET y QR de cliente.
