// Full-Stack Express Server for VPS / Dedicated Hosting
// Supports real-time Multi-Terminal Sync, Customer Display SSE, and Static Asset Serving
import express from 'express';
import path from 'path';
import fs from 'fs';
import os from 'os';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Enable CORS
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
  res.setHeader('Access-Control-Allow-Headers', '*');
  if (req.method === 'OPTIONS') {
    return res.status(204).end();
  }
  next();
});

// Sync State Cache
const syncClients = new Set();
let serverLatestArticles = null;
let serverArticlesVersion = 1;
let serverArticlesLastUpdated = Date.now();

// Durable event journal: lets a terminal replay changes published while it was offline.
// Keep a bounded tail so this file does not grow without limit.
const syncEventLogPath = path.join(__dirname, '.server_sync_events.jsonl');
const MAX_SYNC_EVENTS = 10000;
const syncEventLog = [];
const seenSyncEventIds = new Map();
let syncSequence = 0;
try {
  if (fs.existsSync(syncEventLogPath)) {
    const lines = fs.readFileSync(syncEventLogPath, 'utf8').split(/\r?\n/).filter(Boolean);
    for (const line of lines.slice(-MAX_SYNC_EVENTS)) {
      try {
        const entry = JSON.parse(line);
        if (entry && Number.isFinite(Number(entry.seq)) && entry.message?.id) {
          syncEventLog.push(entry);
          syncSequence = Math.max(syncSequence, Number(entry.seq));
          seenSyncEventIds.set(String(entry.message.id), Number(entry.seq));
        }
      } catch {}
    }
  }
} catch (error) {
  console.warn('[POS sync] Could not load durable event journal:', error?.message || error);
}

function persistSyncEvent(entry) {
  try {
    fs.appendFileSync(syncEventLogPath, JSON.stringify(entry) + '\n', 'utf8');
  } catch (error) {
    console.error('[POS sync] Could not persist sync event:', error?.message || error);
    return false;
  }
  syncEventLog.push(entry);
  seenSyncEventIds.set(String(entry.message.id), Number(entry.seq));
  while (syncEventLog.length > MAX_SYNC_EVENTS) {
    const removed = syncEventLog.shift();
    if (removed?.message?.id) seenSyncEventIds.delete(String(removed.message.id));
  }
  // Compact occasionally, not on every event once the journal reaches its cap.
  if (entry.seq % 250 === 0) {
    try { fs.writeFileSync(syncEventLogPath, syncEventLog.map((item) => JSON.stringify(item)).join('\n') + '\n', 'utf8'); }
    catch (error) { console.warn('[POS sync] Journal compaction failed:', error?.message || error); }
  }
  return true;
}

const mergeCatalogPreservingNewerStock = (incoming) => {
  if (!Array.isArray(incoming)) return incoming;
  if (!Array.isArray(serverLatestArticles) || serverLatestArticles.length === 0) return incoming;
  const existingById = new Map(serverLatestArticles.filter((a) => a?.id != null).map((a) => [String(a.id), a]));
  return incoming.map((article) => {
    const current = existingById.get(String(article?.id));
    if (!current) return article;
    const currentTime = Date.parse(current.updatedAt || '') || 0;
    const incomingTime = Date.parse(article.updatedAt || '') || 0;
    if (currentTime > incomingTime) return { ...article, stock: current.stock, updatedAt: current.updatedAt };
    return article;
  });
};

const applyStockDeltasToServerArticles = (deltas) => {
  if (!Array.isArray(serverLatestArticles) || !Array.isArray(deltas)) return false;
  let changed = false;
  for (const delta of deltas) {
    const article = serverLatestArticles.find((a) => a?.id === delta?.articleId);
    if (!article) continue;
    const amount = Number(delta?.quantityDelta || 0);
    if (!Number.isFinite(amount)) continue;
    article.stock = Math.max(0, Number(article.stock || 0) + amount);
    article.updatedAt = new Date().toISOString();
    changed = true;
  }
  return changed;
};

try {
  if (fs.existsSync(path.join(__dirname, '.server_articles_sync.json'))) {
    const cached = JSON.parse(fs.readFileSync(path.join(__dirname, '.server_articles_sync.json'), 'utf8'));
    if (cached && Array.isArray(cached.articles) && cached.articles.length > 0) {
      serverLatestArticles = cached.articles;
      serverArticlesVersion = cached.version || 1;
      serverArticlesLastUpdated = cached.lastUpdated || Date.now();
    }
  }
} catch {}

// Terminal Payloads
const terminalPayloads = new Map();
const normalizeTerminalId = (raw = 'TERM-01') => {
  let cleaned = (raw || 'TERM-01').trim().toUpperCase();
  if (cleaned.startsWith('TERMINAL')) {
    cleaned = cleaned.replace('TERMINAL', '').trim();
  }
  if (/^\d+$/.test(cleaned)) {
    cleaned = `TERM-${cleaned.padStart(2, '0')}`;
  } else if (/^TERM-\d+$/.test(cleaned)) {
    const num = cleaned.replace('TERM-', '');
    cleaned = `TERM-${num.padStart(2, '0')}`;
  }
  return cleaned || 'TERM-01';
};

// 1. WiFi & LAN Info
app.get('/api/wifi-info', (req, res) => {
  const interfaces = os.networkInterfaces();
  const ips = [];
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name] || []) {
      if (iface.family === 'IPv4' && !iface.internal && !iface.address.startsWith('169.254.')) {
        ips.push(iface.address);
      }
    }
  }
  res.json({ ips });
});

// 2. Real-Time Multi-Terminal Sync Stream (SSE)
app.get('/api/sync/stream', (req, res) => {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    'Connection': 'keep-alive',
    'Access-Control-Allow-Origin': '*',
    'X-Accel-Buffering': 'no',
  });

  const requestedSince = Number(req.query.since || 0);
  const hasCursor = req.query.since !== undefined && Number.isFinite(requestedSince) && requestedSince >= 0;
  const cursor = hasCursor ? requestedSince : syncSequence;
  const connectMsg = JSON.stringify({
    type: 'CONNECTED',
    timestamp: Date.now(),
    hasArticles: !!serverLatestArticles,
    serverArticlesLastUpdated,
    latestSeq: syncSequence,
  });
  res.write(`data: ${connectMsg}\n\n`);

  // Replay missed events before registering the client for live events.
  for (const entry of syncEventLog) {
    if (entry.seq > cursor) {
      try { res.write(`id: ${entry.seq}\ndata: ${JSON.stringify(entry)}\n\n`); } catch {}
    }
  }

  if (serverLatestArticles && serverLatestArticles.length > 0 && !hasCursor) {
    const initMsg = JSON.stringify({
      id: `init_${Date.now()}`,
      type: 'ARTICLES_UPDATED',
      senderTerminalId: 'SERVER',
      senderClientId: 'SERVER',
      timestamp: serverArticlesLastUpdated,
      payload: {
        articles: serverLatestArticles,
        count: serverLatestArticles.length,
      },
    });
    res.write(`data: ${initMsg}\n\n`);
  }

  syncClients.add(res);

  const keepAlive = setInterval(() => {
    try {
      res.write(': keepalive\n\n');
    } catch {
      clearInterval(keepAlive);
      syncClients.delete(res);
    }
  }, 10000);

  req.on('close', () => {
    clearInterval(keepAlive);
    syncClients.delete(res);
  });
});

// 3. Publish Sync Message to all terminals
app.post('/api/sync/publish', (req, res) => {
  try {
    const parsed = req.body;
    const msg = parsed.message || parsed;

    if (!msg || !msg.id || !msg.type) {
      return res.status(400).json({ success: false, error: 'Invalid sync message' });
    }

    const existingSeq = seenSyncEventIds.get(String(msg.id));
    if (existingSeq) {
      return res.json({ success: true, duplicate: true, seq: existingSeq, version: serverArticlesVersion, deliveredTo: syncClients.size });
    }

    const previousServerArticles = Array.isArray(serverLatestArticles) ? JSON.parse(JSON.stringify(serverLatestArticles)) : null;
    const previousArticlesVersion = serverArticlesVersion;
    const previousArticlesLastUpdated = serverArticlesLastUpdated;
    let articlesChanged = false;
    if ((msg.type === 'SALE_PROCESSED' || msg.type === 'PURCHASE_REGISTERED') && msg.payload?.updatedArticles && Array.isArray(msg.payload.updatedArticles)) {
      serverLatestArticles = mergeCatalogPreservingNewerStock(msg.payload.updatedArticles);
      articlesChanged = true;
    } else if ((msg.type === 'SALE_PROCESSED' || msg.type === 'PURCHASE_REGISTERED') && msg.payload?.stockDeltas) {
      articlesChanged = applyStockDeltasToServerArticles(msg.payload.stockDeltas);
    } else if ((msg.type === 'ARTICLES_UPDATED' || msg.type === 'SYNC_RESPONSE_STATE') && msg.payload?.articles && Array.isArray(msg.payload.articles)) {
      serverLatestArticles = mergeCatalogPreservingNewerStock(msg.payload.articles);
      articlesChanged = true;
    } else if (msg.type === 'SYSTEM_RESTORE' && msg.payload?.backupData?.articles && Array.isArray(msg.payload.backupData.articles)) {
      serverLatestArticles = mergeCatalogPreservingNewerStock(msg.payload.backupData.articles);
      articlesChanged = true;
    }

    if (articlesChanged) {
      serverArticlesVersion++;
      serverArticlesLastUpdated = Date.now();
      try {
        fs.writeFileSync(path.join(__dirname, '.server_articles_sync.json'), JSON.stringify({
          articles: serverLatestArticles,
          version: serverArticlesVersion,
          lastUpdated: serverArticlesLastUpdated,
        }));
      } catch {}
    }

    msg.serverVersion = serverArticlesVersion;
    const entry = { seq: syncSequence + 1, message: msg };
    if (!persistSyncEvent(entry)) {
      serverLatestArticles = previousServerArticles;
      serverArticlesVersion = previousArticlesVersion;
      serverArticlesLastUpdated = previousArticlesLastUpdated;
      try {
        if (serverLatestArticles) fs.writeFileSync(path.join(__dirname, '.server_articles_sync.json'), JSON.stringify({ articles: serverLatestArticles, version: serverArticlesVersion, lastUpdated: serverArticlesLastUpdated }));
        else if (fs.existsSync(path.join(__dirname, '.server_articles_sync.json'))) fs.unlinkSync(path.join(__dirname, '.server_articles_sync.json'));
      } catch {}
      return res.status(503).json({ success: false, error: 'No se pudo guardar el evento de sincronización en el servidor.' });
    }
    syncSequence = entry.seq;
    const outgoingData = JSON.stringify(entry);
    for (const client of syncClients) {
      try {
        if (!client.destroyed && !client.writableEnded) {
          client.write(`id: ${entry.seq}\ndata: ${outgoingData}\n\n`);
        } else {
          syncClients.delete(client);
        }
      } catch {
        syncClients.delete(client);
      }
    }

    res.json({ success: true, seq: entry.seq, version: serverArticlesVersion, deliveredTo: syncClients.size });
  } catch (e) {
    res.status(400).json({ success: false, error: e?.message });
  }
});

// Seed the relay catalog only when the server does not have one yet.
app.post('/api/sync/init-articles', (req, res) => {
  try {
    const articles = req.body?.articles;
    if (Array.isArray(articles) && articles.length > 0 && (!Array.isArray(serverLatestArticles) || serverLatestArticles.length === 0)) {
      const msg = {
        id: `catalog_seed_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
        type: 'ARTICLES_UPDATED',
        senderTerminalId: 'SERVER',
        senderClientId: 'SERVER',
        timestamp: Date.now(),
        payload: { articles, count: articles.length },
        serverVersion: serverArticlesVersion + 1,
      };
      const entry = { seq: syncSequence + 1, message: msg };
      if (!persistSyncEvent(entry)) return res.status(503).json({ success: false, error: 'No se pudo guardar el catálogo inicial en el diario de sincronización.' });
      syncSequence = entry.seq;
      serverLatestArticles = articles;
      serverArticlesVersion++;
      serverArticlesLastUpdated = Date.now();
      fs.writeFileSync(path.join(__dirname, '.server_articles_sync.json'), JSON.stringify({
        articles: serverLatestArticles,
        version: serverArticlesVersion,
        lastUpdated: serverArticlesLastUpdated,
      }));
      const outgoingData = JSON.stringify(entry);
      for (const client of syncClients) {
        try { if (!client.destroyed && !client.writableEnded) client.write(`id: ${entry.seq}\ndata: ${outgoingData}\n\n`); else syncClients.delete(client); }
        catch { syncClients.delete(client); }
      }
    }
    res.json({ success: true, version: serverArticlesVersion, lastUpdated: serverArticlesLastUpdated, latestSeq: syncSequence, count: serverLatestArticles?.length || 0 });
  } catch (error) {
    res.status(500).json({ success: false, error: error?.message || 'Could not initialize catalog' });
  }
});

// 4. Current State
app.get('/api/sync/state', (req, res) => {
  res.json({
    latestArticles: serverLatestArticles,
    version: serverArticlesVersion,
    lastUpdated: serverArticlesLastUpdated,
    latestSeq: syncSequence,
    connectedCount: syncClients.size,
  });
});

// Serve frontend static assets from dist
const distPath = path.join(__dirname, 'dist');
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
  app.get('*', (req, res) => {
    res.sendFile(path.join(distPath, 'index.html'));
  });
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`POS Multi-Terminal Sync Server running on port ${PORT}`);
});
