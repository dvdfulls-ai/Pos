<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('X-Content-Type-Options: nosniff');

function reply(int $status, array $body): void {
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function input_json(): array {
    $length = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($length > 12 * 1024 * 1024) reply(413, ['success'=>false,'error'=>'Solicitud demasiado grande']);
    $raw = file_get_contents('php://input');
    if (is_string($raw) && strlen($raw) > 12 * 1024 * 1024) reply(413, ['success'=>false,'error'=>'Solicitud demasiado grande']);
    $value = json_decode($raw ?: '', true);
    if (json_last_error() !== JSON_ERROR_NONE) reply(400, ['success'=>false,'error'=>'JSON inválido']);
    return is_array($value) ? $value : [];
}
function valid_channel($v): string {
    $s = is_string($v) ? trim($v) : '';
    if ($s === '' || strlen($s) > 120 || !preg_match('/^[a-zA-Z0-9_-]+$/', $s)) reply(400, ['success'=>false,'error'=>'Canal inválido']);
    return $s;
}
try {
    $configFile = __DIR__ . '/sync-config.php';
    if (!is_file($configFile)) reply(500, ['success'=>false,'error'=>'Falta configurar sync-config.php']);
    $cfg = require $configFile;
    $action = (string)($_GET['action'] ?? '');
    $method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    if (in_array($action, ['init-articles', 'publish', 'pairing-redeem', 'reset-demo'], true) && $method !== 'POST') {
        header('Allow: POST');
        reply(405, ['success'=>false,'error'=>'Método no permitido']);
    }
    if (in_array($action, ['state', 'poll', 'display-state'], true) && $method !== 'GET') {
        header('Allow: GET');
        reply(405, ['success'=>false,'error'=>'Método no permitido']);
    }
    // GET state/poll requests have no JSON body. Parse JSON only for write actions.
    $body = in_array($action, ['init-articles', 'publish', 'pairing-redeem', 'reset-demo'], true) ? input_json() : [];
    // One-time pairing is deliberately handled before channel/token validation:
    // the browser has no long-lived sync token yet. The panel is the authority for
    // commerce + terminal identity; this POS server creates and stores the actual token.
    if ($action === 'pairing-redeem') {
        if ($method !== 'POST') reply(405,['success'=>false,'error'=>'Método no permitido']);
        $code = strtoupper(preg_replace('/\s+/', '', (string)($body['code'] ?? '')) ?? '');
        $requestedTerminal = strtoupper(trim((string)($body['terminalId'] ?? '')));
        if (!preg_match('/^[A-F0-9]{10}$/',$code) || ($requestedTerminal !== '' && !preg_match('/^[A-Z0-9_-]{1,120}$/',$requestedTerminal))) {
            reply(400,['success'=>false,'error'=>'Código o terminal inválidos.']);
        }
        $panelUrl = trim((string)($cfg['pairing_panel_url'] ?? ''));
        $sharedSecret = (string)($cfg['pairing_shared_secret'] ?? '');
        if (!preg_match('#^https://[^\\s]+/api/pairing-redeem\\.php$#i',$panelUrl) || strlen($sharedSecret)<32) {
            reply(500,['success'=>false,'error'=>'Falta configurar la URL del panel y el secreto compartido en sync-config.php.']);
        }
        // The one-time code identifies the exact terminal; do not require the browser
        // to have that terminal pre-created in its local demo list.
        $panelPayload = json_encode(['code'=>$code], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        $context = stream_context_create(['http'=>[
            'method'=>'POST',
            'timeout'=>12,
            'ignore_errors'=>true,
            'header'=>"Content-Type: application/json\r\nAccept: application/json\r\nX-Pairing-Secret: ".$sharedSecret."\r\n",
            'content'=>$panelPayload
        ]]);
        $panelRaw = @file_get_contents($panelUrl,false,$context);
        if (!is_string($panelRaw)) reply(502,['success'=>false,'error'=>'No se pudo contactar al panel de vinculación. Verifique URL, HTTPS y conexión entre servidores.']);
        $panelResult = json_decode($panelRaw,true);
        if (!is_array($panelResult) || empty($panelResult['success'])) {
            $error = is_array($panelResult) ? (string)($panelResult['error'] ?? '') : '';
            reply(409,['success'=>false,'error'=>$error!=='' ? $error : 'El panel rechazó el código de vinculación.']);
        }
        $channel = valid_channel($panelResult['channelId'] ?? '');
        $terminal = strtoupper(trim((string)($panelResult['terminalId'] ?? '')));
        if (!preg_match('/^[A-Z0-9_-]{1,120}$/',$terminal)) reply(409,['success'=>false,'error'=>'La identidad devuelta por el panel no es válida.']);
        $pdo = new PDO(
            'mysql:host='.$cfg['db_host'].';dbname='.$cfg['db_name'].';charset=utf8mb4',
            $cfg['db_user'], $cfg['db_pass'],
            [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES=>false]
        );
        $token = bin2hex(random_bytes(32));
        $pdo->beginTransaction();
        $pdo->prepare('INSERT IGNORE INTO pos_sync_channels(channel_id,latest_articles_json,last_updated,version) VALUES(?,NULL,0,1)')->execute([$channel]);
        $pdo->prepare('INSERT INTO pos_sync_tokens(token_hash,channel_id,terminal_id,can_read,can_write,active) VALUES(?,?,?,1,1,1)')->execute([hash('sha256',$token),$channel,$terminal]);
        $pdo->commit();
        reply(200,['success'=>true,'token'=>$token,'channelId'=>$channel,'terminalId'=>$terminal,
            'commerceName'=>(string)($panelResult['commerceName'] ?? ''),
            'terminalCode'=>(string)($panelResult['terminalCode'] ?? ''),
            'terminalLabel'=>(string)($panelResult['terminalLabel'] ?? '')]);
    }

    $channelCandidate = $_GET['channelId'] ?? ($body['channelId'] ?? '');
    $channel = valid_channel($channelCandidate);

    // Read-only endpoint for the QR customer display. It returns ONLY the latest
    // CUSTOMER_DISPLAY_SYNC state for the requested terminal, never the POS event log.
    // The QR display is intentionally view-only and must work on phones that do not
    // have the cashier terminal's private synchronization token in localStorage.
    if ($action === 'display-state') {
        $terminal = strtoupper(trim((string)($_GET['terminal'] ?? 'TERM-01')));
        if (preg_match('/^\d+$/', $terminal)) $terminal = 'TERM-' . str_pad($terminal, 2, '0', STR_PAD_LEFT);
        elseif (preg_match('/^TERM-(\d+)$/', $terminal, $m)) $terminal = 'TERM-' . str_pad($m[1], 2, '0', STR_PAD_LEFT);
        if ($terminal === '' || strlen($terminal) > 40 || !preg_match('/^[A-Z0-9_-]+$/', $terminal)) {
            reply(400, ['success'=>false,'error'=>'Terminal inválida']);
        }
        $displayPdo = new PDO(
            'mysql:host='.$cfg['db_host'].';dbname='.$cfg['db_name'].';charset=utf8mb4',
            $cfg['db_user'], $cfg['db_pass'],
            [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES=>false]
        );
        $st = $displayPdo->prepare('SELECT message_json FROM pos_sync_events WHERE channel_id=? ORDER BY seq DESC LIMIT 500');
        $st->execute([$channel]);
        while ($row = $st->fetch()) {
            $message = json_decode((string)$row['message_json'], true);
            if (!is_array($message) || ($message['type'] ?? '') !== 'CUSTOMER_DISPLAY_SYNC') continue;
            $payload = is_array($message['payload'] ?? null) ? $message['payload'] : [];
            $state = is_array($payload['state'] ?? null) ? $payload['state'] : $payload;
            $stateTerminal = strtoupper(trim((string)($state['terminalId'] ?? $payload['terminalId'] ?? '')));
            if (preg_match('/^\d+$/', $stateTerminal)) $stateTerminal = 'TERM-' . str_pad($stateTerminal, 2, '0', STR_PAD_LEFT);
            elseif (preg_match('/^TERM-(\d+)$/', $stateTerminal, $m)) $stateTerminal = 'TERM-' . str_pad($m[1], 2, '0', STR_PAD_LEFT);
            if ($stateTerminal !== $terminal || !isset($state['status'])) continue;
            reply(200, ['success'=>true, 'state'=>$state]);
        }
        reply(200, ['success'=>true, 'state'=>null]);
    }

    $provided = $_SERVER['HTTP_X_SYNC_TOKEN'] ?? '';
    if (!is_string($provided) || strlen($provided) < 32 || strlen($provided) > 256) {
        reply(401, ['success'=>false,'error'=>'Token ausente o inválido']);
    }
    $pdo = new PDO(
        'mysql:host='.$cfg['db_host'].';dbname='.$cfg['db_name'].';charset=utf8mb4',
        $cfg['db_user'], $cfg['db_pass'],
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES=>false]
    );
    $tokenHash = hash('sha256', $provided);
    $auth = $pdo->prepare('SELECT channel_id, terminal_id, can_read, can_write, active FROM pos_sync_tokens WHERE token_hash=? LIMIT 1');
    $auth->execute([$tokenHash]);
    $identity = $auth->fetch();
    if (!$identity || (int)$identity['active'] !== 1 || !hash_equals((string)$identity['channel_id'], $channel)) {
        reply(401, ['success'=>false,'error'=>'Token no autorizado para este canal']);
    }
    $writeActions = ['init-articles', 'publish', 'reset-demo'];
    if (in_array($action, $writeActions, true) && (int)$identity['can_write'] !== 1) {
        reply(403, ['success'=>false,'error'=>'El token no tiene permiso de escritura']);
    }
    if (in_array($action, ['state', 'poll'], true) && (int)$identity['can_read'] !== 1) {
        reply(403, ['success'=>false,'error'=>'El token no tiene permiso de lectura']);
    }

    if ($action === 'reset-demo') {
        $requestedResetChannel = valid_channel($body['channelId'] ?? '');
        if (!hash_equals((string)$identity['channel_id'], $requestedResetChannel)) {
            reply(403, ['success'=>false,'error'=>'El canal de restauración no coincide con el canal autorizado']);
        }
        $channel = $requestedResetChannel;
        if (!hash_equals('RESTAURAR DEMO', (string)($body['confirmation'] ?? ''))) {
            reply(400, ['success'=>false,'error'=>'Confirmación de restauración inválida']);
        }
        if (strtoupper((string)$identity['terminal_id']) !== 'TERM-01') {
            reply(403, ['success'=>false,'error'=>'Por seguridad, la restauración global solo puede iniciarse desde TERM-01']);
        }
        $articles = $body['articles'] ?? null;
        if (!is_array($articles) || count($articles) < 1 || count($articles) > 25000) {
            reply(400, ['success'=>false,'error'=>'Catálogo de demostración inválido']);
        }
        $catalogJson = json_encode($articles, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if ($catalogJson === false || strlen($catalogJson) > 5_000_000) {
            reply(413, ['success'=>false,'error'=>'Catálogo de demostración demasiado grande']);
        }
        $messageId = 'factory-reset-' . bin2hex(random_bytes(16));
        $now = (int)floor(microtime(true) * 1000);
        $message = [
            'id' => $messageId,
            'type' => 'SYSTEM_RESET',
            'senderTerminalId' => (string)$identity['terminal_id'],
            'senderClientId' => 'SERVER_FACTORY_RESET',
            'timestamp' => $now,
            'payload' => ['articles' => $articles, 'resetAt' => $now]
        ];
        $messageJson = json_encode($message, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if ($messageJson === false || strlen($messageJson) > 5_000_000) {
            reply(413, ['success'=>false,'error'=>'No se pudo preparar el evento de restauración']);
        }
        $pdo->beginTransaction();
        $pdo->prepare('INSERT IGNORE INTO pos_sync_channels(channel_id,latest_articles_json,last_updated,version) VALUES(?,NULL,0,1)')->execute([$channel]);
        $lock = $pdo->prepare('SELECT channel_id FROM pos_sync_channels WHERE channel_id=? FOR UPDATE');
        $lock->execute([$channel]);
        // El usuario confirmó que los datos previos eran de prueba: retirar eventos viejos
        // evita que una terminal desconectada los reproduzca después del reinicio.
        $pdo->prepare('DELETE FROM pos_sync_events WHERE channel_id=?')->execute([$channel]);
        $ins = $pdo->prepare('INSERT INTO pos_sync_events(channel_id,message_id,message_json) VALUES(?,?,?)');
        $ins->execute([$channel, $messageId, $messageJson]);
        $seq = (int)$pdo->lastInsertId();
        $pdo->prepare('UPDATE pos_sync_channels SET latest_articles_json=?,last_updated=?,latest_seq=?,version=version+1 WHERE channel_id=?')->execute([$catalogJson,$now,$seq,$channel]);
        $pdo->commit();
        reply(200, ['success'=>true,'seq'=>$seq,'message'=>'Restauración global publicada']);
    }

    if ($action === 'state') {
        $channel = valid_channel($_GET['channelId'] ?? '');
        $st = $pdo->prepare('SELECT latest_articles_json,last_updated,latest_seq FROM pos_sync_channels WHERE channel_id=?');
        $st->execute([$channel]); $row = $st->fetch();
        reply(200, ['success'=>true,'latestArticles'=>($row && $row['latest_articles_json']) ? json_decode($row['latest_articles_json'], true) : [],'lastUpdated'=>$row ? (int)$row['last_updated'] : 0,'latestSeq'=>$row ? (int)$row['latest_seq'] : 0]);
    }
    if ($action === 'poll') {
        $channel = valid_channel($_GET['channelId'] ?? '');
        $since = max(0, (int)($_GET['since'] ?? 0));
        $limit = min(200, max(1, (int)($_GET['limit'] ?? 100)));
        $st = $pdo->prepare('SELECT seq,message_json FROM pos_sync_events WHERE channel_id=? AND seq>? ORDER BY seq ASC LIMIT '.$limit);
        $st->execute([$channel,$since]); $events=[];
        while ($row=$st->fetch()) $events[]=['seq'=>(int)$row['seq'],'message'=>json_decode($row['message_json'],true)];
        $last = $since;
        if ($events) $last = (int)$events[count($events)-1]['seq'];
        reply(200,['success'=>true,'events'=>$events,'latestSeq'=>$last]);
    }
    if ($action === 'init-articles') {
        $channel = valid_channel($body['channelId'] ?? '');
        $articles = $body['articles'] ?? null;
        if (!is_array($articles) || count($articles) > 25000) reply(400,['success'=>false,'error'=>'Catálogo inválido o demasiado grande']);
        $json = json_encode($articles, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if ($json === false) reply(400,['success'=>false,'error'=>'No se pudo serializar el catálogo']);
        $pdo->beginTransaction();
        $pdo->prepare('INSERT IGNORE INTO pos_sync_channels(channel_id,latest_articles_json,last_updated,version) VALUES(?,NULL,0,1)')->execute([$channel]);
        // Only initialize an empty baseline. Two terminals can connect at the same time;
        // an unconditional upsert here lets the second terminal replace the first one's
        // freshly seeded catalog with its older local stock snapshot.
        $seedLock = $pdo->prepare('SELECT latest_articles_json,last_updated,latest_seq FROM pos_sync_channels WHERE channel_id=? FOR UPDATE');
        $seedLock->execute([$channel]);
        $seedRow = $seedLock->fetch();
        $seededNow = !$seedRow || !is_string($seedRow['latest_articles_json'] ?? null) || trim((string)$seedRow['latest_articles_json']) === '' || (string)$seedRow['latest_articles_json'] === 'null' || (string)$seedRow['latest_articles_json'] === '[]';
        if ($seededNow) {
            $now = (int)floor(microtime(true)*1000);
            $pdo->prepare('UPDATE pos_sync_channels SET latest_articles_json=?,last_updated=?,version=version+1 WHERE channel_id=?')->execute([$json,$now,$channel]);
            $seedArticles = $articles;
            $seedUpdated = $now;
        } else {
            $seedArticles = json_decode((string)$seedRow['latest_articles_json'], true);
            if (!is_array($seedArticles)) $seedArticles = $articles;
            $seedUpdated = (int)($seedRow['last_updated'] ?? 0);
        }
        $pdo->commit();
        $st=$pdo->prepare('SELECT latest_seq FROM pos_sync_channels WHERE channel_id=?'); $st->execute([$channel]);
        reply(200,['success'=>true,'latestArticles'=>$seedArticles,'lastUpdated'=>$seedUpdated,'latestSeq'=>(int)$st->fetchColumn()]);
    }
    if ($action === 'publish') {
        $channel = valid_channel($body['channelId'] ?? '');
        $message = $body['message'] ?? null;
        if (is_array($message)) {
            // Never trust a terminal identity supplied by browser payload.
            $message['senderTerminalId'] = (string)$identity['terminal_id'];
        }
        if (!is_array($message) || !is_string($message['id'] ?? null) || !preg_match('/^[a-zA-Z0-9_.:-]{1,190}$/',$message['id']) || !is_string($message['type'] ?? null)) reply(400,['success'=>false,'error'=>'Mensaje inválido']);
        $msgJson = json_encode($message, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if ($msgJson === false || strlen($msgJson) > 5_000_000) reply(413,['success'=>false,'error'=>'Mensaje demasiado grande']);
        $pdo->beginTransaction();
        $pdo->prepare('INSERT IGNORE INTO pos_sync_channels(channel_id,latest_articles_json,last_updated,version) VALUES(?,NULL,0,1)')->execute([$channel]);
        // Serialize every publish for this channel BEFORE assigning its event sequence.
        // Otherwise a later catalog snapshot could be committed before an earlier sale delta,
        // making the server baseline and clients' sequence-ordered replay disagree.
        $catalogLock = $pdo->prepare('SELECT latest_articles_json FROM pos_sync_channels WHERE channel_id=? FOR UPDATE');
        $catalogLock->execute([$channel]);
        $lockedCatalogRaw = $catalogLock->fetchColumn();

        // Ordinary catalog edits (price/name/barcode/etc.) must not roll stock back
        // to a stale terminal snapshot. Stock is changed through SALE/PURCHASE/STOCK_ADJUSTED
        // deltas; preserve the server's current stock for already-known article IDs.
        $typeBeforeInsert = (string)($message['type'] ?? '');
        $incomingCatalog = $message['payload']['articles'] ?? null;
        if (is_array($incomingCatalog) && in_array($typeBeforeInsert, ['ARTICLES_UPDATED', 'SYNC_RESPONSE_STATE'], true)) {
            $existingRaw = $lockedCatalogRaw;
            $existingCatalog = is_string($existingRaw) && $existingRaw !== '' ? json_decode($existingRaw, true) : null;
            if (is_array($existingCatalog)) {
                $stockById = [];
                foreach ($existingCatalog as $existingArticle) {
                    if (is_array($existingArticle) && isset($existingArticle['id'])) {
                        $stockById[(string)$existingArticle['id']] = $existingArticle['stock'] ?? 0;
                    }
                }
                // Explicit stock overrides are allowed only on catalog-import events.
                // All other catalog publishes keep the server's authoritative stock.
                $stockOverrides = [];
                if (($message['payload']['reason'] ?? '') === 'catalog-import'
                    && is_array($message['payload']['stockOverrides'] ?? null)
                    && count($message['payload']['stockOverrides']) <= 10000) {
                    foreach ($message['payload']['stockOverrides'] as $override) {
                        if (!is_array($override) || !isset($override['articleId'], $override['stock'])) continue;
                        $overrideId = (string)$override['articleId'];
                        $overrideStock = $override['stock'];
                        if ($overrideId === '' || !is_numeric($overrideStock) || !is_finite((float)$overrideStock)) continue;
                        $stockOverrides[$overrideId] = max(0, (float)$overrideStock);
                    }
                }
                foreach ($incomingCatalog as &$incomingArticle) {
                    if (!is_array($incomingArticle) || !isset($incomingArticle['id'])) continue;
                    $articleId = (string)$incomingArticle['id'];
                    if (array_key_exists($articleId, $stockOverrides)) {
                        $incomingArticle['stock'] = $stockOverrides[$articleId];
                    } elseif (array_key_exists($articleId, $stockById)) {
                        $incomingArticle['stock'] = $stockById[$articleId];
                    }
                }
                unset($incomingArticle);
                $message['payload']['articles'] = $incomingCatalog;
                $msgJson = json_encode($message, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
                if ($msgJson === false || strlen($msgJson) > 5_000_000) {
                    throw new RuntimeException('Mensaje de catálogo demasiado grande tras reconciliar stock');
                }
            }
        }

        $ins=$pdo->prepare('INSERT IGNORE INTO pos_sync_events(channel_id,message_id,message_json) VALUES(?,?,?)');
        $ins->execute([$channel,$message['id'],$msgJson]);
        $inserted = $ins->rowCount() === 1;
        $seq=(int)$pdo->lastInsertId();
        if (!$inserted) {
            // Idempotency: an acknowledgement retry must never reapply a stale catalog snapshot.
            $q=$pdo->prepare('SELECT seq FROM pos_sync_events WHERE channel_id=? AND message_id=?');
            $q->execute([$channel,$message['id']]);
            $seq=(int)$q->fetchColumn();
            $pdo->commit();
            reply(200,['success'=>true,'seq'=>$seq,'duplicate'=>true]);
        }
        // Keep the server-side baseline current. Apply stock deltas exactly once (only
        // after the idempotent event insert succeeds), so a newly connected terminal does
        // not receive a catalog whose stock predates sales/purchases.
        $type = (string)($message['type'] ?? '');
        $articles = $message['payload']['articles'] ?? null;
        if (!is_array($articles) && $type === 'ARTICLES_UPDATED' && is_array($message['payload']['updatedArticles'] ?? null)) {
            $articles = $message['payload']['updatedArticles'];
        }
        $now = (int)floor(microtime(true) * 1000);
        if (is_array($articles) && in_array($type, ['ARTICLES_UPDATED','SYSTEM_RESTORE','SYNC_RESPONSE_STATE'], true)) {
            $catalogJson = json_encode($articles, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
            if ($catalogJson === false) throw new RuntimeException('No se pudo serializar el catálogo');
            $pdo->prepare('UPDATE pos_sync_channels SET latest_articles_json=?,last_updated=?,latest_seq=GREATEST(latest_seq,?),version=version+1 WHERE channel_id=?')->execute([$catalogJson,$now,$seq,$channel]);
        } else {
            $deltas = $message['payload']['stockDeltas'] ?? null;
            if (in_array($type, ['SALE_PROCESSED','PURCHASE_REGISTERED','STOCK_ADJUSTED'], true) && is_array($deltas) && count($deltas) <= 5000) {
                // The channel row is already locked before event insertion, so stock deltas
                // are applied in the same order that poll() exposes their sequence numbers.
                $catalogRaw = $lockedCatalogRaw;
                if (is_string($catalogRaw) && $catalogRaw !== '') {
                    $catalog = json_decode($catalogRaw, true);
                    if (is_array($catalog)) {
                        $index = [];
                        foreach ($catalog as $i => $article) {
                            if (is_array($article) && isset($article['id'])) $index[(string)$article['id']] = $i;
                        }
                        foreach ($deltas as $delta) {
                            if (!is_array($delta) || !isset($delta['articleId'], $delta['quantityDelta'])) continue;
                            $id = (string)$delta['articleId'];
                            $amount = (float)$delta['quantityDelta'];
                            if (!is_finite($amount) || !isset($index[$id])) continue;
                            $i = $index[$id];
                            $oldStock = isset($catalog[$i]['stock']) && is_numeric($catalog[$i]['stock']) ? (float)$catalog[$i]['stock'] : 0.0;
                            $catalog[$i]['stock'] = max(0, $oldStock + $amount);
                        }
                        $catalogJson = json_encode($catalog, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
                        if ($catalogJson !== false) {
                            $pdo->prepare('UPDATE pos_sync_channels SET latest_articles_json=?,last_updated=?,latest_seq=GREATEST(latest_seq,?),version=version+1 WHERE channel_id=?')->execute([$catalogJson,$now,$seq,$channel]);
                        } else {
                            $pdo->prepare('UPDATE pos_sync_channels SET latest_seq=GREATEST(latest_seq,?),version=version+1 WHERE channel_id=?')->execute([$seq,$channel]);
                        }
                    } else {
                        $pdo->prepare('UPDATE pos_sync_channels SET latest_seq=GREATEST(latest_seq,?),version=version+1 WHERE channel_id=?')->execute([$seq,$channel]);
                    }
                } else {
                    $pdo->prepare('UPDATE pos_sync_channels SET latest_seq=GREATEST(latest_seq,?),version=version+1 WHERE channel_id=?')->execute([$seq,$channel]);
                }
            } else {
                $pdo->prepare('UPDATE pos_sync_channels SET latest_seq=GREATEST(latest_seq,?),version=version+1 WHERE channel_id=?')->execute([$seq,$channel]);
            }
        }
        $pdo->commit();
        reply(200,['success'=>true,'seq'=>$seq]);
    }
    reply(404,['success'=>false,'error'=>'Acción no encontrada']);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
    error_log('POS sync API error: '.$e->getMessage());
    reply(500,['success'=>false,'error'=>'Error interno de sincronización']);
}
