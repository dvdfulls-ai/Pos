SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS pos_sync_channels (
  channel_id VARCHAR(120) NOT NULL,
  latest_articles_json LONGTEXT NULL,
  version BIGINT UNSIGNED NOT NULL DEFAULT 1,
  last_updated BIGINT NOT NULL DEFAULT 0,
  latest_seq BIGINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (channel_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS pos_sync_events (
  seq BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  channel_id VARCHAR(120) NOT NULL,
  message_id VARCHAR(190) NOT NULL,
  message_json LONGTEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (seq),
  UNIQUE KEY uq_channel_message (channel_id, message_id),
  KEY ix_channel_seq (channel_id, seq),
  KEY ix_created_at (created_at),
  CONSTRAINT fk_pos_sync_events_channel FOREIGN KEY (channel_id)
    REFERENCES pos_sync_channels(channel_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tokens revocables por terminal. Insertar SHA-256 del token, nunca el token plano.
CREATE TABLE IF NOT EXISTS pos_sync_tokens (
  token_hash CHAR(64) NOT NULL,
  channel_id VARCHAR(120) NOT NULL,
  terminal_id VARCHAR(80) NOT NULL,
  can_read TINYINT(1) NOT NULL DEFAULT 1,
  can_write TINYINT(1) NOT NULL DEFAULT 1,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_used_at DATETIME NULL,
  PRIMARY KEY (token_hash),
  KEY ix_pos_sync_tokens_channel (channel_id, active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
