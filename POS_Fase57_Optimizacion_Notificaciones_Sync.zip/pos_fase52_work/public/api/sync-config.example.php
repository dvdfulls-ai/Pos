<?php
// Copie este archivo como sync-config.php y complete los valores en el servidor.
// Guarde sync-config.php fuera del acceso público cuando el hosting lo permita.
return [
    'db_host' => 'localhost',
    'db_name' => 'CAMBIAR_NOMBRE_COMPLETO_BASE',
    'db_user' => 'CAMBIAR_USUARIO_COMPLETO',
    'db_pass' => 'CAMBIAR_CONTRASENA',
    // URL pública del endpoint de vinculación del panel multi-comercio.
    'pairing_panel_url' => 'https://panelpos.novamedia.com.ar/api/pairing-redeem.php',
    // Debe ser EXACTAMENTE igual al pairing_shared_secret del panel.
    'pairing_shared_secret' => 'REEMPLAZAR_POR_EL_MISMO_SECRETO_ALEATORIO_LARGO_EN_AMBOS_SERVIDORES',
];
