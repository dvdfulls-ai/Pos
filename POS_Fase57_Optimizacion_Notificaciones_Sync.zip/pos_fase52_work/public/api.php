<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$action = isset($_GET['action']) ? $_GET['action'] : '';
$rawBody = file_get_contents('php://input');
$body = json_decode($rawBody, true) ?: [];

function makeRequest($url, $method = 'GET', $headers = [], $data = null) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);

    if (!empty($headers)) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }

    if ($data !== null) {
        $jsonData = is_string($data) ? $data : json_encode($data);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
    }

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);

    return [
        'code' => $httpCode,
        'body' => $response,
        'error' => $err
    ];
}

// 1. VERIFY CREDENTIALS
if ($action === 'verify') {
    $token = trim($body['accessToken'] ?? '');
    if (!$token) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Access Token no proporcionado']);
        exit;
    }

    $userRes = makeRequest('https://api.mercadopago.com/users/me', 'GET', [
        "Authorization: Bearer $token"
    ]);

    if ($userRes['code'] < 200 || $userRes['code'] >= 300) {
        http_response_code($userRes['code'] ?: 400);
        $data = json_decode($userRes['body'], true);
        echo json_encode([
            'success' => false, 
            'error' => $data['message'] ?? 'Token de Mercado Pago inválido o revocado'
        ]);
        exit;
    }

    $userData = json_decode($userRes['body'], true);

    // List of POS
    $posRes = makeRequest('https://api.mercadopago.com/pos', 'GET', [
        "Authorization: Bearer $token"
    ]);
    $posList = [];
    if ($posRes['code'] >= 200 && $posRes['code'] < 300) {
        $posData = json_decode($posRes['body'], true);
        $posList = $posData['results'] ?? [];
    }

    $posListResult = [];
    foreach ($posList as $p) {
        $pId = $p['id'] ?? 0;
        $qrObj = $p['qr'] ?? ($p['qr_response'] ?? []);
        $qrImage = $qrObj['image'] ?? ($qrObj['template_image'] ?? ($qrObj['template_document'] ?? ''));
        $qrData = $qrObj['qr_code'] ?? ($qrObj['qr_number'] ?? ($qrObj['uuid'] ?? ''));

        // Intentar obtener detalles del QR de la caja vía API v2 y v1 si no vinieron en la lista
        if ((!$qrImage || !$qrData) && $pId) {
            $endpoints = [
                "https://api.mercadopago.com/v2/pos/$pId",
                "https://api.mercadopago.com/pos/$pId",
            ];
            if (!empty($p['external_id'])) {
                $extId = urlencode($p['external_id']);
                $endpoints[] = "https://api.mercadopago.com/pos?external_id=$extId";
                $endpoints[] = "https://api.mercadopago.com/v2/pos?external_id=$extId";
            }
            if (!empty($userData['id']) && !empty($p['store_id'])) {
                $uId = $userData['id'];
                $sId = $p['store_id'];
                $endpoints[] = "https://api.mercadopago.com/users/$uId/stores/$sId/pos/$pId";
            }

            foreach ($endpoints as $ep) {
                $detRes = makeRequest($ep, 'GET', [
                    "Authorization: Bearer $token"
                ]);
                if ($detRes['code'] >= 200 && $detRes['code'] < 300) {
                    $detData = json_decode($detRes['body'], true);
                    // Si devolvió lista en results:
                    $item = isset($detData['results'][0]) ? $detData['results'][0] : $detData;
                    $dQr = $item['qr_response'] ?? ($item['qr'] ?? []);
                    if (!$qrImage) $qrImage = $dQr['image'] ?? ($dQr['template_image'] ?? ($dQr['template_document'] ?? ''));
                    if (!$qrData) $qrData = $dQr['qr_code'] ?? ($dQr['qr_number'] ?? ($dQr['uuid'] ?? ''));
                    if ($qrImage && $qrData) break;
                }
            }
        }

        $pExt = $p['external_id'] ?? '';
        if (empty($pExt) && !empty($pId)) {
            $assignRes = makeRequest("https://api.mercadopago.com/pos/$pId", 'PUT', [
                "Authorization: Bearer $token",
                'Content-Type: application/json'
            ], [
                'external_id' => strval($pId)
            ]);
            if ($assignRes['code'] >= 200 && $assignRes['code'] < 300) {
                $pExt = strval($pId);
            } else {
                $assignV2Res = makeRequest("https://api.mercadopago.com/v2/pos/$pId", 'PUT', [
                    "Authorization: Bearer $token",
                    'Content-Type: application/json'
                ], [
                    'external_id' => strval($pId)
                ]);
                if ($assignV2Res['code'] >= 200 && $assignV2Res['code'] < 300) {
                    $pExt = strval($pId);
                }
            }
        }

        $posListResult[] = [
            'id' => $pId,
            'name' => $p['name'] ?? '',
            'externalId' => $pExt,
            'storeId' => $p['store_id'] ?? '',
            'qrImage' => $qrImage,
            'qrData' => $qrData
        ];
    }

    echo json_encode([
        'success' => true,
        'user' => [
            'id' => $userData['id'] ?? 0,
            'nickname' => $userData['nickname'] ?? '',
            'email' => $userData['email'] ?? '',
            'firstName' => $userData['first_name'] ?? '',
            'lastName' => $userData['last_name'] ?? '',
        ],
        'posList' => $posListResult
    ]);
    exit;
}

// 2. CREATE IN-STORE ORDER
if ($action === 'create-order') {
    $token = trim($body['accessToken'] ?? '');
    $userId = trim((string)($body['userId'] ?? ''));
    $posId = trim((string)($body['posId'] ?? ''));
    $externalReference = $body['externalReference'] ?? ('POS-' . round(microtime(true) * 1000));
    $total = floatval($body['total'] ?? 0);

    if (!$token || !$userId || !$posId) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Faltan parámetros requeridos (token, userId, posId)']);
        exit;
    }

    $roundedTotal = round($total, 2);

    $finalItems = [
        [
            'sku_number' => 'VENTA-POS',
            'category' => 'marketplace',
            'title' => $body['title'] ?? 'Venta en Mostrador POS',
            'description' => 'Compra en mostrador',
            'unit_price' => $roundedTotal,
            'quantity' => 1,
            'unit_measure' => 'unit',
            'total_amount' => $roundedTotal
        ]
    ];

    $orderPayload = [
        'external_reference' => $externalReference,
        'title' => $body['title'] ?? 'Venta en Caja POS',
        'description' => 'Compra en mostrador',
        'total_amount' => $roundedTotal,
        'items' => $finalItems
    ];

    // Intento 1: Llamada directa con el posId suministrado
    $url = "https://api.mercadopago.com/instore/qr/seller/collectors/$userId/pos/" . urlencode($posId) . "/orders";
    $res = makeRequest($url, 'PUT', [
        "Authorization: Bearer $token",
        'Content-Type: application/json'
    ], $orderPayload);

    if ($res['code'] >= 200 && $res['code'] < 300) {
        echo json_encode([
            'success' => true,
            'externalReference' => $externalReference,
            'total' => $roundedTotal,
            'status' => 'opened',
            'usedPosId' => $posId
        ]);
        exit;
    }

    // Si falló (ej: 404 o 400), buscar en la lista de POS del usuario en Mercado Pago
    // para resolver si la caja usa su external_id o id numérico
    $posRes = makeRequest('https://api.mercadopago.com/pos', 'GET', [
        "Authorization: Bearer $token"
    ]);

    if ($posRes['code'] >= 200 && $posRes['code'] < 300) {
        $posData = json_decode($posRes['body'], true);
        $posList = $posData['results'] ?? [];

        $matchedPos = null;
        foreach ($posList as $p) {
            $pId = strval($p['id'] ?? '');
            $pExt = strval($p['external_id'] ?? '');
            $pName = strtolower(trim($p['name'] ?? ''));

            if ($pId === $posId || $pExt === $posId || $pName === strtolower(trim($posId))) {
                $matchedPos = $p;
                break;
            }
        }

        if ($matchedPos) {
            $pId = strval($matchedPos['id'] ?? '');
            $pExt = strval($matchedPos['external_id'] ?? '');
            $storeId = strval($matchedPos['store_id'] ?? '');

            // Si la caja no tiene external_id asignado en Mercado Pago, asignarle su ID numérico
            if (empty($pExt) && !empty($pId)) {
                $assignRes = makeRequest("https://api.mercadopago.com/pos/$pId", 'PUT', [
                    "Authorization: Bearer $token",
                    'Content-Type: application/json'
                ], [
                    'external_id' => $pId
                ]);
                if ($assignRes['code'] >= 200 && $assignRes['code'] < 300) {
                    $pExt = $pId;
                } else {
                    $assignV2Res = makeRequest("https://api.mercadopago.com/v2/pos/$pId", 'PUT', [
                        "Authorization: Bearer $token",
                        'Content-Type: application/json'
                    ], [
                        'external_id' => $pId
                    ]);
                    if ($assignV2Res['code'] >= 200 && $assignV2Res['code'] < 300) {
                        $pExt = $pId;
                    }
                }
            }

            // Candidatos estrictos para ESTA caja (NUNCA incluir 'default' a menos que esta caja sea explícitamente default)
            $isExplicitlyDefault = ($posId === 'default' || $pExt === 'default' || (isset($matchedPos['name']) && strtolower(trim($matchedPos['name'])) === 'qr #01'));
            $candidates = array_unique(array_filter([
                $pExt ?: null,
                $pId ?: null,
                $isExplicitlyDefault ? 'default' : null
            ]));

            // Averiguar external_id de la sucursal/store si tiene
            $storeCandidates = array_filter([$storeId]);
            if (!empty($storeId)) {
                $stRes = makeRequest("https://api.mercadopago.com/users/$userId/stores/$storeId", 'GET', [
                    "Authorization: Bearer $token"
                ]);
                if ($stRes['code'] >= 200 && $stRes['code'] < 300) {
                    $stData = json_decode($stRes['body'], true);
                    if (!empty($stData['external_id'])) {
                        $storeCandidates[] = $stData['external_id'];
                    }
                }
            }

            $lastErr = null;
            foreach ($candidates as $cand) {
                $tryUrls = [
                    "https://api.mercadopago.com/instore/qr/seller/collectors/$userId/pos/" . urlencode($cand) . "/orders"
                ];

                foreach ($storeCandidates as $stCand) {
                    $tryUrls[] = "https://api.mercadopago.com/instore/qr/seller/collectors/$userId/stores/" . urlencode($stCand) . "/pos/" . urlencode($cand) . "/orders";
                }

                foreach ($tryUrls as $retryUrl) {
                    $retryRes = makeRequest($retryUrl, 'PUT', [
                        "Authorization: Bearer $token",
                        'Content-Type: application/json'
                    ], $orderPayload);

                    if ($retryRes['code'] >= 200 && $retryRes['code'] < 300) {
                        echo json_encode([
                            'success' => true,
                            'externalReference' => $externalReference,
                            'total' => $roundedTotal,
                            'status' => 'opened',
                            'usedPosId' => $cand,
                            'resolvedFrom' => $posId
                        ]);
                        exit;
                    } else {
                        $lastErr = $retryRes;
                    }
                }
            }

            if ($lastErr) {
                $res = $lastErr;
            }
        }
    }

    http_response_code($res['code'] ?: 400);
    $errData = json_decode($res['body'], true);
    echo json_encode([
        'success' => false,
        'error' => $errData['message'] ?? ($errData['error'] ?? 'No se pudo crear la orden en Mercado Pago'),
        'details' => $errData
    ]);
    exit;
}

// 3. CHECK ORDER
if ($action === 'check-order') {
    $token = trim($_GET['accessToken'] ?? ($body['accessToken'] ?? ''));
    $externalReference = trim($_GET['externalReference'] ?? ($body['externalReference'] ?? ''));

    if (!$token || !$externalReference) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Parámetros requeridos']);
        exit;
    }

    $searchRes = makeRequest(
        "https://api.mercadopago.com/merchant_orders/search?external_reference=" . urlencode($externalReference),
        'GET',
        ["Authorization: Bearer $token"]
    );

    if ($searchRes['code'] >= 200 && $searchRes['code'] < 300) {
        $data = json_decode($searchRes['body'], true);
        $orders = $data['elements'] ?? [];
        foreach ($orders as $ord) {
            if (($ord['order_status'] ?? '') === 'paid' || ($ord['status'] ?? '') === 'closed') {
                $paymentId = $ord['id'] ?? '';
                foreach ($ord['payments'] ?? [] as $p) {
                    if (($p['status'] ?? '') === 'approved') {
                        $paymentId = $p['id'];
                        break;
                    }
                }
                echo json_encode([
                    'success' => true,
                    'paid' => true,
                    'paymentId' => $paymentId,
                    'status' => 'approved',
                    'amount' => $ord['total_amount'] ?? 0
                ]);
                exit;
            }
        }
    }

    // Direct payments search fallback
    $payRes = makeRequest(
        "https://api.mercadopago.com/v1/payments/search?external_reference=" . urlencode($externalReference),
        'GET',
        ["Authorization: Bearer $token"]
    );

    if ($payRes['code'] >= 200 && $payRes['code'] < 300) {
        $pData = json_decode($payRes['body'], true);
        foreach ($pData['results'] ?? [] as $p) {
            if (($p['status'] ?? '') === 'approved') {
                echo json_encode([
                    'success' => true,
                    'paid' => true,
                    'paymentId' => $p['id'],
                    'status' => 'approved',
                    'amount' => $p['transaction_amount'] ?? 0
                ]);
                exit;
            }
        }
    }

    echo json_encode([
        'success' => true,
        'paid' => false,
        'status' => 'pending'
    ]);
    exit;
}

// 4. DELETE ORDER
if ($action === 'delete-order') {
    $token = trim($body['accessToken'] ?? '');
    $userId = $body['userId'] ?? '';
    $posId = trim((string)($body['posId'] ?? ''));

    if ($token && $userId && $posId) {
        makeRequest("https://api.mercadopago.com/instore/qr/seller/collectors/$userId/pos/$posId/orders", 'DELETE', [
            "Authorization: Bearer $token"
        ]);
    }
    echo json_encode(['success' => true]);
    exit;
}

echo json_encode(['success' => false, 'error' => 'Acción no reconocida']);
