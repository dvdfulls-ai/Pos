# Revisión 9 — Corrección de diferencias de stock entre terminales

## Cambios
- La API PHP bloquea la fila del canal antes de insertar el evento, serializando las publicaciones por canal para que el orden de los números de secuencia coincida con el orden en que se aplican los cambios de stock.
- Los mensajes `ARTICLES_UPDATED` y `SYNC_RESPONSE_STATE` conservan el stock actual del servidor para artículos existentes; una edición de precio/nombre u otros datos no restaura cantidades antiguas de una terminal.
- Los eventos de venta y compra se aplican preferentemente como `stockDeltas`, incluso si un mensaje también contiene una copia completa del catálogo.
- La búsqueda del artículo al aplicar diferencias compara los identificadores como texto, evitando fallos si una terminal tiene el ID como número y otra como cadena.

## Validación
- `php -l public/api/sync.php`: sin errores de sintaxis.
- No se pudo completar `npm install` en el entorno de preparación porque agotó el tiempo de espera; ejecutar `npm install` y `npm run build` en el equipo antes de publicar.

## Publicación
- Compilar y subir el contenido de `dist`.
- Reemplazar `public/api/sync.php` con el archivo de esta revisión.
- Conservar `public/api/sync-config.php` y los tokens actuales.
