# Optimización del Historial — Fase 21

## Objetivo

Hacer que la exportación CSV del Historial use menos memoria temporal y mantenga columnas correctas cuando los textos incluyen comas, comillas o saltos de línea.

## Cambios

- Sustituye la URI `data:` y su copia codificada por un `Blob` y una URL temporal.
- Construye el CSV en bloques de hasta 500 registros para no crear simultáneamente un arreglo de todas las filas completas.
- Escapa correctamente todos los campos CSV (comillas, comas y saltos de línea).
- Incluye BOM UTF-8 para mejorar la apertura de acentos en hojas de cálculo.
- Mantiene el mismo nombre de archivo, columnas, registros filtrados y formato de fecha/hora.

## Seguridad y alcance

- Solo cambia la exportación del Historial.
- No escribe en `localStorage` ni IndexedDB.
- No modifica ventas, stock, cajas, cuentas corrientes, colas, cursores, API ni vinculación de terminales.
- La descarga sigue incluyendo todos los registros que coinciden con los filtros, no solamente las primeras 100 filas visibles.

## Verificación realizada

- Revisión de sintaxis TSX mediante TypeScript `transpileModule` (sin diagnósticos sintácticos).
- Integridad del ZIP comprobada.
- No se ejecutó una compilación integral ni pruebas en navegador en este entorno; deben verificarse al integrar el código fuente.
