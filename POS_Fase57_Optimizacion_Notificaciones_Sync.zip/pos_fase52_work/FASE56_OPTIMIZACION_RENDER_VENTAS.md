# Fase 56 — Aislamiento de renderizados de Ventas

## Objetivo
Reducir renderizados innecesarios de la pantalla de Ventas en equipos con catálogos grandes, sin desactivar operaciones ni cambiar el almacenamiento.

## Cambios
- Se agregó un contexto específico para los datos que consume `SalesModule`.
- Las acciones expuestas por ese contexto mantienen referencias estables y delegan en las funciones vigentes del proveedor.
- `SalesModule` ahora consume el contexto específico y está envuelto en `React.memo`, para que actualizaciones ajenas a Ventas (por ejemplo, cambios de conectividad o estado de sincronización) no lo vuelvan a renderizar por el contexto general.
- Las actualizaciones relevantes para Ventas siguen propagándose: artículos, carrito, total, turno de caja, cuentas, terminal y ventas.
- Se conserva el contexto general `useApp` para el resto del programa y para evitar una migración masiva de módulos en esta fase.

## Datos y funciones que no se modificaron
- No se modificó `StorageService`, IndexedDB ni la persistencia de artículos/stock.
- No se modificó la lógica de registrar ventas, descontar stock, guardar auditorías ni sincronizar terminales.
- No se modificaron PHP, SQL, configuración del servidor ni producción.
- Se mantiene el ocultamiento visual del Historial incorporado en Fase 55; el registro de ventas y auditorías sigue activo.

## Verificación
- Se verificó la transpilación/sintaxis TypeScript de `AppContext.tsx` y `SalesModule.tsx` sin errores de sintaxis.
- No se pudo ejecutar `npm run build` ni el chequeo completo de tipos porque el ZIP no incluye `node_modules` y las dependencias no están disponibles en la caché local.
- No se realizó una medición real de CPU en una PC del comercio. La reducción debe comprobarse en DEV comparando el Administrador de tareas antes y después.

## Prueba recomendada
1. Instalar esta fase únicamente en DEV y en una terminal de prueba.
2. Abrir Ventas y dejar el POS quieto durante 2 minutos; observar CPU.
3. Cambiar entre Artículos, Compras y Ventas; observar si hay picos prolongados.
4. Registrar ventas de prueba y comprobar que el stock se descuente, persista al cerrar/abrir y se sincronice con la segunda terminal.
5. Confirmar que las auditorías y el historial de ventas continúan registrándose aunque su pantalla siga oculta.

No borrar datos del navegador ni de IndexedDB para realizar esta prueba.
