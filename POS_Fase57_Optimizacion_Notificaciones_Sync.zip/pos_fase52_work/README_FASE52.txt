FASE 52 - Corrección puntual de conexión

Partir de esta carpeta como proyecto completo. Cambios respecto de Fase 51:
1) src/services/network.ts
2) src/services/cloudSync.ts

No reemplazar ni modificar archivos PHP del servidor. Antes de publicar, conservar un respaldo del proyecto y comprobar que no haya operaciones pendientes de sincronización.
