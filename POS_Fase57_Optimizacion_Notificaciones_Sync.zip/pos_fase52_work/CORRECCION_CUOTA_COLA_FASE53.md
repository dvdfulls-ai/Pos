# Fase 53 — Cola VPS fuera de localStorage

## Causa
El error `QuotaExceededError` identifica una clave específica: `pos_vps_pending_queue_v1_<canal>`. La versión recibida guardaba el JSON entero de la cola de sincronización en `localStorage`. Esto consume el límite reducido de almacenamiento web al acumular eventos pendientes o snapshots, especialmente al importar catálogos o vender con la conexión interrumpida. La compactación previa solo elimina snapshots reemplazables; conserva ventas, compras y movimientos, por lo que no resuelve una cola de operaciones críticas grande.

## Cambio
- La cola de reintentos del relay VPS se almacena ahora en IndexedDB, con un registro por mensaje y acceso por canal.
- Las publicaciones se agregan en una transacción IndexedDB; al confirmar el servidor, se elimina solo el mensaje confirmado, preservando los pendientes restantes.
- Las colas `pos_vps_pending_queue_v1_*` existentes se migran una sola vez a IndexedDB, conservando el identificador de canal. La clave anterior se borra únicamente después de confirmar la transacción; una cola malformada se deja intacta.
- Los catálogos completos siguen guardándose en el POS y se materializan al publicar; no se duplican en cada mensaje de la cola.
- Se mantiene la compactación de snapshots reemplazables, sin descartar operaciones financieras/stock.

## Alcance y cautelas
IndexedDB ofrece una cuota mucho mayor que localStorage, pero no es ilimitado: depende del navegador, del espacio libre y de las políticas del dispositivo. La aplicación tampoco puede garantizar la entrega de una venta si el almacenamiento del navegador se niega por completo a guardar. No se borran operaciones pendientes como recuperación automática. Verificar el build y hacer una prueba real de desconexión/reconexión, ventas y restauración de catálogo antes de desplegar.
