# Fase 23 — búsqueda priorizada en Historial

## Objetivo
Mantener el campo de búsqueda receptivo cuando el historial contiene muchos registros.

## Cambio
- Usa `useDeferredValue` de React para que el filtrado de Historial pueda ejecutarse con prioridad menor que la escritura en el campo de búsqueda.
- El texto del input se actualiza de inmediato; los resultados pueden actualizarse unos instantes después mientras React procesa el filtro.
- Los filtros de tipo, usuario y fecha, la búsqueda por nombre/código de barras y el detalle de registros se mantienen.
- No cambia datos persistidos, APIs, colas, cursores, tokens ni reglas de sincronización.

## Validación pendiente
Es un cambio acotado de interfaz. Debe compilarse con el proyecto completo y probarse con búsqueda por ticket, artículo y código de barras. No se ha podido ejecutar una compilación completa ni una prueba de navegador en este entorno.
