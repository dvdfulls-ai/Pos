# Correcciones puntuales — Fase 28

Se aplican únicamente dos ajustes solicitados:

1. **Foco del comprobante de venta:** cuando se abre la ventana flotante del ticket, el foco de teclado pasa al botón «Listo / Nueva Venta». Así Enter se procesa como la acción de ese botón y no queda dirigido al campo de búsqueda/barcode que está detrás. La lógica existente del botón y el atajo Enter se conservan.
2. **Botones de Preparación segura para IndexedDB:** se separa el encabezado del grupo de acciones y los botones ahora se distribuyen con `flex-wrap`, pudiendo ocupar varias filas según el ancho disponible para no salirse de la pantalla.

No se cambiaron el servidor, la base de datos, la sincronización, las reglas de ventas, stock ni el contenido de almacenamiento.

## Pruebas recomendadas

- Finalizar una venta y comprobar que el foco quede en «Listo / Nueva Venta»; pulsar Enter una vez y verificar que vuelva a Nueva Venta.
- Entrar en Configuración y comprobar que todos los botones de «Preparación segura para IndexedDB» queden dentro del panel, también con una ventana estrecha.

La verificación de sintaxis no sustituye la prueba funcional en el navegador.
