# Fase 54 — Optimización de CPU, historial y lecturas de movimientos

Base: `POS_Fase53_Persistencia_Durable_Articulos_Stock_IndexedDB.zip`.

## Cambios

- El historial construye únicamente las categorías solicitadas por la pestaña activa.
- Los filtros Hoy / Últimos 7 días descartan registros antes de crear los objetos de presentación.
- Las búsquedas y el paginado existente se conservan; se siguen mostrando 100 registros por página y el resto permanece disponible.
- Se eliminó la creación de un segundo arreglo auxiliar para ordenar el historial; las fechas se convierten a milisegundos una vez por registro y se reutilizan al ordenar.
- Se agregó caché de arrays de ventas, compras y auditoría asociada al texto exacto guardado. Si una sincronización, importación o restauración cambia el valor de localStorage, la comparación del texto invalida automáticamente la caché y vuelve a leer el dato actualizado.
- Las altas locales y remotas crean nuevas referencias de arrays para que React actualice correctamente la interfaz.
- El polling VPS pasa de 2,5 a 4 segundos, con backoff ante errores y un intervalo mayor en pestañas ocultas. Se mantiene una sola solicitud de polling simultánea.
- No se limita ni elimina el historial de ventas, compras o movimientos financieros. La auditoría conserva su límite preexistente de 500 entradas.
- No se cambia PHP, SQL, tablas, claves de negocio ni el formato de los respaldos.

## Alcance y limitaciones conocidas

Esta fase reduce reconstrucciones, ordenamientos y parseos repetidos. No elimina todavía el costo de serializar el snapshot completo `pos_sales_v1` en cada venta, porque cambiar ese mecanismo requiere una migración transaccional del libro de ventas a IndexedDB y adaptar la lectura inicial y el flujo de confirmación de venta. No se debe afirmar que esta fase elimina por completo el consumo de CPU hasta medirla con el volumen real del comercio.

## Validaciones realizadas

- Sintaxis TypeScript/TSX de `HistoryModule.tsx`, `storage.ts` y `cloudSync.ts`: sin errores de transpilación sintáctica.
- Integridad del ZIP de entrada y del ZIP de salida: verificada.
- No se ejecutó el build completo de Vite ni pruebas con navegador/servidor porque el proyecto no incluye `node_modules` ni conexión al entorno DEV en este entorno.

## Pruebas en DEV

1. Abrir Historial en la pestaña Ventas y luego en Auditoría; verificar que los filtros y el detalle (ojito) sigan funcionando.
2. Registrar varias ventas y observar el Administrador de tareas de Windows: el uso de CPU debe volver a niveles normales después de cada operación.
3. Abrir Historial, cambiar filtros y buscar artículos; comprobar que no se pierdan registros.
4. Probar sincronización entre TERM-01 y TERM-02 durante ventas; la latencia puede aumentar ligeramente por el polling de 4 segundos.
5. Reiniciar ambas terminales y comprobar que ventas y auditoría siguen presentes.

No limpiar IndexedDB ni localStorage. Probar primero en DEV y no reemplazar producción con esta fase sin validar.
