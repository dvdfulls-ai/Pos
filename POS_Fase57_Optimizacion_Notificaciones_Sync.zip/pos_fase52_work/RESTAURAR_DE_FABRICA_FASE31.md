# Fase 31 — Restaurar de fábrica en todas las terminales

## Alcance

Agrega en **Configuración → Nube, Hosting y Modo Offline** una zona roja de restauración coordinada. El proceso requiere Internet, permiso `canManageSettings`, estar en `TERM-01` y confirmar dos veces (confirmación del navegador y frase `RESTAURAR DEMO`).

Cuando el servidor acepta la solicitud:

- elimina del canal compartido los eventos de sincronización anteriores (confirmado por el usuario que eran datos de prueba);
- actualiza el catálogo central al catálogo de demostración empaquetado con la aplicación;
- publica un evento `SYSTEM_RESET` para que las otras terminales vinculadas limpien sus datos locales y recarguen;
- limpia datos comerciales y configuraciones personalizadas locales, pero conserva el identificador de terminal, el canal y los tokens de sincronización para no desvincular las cajas;
- al volver a iniciar, los demás datos vuelven a sus valores iniciales de demostración.

La base de datos no cambia de esquema y no se toca ningún otro canal/comercio.

## Despliegue obligatorio

Esta función requiere **dos partes**. No alcanza con subir solamente el frontend:

1. Integrar el código fuente y ejecutar la compilación habitual (`npm run build`). Publicar el contenido compilado de `dist/`.
2. Actualizar `public/api/sync.php` en el hosting con la versión incluida en este ZIP, manteniendo intacto el archivo privado `sync-config.php` del servidor. No reemplazar `sync-config.php` ni copiar credenciales desde ejemplos.

El endpoint de reset requiere token de sincronización con permiso de escritura y solo acepta la solicitud desde `TERM-01`. La interfaz solo habilita la acción a usuarios con permiso de administrar configuración. No cambia el esquema SQL.

## Prueba segura antes de usar

1. Hacer una copia de seguridad de la base de datos y del despliegue actual.
2. Probar primero en el POS de prueba `posprueba.novamedia.com.ar`, nunca en producción.
3. Confirmar que TERM-01 y TERM-02 están conectadas y sin cola pendiente.
4. Desde TERM-01, entrar en Configuración → Nube, Hosting y Modo Offline y usar el botón rojo. Solo continuar si se desea borrar de verdad los datos comerciales del canal de prueba.
5. Verificar que ambas terminales recarguen, conserven sus identificadores y vinculación, muestren el catálogo de demostración y tengan historial/caja/cuentas vacíos.
6. Hacer una venta de prueba en cada terminal y comprobar que vuelvan a sincronizar en ambos sentidos.

## Límites

- No ejecutar si hay ventas reales que deban conservarse o si alguna terminal tiene operaciones offline pendientes.
- Las copias auxiliares de diagnóstico/backup de IndexedDB (`pos_ledger_v1`) no se borran con esta acción; son una copia secundaria y no la fuente activa de datos del POS.
- Se verificó sintaxis/transpilación de los archivos modificados y `php -l` del endpoint. No se pudo ejecutar una compilación completa ni una prueba real contra el hosting/DB desde este entorno.
