# Fase 57 — Optimización de notificaciones de sincronización

## Base
Continuación directa de `POS_Fase56_Aislamiento_Renderizados_Ventas.zip`.

## Cambio aislado
- `CloudSync.getStatus()` ahora devuelve el estado en memoria sin iniciar lecturas asíncronas de IndexedDB.
- `refreshPendingCount()` notifica únicamente cuando cambia la cantidad de operaciones pendientes.
- `notifyStatus()` compara una firma estable del estado y omite notificaciones idénticas.
- La suscripción inicial realiza una lectura controlada de la cola para hidratar el contador.

## Se conserva
- Polling remoto de 4 segundos y su backoff ante errores.
- Orden de la cola y confirmación individual de mensajes.
- Persistencia IndexedDB, operaciones offline y reintentos.
- Lógica de ventas, artículos, stock, compras, cuentas, historial y API PHP/MySQL.
- No requiere cambios SQL ni modifica producción.

## Verificación
- Revisado el flujo de polling y vaciado de cola: cuando no hay cambios, las notificaciones repetidas ya no disparan lecturas de cola ni actualizaciones de suscriptores.
- Transpilación sintáctica del archivo modificado con TypeScript: OK.
- No se pudo ejecutar `vite build` ni el chequeo integral de tipos: el ZIP no incluye `node_modules` y la instalación de dependencias agotó el tiempo disponible.

## Prueba solicitada
Instalar primero en el entorno de prueba, mantener Ventas quieta durante 1 minuto y observar CPU. Después probar una venta, sincronización entre dos terminales y una operación offline/reconexión. Comparar sin borrar datos ni limpiar IndexedDB.
