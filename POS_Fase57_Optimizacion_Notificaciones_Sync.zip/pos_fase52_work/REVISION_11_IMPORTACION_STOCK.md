# Revisión 11 — Importación de catálogo y sincronización de stock

## Qué corrige

- La importación distingue entre una columna de stock inexistente/vacía y un valor de stock explícito.
- En modo **Sumar y actualizar (MERGE)**, una fila sin stock no pone el stock del artículo en cero ni pisa el valor local.
- Los valores de stock presentes en el archivo se envían como ajustes explícitos (`stockOverrides`) junto con el evento `ARTICLES_UPDATED`.
- `public/api/sync.php` aplica esos ajustes explícitos únicamente a eventos marcados como `reason: catalog-import`; para el resto de los cambios de catálogo mantiene el stock autoritativo del servidor y evita que una terminal con datos viejos revierta ventas.
- Se conserva el resto de los flujos del POS y la cola de sincronización existente.

## Archivos modificados

- `src/modules/inventory/CatalogImportModal.tsx`
- `public/api/sync.php`

## Validación realizada

- `php -l public/api/sync.php`: correcto, sin errores de sintaxis.
- No se pudo completar `npm install` en el entorno de preparación por tiempo de espera; por eso no se afirma que se haya ejecutado exitosamente `npm run build`.

## Antes de desplegar

1. Hacer una copia de seguridad del proyecto y de la base de datos MySQL.
2. Probar primero con una copia de la base y dos terminales.
3. En una planilla de prueba, importar una fila con stock explícito y otra sin stock; comprobar que solo la primera modifica stock.
4. Probar ventas simultáneas en ambas terminales y comprobar que los cambios se reflejan sin recargar la página.
5. Al subir `public/api/sync.php`, conservar el archivo de configuración del servidor `public/api/sync-config.php`; no reemplazarlo por el ejemplo.
