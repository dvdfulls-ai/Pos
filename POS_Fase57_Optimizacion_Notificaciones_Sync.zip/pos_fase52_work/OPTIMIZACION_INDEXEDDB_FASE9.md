# Optimización IndexedDB — Fase 9

## Objetivo
Ampliar la copia/verificación previa a la migración para incluir los datos esenciales del catálogo y las colas de sincronización offline, sin cambiar todavía el almacenamiento activo del POS.

## Cambios
- Se incluyen `pos_articles_v1` y `pos_accounts_v1` en la copia, comparación y exportación.
- Se detectan dinámicamente las claves `pos_vps_pending_queue_v1_*` y `pos_vps_sync_cursor_v1_*` de la terminal actual, para incluirlas en copia, comparación y respaldo.
- No se copian claves de tokens de sincronización ni se cambia la configuración de vinculación.
- Las operaciones siguen siendo auxiliares; no cambian `StorageService`, no borran `localStorage` y no cambian la cola activa.

## Pruebas pendientes
- Ejecutar «Copiar y verificar historiales» en cada terminal.
- Ejecutar «Comparar con datos actuales» después de que la terminal haya sincronizado.
- Descargar un respaldo nuevo y guardarlo en un lugar seguro.
- Verificar con una compilación completa y prueba funcional en navegador antes de desplegar.

Este ZIP es código fuente, no una compilación lista para DirectAdmin.
