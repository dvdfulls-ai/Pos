# Optimización POS de prueba — Fase 15

## Objetivo
Reducir trabajo repetido al buscar artículos en Artículos & Stock cuando el catálogo contiene miles de registros.

## Cambio
- `InventoryModule.tsx` crea un índice de texto normalizado en memoria, memoizado por la referencia de `articles`.
- Al escribir en el buscador, se normaliza la consulta una vez y se reutilizan los campos indexados para nombre, marca, categoría, subcategoría y proveedor.
- La búsqueda por código de barras conserva el comportamiento literal anterior.
- Se mantiene el filtrado por marca, proveedor, categoría y stock, la paginación de 50 filas, y se devuelven los objetos `Article` originales.

## Seguridad / alcance
- No modifica `localStorage`, IndexedDB, datos guardados, API PHP, base de datos, tokens, colas ni cursores.
- No cambia las reglas de sincronización ni los procesos de venta.
- El índice se reconstruye cuando cambia la colección `articles`; no se persiste.

## Validaciones realizadas
- Cambio limitado a `src/modules/inventory/InventoryModule.tsx` más este documento.
- La revisión estática confirma que el filtro conserva los mismos campos de búsqueda y filtros de inventario.
- ZIP íntegro verificado.
- No se ejecutó compilación integral ni prueba real en navegador; deben validarse en el entorno de prueba antes de dar por confirmada la mejora.

## Prueba sugerida
1. Abrir Artículos & Stock con el catálogo de 8.755 artículos.
2. Comprobar carga inicial, buscar por nombre, código de barras, marca, categoría y proveedor.
3. Cambiar filtros de stock y avanzar páginas.
4. Modificar un artículo y confirmar que sus datos siguen apareciendo correctamente tras guardar.
