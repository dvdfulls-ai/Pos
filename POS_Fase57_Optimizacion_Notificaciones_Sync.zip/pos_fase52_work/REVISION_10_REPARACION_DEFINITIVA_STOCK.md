# Revisión 10 — reparación de reconciliación de stock entre terminales

## Causa corregida

Al recibir `ARTICLES_UPDATED`, `CloudSync` calculaba/filtraba el catálogo para proteger los cambios locales pendientes y lo enviaba a `onArticlesUpdate`. Inmediatamente después, el listener de `StorageService` también guardaba el catálogo original del mensaje, sin esa protección. Ese segundo guardado podía deshacer la reconciliación y recuperar cantidades viejas de stock.

## Cambios

- Los mensajes `ARTICLES_UPDATED` y `SYNC_RESPONSE_STATE` pasan por la misma reconciliación de catálogo en `CloudSync`.
- `StorageService` ya no vuelve a guardar el payload crudo de esos mensajes después de que CloudSync entregó el catálogo reconciliado.
- Comparación de IDs de artículos normalizada a texto en las búsquedas de ajuste de stock y al obtener el stock base para ventas/compras.
- `init-articles` ahora inicializa el catálogo del servidor solo si sigue vacío y bloquea la fila dentro de una transacción. Dos terminales que arrancan a la vez ya no pueden pisar la inicialización con sus catálogos locales distintos.
- Se conserva el modelo de deltas para ventas, compras y ajustes; no se cambian los flujos de cobros ni caja.

## Despliegue

1. En `pos_work`, ejecutar `npm install` y luego `npm run build`.
2. Subir el contenido de `dist` al directorio público del sitio, reemplazando los archivos anteriores.
3. Reemplazar en el hosting `public/api/sync.php` por el archivo de esta revisión (en la subida web, la ruta de destino es `api/sync.php`).
4. No reemplazar ni borrar `api/sync-config.php`; no hace falta crear tablas ni generar tokens nuevos.
5. Cerrar y volver a abrir/recargar las tres terminales después de desplegar.

## Validación realizada

- Sintaxis PHP validada con `php -l`.
- Integridad del ZIP validada al empaquetar.
- No se pudo completar `npm install` en el entorno de construcción por timeout; por eso no se afirma que el build frontend ni la prueba en el hosting hayan sido ejecutados aquí.
