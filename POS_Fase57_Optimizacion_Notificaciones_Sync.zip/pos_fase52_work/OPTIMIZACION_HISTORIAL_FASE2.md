# Optimización POS de prueba — Fase 2

## Alcance

Solo se optimizó la preparación de la lista de Historial en `src/modules/history/HistoryModule.tsx`. No se modificaron `storage.ts`, `cloudSync.ts`, la configuración de vinculación, el esquema SQL ni datos persistidos.

## Cambio

Los filtros de tipo, usuario y fecha se aplican ahora antes de crear los objetos duplicados de la línea de tiempo. Así, al consultar por ejemplo solo ventas de hoy o solo auditoría, se construyen y ordenan menos filas. La búsqueda por texto sigue ejecutándose después de esos filtros y el modal de detalle conserva el objeto original.

## Verificación

- Transpilación sintáctica TypeScript/TSX: sin diagnósticos en `HistoryModule.tsx` ni `storage.ts`.
- Se verificó que `public/api/sync.php` incluido sigue conteniendo `pairing-redeem`.
- No fue posible ejecutar un build completo porque la instalación de dependencias falló por un error DNS del registro npm en el entorno de trabajo.
- No se midió el rendimiento contra la base de datos ni el navegador del comercio; por tanto, este cambio necesita prueba en el sitio de prueba.

## No incluido

La migración de ventas/movimientos a IndexedDB requiere rediseño asíncrono porque el almacenamiento actual se usa de forma síncrona en varios módulos. No se hizo una migración automática ni se eliminaron/recortaron registros.
