# Revisión 5 — seguridad y pruebas

Esta revisión conserva el transporte de sincronización PHP + MySQL, la cola local para trabajar sin conexión, tokens individuales por terminal y eventos idempotentes. No depende de Firestore para sincronizar terminales.

Antes de usar datos reales, completar las pruebas aisladas descritas en `PHP_MYSQL_SYNC_SETUP.md`, incluyendo sincronización entre las dos terminales, ventas/compras y reconexión tras una interrupción de Internet.

No se declara superada la prueba de integración real: en el entorno de preparación no se pudo completar la instalación de dependencias npm ni conectar con la base de datos del hosting.
