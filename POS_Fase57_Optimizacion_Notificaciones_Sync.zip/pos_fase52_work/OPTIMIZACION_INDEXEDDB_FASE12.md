# Optimización IndexedDB — Fase 12

## Objetivo

Verificar que el respaldo importado en el almacén aislado `restore_staging` siga presente y legible después de guardarse, sin aplicar cambios al POS activo.

## Cambios

- Nuevo método `verifyStagedLedgerBackup()` en `src/services/indexedDbLedgerMigration.ts`.
- Nuevo botón **Verificar respaldo en ensayo** en Configuración → Cloud/Offline.
- La verificación vuelve a leer todas las filas de `restore_staging`, valida clave/contenido, parsea cada JSON, detecta claves duplicadas y comprueba la marca de importación.
- Presenta número de claves, tamaño aproximado de los contenidos, fecha de verificación y errores detectados.

## Seguridad y alcance

- Solo lectura sobre `restore_staging`.
- No escribe en `localStorage`, no modifica snapshots activos y no cambia `StorageService`, ventas, stock, caja, cuentas corrientes, pagos ni cola de sincronización.
- No ejecuta una restauración real ni activa IndexedDB como almacenamiento principal.

## Verificaciones técnicas realizadas

- Transpilación TypeScript/TSX de los dos archivos modificados: sin diagnósticos.
- Integridad del ZIP: verificada.
- El endpoint `pairing-redeem` de `public/api/sync.php` se conserva sin cambios.
- No se pudo ejecutar compilación completa ni pruebas de navegador en este entorno; deben hacerse antes de desplegar.
