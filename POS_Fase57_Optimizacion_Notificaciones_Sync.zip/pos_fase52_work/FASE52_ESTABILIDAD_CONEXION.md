FASE 52 - ESTABILIDAD DE CONEXION Y DEDUPLICACION DE STATE

Base: POS Fase 51.

Cambios exclusivos:
- src/services/network.ts: elimina las comprobaciones repetidas contra Google y el icono cada 2,5 segundos. Usa eventos online/offline/focus, una comprobación HEAD al mismo origen cada 15 segundos (solo con pestaña visible) y timeout de 3,5 segundos.
- src/services/cloudSync.ts: impide iniciar más de una consulta state simultánea por instancia; agrega timeout de 12 segundos y reintento de 10 segundos después de un fallo.
- Se conserva el polling de fase 51, el cursor incremental, la cola local y sus confirmaciones. No se modifican PHP, datos, stock, ventas, caja, cuentas, usuarios, lector ni configuración de Mercado Pago.

IMPORTANTE:
- Esta fase reduce solicitudes repetidas y mejora la recuperación ante cortes, pero no puede corregir fallas de DNS, del proveedor de Internet o del hosting.
- Los errores HTTP del servidor (por ejemplo 500) requieren revisar la respuesta del endpoint por separado.
- El ZIP contiene el código fuente; no se pudo ejecutar una compilación en este entorno porque no hay dependencias instaladas y no se realizó instalación de paquetes.
