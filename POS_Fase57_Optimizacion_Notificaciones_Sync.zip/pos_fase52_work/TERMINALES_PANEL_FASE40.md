FASE 40 — Corrección de error de inicialización

Se corrige el error `Cannot access 'L' before initialization` al abrir el POS.

Causa identificada en Fase 39: el arreglo de dependencias de un `useEffect` referenciaba `saveTerminalsList` antes de que esa constante quedara inicializada durante el primer render.

Corrección aislada en `src/context/AppContext.tsx`: el listener de vinculación ahora se registra una sola vez y consulta la lista persistida en el momento del evento, evitando el acceso temprano. Se conserva el flujo de vinculación de terminales incorporado en Fase 39.

No se modificaron otros archivos funcionales ni la base de datos. Verificar en navegador que el POS abra y luego vincular una terminal nueva.
