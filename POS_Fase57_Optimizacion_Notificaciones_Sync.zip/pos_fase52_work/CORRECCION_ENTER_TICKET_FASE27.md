# Corrección puntual — Enter en el comprobante de venta (Fase 27)

## Cambio realizado
- En el modal del comprobante/ticket de venta, al presionar Enter ahora se activa el mismo botón `Listo / Nueva Venta` que se activa con un clic.
- Se evita la acción predeterminada de Enter para reducir el riesgo de ejecutar una segunda acción accidental.
- Se conserva el cierre del comprobante, la limpieza de la venta completada en pantalla y el enfoque del campo de código de barras para la siguiente venta.

## Alcance
Solo se modificó `src/modules/sales/SalesModule.tsx`. No se modificaron el servidor, la base de datos, la sincronización, el almacenamiento, el stock, los pagos ni las reglas de ventas.

## Validación
Probar en el POS de prueba: finalizar una venta, comprobar que se abre el ticket, pulsar Enter una sola vez y verificar que se cierre el comprobante y quede listo para una nueva venta. Probar también el botón con clic e imprimir el ticket.
