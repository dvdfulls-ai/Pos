# POS prueba — Optimización de almacenamiento local, Fase 3

## Base
Parte de `pos-prueba-optimizacion-historial-fase2-con-vinculacion.zip`, que conserva la acción `pairing-redeem` en `public/api/sync.php`.

## Cambios acotados
- `src/services/storage.ts`
- Las escrituras de movimientos de cuentas corrientes, movimientos de caja e historial de turnos ya no intentan resolver la cuota eliminando registros antiguos.
- Se eliminó la limpieza de auditoría que podía borrar todos los logs cuando fallaba el guardado de turnos.
- Ante `QuotaExceededError`, se intenta liberar únicamente el estado transitorio de la pantalla de cliente (clave global y claves por terminal) y repetir una vez la escritura.
- Si sigue sin haber espacio, se conserva la lista completa en la caché de memoria de esa sesión y se registra un error claro en consola; no se recorta la lista a 500/200/100/50 movimientos ni se borran ventas, catálogo, compras, cuentas corrientes, auditoría o cola de sincronización.
- `addCashMovement` usa el mismo guardado protegido en vez de llamar directamente a `localStorage.setItem`.

## No se modificó
- `public/api/sync.php`, configuración de vinculación y secreto compartido.
- Esquema de base de datos, panel multi-comercio, pagos por terminal, ventas, artículos o cola offline de `cloudSync.ts`.
- La estructura síncrona de `StorageService`; no se realizó una migración parcial a IndexedDB.

## Validación
- Transpilación/sintaxis TypeScript de `storage.ts` y `HistoryModule.tsx`: sin diagnósticos.
- Acción `pairing-redeem` presente en `public/api/sync.php`.
- No fue posible validar compilación completa ni comportamiento con los 8.700 artículos en un navegador real en este entorno.

## Limitación importante
Si el navegador ya está lleno incluso después de retirar el estado transitorio de pantalla de cliente, no existe espacio para guardar otra copia de un registro en `localStorage`. En ese caso no se destruye el historial existente, pero los cambios nuevos afectados pueden quedar solo en memoria hasta que se libere espacio o se cierre la sesión. La solución estructural para grandes volúmenes sigue siendo migrar registros y cola offline a IndexedDB con migración verificada, backups y pruebas de sincronización; esta fase no pretende sustituir esa migración.
