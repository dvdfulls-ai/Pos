REVISION 6 — Actualización en tiempo real de cuentas corrientes

Problema corregido:
Al recibir un evento remoto ACCOUNTS_UPDATED, StorageService escribía cuentas y movimientos en localStorage, pero no actualizaba cachedAccountsMemory y cachedAccountMovementsMemory. Como getAccounts() y getAccountMovements() priorizan esas cachés en memoria, la interfaz seguía leyendo los datos anteriores hasta recargar la página.

Cambio aplicado:
- Cuando llega ACCOUNTS_UPDATED, actualiza la caché de cuentas y la caché de movimientos si cada campo es un array.
- Luego persiste esos mismos arrays en localStorage y emite el broadcast que activa la recarga reactiva de AppContext.
- No modifica cálculos de saldos, flujos de cobro/pago, caja, ventas, compras, autenticación ni protocolo PHP/MySQL.

Prueba sugerida tras instalar:
1. Abrir TERM-01 y TERM-02.
2. En TERM-01 registrar un movimiento de prueba en una cuenta corriente.
3. Verificar que saldo e historial de movimientos se actualicen en TERM-02 sin recargar.
4. Repetir con un cobro/pago de cuenta corriente y verificar ambas terminales.

Alcance de validación:
Se verificó que el cambio es localizado en la rama ACCOUNTS_UPDATED. No se afirma una compilación completa ni una prueba end-to-end en el hosting.
