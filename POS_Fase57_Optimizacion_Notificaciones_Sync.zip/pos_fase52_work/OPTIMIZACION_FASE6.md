# Fase 6 — Interfaz de copia y verificación de historiales

## Cambios
- Se integra en Configuración > Cloud/Offline un control manual para copiar a IndexedDB y verificar los historiales seleccionados.
- Muestra el estado por clave, cantidad de registros y tamaño aproximado.
- Errores se presentan en pantalla sin borrar ni modificar las claves originales de localStorage.
- Se mantiene la vinculación de terminales y no se cambia el backend activo de StorageService.

## Límites
- No es todavía una migración activa: la aplicación sigue leyendo/escribiendo sus datos habituales en localStorage.
- Ejecutar la copia puede necesitar espacio adicional en el navegador; ante error, el origen queda intacto.
- La compilación completa y la prueba en navegador con datos reales quedan pendientes.
