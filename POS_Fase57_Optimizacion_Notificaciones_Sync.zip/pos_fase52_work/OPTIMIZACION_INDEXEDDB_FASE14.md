# Optimización IndexedDB — Fase 14

## Diagnóstico de almacenamiento (solo lectura)

Se agregó a Configuración → Cloud/Offline el botón **“Diagnosticar tamaño y tiempos”**. El diagnóstico:

- Enumera las claves del POS ya consideradas por la preparación de migración, incluyendo colas y cursores VPS.
- Mide el tiempo de lectura de cada clave de `localStorage` y el tiempo de análisis JSON.
- Informa tamaño aproximado por clave y total, cantidad de registros cuando el valor es un arreglo y cantidad de entradas de cola cuando puede determinarse.
- Intenta consultar `navigator.storage.estimate()` como dato general del navegador, indicando que no es exclusivo del POS.
- Señala claves ausentes, errores de lectura o JSON inválido.

## Límites y seguridad

- No modifica `localStorage`, IndexedDB, el respaldo de ensayo, las colas ni los cursores.
- No cambia `StorageService`, la API síncrona de almacenamiento ni el proceso de sincronización.
- No incluye tokens ni secretos.
- Las mediciones de tamaño son aproximadas (caracteres × 2 bytes); los tiempos varían según equipo, navegador y carga.
- El diagnóstico analiza cada JSON completo para medir tiempo de parseo, por lo que puede tardar con claves grandes; ejecutar una vez y esperar su resultado.
- Esta entrega es código fuente: requiere compilar el proyecto por el flujo habitual antes de publicarlo. No subir este ZIP de fuentes como si fuera un `dist` compilado.

## Validaciones realizadas

- Revisión de sintaxis TypeScript mediante transpile check en los dos archivos modificados.
- Integridad del ZIP.
- Se verificó que `public/api/sync.php` mantiene `pairing-redeem`.
- No se completó un build integral ni una prueba real en navegador; deben validarse en el entorno de desarrollo antes de desplegar.
