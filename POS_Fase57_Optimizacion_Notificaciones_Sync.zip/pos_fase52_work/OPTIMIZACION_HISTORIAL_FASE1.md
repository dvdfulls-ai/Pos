# Optimización POS — Fase 1: Historial

## Cambios aplicados

- El listado de ventas ya no genera para cada venta una cadena concatenada con el nombre y la cantidad de cada artículo al abrir Historial. Ahora muestra un resumen corto con el número de artículos.
- El listado de compras tampoco concatena todos los artículos en un texto duplicado por fila; muestra factura y cantidad de productos.
- La búsqueda por nombre o código de artículo se conserva, pero consulta las líneas de venta/compra solo cuando hay un término de búsqueda.
- El ordenamiento convierte cada fecha a número una sola vez por reconstrucción de la línea temporal.
- El detalle completo continúa disponible desde el botón del ojito, usando los objetos originales de venta/compra.

## Alcance y seguridad

- No se cambió el esquema de datos, la sincronización, los tokens, el stock, caja, pagos, cuentas corrientes ni la estructura de persistencia.
- No se borran ni recortan ventas, compras, movimientos o auditoría.
- Este paquete contiene código fuente; no es un `dist` compilado y no debe subirse directamente como sitio público.

## Verificación realizada

- ZIP de origen válido antes de editar.
- El archivo `HistoryModule.tsx` modificado pasó la comprobación sintáctica TSX mediante TypeScript `transpileModule` (sin diagnósticos de sintaxis).
- No se pudo completar `npm install` en este entorno porque la conexión al registro npm falló (`EAI_AGAIN`); por eso no se pudo ejecutar el build completo ni probarlo en navegador con el historial real.

## Próxima fase recomendada

Migrar las colecciones crecientes de `localStorage` a IndexedDB con una migración que preserve los datos existentes, y adaptar la cola de sincronización para evitar escrituras/serializaciones completas repetidas. Esa fase debe hacerse por separado y probarse con respaldo antes de desplegar.
