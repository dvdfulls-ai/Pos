# Fase 24 — Comparación de almacenamiento entre terminales

## Objetivo
Facilitar una comparación segura del almacenamiento local de cada terminal antes de considerar cualquier cambio en la persistencia o sincronización.

## Cambio
- Añade el botón **Descargar informe Fase 24** junto al diagnóstico existente de tamaño y tiempos.
- El JSON exportado incluye terminal identificada, canal identificado, fecha de medición, tamaños aproximados, tiempos de lectura/análisis, conteos disponibles y estado de claves/colas.
- No exporta el contenido de ventas ni artículos; solo métricas y nombres de claves.

## Seguridad y alcance
- Solo lectura: no escribe ni borra localStorage o IndexedDB.
- No cambia `cloudSync.ts`, endpoints PHP, base de datos, esquema, tokens, reglas de stock, ventas, caja ni cuentas corrientes.
- No cambia el almacenamiento activo ni migra datos.

## Prueba sugerida
1. Integrar/compilar este ZIP como de costumbre.
2. En terminal 01, abrir Configuración → Preparación segura para IndexedDB → **Diagnosticar tamaño y tiempos** y luego **Descargar informe Fase 24**.
3. Repetir en terminal 02, después de que ambas estén conectadas y la sincronización se haya estabilizado.
4. Conservar ambos JSON y compararlos; repetir tras un período normal de ventas. No borrar colas ni restaurar copias durante esta prueba.

Los tamaños son aproximados y pueden variar por navegador. La estimación del navegador puede incluir datos de otros espacios/orígenes según su implementación. Una diferencia de tamaños no demuestra por sí sola que existan ventas duplicadas; hay que comparar conteos, claves y contexto de sincronización.
