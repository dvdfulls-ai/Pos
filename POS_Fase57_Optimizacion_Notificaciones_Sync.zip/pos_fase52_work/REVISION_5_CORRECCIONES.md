# Revisión 5 — arranque de sincronización PHP/MySQL

## Correcciones incluidas

1. `src/context/AppContext.tsx`: al iniciar el POS se registra la terminal actual en `CloudSync`, por lo que el cliente empieza a consultar `/api/sync.php?action=state` sin tener que cambiar manualmente el selector de terminal.
2. `public/api/sync.php`: solo analiza un cuerpo JSON en las acciones POST `publish` e `init-articles`. Las acciones GET `state` y `poll` ya no fallan intentando decodificar un cuerpo vacío.

## Comprobaciones realizadas en el entorno de preparación

- `php -l public/api/sync.php`: correcto.
- `php -l` para todos los PHP de `public/`: correcto.
- Transpilación sintáctica de TypeScript/TSX para `AppContext.tsx` y `cloudSync.ts`: correcta.
- Revisión estática: las rutas frontend (`/api/sync.php?action=state`, `poll`, `publish`, `init-articles`) coinciden con las acciones implementadas por PHP.

## Comprobaciones que faltan

No se pudo completar `npm install` en el entorno de preparación porque la descarga de dependencias agotó el tiempo disponible. Por eso no se declara un `npm run build` completo ni una prueba de integración contra la base MySQL del hosting. El paquete es el código corregido para compilar en Windows con la instalación de Node/npm del usuario; no se debe considerar una prueba real de dos terminales superada hasta hacerla en el subdominio aislado.

## Compilación y subida

1. Descomprimir el ZIP en una carpeta nueva.
2. Abrir CMD dentro de `pos_work`.
3. Ejecutar `npm install` y esperar a que termine sin errores.
4. Ejecutar `npm run build`; continuar solo si finaliza correctamente.
5. Subir el **contenido de `dist/`** al document root de `pos-sync-check.turadio.online`, manteniendo `api/sync-config.php` ya configurado. No subir sobre producción.
6. Probar ambas terminales con datos ficticios antes de usar datos reales.

No compartir tokens ni credenciales. No modificar Mercado Pago ni la API de producción.
