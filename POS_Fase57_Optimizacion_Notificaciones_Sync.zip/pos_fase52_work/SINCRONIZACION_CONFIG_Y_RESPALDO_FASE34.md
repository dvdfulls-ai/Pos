# Fase 34 — Sincronización de configuración y respaldo total

## Cambios puntuales
- Al guardar **Comercio & Datos**, la información comercial se publica por CloudSync y se aplica en las demás terminales del mismo canal.
- Al guardar la configuración de **ticketera/impresora**, se sincronizan sus opciones entre terminales y se actualiza la pantalla de configuración si está abierta.
- Los atajos de teclado guardados también se sincronizan.
- El respaldo JSON total ahora incluye `printerConfig` y `keyboardShortcuts`, además de `businessInfo`, `paymentConfig`, usuarios y `darkMode`.
- Al restaurar un respaldo, las terminales que reciben el evento aplican los datos comerciales, la configuración de ticketera/impresora, los atajos y el modo claro/oscuro del archivo. La interfaz escucha el evento de restauración del tema para actualizarse sin quedar desfasada.

## Prueba sugerida
1. Desplegar primero en `posprueba.novamedia.com.ar` mediante el flujo habitual de compilación.
2. En TERM-01, modificar Comercio & Datos y pulsar Guardar; comprobar TERM-02 sin recargar.
3. Cambiar y guardar una opción de ticketera/impresora; comprobar que TERM-02 recibe la configuración.
4. Poner TERM-01 en modo oscuro, descargar un respaldo JSON y verificar que contiene `darkMode: true`, `printerConfig` y `keyboardShortcuts`.
5. Cambiar temporalmente el tema y una opción de impresora en ambas terminales; restaurar el JSON desde TERM-01 y verificar que la configuración del respaldo y su tema se aplican en ambas.

## Alcance y validación
- No se modificaron archivos PHP ni la base de datos.
- Se verificó la sintaxis TypeScript/TSX de los cuatro archivos fuente modificados y la integridad del ZIP.
- No se afirma una prueba de extremo a extremo en el navegador; debe validarse con las dos terminales del entorno de prueba.
