# Fase 53 — Persistencia durable y sincronización de artículos/stock

Base: POS_Fase52_Cuota_Corregida(1).zip

## Cambios
- Se incorpora un almacén IndexedDB independiente (`pos_catalog_durable_v1`) para conservar el catálogo completo como respaldo durable.
- Al iniciar, la aplicación recupera primero el catálogo durable y recién después habilita la conexión/sincronización VPS, evitando que un snapshot antiguo de localStorage se imponga durante el arranque.
- Las altas y ediciones guardan el catálogo en IndexedDB antes de publicarlo. Si el guardado durable falla, no se anuncia el cambio como sincronizado y se emite un error visible en consola/evento.
- Los catálogos diferidos de la cola se materializan desde IndexedDB, con fallback a localStorage para instalaciones previas.
- Los catálogos remotos se guardan en IndexedDB antes de actualizar la vista.
- Los movimientos de stock recibidos por ventas, compras y ajustes se persisten también en IndexedDB.
- La edición de un artículo que cambia el stock publica primero el snapshot descriptivo y después un evento STOCK_ADJUSTED con la diferencia. Esto respeta la protección del servidor que conserva el stock existente ante snapshots ordinarios.

## Compatibilidad / alcance
- No se modifica `public/api/sync.php`.
- No se agrega ni modifica SQL.
- No se toca ninguna configuración de producción.
- Se conserva localStorage como caché síncrona para no reescribir los módulos existentes.

## Validaciones realizadas
- Integridad del ZIP original verificada antes de modificarlo.
- Sintaxis TypeScript/TSX verificada en los cuatro archivos modificados: 0 errores sintácticos.
- `php -l public/api/sync.php`: sin errores; el PHP no fue modificado.
- No se ejecutó un build completo de Vite ni una prueba real contra el servidor/MySQL porque el ZIP no contiene `node_modules` ni acceso al entorno DEV.

## Pruebas recomendadas en DEV
1. En TERM-01 crear un artículo nuevo y esperar a que TERM-02 lo reciba.
2. Editar ese artículo aumentando stock; comprobar que TERM-02 recibe el mismo stock.
3. Reiniciar ambas terminales y verificar que el artículo y stock permanecen.
4. Hacer una venta en TERM-01 y una compra/entrada de stock en TERM-02; verificar convergencia en ambas terminales.

No borrar IndexedDB ni datos del navegador antes de las pruebas.
