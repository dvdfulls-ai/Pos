# Revisión 8 — recepción de cuentas corrientes en TERM-03

## Corrección
El sondeo del relay PHP/MySQL ya no descarta mensajes entrantes comparando `senderTerminalId` con el identificador configurado localmente. El servidor fija `senderTerminalId` según el registro del token, así que un registro antiguo o inconsistente podía hacer que una sesión ignorara eventos válidos. Ahora la sesión descarta únicamente sus propios mensajes de eco comparando `senderClientId` con el `CLIENT_ID` local.

## Alcance
- Aplica a eventos de cuentas corrientes y también a los demás tipos de sincronización recibidos por el relay.
- No cambia el formato del token, el hash, el canal ni el esquema MySQL.
- No reemplaza `api/sync-config.php`.

## Validación
- `public/api/sync.php`: comprobación de sintaxis PHP correcta.
- No se pudo completar `npm install` en el entorno de empaquetado por timeout; la compilación `npm run build` queda pendiente de validar en el equipo del usuario.
