# POS Sync PHP/MySQL — paquete candidato para prueba aislada

## Estado y límites
Este ZIP es una **copia de prueba**, no reemplaza el POS activo. La conexión PHP/MySQL ya fue probada por el usuario con un archivo diagnóstico independiente. En esta copia:

- `public/api/sync.php` pasa `php -l`.
- `src/services/cloudSync.ts` pasa la comprobación de transpilación sintáctica de TypeScript.
- Se agregó autenticación por token individual y revocable por terminal; el servidor almacena SHA-256 del token y aplica permisos por canal.
- El servidor aplica deltas de stock una sola vez al catálogo central, después de aceptar un evento idempotente.
- **No se pudo completar `npm run build` en el entorno de preparación porque Vite/dependencias no están instalados y la instalación de npm agotó el tiempo disponible.** No se ha realizado una prueba de integración con el MySQL del usuario ni una prueba real entre dos terminales. Por tanto, solo puede usarse en un entorno aislado y con datos ficticios.

## 1. Compilar la copia en Windows
1. Descomprimir el ZIP en una carpeta de prueba, no dentro del POS activo.
2. Abrir CMD o PowerShell en la carpeta `pos_work` (la que contiene `package.json`).
3. Verificar Node.js con `node -v` y `npm -v`. La versión de Vite de este proyecto requiere una versión moderna de Node.js compatible con Vite 8.
4. Ejecutar `npm install`. Si termina con error, no continuar y guardar el error completo sin credenciales.
5. Ejecutar `npm run build`. Debe terminar sin errores y crear `dist`.
6. Si la compilación falla, no subir la carpeta `dist`; primero hay que corregir el error.

## 2. Crear un destino de prueba
- Usar preferentemente un **subdominio de prueba** cuyo document root esté vacío y separado de la web/POS actual, con HTTPS habilitado. La aplicación usa rutas absolutas como `/api/sync.php`, por eso no debe probarse dentro de una subcarpeta de un sitio existente.
- No subir sobre el sitio en producción. No modificar ni reemplazar `public/api.php` (API existente de Mercado Pago).
- Subir el contenido generado de `dist/` al document root del subdominio de prueba. La carpeta `public/api/` se copia normalmente dentro de `dist/api/`; verificar que existan `dist/api/sync.php`, `dist/api/sync-schema.sql` y `dist/api/.htaccess` antes de subir.
- Mantener la protección con contraseña del subdominio si el panel la ofrece. HTTPS es obligatorio.

## 3. Configurar la base de datos
1. Copiar `api/sync-config.example.php` a `api/sync-config.php` en el document root de prueba y completar `db_host`, `db_name`, `db_user` y `db_pass` con los datos de `turadioonline_pos_sync`. No enviar contraseñas por chat.
2. En phpMyAdmin, seleccionar `turadioonline_pos_sync` y ejecutar únicamente el bloque `CREATE TABLE pos_sync_tokens` de `api/sync-schema.sql` si la tabla todavía no existe. No borrar ni vaciar `pos_sync_channels` ni `pos_sync_events`.
3. El `.htaccess` de la API bloquea el acceso HTTP directo a la configuración y al SQL en Apache. Si el hosting no utiliza Apache o ignora `.htaccess`, no continuar hasta establecer una regla equivalente desde el panel/soporte.

## 4. Crear un token por terminal
Generar dos tokens aleatorios distintos de al menos 32 caracteres y guardarlos localmente. En PowerShell se puede generar un token hexadecimal de 64 caracteres así:

```powershell
$b = New-Object byte[] 32
$rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
$rng.GetBytes($b)
$rng.Dispose()
$token = -join ($b | ForEach-Object { $_.ToString('x2') })
$token
```

No reutilizar un token entre terminales. Para cada token, ejecutar una sentencia en phpMyAdmin sustituyendo los valores:

```sql
INSERT INTO pos_sync_tokens (token_hash, channel_id, terminal_id, can_read, can_write, active)
VALUES (SHA2('PEGAR_TOKEN_PC1', 256), 'posprueba2026', 'TERM-01', 1, 1, 1);
```

Para la segunda PC, usar el segundo token y `TERM-02`. El `terminal_id` debe coincidir con el ID que la aplicación muestra/configura para esa terminal. Si los IDs son distintos, usar los IDs reales. El token plano no se almacena en MySQL; solo su hash.

## 5. Abrir el canal de prueba
- Abrir la aplicación del subdominio con `?channel=posprueba2026` en ambas terminales.
- Configurar terminal 1 como `TERM-01` y terminal 2 como `TERM-02` (o usar los IDs que se insertaron en la tabla).
- Al conectar, cada navegador pedirá su token la primera vez. Pegar el token asignado a esa PC. No compartir tokens por chat.
- Si un token se escribe mal, comprobar la fila en `pos_sync_tokens` y volver a cargar la página. No usar credenciales de la base como token.

## 6. Pruebas aisladas obligatorias
Usar solo productos ficticios y una base/canal de prueba.
1. Sin token: debe rechazar la API con 401.
2. Token incorrecto o de otro canal: 401.
3. Token sin permiso de escritura: 403 al publicar.
4. Crear un artículo de prueba, comprobar que la otra terminal lo recibe.
5. Registrar una venta de prueba y verificar que stock no se descuente dos veces.
6. Hacer dos movimientos seguidos desde ambas terminales.
7. Desconectar Internet en una PC, registrar movimiento ficticio, reconectar y comprobar la cola pendiente.
8. Recargar ambas terminales y comprobar que el stock sigue consistente.
9. Revisar logs de PHP si hay errores; no publicar esos logs con credenciales.

## Seguridad y limitaciones
- Un token guardado en un navegador no es un secreto contra alguien con acceso al navegador o ante una vulnerabilidad XSS. Mantener HTTPS, usuarios protegidos y el subdominio de prueba aislado.
- Revocar una terminal cambiando `active=0` en su fila de `pos_sync_tokens`.
- La API no implementa por sí misma los roles de usuario del POS; el token solo autoriza la sincronización de una terminal a un canal.
- Aún deben probarse compilación completa, catálogos grandes (8.700 artículos), límites PHP (`post_max_size`, `memory_limit`, `max_execution_time`), concurrencia, recuperación de desconexión prolongada y todos los módulos de negocio.
- No utilizar con datos reales ni sustituir el POS actual hasta que todas las pruebas terminen satisfactoriamente.


## Vinculación con el panel multi-comercio (prueba aislada)
Para habilitar el botón «Generar código» del panel, copie `public/api/sync-config.example.php` como `public/api/sync-config.php` y configure `pairing_panel_url` con `https://panelpos.novamedia.com.ar/api/pairing-redeem.php`. El valor `pairing_shared_secret` debe coincidir exactamente con `api/config.php` del panel y tener al menos 32 caracteres aleatorios. Mantenga los secretos solo en archivos PHP del servidor, nunca en el frontend.
El POS guarda el token como SHA-256 en `pos_sync_tokens`; el navegador conserva el token en localStorage y una cookie persistente de respaldo. Si Chrome borra todos los datos del sitio al salir, tendrá que vincular de nuevo.
