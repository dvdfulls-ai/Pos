FASE 41 - Corrección del flujo para vincular una terminal nueva

Problema: al crear una terminal nueva en el panel, el POS no la muestra en el selector hasta completar la vinculación; pero el POS no ofrecía una acción visible para volver a abrir el ingreso del código cuando el navegador ya estaba vinculado a otra terminal.

Cambio acotado:
- En Configuración > Terminales / Cajas se agregó el botón verde “Vincular terminal del panel”.
- El botón abre el ingreso del código temporal generado para la terminal nueva en el panel.
- Al validar el código, se conserva el flujo existente: el POS recibe el ID real, agrega/actualiza esa terminal en la lista local y la activa.
- Se parte de la Fase 40, conservando su corrección del error de inicialización.

Uso:
1. Subir/compilar esta versión del POS de prueba.
2. En el panel, generar un código temporal para la cuarta terminal.
3. En el POS, ir a Configuración > Terminales / Cajas y pulsar “Vincular terminal del panel”.
4. Pegar el código temporal vigente.
5. La terminal vinculada debe incorporarse a la lista del POS. Si el código vence, generar otro en el panel.

No modifica la base de datos ni el sitio de producción. No se afirma que haya sido probado en el navegador del usuario; compilar y verificar en el entorno de prueba antes de reemplazar la versión publicada.
