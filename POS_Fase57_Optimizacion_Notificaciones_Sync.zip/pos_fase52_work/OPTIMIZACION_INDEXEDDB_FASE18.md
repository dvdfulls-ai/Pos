# Optimización POS — Fase 18

## Diagnóstico del historial real (solo lectura)

Añade en Historial un botón para medir la cantidad de elementos actualmente cargados en memoria, su distribución por tipo y el coste de ordenar una copia y aplicar los filtros vigentes. No escribe ni borra datos y no toca localStorage, IndexedDB, colas, cursores, APIs ni la base de datos.

La ordenación se ejecuta sobre una copia de la línea de tiempo y usa los filtros actuales. Los resultados son diagnósticos orientativos dependientes del equipo, volumen y carga del navegador; no representan por sí solos el tiempo total de apertura/renderizado.

## Verificación

- Confirmar que se conserva `pairing-redeem` en `public/api/sync.php`.
- ZIP de código fuente; requiere la compilación habitual, no subir directamente como sitio compilado.
- La prueba de carga simulada existente permanece disponible.
