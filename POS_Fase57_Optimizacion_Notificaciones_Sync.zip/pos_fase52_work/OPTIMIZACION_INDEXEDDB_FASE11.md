# Optimización IndexedDB — Fase 11

## Objetivo

Probar que un respaldo JSON exportado puede validarse y guardarse en un área de ensayo independiente, sin restaurarlo sobre los datos activos del POS.

## Cambios

- IndexedDB pasa a versión 2 y crea el almacén separado `restore_staging`; el almacén de snapshots actual no se borra ni se reemplaza.
- Se agrega `stageLedgerBackupForRestore`, que valida el formato del respaldo, el nombre de base, las claves admitidas, duplicados y validez del JSON de cada entrada.
- El respaldo importado se escribe únicamente en `restore_staging` y se vuelve a leer para comprobar que coincida.
- En Configuración → Cloud/Offline aparece «Probar restauración (sin aplicar)» para seleccionar el JSON descargado en la fase anterior.
- La operación no escribe en `localStorage`, no aplica ventas ni movimientos, y no sustituye los snapshots actuales.
- Se mantiene el código de vinculación `pairing-redeem`; no se modifican API PHP, tablas SQL, pagos ni cola activa de sincronización.

## Verificaciones realizadas

- Transpilación sintáctica de `indexedDbLedgerMigration.ts` y `SettingsModule.tsx`: sin diagnósticos.
- `public/api/sync.php` conserva la acción `pairing-redeem`.
- ZIP validado con `unzip -t`.

## Pendiente antes de desplegar

- Compilación completa (`npm run build` / `npm run lint`) en un entorno con dependencias instaladas.
- Prueba en navegador con el respaldo real descargado por el usuario.
- Confirmar que IndexedDB puede actualizarse a versión 2 sin pestañas antiguas abiertas.
- La prueba de restauración es un ensayo aislado; no cambia el backend activo de StorageService ni supone que el POS ya use IndexedDB para operar.

Este paquete contiene código fuente, no una compilación lista para subir directamente a DirectAdmin.
