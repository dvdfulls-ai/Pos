# Fase 55 — Modo de prueba con Historial visual desactivado

Base: POS Fase 54 (incluye la persistencia durable de artículos y stock de Fase 53).

## Cambio
- Se oculta temporalmente la pestaña Historial.
- Se evita montar el componente visual `HistoryModule`.
- No se eliminan registros, ventas, auditorías ni movimientos.
- No se modifica la persistencia de ventas ni el guardado durable del catálogo/stock.
- No se modifica `public/api/sync.php`, SQL ni configuración de producción.

## Importante
Esta medida evita abrir/cargar la pantalla global de Historial durante las pruebas. No desactiva el registro histórico de las ventas, porque hacerlo podría provocar pérdida de trazabilidad. Tampoco garantiza por sí sola resolver un uso de CPU del 100% originado en otra parte del POS.

## Prueba en DEV
1. Instalar en las dos terminales de DEV.
2. Confirmar que no aparece la pestaña Historial.
3. Hacer ventas consecutivas.
4. Crear un artículo y aumentar stock.
5. Reiniciar el programa y comprobar que el artículo y el stock siguen presentes.
6. Observar el Administrador de tareas de Windows y anotar si el CPU vuelve al 100%.

No borrar IndexedDB ni limpiar datos del navegador. No instalar en producción.
