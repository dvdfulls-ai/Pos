# Pruebas locales de Firestore Emulator

1. Copiá `.env.emulator.example` como `.env.local` para activar el emulador únicamente en este entorno de desarrollo.
2. En una terminal, ejecutá `npm run emulators` desde esta carpeta y dejá el proceso abierto. La primera ejecución puede descargar Firebase CLI y el emulador.
3. En otra terminal, ejecutá `npm run dev`.
4. Abrí ambas terminales de prueba desde esta misma computadora. Si la segunda terminal corre en otra computadora, configurá `VITE_FIRESTORE_EMULATOR_HOST` con la IP LAN de la computadora que ejecuta el emulador y permití el puerto 8080 en la red local.
5. Confirmá en la consola del navegador que aparece `[Firestore] Emulator enabled ...`. Si no aparece, no hagas ventas de prueba hasta revisar `.env.local`.
6. El emulador usa una base local vacía y no modifica la base de producción. Los datos del emulador pueden perderse al detenerlo, salvo que se configure exportación/importación.
7. Para volver a producción, quitá `VITE_USE_FIREBASE_EMULATOR=true` de `.env.local` y reiniciá Vite. No despliegues reglas ni configuración del emulador a producción como parte de esta prueba.

Prueba mínima: cargar un catálogo de prueba, verificar stock 20 en ambas terminales, vender 1 unidad en la terminal A, comprobar 19 en A y B, recargar ambas y comprobar que sigue en 19. Después probar una compra y una venta a cuenta corriente para verificar los módulos relacionados.
