# Fase 42 — Corrección de cuota en cola de sincronización

## Objetivo
Reducir el crecimiento de la cola `pos_vps_pending_queue_v1_<canal>` causado por actualizaciones repetidas y temporales de la pantalla del cliente, que producían `QuotaExceededError` en Chrome.

## Cambios en `src/services/cloudSync.ts`
- `CUSTOMER_DISPLAY_SYNC` se trata como estado temporal reemplazable: antes de encolar uno nuevo, se quita la versión anterior del mismo tipo.
- Si una escritura de la cola falla por cuota, se compactan los estados reemplazables y se reintenta una vez.
- La compactación conserva los mensajes de operaciones (ventas, compras, ajustes de stock y movimientos) y solo reduce snapshots reemplazables: cuentas, usuarios, caja, catálogo, respuestas de estado y pantalla de cliente.
- Si incluso después de compactar no puede guardarse un `CUSTOMER_DISPLAY_SYNC`, se omite únicamente ese snapshot temporal. No se aplica ese descarte a ventas ni a operaciones financieras.

## Límites y prueba necesaria
Esta fase busca corregir el patrón exacto de errores repetidos al actualizar la pantalla de cliente y recuperar colas con snapshots obsoletos. No puede prometer que `localStorage` nunca alcance su cuota si una cola contiene una cantidad extraordinaria de operaciones importantes sin conexión, o si otras claves del sitio ocupan todo el espacio.

No se borran ventas, artículos, compras, cuentas, movimientos ni la cola completa. Antes de probar en producción, conservar un respaldo del POS y comprobar la sincronización en ambas terminales.

## Estado de validación
- Revisión estática del cambio realizada.
- No se pudo completar `npm install` en este entorno por tiempo de espera; por ello no se afirma que el build de producción haya sido ejecutado.
- Requiere prueba real en `posprueba.novamedia.com.ar` con el respaldo y verificación de que las operaciones financieras siguen llegando al servidor.
