import React, { useState, useRef, useEffect, useMemo, useDeferredValue } from 'react';
import { 
  History, 
  Search, 
  Filter, 
  Calendar, 
  User, 
  Download, 
  ShoppingBag, 
  Receipt, 
  DollarSign, 
  ShieldAlert, 
  FileText,
  Clock,
  Eye,
  X,
  Printer,
  CheckCircle2,
  AlertCircle,
  Truck,
  CreditCard,
  ArrowDownRight,
  ArrowUpRight,
  UserCheck,
  Tag
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import { Sale, Purchase, AccountMovement, AuditLog, ExternalServiceSale } from '../../types';
import { matchesQuery, formatThousands } from '../../utils/text';

export const HistoryModule: React.FC = () => {
  const { sales, purchases, accountMovements, auditLogs, externalServiceSales } = useApp();
  const { users } = useAuth();

  const [activeType, setActiveType] = useState<'ALL' | 'VENTAS' | 'COMPRAS' | 'CUENTAS' | 'AUDITORIA'>('ALL');
  const [selectedUserId, setSelectedUserId] = useState<string>('ALL');
  const [dateFilter, setDateFilter] = useState<'ALL' | 'TODAY' | 'WEEK'>('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  // Keep the text input responsive while React prioritizes filtering a large history list.
  const deferredSearchTerm = useDeferredValue(searchTerm);
  const searchInputRef = useRef<HTMLInputElement>(null);
  // Selected item modal for complete detailed view with the eye ("ojito")
  const [selectedItem, setSelectedItem] = useState<TimelineItem | null>(null);
  const [visibleCount, setVisibleCount] = useState(100);
  const [loadTestResult, setLoadTestResult] = useState<{ count: number; buildMs: number; sortMs: number; filterMs: number; matches: number } | null>(null);
  const [realHistoryDiagnostic, setRealHistoryDiagnostic] = useState<{ total: number; sales: number; purchases: number; accounts: number; audit: number; sortMs: number; filterMs: number; visible: number } | null>(null);

  // Enfocar el buscador al entrar a Historial y después de acciones.
  useEffect(() => {
    const focusSearchInput = () => {
      setTimeout(() => {
        if (!selectedItem) {
          searchInputRef.current?.focus();
          searchInputRef.current?.select();
        }
      }, 50);
    };

    focusSearchInput();

    const refocusSearchAfterAction = (event: MouseEvent) => {
      const target = event.target as HTMLElement | null;
      if (target?.closest('input, textarea, select, [contenteditable="true"]')) return;
      setTimeout(() => {
        if (!selectedItem) {
          searchInputRef.current?.focus();
          searchInputRef.current?.select();
        }
      }, 80);
    };

    document.addEventListener('click', refocusSearchAfterAction);
    return () => document.removeEventListener('click', refocusSearchAfterAction);
  }, [selectedItem]);

  // Consolidated timeline records
  interface TimelineItem {
    id: string;
    type: 'VENTA' | 'COMPRA' | 'COBRO_CTA' | 'AUDITORIA';
    title: string;
    subtitle: string;
    details: string;
    amount?: number;
    paymentMethod?: string;
    userId: string;
    userName: string;
    timestamp: string;
    rawObject?: any;
    isPaid?: boolean;
    statusLabel?: string;
    displayDate: string;
    displayTime: string;
    timestampMs: number;
  }

  // Calculate date boundaries before building the timeline so type/user/date filters
  // can discard records before allocating duplicate timeline objects.
  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const startOfWeek = startOfToday - (7 * 24 * 60 * 60 * 1000);
  // Build the base timeline only when source data changes. Type, user, date and
  // text filters are applied below, so changing a filter does not recreate every
  // timeline object or repeat the global sort.


  const allItems: TimelineItem[] = useMemo(() => {
    // Build only the timeline category/date range currently requested. On older PCs,
    // mapping and sorting every historical record after each new sale caused avoidable
    // CPU and memory pressure even though the table renders only 100 rows.
    const inSelectedDateRange = (timestamp: string) => {
      if (dateFilter === 'ALL') return true;
      const ms = Date.parse(timestamp) || 0;
      return ms >= (dateFilter === 'TODAY' ? startOfToday : startOfWeek);
    };
    const includeSales = activeType === 'ALL' || activeType === 'VENTAS';
    const includePurchases = activeType === 'ALL' || activeType === 'COMPRAS';
    const includeAccounts = activeType === 'ALL' || activeType === 'CUENTAS';
    const includeAudit = activeType === 'ALL' || activeType === 'AUDITORIA';

    // Account movements can reference older sales/purchases. Build lookup maps only
    // when the account timeline is requested; do not pay this cost on the sales tab.
    const salesById = new Map<string, Sale>();
    const salesByReceipt = new Map<string, Sale>();
    const purchasesById = new Map<string, Purchase>();
    const purchasesByInvoice = new Map<string, Purchase>();
    if (includeAccounts && accountMovements.length) {
      for (const sale of sales) {
        salesById.set(String(sale.id), sale);
        salesByReceipt.set(String(sale.receiptNumber), sale);
      }
      for (const purchase of purchases) {
        purchasesById.set(String(purchase.id), purchase);
        purchasesByInvoice.set(String(purchase.invoiceNumber), purchase);
      }
    }

    const items: TimelineItem[] = [];
    if (includeSales) {
      for (const sale of sales) {
        if (!inSelectedDateRange(sale.timestamp)) continue;
        const isCtaCte = sale.paymentMethod === 'CUENTA_CORRIENTE';
        items.push({
          id: sale.id, type: 'VENTA', title: `Venta Ticket #${sale.receiptNumber}`,
          subtitle: `${sale.items.length} artículos`, details: `Cliente: ${sale.clientName || 'Consumidor Final'}`,
          amount: sale.total,
          paymentMethod: sale.paymentDetails?.isMixedPayment ? 'Mixto (Transf. + Ef.)' : sale.paymentMethod,
          userId: sale.userId, userName: sale.userName, timestamp: sale.timestamp, rawObject: sale,
          isPaid: !isCtaCte, statusLabel: isCtaCte ? 'Cta. Cte. (A Cobrar)' : 'Cobrado',
          displayDate: '', displayTime: '', timestampMs: Date.parse(sale.timestamp) || 0,
        });
      }
      for (const serviceSale of externalServiceSales || []) {
        if (!inSelectedDateRange(serviceSale.timestamp)) continue;
        items.push({
          id: serviceSale.id, type: 'VENTA',
          title: `Servicio Externo: ${serviceSale.serviceName || serviceSale.service}`,
          subtitle: serviceSale.notes || `Recarga o Cobro de ${serviceSale.serviceName || serviceSale.service}`,
          details: `Terminal: ${serviceSale.terminalId || 'TERM-01'}`, amount: serviceSale.amount,
          paymentMethod: 'Efectivo', userId: serviceSale.userId, userName: serviceSale.userName,
          timestamp: serviceSale.timestamp, rawObject: serviceSale, isPaid: true, statusLabel: 'Cobrado',
          displayDate: '', displayTime: '', timestampMs: Date.parse(serviceSale.timestamp) || 0,
        });
      }
    }
    if (includePurchases) {
      for (const purchase of purchases) {
        if (!inSelectedDateRange(purchase.timestamp)) continue;
        const isCtaCte = purchase.paymentMethod === 'CUENTA_CORRIENTE';
        items.push({
          id: purchase.id, type: 'COMPRA', title: `Compra a Proveedor: ${purchase.supplierName}`,
          subtitle: `Factura: ${purchase.invoiceNumber} (${purchase.items.length} productos ingresados)`,
          details: `Proveedor: ${purchase.supplierName}`, amount: purchase.total,
          paymentMethod: purchase.paymentMethod, userId: purchase.userId, userName: purchase.userName,
          timestamp: purchase.timestamp, rawObject: purchase, isPaid: !isCtaCte,
          statusLabel: isCtaCte ? 'Cta. Cte. (A Pagar)' : 'Pagado',
          displayDate: '', displayTime: '', timestampMs: Date.parse(purchase.timestamp) || 0,
        });
      }
    }
    if (includeAccounts) {
      for (const movement of accountMovements) {
        if (!inSelectedDateRange(movement.timestamp)) continue;
        const referenceId = movement.referenceId == null ? '' : String(movement.referenceId);
        const linkedSale = referenceId ? (salesById.get(referenceId) || salesByReceipt.get(referenceId)) : undefined;
        const linkedPurchase = referenceId ? (purchasesById.get(referenceId) || purchasesByInvoice.get(referenceId)) : undefined;
        const isPayment = movement.type === 'CREDIT';
        items.push({
          id: movement.id, type: 'COBRO_CTA', title: `Movimiento Cta. Cte.: ${movement.accountName}`,
          subtitle: movement.concept,
          details: `Tipo: ${movement.type === 'DEBIT' ? 'Cargo (Deuda generada)' : 'Cobro / Pago acreditado'}`,
          amount: movement.amount, paymentMethod: movement.paymentMethod, userId: movement.userId,
          userName: movement.userName, timestamp: movement.timestamp,
          rawObject: { movement, linkedSale, linkedPurchase }, isPaid: isPayment,
          statusLabel: isPayment ? 'Cobrado / Acreditado' : 'Deuda Generada',
          displayDate: '', displayTime: '', timestampMs: Date.parse(movement.timestamp) || 0,
        });
      }
    }
    if (includeAudit) {
      for (const audit of auditLogs) {
        if (!inSelectedDateRange(audit.timestamp)) continue;
        items.push({
          id: audit.id, type: 'AUDITORIA', title: `[${audit.module}] ${audit.action}`,
          subtitle: audit.description, details: `Terminal: ${audit.terminalId} | Rol: ${audit.userRole}`,
          userId: audit.userId, userName: audit.userName, timestamp: audit.timestamp, rawObject: audit,
          isPaid: true, statusLabel: 'Registrado', displayDate: '', displayTime: '',
          timestampMs: Date.parse(audit.timestamp) || 0,
        });
      }
    }

    // Sort once using numeric timestamps already parsed above, avoiding Date allocation
    // inside the comparator and an additional wrapper array for every record.
    items.sort((a, b) => b.timestampMs - a.timestampMs);
    for (const item of items) {
      const date = new Date(item.timestampMs);
      item.displayDate = date.toLocaleDateString();
      item.displayTime = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    return items;
  }, [sales, externalServiceSales, purchases, accountMovements, auditLogs, activeType, dateFilter, startOfToday, startOfWeek]);

  // Search is applied after basic filters, so expensive item-level search runs on a smaller set.

  useEffect(() => {
    setVisibleCount(100);
  }, [activeType, selectedUserId, dateFilter, searchTerm]);

  const filteredItems = useMemo(() => allItems.filter(item => {
    if (activeType === 'VENTAS' && item.type !== 'VENTA') return false;
    if (activeType === 'COMPRAS' && item.type !== 'COMPRA') return false;
    if (activeType === 'CUENTAS' && item.type !== 'COBRO_CTA') return false;
    if (activeType === 'AUDITORIA' && item.type !== 'AUDITORIA') return false;
    if (selectedUserId !== 'ALL' && item.userId !== selectedUserId) return false;
    const itemTime = item.timestampMs;
    if (dateFilter === 'TODAY' && itemTime < startOfToday) return false;
    if (dateFilter === 'WEEK' && itemTime < startOfWeek) return false;
    if (deferredSearchTerm) {
      const matchesSummary = matchesQuery(item.title, deferredSearchTerm) ||
        matchesQuery(item.subtitle, deferredSearchTerm) ||
        matchesQuery(item.userName, deferredSearchTerm) ||
        matchesQuery(item.details, deferredSearchTerm) ||
        (!!item.paymentMethod && matchesQuery(item.paymentMethod, deferredSearchTerm));
      if (matchesSummary) return true;

      // Preserve searching by product name without constructing a large concatenated
      // string for every historical sale/purchase whenever History opens.
      if (item.type === 'VENTA' && item.rawObject?.items) {
        return item.rawObject.items.some((line: any) => matchesQuery(line.name, deferredSearchTerm) || matchesQuery(line.barcode, deferredSearchTerm));
      }
      if (item.type === 'COMPRA' && item.rawObject?.items) {
        return item.rawObject.items.some((line: any) => matchesQuery(line.name, deferredSearchTerm) || matchesQuery(line.barcode, deferredSearchTerm));
      }
      return false;
    }
    return true;
  }), [allItems, activeType, selectedUserId, dateFilter, startOfToday, startOfWeek, deferredSearchTerm]);
  const visibleItems = useMemo(() => filteredItems.slice(0, visibleCount), [filteredItems, visibleCount]);

  // Isolated synthetic load test: generated in memory only; never reads or writes POS records.
  const runHistoryLoadTest = (count: number) => {
    const buildStart = performance.now();
    const synthetic = Array.from({ length: count }, (_, index) => ({
      id: `load-test-${index}`,
      type: (index % 4 === 0 ? 'COMPRA' : index % 7 === 0 ? 'COBRO_CTA' : index % 11 === 0 ? 'AUDITORIA' : 'VENTA'),
      title: `Operación de prueba #${index}`,
      subtitle: `Artículo simulado ${index % 8755} código ${String(index % 100000).padStart(6, '0')}`,
      userName: `Usuario ${(index % 5) + 1}`,
      timestamp: new Date(Date.now() - (index * 60000)).toISOString(),
    }));
    const buildMs = performance.now() - buildStart;

    const sortStart = performance.now();
    synthetic.sort((a, b) => Date.parse(b.timestamp) - Date.parse(a.timestamp));
    const sortMs = performance.now() - sortStart;

    const filterStart = performance.now();
    const matches = synthetic.filter(item => item.type === 'VENTA' && (item.title.includes('1') || item.subtitle.includes('1'))).length;
    const filterMs = performance.now() - filterStart;

    setLoadTestResult({ count, buildMs, sortMs, filterMs, matches });
  };

  // Read-only diagnostic against the real in-memory timeline. It does not alter POS data.
  const runRealHistoryDiagnostic = () => {
    const sortStart = performance.now();
    const sortedCopy = allItems.map((item, index) => ({ item, index, time: item.timestampMs }));
    sortedCopy.sort((a, b) => b.time - a.time || a.index - b.index);
    const sortMs = performance.now() - sortStart;

    const filterStart = performance.now();
    const currentFilterMatches = sortedCopy.filter(({ item }) => {
      if (activeType === 'VENTAS' && item.type !== 'VENTA') return false;
      if (activeType === 'COMPRAS' && item.type !== 'COMPRA') return false;
      if (activeType === 'CUENTAS' && item.type !== 'COBRO_CTA') return false;
      if (activeType === 'AUDITORIA' && item.type !== 'AUDITORIA') return false;
      if (selectedUserId !== 'ALL' && item.userId !== selectedUserId) return false;
      const itemTime = item.timestampMs;
      if (dateFilter === 'TODAY' && itemTime < startOfToday) return false;
      if (dateFilter === 'WEEK' && itemTime < startOfWeek) return false;
      if (!searchTerm) return true;
      const summaryMatch = matchesQuery(item.title, searchTerm) || matchesQuery(item.subtitle, searchTerm) || matchesQuery(item.userName, searchTerm) || matchesQuery(item.details, searchTerm) || (!!item.paymentMethod && matchesQuery(item.paymentMethod, searchTerm));
      if (summaryMatch) return true;
      if ((item.type === 'VENTA' || item.type === 'COMPRA') && item.rawObject?.items) return item.rawObject.items.some((line: any) => matchesQuery(line.name, searchTerm) || matchesQuery(line.barcode, searchTerm));
      return false;
    });
    const filterMs = performance.now() - filterStart;
    setRealHistoryDiagnostic({
      total: allItems.length,
      sales: allItems.filter(item => item.type === 'VENTA').length,
      purchases: allItems.filter(item => item.type === 'COMPRA').length,
      accounts: allItems.filter(item => item.type === 'COBRO_CTA').length,
      audit: allItems.filter(item => item.type === 'AUDITORIA').length,
      sortMs, filterMs, visible: currentFilterMatches.length,
    });
  };

  const exportCSV = () => {
    const headers = ['ID', 'Fecha', 'Hora', 'Tipo', 'Titulo', 'Detalle', 'Monto', 'Medio de Pago', 'Estado', 'Usuario'];
    // Escape every field according to CSV rules. This also handles commas and line breaks
    // in concepts/user names without corrupting the exported columns.
    const escapeCSV = (value: unknown) => {
      const text = value === undefined || value === null ? '' : String(value);
      return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
    };

    // Build modest chunks instead of creating one giant data: URI plus an encoded copy
    // of the entire history, which can consume several times the CSV's size in memory.
    const parts: string[] = ['\uFEFF' + headers.map(escapeCSV).join(',') + '\r\n'];
    const chunkSize = 500;
    for (let start = 0; start < filteredItems.length; start += chunkSize) {
      const chunkLines: string[] = [];
      const end = Math.min(start + chunkSize, filteredItems.length);
      for (let index = start; index < end; index++) {
        const item = filteredItems[index];
        chunkLines.push([
          item.id,
          item.displayDate,
          item.displayTime,
          item.type,
          item.title,
          item.subtitle,
          item.amount ?? 0,
          item.paymentMethod || '-',
          item.statusLabel || '-',
          item.userName,
        ].map(escapeCSV).join(','));
      }
      parts.push(chunkLines.join('\r\n') + '\r\n');
    }

    const blob = new Blob(parts, { type: 'text/csv;charset=utf-8' });
    const objectUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = objectUrl;
    link.download = `historial_control_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
  };

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-6 space-y-4 w-full">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-neutral-900 p-4 rounded-xl border border-neutral-200 dark:border-neutral-800 shadow-xs">
        <div>
          <h2 className="text-lg font-bold text-neutral-900 dark:text-white tracking-tight flex items-center gap-2">
            <History className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <span>Historial & Auditoría de Control Completo</span>
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
            Supervise todas las operaciones: compras a proveedores, ventas, cuentas corrientes y auditorías (cobradas o pendientes)
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={exportCSV}
            className="primary-action-dark-white px-4 py-2 bg-neutral-900 hover:bg-neutral-800 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Download className="w-4 h-4 text-white" />
            Exportar CSV
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="p-4 bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200 dark:border-neutral-800 space-y-3 shadow-xs">
        {/* Module Type Tabs */}
        <div className="flex flex-wrap gap-1.5">
          {[
            { key: 'ALL', label: 'Todo el Historial' },
            { key: 'VENTAS', label: 'Ventas Facturadas' },
            { key: 'COMPRAS', label: 'Compras a Proveedores' },
            { key: 'CUENTAS', label: 'Cuentas Corrientes' },
            { key: 'AUDITORIA', label: 'Auditoría del Sistema' },
          ].map(tab => (
            <button
              key={tab.key}
              type="button"
              onClick={() => setActiveType(tab.key as any)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                activeType === tab.key
                  ? 'bg-neutral-900 dark:bg-indigo-600 text-white shadow-xs'
                  : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-700'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 pt-2 border-t border-neutral-100 dark:border-neutral-800">
          {/* Search box */}
          <div className="sm:col-span-6 relative">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-neutral-400" />
            <input
              ref={searchInputRef}
              type="text"
              placeholder="Buscar por ticket, proveedor, concepto, cliente o producto..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-neutral-50 dark:bg-neutral-800/80 border border-neutral-200 dark:border-neutral-700 rounded-lg text-xs text-neutral-900 dark:text-white focus:bg-white dark:focus:bg-neutral-900 focus:outline-hidden focus:ring-2 focus:ring-neutral-900 dark:focus:ring-indigo-500"
            />
          </div>

          {/* User selector */}
          <div className="sm:col-span-3">
            <select
              value={selectedUserId}
              onChange={(e) => setSelectedUserId(e.target.value)}
              className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800/80 border border-neutral-200 dark:border-neutral-700 rounded-lg text-xs font-medium text-neutral-700 dark:text-neutral-200 focus:outline-hidden focus:ring-2 focus:ring-neutral-900 dark:focus:ring-indigo-500"
            >
              <option value="ALL">Todos los Usuarios</option>
              {users.map(u => (
                <option key={u.id} value={u.id}>
                  {u.name} ({u.role})
                </option>
              ))}
            </select>
          </div>

          {/* Date range selector */}
          <div className="sm:col-span-3">
            <select
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value as any)}
              className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800/80 border border-neutral-200 dark:border-neutral-700 rounded-lg text-xs font-medium text-neutral-700 dark:text-neutral-200 focus:outline-hidden focus:ring-2 focus:ring-neutral-900 dark:focus:ring-indigo-500"
            >
              <option value="ALL">Todo el Tiempo</option>
              <option value="TODAY">Solo Hoy</option>
              <option value="WEEK">Últimos 7 Días</option>
            </select>
          </div>
        </div>
      </div>

      {/* Synthetic load test: isolated from live POS records and storage. */}
      <div className="p-4 bg-neutral-50 dark:bg-neutral-900/70 rounded-xl border border-dashed border-neutral-300 dark:border-neutral-700 space-y-3">
        <div>
          <h3 className="text-sm font-bold text-neutral-800 dark:text-neutral-100">Prueba de carga simulada del Historial</h3>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">Genera registros ficticios solo en memoria. No crea ventas reales ni modifica localStorage, IndexedDB o la sincronización.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {[1000, 5000, 10000].map(count => (
            <button key={count} type="button" onClick={() => runHistoryLoadTest(count)} className="px-3 py-2 rounded-lg text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white">Probar {count.toLocaleString('es-AR')} registros</button>
          ))}
        </div>
        <div className="pt-2 border-t border-neutral-200 dark:border-neutral-700 space-y-2">
          <div>
            <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-100">Diagnóstico del historial real</h4>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">Mide los registros ya cargados en memoria y el coste de ordenar una copia y aplicar los filtros actuales. No guarda ni modifica información.</p>
          </div>
          <button type="button" onClick={runRealHistoryDiagnostic} className="px-3 py-2 rounded-lg text-xs font-bold bg-neutral-800 hover:bg-neutral-700 dark:bg-neutral-700 dark:hover:bg-neutral-600 text-white">Medir historial real (solo lectura)</button>
          {realHistoryDiagnostic && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="rounded-lg bg-white dark:bg-neutral-800 p-3"><div className="text-neutral-500">Total de registros</div><strong>{realHistoryDiagnostic.total.toLocaleString('es-AR')}</strong></div>
              <div className="rounded-lg bg-white dark:bg-neutral-800 p-3"><div className="text-neutral-500">Ventas / compras</div><strong>{realHistoryDiagnostic.sales.toLocaleString('es-AR')} / {realHistoryDiagnostic.purchases.toLocaleString('es-AR')}</strong></div>
              <div className="rounded-lg bg-white dark:bg-neutral-800 p-3"><div className="text-neutral-500">Cuentas / auditoría</div><strong>{realHistoryDiagnostic.accounts.toLocaleString('es-AR')} / {realHistoryDiagnostic.audit.toLocaleString('es-AR')}</strong></div>
              <div className="rounded-lg bg-white dark:bg-neutral-800 p-3"><div className="text-neutral-500">Ordenar copia / filtrar</div><strong>{realHistoryDiagnostic.sortMs.toFixed(2)} / {realHistoryDiagnostic.filterMs.toFixed(2)} ms</strong></div>
              <div className="rounded-lg bg-white dark:bg-neutral-800 p-3"><div className="text-neutral-500">Coinciden filtros actuales</div><strong>{realHistoryDiagnostic.visible.toLocaleString('es-AR')}</strong></div>
            </div>
          )}
        </div>
        {loadTestResult && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
            <div className="rounded-lg bg-white dark:bg-neutral-800 p-3"><div className="text-neutral-500">Registros simulados</div><strong>{loadTestResult.count.toLocaleString('es-AR')}</strong></div>
            <div className="rounded-lg bg-white dark:bg-neutral-800 p-3"><div className="text-neutral-500">Generación</div><strong>{loadTestResult.buildMs.toFixed(2)} ms</strong></div>
            <div className="rounded-lg bg-white dark:bg-neutral-800 p-3"><div className="text-neutral-500">Ordenamiento</div><strong>{loadTestResult.sortMs.toFixed(2)} ms</strong></div>
            <div className="rounded-lg bg-white dark:bg-neutral-800 p-3"><div className="text-neutral-500">Filtro / coincidencias</div><strong>{loadTestResult.filterMs.toFixed(2)} ms / {loadTestResult.matches}</strong></div>
          </div>
        )}
      </div>

      {/* Timeline List */}
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-50 dark:bg-neutral-800/90 border-b border-neutral-200 dark:border-neutral-700 text-neutral-500 dark:text-neutral-400 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="px-4 py-3">Fecha & Hora</th>
                <th className="px-4 py-3">Tipo</th>
                <th className="px-4 py-3">Operación / Detalle</th>
                <th className="px-4 py-3">Usuario</th>
                <th className="px-4 py-3">Medio / Estado</th>
                <th className="px-4 py-3 text-right">Importe ($)</th>
                <th className="px-4 py-3 text-center">Detalle (Ojito)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
              {visibleItems.map((item) => {
                const isSale = item.type === 'VENTA';
                const isPurchase = item.type === 'COMPRA';
                const isAccount = item.type === 'COBRO_CTA';
                const isAudit = item.type === 'AUDITORIA';

                return (
                  <tr key={item.id} className="hover:bg-neutral-50/80 dark:hover:bg-neutral-800/50 transition-colors">
                    <td className="px-4 py-3 font-mono text-neutral-600 dark:text-neutral-300 whitespace-nowrap">
                      {item.displayDate}{' '}
                      <span className="text-neutral-400 dark:text-neutral-500">
                        {item.displayTime}
                      </span>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                        isSale 
                          ? 'bg-neutral-900 text-white dark:bg-neutral-700 dark:text-white' 
                          : isPurchase 
                          ? 'bg-amber-100 text-amber-900 dark:bg-amber-950/70 dark:text-amber-300' 
                          : isAccount 
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-300' 
                          : 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/70 dark:text-indigo-300'
                      }`}>
                        {item.type === 'COBRO_CTA' ? 'CTA. CTE.' : item.type}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-semibold text-neutral-900 dark:text-white">{item.title}</div>
                      <div className="text-[11px] text-neutral-500 dark:text-neutral-400 line-clamp-1 mt-0.5">
                        {item.subtitle}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-neutral-700 dark:text-neutral-300 whitespace-nowrap">
                      <div className="font-medium">{item.userName}</div>
                    </td>
                    <td className="px-4 py-3 text-neutral-600 dark:text-neutral-300 whitespace-nowrap">
                      <div className="flex flex-col gap-0.5 items-start">
                        <span className="font-medium text-[11px]">{item.paymentMethod || '-'}</span>
                        {item.statusLabel && (
                          <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                            item.isPaid
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800'
                              : 'bg-amber-50 text-amber-700 border border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800'
                          }`}>
                            {item.statusLabel}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-bold text-sm whitespace-nowrap">
                      {item.amount !== undefined ? (
                        <span className={isSale ? 'text-neutral-900 dark:text-white' : isPurchase ? 'text-rose-600 dark:text-rose-400' : 'text-emerald-700 dark:text-emerald-400'}>
                          ${formatThousands(item.amount)}
                        </span>
                      ) : (
                        <span className="text-neutral-400 font-normal">-</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <button
                        type="button"
                        onClick={() => setSelectedItem(item)}
                        className="p-1.5 text-neutral-600 dark:text-neutral-300 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-neutral-800 rounded-lg transition-colors shadow-2xs border border-transparent hover:border-indigo-200 dark:hover:border-neutral-700"
                        title={`Ver con el ojito el detalle completo de ${item.title}`}
                      >
                        <Eye className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                      </button>
                    </td>
                  </tr>
                );
              })}

              {filteredItems.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-neutral-400 dark:text-neutral-500">
                    No se encontraron registros con los filtros seleccionados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {filteredItems.length > visibleItems.length && (
        <div className="flex flex-col items-center gap-2 py-3">
          <p className="text-xs text-neutral-500 dark:text-neutral-400">
            Mostrando {visibleItems.length.toLocaleString()} de {filteredItems.length.toLocaleString()} registros. El historial completo se conserva.
          </p>
          <button
            type="button"
            onClick={() => setVisibleCount(current => Math.min(current + 100, filteredItems.length))}
            className="px-4 py-2 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-bold transition-colors"
          >
            Cargar 100 registros más
          </button>
        </div>
      )}

      {/* COMPLETE DETAIL MODAL (OJITO VIEW) FOR ANY ITEM IN HISTORY */}
      {selectedItem && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-neutral-900 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-neutral-200 dark:border-neutral-700 flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95">
            {/* Modal Header */}
            <div className="p-4 bg-neutral-900 dark:bg-neutral-950 text-white flex items-center justify-between border-b border-neutral-800">
              <div className="flex items-center gap-2.5">
                {selectedItem.type === 'VENTA' && <Receipt className="w-5 h-5 text-emerald-400" />}
                {selectedItem.type === 'COMPRA' && <Truck className="w-5 h-5 text-amber-400" />}
                {selectedItem.type === 'COBRO_CTA' && <DollarSign className="w-5 h-5 text-indigo-400" />}
                {selectedItem.type === 'AUDITORIA' && <ShieldAlert className="w-5 h-5 text-rose-400" />}
                <div>
                  <h3 className="font-bold text-sm leading-tight text-white">{selectedItem.title}</h3>
                  <p className="text-[11px] text-neutral-400">{selectedItem.subtitle}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedItem(null)}
                className="text-neutral-400 hover:text-white p-1 rounded-lg hover:bg-neutral-800 transition-colors"
                title="Cerrar ventana"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-5 overflow-y-auto space-y-4 text-xs">
              {/* Status and Summary Header */}
              <div className="p-3 bg-neutral-50 dark:bg-neutral-800/80 rounded-xl border border-neutral-200 dark:border-neutral-700 flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block font-medium">Estado del registro</span>
                  <span className={`inline-flex items-center gap-1 font-bold text-xs px-2 py-0.5 rounded-full mt-0.5 ${
                    selectedItem.isPaid
                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300'
                      : 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300'
                  }`}>
                    <CheckCircle2 className="w-3 h-3" />
                    {selectedItem.statusLabel || (selectedItem.isPaid ? 'Cobrado / Liquidado' : 'Pendiente')}
                  </span>
                </div>
                {selectedItem.amount !== undefined && (
                  <div className="text-right">
                    <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block font-medium">Monto Total</span>
                    <span className="font-mono font-black text-lg text-neutral-900 dark:text-white">
                      ${formatThousands(selectedItem.amount)}
                    </span>
                  </div>
                )}
              </div>

              {/* DETAILS FOR: VENTA */}
              {selectedItem.type === 'VENTA' && (() => {
                const sale: Sale = selectedItem.rawObject;
                if (!sale || !sale.items) {
                  // Fallback for external service sale
                  const es = selectedItem.rawObject as ExternalServiceSale;
                  return (
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-2 p-3 bg-neutral-50 dark:bg-neutral-800/50 rounded-xl border border-neutral-200 dark:border-neutral-700 text-[11px]">
                        <div><strong className="text-neutral-500 dark:text-neutral-400">Servicio:</strong> <span className="font-bold text-neutral-900 dark:text-white">{es?.serviceName || es?.service}</span></div>
                        <div><strong className="text-neutral-500 dark:text-neutral-400">Medio:</strong> <span className="text-neutral-800 dark:text-neutral-200">Efectivo</span></div>
                        <div><strong className="text-neutral-500 dark:text-neutral-400">Cajero:</strong> <span className="text-neutral-800 dark:text-neutral-200">{es?.userName}</span></div>
                        <div><strong className="text-neutral-500 dark:text-neutral-400">Fecha:</strong> <span className="text-neutral-800 dark:text-neutral-200">{new Date(selectedItem.timestamp).toLocaleString()}</span></div>
                      </div>
                      {es?.notes && (
                        <div className="p-3 bg-sky-50 dark:bg-sky-950/30 rounded-xl border border-sky-200 dark:border-sky-800 text-sky-900 dark:text-sky-200">
                          <strong>Notas / Referencia:</strong> {es.notes}
                        </div>
                      )}
                    </div>
                  );
                }

                return (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 p-3 bg-neutral-50 dark:bg-neutral-800/50 rounded-xl border border-neutral-200 dark:border-neutral-700 text-[11px]">
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">Comprobante</span>
                        <span className="font-mono font-bold text-neutral-900 dark:text-white">Ticket #{sale.receiptNumber}</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">Cliente</span>
                        <span className="font-bold text-neutral-900 dark:text-white">{sale.clientName || 'Consumidor Final'}</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">Forma de Pago</span>
                        <span className="font-bold text-neutral-900 dark:text-white">{sale.paymentMethod}</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">Cajero / Operador</span>
                        <span className="text-neutral-800 dark:text-neutral-200">{sale.userName}</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">Terminal</span>
                        <span className="text-neutral-800 dark:text-neutral-200">{sale.terminalId}</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">Fecha y Hora</span>
                        <span className="text-neutral-800 dark:text-neutral-200">{new Date(sale.timestamp).toLocaleString()}</span>
                      </div>
                    </div>

                    {/* Additional payment details if available */}
                    {sale.paymentDetails && Object.keys(sale.paymentDetails).length > 0 && (
                      <div className="p-2.5 bg-neutral-100 dark:bg-neutral-800 rounded-lg text-[11px] text-neutral-700 dark:text-neutral-300 space-y-0.5 font-mono">
                        {sale.paymentDetails.cashReceived !== undefined && (
                          <div>Importe recibido: ${formatThousands(sale.paymentDetails.cashReceived)} | Vuelto: ${formatThousands(sale.paymentDetails.cashChange || 0)}</div>
                        )}
                        {sale.paymentDetails.mpTransactionId && (
                          <div>Transacción Mercado Pago: #{sale.paymentDetails.mpTransactionId}</div>
                        )}
                        {sale.paymentDetails.transferRef && (
                          <div>Comprobante Transferencia: {sale.paymentDetails.transferRef}</div>
                        )}
                        {sale.paymentDetails.cardBrand && (
                          <div>Tarjeta: {sale.paymentDetails.cardBrand} ****{sale.paymentDetails.cardLastFour || ''} (Cupón: {sale.paymentDetails.couponNumber || '-'})</div>
                        )}
                      </div>
                    )}

                    {/* Products Table */}
                    <div>
                      <h4 className="font-bold text-neutral-800 dark:text-neutral-200 mb-1.5 uppercase text-[10px] tracking-wider">
                        Productos de la Venta ({sale.items.length})
                      </h4>
                      <div className="border border-neutral-200 dark:border-neutral-700 rounded-xl overflow-hidden">
                        <table className="w-full text-left text-xs">
                          <thead className="bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 font-semibold text-[10px] uppercase">
                            <tr>
                              <th className="p-2">Cant.</th>
                              <th className="p-2">Descripción</th>
                              <th className="p-2 text-right">Unitario</th>
                              <th className="p-2 text-right">Total</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-neutral-200 dark:divide-neutral-700">
                            {sale.items.map((it, idx) => (
                              <tr key={idx} className="hover:bg-neutral-50 dark:hover:bg-neutral-800/40">
                                <td className="p-2 font-mono font-bold text-neutral-900 dark:text-white">{it.quantity}x</td>
                                <td className="p-2 text-neutral-800 dark:text-neutral-200">{it.name}</td>
                                <td className="p-2 text-right font-mono text-neutral-600 dark:text-neutral-400">${formatThousands(it.unitPrice)}</td>
                                <td className="p-2 text-right font-mono font-bold text-neutral-900 dark:text-white">${formatThousands(it.total)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    {/* Totals Breakdown */}
                    <div className="p-3 bg-neutral-50 dark:bg-neutral-800/50 rounded-xl border border-neutral-200 dark:border-neutral-700 space-y-1 text-xs">
                      <div className="flex justify-between text-neutral-600 dark:text-neutral-400">
                        <span>Subtotal:</span>
                        <span className="font-mono font-bold">${formatThousands(sale.subtotal || sale.total)}</span>
                      </div>
                      {Boolean(sale.discount && sale.discount > 0) && (
                        <div className="flex justify-between text-emerald-600 dark:text-emerald-400 font-bold">
                          <span>Descuento Aplicado:</span>
                          <span className="font-mono">-${formatThousands(sale.discount)}</span>
                        </div>
                      )}
                      <div className="flex justify-between items-baseline pt-1 border-t border-neutral-200 dark:border-neutral-700 font-bold text-neutral-900 dark:text-white text-sm">
                        <span>TOTAL FINAL:</span>
                        <span className="font-mono text-base font-black text-emerald-600 dark:text-emerald-400">
                          ${formatThousands(sale.total)}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* DETAILS FOR: COMPRA A PROVEEDOR */}
              {selectedItem.type === 'COMPRA' && (() => {
                const purchase: Purchase = selectedItem.rawObject;
                if (!purchase) return null;

                return (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 p-3 bg-neutral-50 dark:bg-neutral-800/50 rounded-xl border border-neutral-200 dark:border-neutral-700 text-[11px]">
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">Proveedor</span>
                        <span className="font-bold text-neutral-900 dark:text-white">{purchase.supplierName}</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">N° Factura / Remito</span>
                        <span className="font-mono font-bold text-neutral-900 dark:text-white">{purchase.invoiceNumber}</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">Forma de Pago</span>
                        <span className="font-bold text-neutral-900 dark:text-white">{purchase.paymentMethod}</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">CUIT / Tax ID</span>
                        <span className="text-neutral-800 dark:text-neutral-200 font-mono">{purchase.supplierTaxId || 'S/D'}</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">Responsable</span>
                        <span className="text-neutral-800 dark:text-neutral-200">{purchase.userName}</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">Fecha y Hora</span>
                        <span className="text-neutral-800 dark:text-neutral-200">{new Date(purchase.timestamp).toLocaleString()}</span>
                      </div>
                    </div>

                    {purchase.paymentRef && (
                      <div className="p-2.5 bg-neutral-100 dark:bg-neutral-800 rounded-lg text-[11px] text-neutral-700 dark:text-neutral-300">
                        <strong>Referencia o Comprobante de Pago:</strong> {purchase.paymentRef}
                      </div>
                    )}

                    {/* Insumos / Artículos Comprados */}
                    <div>
                      <h4 className="font-bold text-neutral-800 dark:text-neutral-200 mb-1.5 uppercase text-[10px] tracking-wider">
                        Mercadería Ingresada al Stock ({purchase.items?.length || 0})
                      </h4>
                      <div className="border border-neutral-200 dark:border-neutral-700 rounded-xl overflow-hidden">
                        <table className="w-full text-left text-xs">
                          <thead className="bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 font-semibold text-[10px] uppercase">
                            <tr>
                              <th className="p-2">Cant.</th>
                              <th className="p-2">Insumo / Producto</th>
                              <th className="p-2 text-right">Costo Unit.</th>
                              <th className="p-2 text-right">Subtotal</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-neutral-200 dark:divide-neutral-700">
                            {purchase.items?.map((it, idx) => (
                              <tr key={idx} className="hover:bg-neutral-50 dark:hover:bg-neutral-800/40">
                                <td className="p-2 font-mono font-bold text-neutral-900 dark:text-white">{it.quantity}x</td>
                                <td className="p-2 text-neutral-800 dark:text-neutral-200">{it.name}</td>
                                <td className="p-2 text-right font-mono text-neutral-600 dark:text-neutral-400">${formatThousands(it.costPrice)}</td>
                                <td className="p-2 text-right font-mono font-bold text-neutral-900 dark:text-white">${formatThousands(it.total)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    <div className="p-3 bg-neutral-50 dark:bg-neutral-800/50 rounded-xl border border-neutral-200 dark:border-neutral-700 flex justify-between items-center text-sm font-bold text-neutral-900 dark:text-white">
                      <span>TOTAL FACTURA PROVEEDOR:</span>
                      <span className="font-mono text-base font-black text-rose-600 dark:text-rose-400">
                        ${formatThousands(purchase.total)}
                      </span>
                    </div>
                  </div>
                );
              })()}

              {/* DETAILS FOR: CUENTA CORRIENTE (COBROS & CARGOS) */}
              {selectedItem.type === 'COBRO_CTA' && (() => {
                const raw = selectedItem.rawObject;
                const movement: AccountMovement = raw?.movement;
                const linkedSale: Sale = raw?.linkedSale;
                const linkedPurchase: Purchase = raw?.linkedPurchase;

                return (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-2.5 p-3 bg-neutral-50 dark:bg-neutral-800/50 rounded-xl border border-neutral-200 dark:border-neutral-700 text-[11px]">
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">Titular de la Cuenta</span>
                        <span className="font-bold text-neutral-900 dark:text-white">{movement?.accountName || selectedItem.title}</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">Tipo de Operación</span>
                        <span className={`font-bold ${movement?.type === 'DEBIT' ? 'text-amber-600' : 'text-emerald-600'}`}>
                          {movement?.type === 'DEBIT' ? 'Cargo (Deuda en Cuenta)' : 'Cobro / Abono Acreditado'}
                        </span>
                      </div>
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">Concepto</span>
                        <span className="text-neutral-800 dark:text-neutral-200">{movement?.concept || selectedItem.subtitle}</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">Medio de Pago / Cobro</span>
                        <span className="text-neutral-800 dark:text-neutral-200 font-medium">{movement?.paymentMethod || 'Acreditación en Cuenta'}</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">Cajero / Operador</span>
                        <span className="text-neutral-800 dark:text-neutral-200">{movement?.userName}</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">Fecha y Hora</span>
                        <span className="text-neutral-800 dark:text-neutral-200">{new Date(selectedItem.timestamp).toLocaleString()}</span>
                      </div>
                    </div>

                    {/* If linked to a sale, show products included */}
                    {linkedSale && (
                      <div>
                        <div className="flex items-center justify-between mb-1.5">
                          <h4 className="font-bold text-neutral-800 dark:text-neutral-200 uppercase text-[10px] tracking-wider flex items-center gap-1.5">
                            <Receipt className="w-3.5 h-3.5 text-indigo-500" />
                            <span>Ticket de Venta Asociado #{linkedSale.receiptNumber}</span>
                          </h4>
                          <span className="text-[10px] font-mono font-bold bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded">
                            Total Venta: ${formatThousands(linkedSale.total)}
                          </span>
                        </div>
                        <div className="border border-neutral-200 dark:border-neutral-700 rounded-xl overflow-hidden">
                          <table className="w-full text-left text-xs">
                            <thead className="bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 font-semibold text-[10px] uppercase">
                              <tr>
                                <th className="p-2">Cant.</th>
                                <th className="p-2">Producto Cargado a Cuenta</th>
                                <th className="p-2 text-right">Precio</th>
                                <th className="p-2 text-right">Total</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-neutral-200 dark:divide-neutral-700">
                              {linkedSale.items.map((it, idx) => (
                                <tr key={idx} className="hover:bg-neutral-50 dark:hover:bg-neutral-800/40">
                                  <td className="p-2 font-mono font-bold text-neutral-900 dark:text-white">{it.quantity}x</td>
                                  <td className="p-2 text-neutral-800 dark:text-neutral-200">{it.name}</td>
                                  <td className="p-2 text-right font-mono text-neutral-600 dark:text-neutral-400">${formatThousands(it.unitPrice)}</td>
                                  <td className="p-2 text-right font-mono font-bold text-neutral-900 dark:text-white">${formatThousands(it.total)}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}

                    {/* If linked to a purchase, show products included */}
                    {linkedPurchase && (
                      <div>
                        <div className="flex items-center justify-between mb-1.5">
                          <h4 className="font-bold text-neutral-800 dark:text-neutral-200 uppercase text-[10px] tracking-wider flex items-center gap-1.5">
                            <Truck className="w-3.5 h-3.5 text-amber-500" />
                            <span>Factura de Compra Asociada #{linkedPurchase.invoiceNumber}</span>
                          </h4>
                          <span className="text-[10px] font-mono font-bold bg-amber-50 text-amber-700 px-2 py-0.5 rounded">
                            Total Compra: ${formatThousands(linkedPurchase.total)}
                          </span>
                        </div>
                        <div className="border border-neutral-200 dark:border-neutral-700 rounded-xl overflow-hidden">
                          <table className="w-full text-left text-xs">
                            <thead className="bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 font-semibold text-[10px] uppercase">
                              <tr>
                                <th className="p-2">Cant.</th>
                                <th className="p-2">Insumo</th>
                                <th className="p-2 text-right">Costo</th>
                                <th className="p-2 text-right">Total</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-neutral-200 dark:divide-neutral-700">
                              {linkedPurchase.items?.map((it, idx) => (
                                <tr key={idx} className="hover:bg-neutral-50 dark:hover:bg-neutral-800/40">
                                  <td className="p-2 font-mono font-bold text-neutral-900 dark:text-white">{it.quantity}x</td>
                                  <td className="p-2 text-neutral-800 dark:text-neutral-200">{it.name}</td>
                                  <td className="p-2 text-right font-mono text-neutral-600 dark:text-neutral-400">${formatThousands(it.costPrice)}</td>
                                  <td className="p-2 text-right font-mono font-bold text-neutral-900 dark:text-white">${formatThousands(it.total)}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}

                    {!linkedSale && !linkedPurchase && (
                      <div className="p-3 bg-neutral-100 dark:bg-neutral-800/70 rounded-xl text-neutral-600 dark:text-neutral-400 text-xs">
                        Movimiento directo de dinero aplicado sobre el saldo de la cuenta corriente.
                      </div>
                    )}

                    <div className="p-3 bg-neutral-50 dark:bg-neutral-800/50 rounded-xl border border-neutral-200 dark:border-neutral-700 flex justify-between items-center text-sm font-bold text-neutral-900 dark:text-white">
                      <span>MONTO DEL MOVIMIENTO:</span>
                      <span className={`font-mono text-base font-black ${
                        movement?.type === 'DEBIT' ? 'text-amber-600' : 'text-emerald-600'
                      }`}>
                        ${formatThousands(selectedItem.amount || 0)}
                      </span>
                    </div>
                  </div>
                );
              })()}

              {/* DETAILS FOR: AUDITORIA DEL SISTEMA */}
              {selectedItem.type === 'AUDITORIA' && (() => {
                const audit: AuditLog = selectedItem.rawObject;
                if (!audit) return null;

                return (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-2.5 p-3 bg-neutral-50 dark:bg-neutral-800/50 rounded-xl border border-neutral-200 dark:border-neutral-700 text-[11px]">
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">Módulo del Sistema</span>
                        <span className="font-bold text-neutral-900 dark:text-white font-mono uppercase">[{audit.module}]</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">Acción Ejecutada</span>
                        <span className="font-bold text-indigo-600 dark:text-indigo-400 font-mono">{audit.action}</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">Usuario Responsable</span>
                        <span className="text-neutral-800 dark:text-neutral-200 font-medium">{audit.userName} ({audit.userRole})</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-400 block">Terminal</span>
                        <span className="text-neutral-800 dark:text-neutral-200 font-mono">{audit.terminalId}</span>
                      </div>
                      <div className="col-span-2">
                        <span className="text-neutral-500 dark:text-neutral-400 block">Fecha y Hora Exacta</span>
                        <span className="text-neutral-800 dark:text-neutral-200 font-mono">{new Date(audit.timestamp).toLocaleString()}</span>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-bold text-neutral-800 dark:text-neutral-200 mb-1 uppercase text-[10px] tracking-wider">
                        Descripción de la Actividad
                      </h4>
                      <div className="p-3 bg-neutral-50 dark:bg-neutral-800/80 rounded-xl border border-neutral-200 dark:border-neutral-700 text-xs text-neutral-900 dark:text-neutral-100 font-medium leading-relaxed">
                        {audit.description}
                      </div>
                    </div>

                    {/* Metadata / Details if present */}
                    {audit.details && Object.keys(audit.details).length > 0 && (
                      <div>
                        <h4 className="font-bold text-neutral-800 dark:text-neutral-200 mb-1 uppercase text-[10px] tracking-wider">
                          Datos y Parámetros Técnicos
                        </h4>
                        <div className="p-3 bg-neutral-900 dark:bg-neutral-950 text-neutral-200 rounded-xl font-mono text-[11px] overflow-x-auto space-y-1">
                          {Object.entries(audit.details).map(([k, v]) => (
                            <div key={k} className="flex gap-2">
                              <span className="text-indigo-400 font-semibold">{k}:</span>
                              <span>{typeof v === 'object' ? JSON.stringify(v) : String(v)}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-neutral-100 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 flex items-center justify-between">
              <div>
                {(selectedItem.type === 'VENTA' || selectedItem.type === 'COMPRA' || selectedItem.type === 'COBRO_CTA') && (
                  <button
                    type="button"
                    onClick={() => window.print()}
                    className="px-4 py-2 border border-neutral-300 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
                  >
                    <Printer className="w-4 h-4" />
                    <span>Imprimir Comprobante</span>
                  </button>
                )}
              </div>
              <button
                type="button"
                onClick={() => setSelectedItem(null)}
                className="px-5 py-2 bg-neutral-900 hover:bg-neutral-800 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
              >
                Cerrar Detalle
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
