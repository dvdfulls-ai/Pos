import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { 
  Barcode, 
  Search, 
  Trash2, 
  Plus, 
  Minus, 
  CreditCard, 
  Banknote, 
  QrCode, 
  UserCheck, 
  Receipt, 
  AlertCircle,
  Printer,
  CheckCircle2,
  Sparkles,
  Camera,
  X,
  Tv,
  Settings,
  Wallet,
  Clock,
  Pause,
  Play,
  Zap,
  Radio,
  RefreshCw,
  ArrowDownRight,
  Check,
  Smartphone,
  FileText,
  Eye,
  EyeOff,
  Percent,
  Package
} from 'lucide-react';
import { useSalesApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import { Article, PaymentMethod, Sale, PaymentConfig, ParkedSale, ReceivedTransferItem } from '../../types';
import { StorageService, OFFICIAL_MP_QRS } from '../../services/storage';
import { PaymentConfigModal } from '../customer/PaymentConfigModal';
import { MercadoPagoService } from '../../services/mercadoPagoService';
import { generateArgentinaInteroperableQr } from '../../utils/emvco';
import { DialogService } from '../../services/dialog';
import { QuickArticleModal } from '../../components/common/QuickArticleModal';
import { matchesQuery, formatThousands, parseFormattedNumber, toTitleCase } from '../../utils/text';

const SalesModuleComponent: React.FC = () => {
  const { 
    articles, 
    addArticle,
    adjustStock,
    cart, 
    addToCart, 
    removeFromCart, 
    updateCartQuantity, 
    clearCart, 
    loadCart,
    cartTotal,
    processSale,
    currentShift,
    accounts,
    currentTerminalId,
    addExternalServiceSale,
    sales
  } = useSalesApp();

  const { hasPermission } = useAuth();

  // Barcode & Article search input
  const [barcodeInput, setBarcodeInput] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('TODOS');
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [lastCompletedSale, setLastCompletedSale] = useState<Sale | null>(null);
  const [showTicketModal, setShowTicketModal] = useState(false);
  const [quickStockArticle, setQuickStockArticle] = useState<Article | null>(null);
  const [quickStockAmount, setQuickStockAmount] = useState('');
  // Detecta ráfagas de dígitos terminadas en Enter (lectores de código de barras)
  // dentro del campo de ajuste manual, para impedir que un escaneo cambie el stock.
  const quickStockKeyBurstRef = useRef<{ key: string; at: number }[]>([]);
  const [showArticleNotFound, setShowArticleNotFound] = useState(false);
  const [notFoundButtonIndex, setNotFoundButtonIndex] = useState(1);
  const notFoundCancelButtonRef = useRef<HTMLButtonElement>(null);
  const notFoundAddButtonRef = useRef<HTMLButtonElement>(null);
  const [notFoundCode, setNotFoundCode] = useState('');

  const [showQuickAddArticle, setShowQuickAddArticle] = useState(false);
  const [quickArticleForm, setQuickArticleForm] = useState({ barcode: '', name: '', brand: '', category: '', costPrice: '0', salePrice: '0', stock: '0', minStock: '0' });
  const quickArticleBarcodeRef = useRef<HTMLInputElement>(null);
  const quickArticleNameRef = useRef<HTMLInputElement>(null);

  // Navegación por teclado exclusiva del aviso «Artículo no encontrado».
  useEffect(() => {
    if (!showArticleNotFound || showQuickAddArticle) return;
    const handleNotFoundKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
        event.preventDefault();
        event.stopPropagation();
        setNotFoundButtonIndex((current) => (current + 1) % 2);
      } else if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
        event.preventDefault();
        event.stopPropagation();
        setNotFoundButtonIndex((current) => (current + 1) % 2);
      } else if (event.key === 'Enter') {
        event.preventDefault();
        event.stopPropagation();
        (notFoundButtonIndex === 0 ? notFoundCancelButtonRef.current : notFoundAddButtonRef.current)?.click();
      }
    };
    window.addEventListener('keydown', handleNotFoundKeyDown, true);
    return () => window.removeEventListener('keydown', handleNotFoundKeyDown, true);
  }, [showArticleNotFound, showQuickAddArticle, notFoundButtonIndex]);

  // Un único zoom compartido entre Artículos, Comprobante y todas las ventanas del sistema.
  const ZOOM_LEVELS = [
    { percent: 100, label: '100%' },
    { percent: 115, label: '115%' },
    { percent: 130, label: '130%' },
    { percent: 150, label: '150%' },
  ];

  const [sharedZoomIndex, setSharedZoomIndex] = useState<number>(() => {
    try {
      const shared = localStorage.getItem('pos_global_zoom');
      if (shared !== null) {
        const value = parseInt(shared, 10);
        if (!isNaN(value) && value >= 0 && value < ZOOM_LEVELS.length) return value;
      }
      const oldArticles = parseInt(localStorage.getItem('pos_sales_articles_zoom') || '0', 10);
      const oldCart = parseInt(localStorage.getItem('pos_sales_cart_zoom') || '0', 10);
      return Math.max(0, Math.min(ZOOM_LEVELS.length - 1, Math.max(oldArticles || 0, oldCart || 0)));
    } catch {}
    return 0;
  });

  const handleSharedZoomChange = (newIndex: number) => {
    const clamped = Math.max(0, Math.min(ZOOM_LEVELS.length - 1, newIndex));
    setSharedZoomIndex(clamped);
    try {
      localStorage.setItem('pos_global_zoom', clamped.toString());
      // Keep legacy keys aligned for compatibility with existing saved settings.
      localStorage.setItem('pos_sales_articles_zoom', clamped.toString());
      localStorage.setItem('pos_sales_cart_zoom', clamped.toString());
    } catch {}
    window.dispatchEvent(new CustomEvent('pos-global-zoom-change', { detail: clamped }));
  };

  const handleArticlesZoomChange = handleSharedZoomChange;
  const handleCartZoomChange = handleSharedZoomChange;
  const articlesZoomIndex = sharedZoomIndex;
  const cartZoomIndex = sharedZoomIndex;

  // Configuración adaptable de artículos según zoom (evita deformación y se adapta a pantallas)
  const articlesZoomConfig = useMemo(() => {
    switch (articlesZoomIndex) {
      case 1: // 115% (Medio)
        return {
          gridCols: 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-3',
          cardPadding: 'p-3.5 min-h-[8.5rem]',
          brandText: 'text-[11px] font-semibold',
          stockBadge: 'text-xs px-2 py-0.5 font-bold',
          nameText: 'text-sm font-semibold leading-snug line-clamp-2',
          priceText: 'text-base font-black',
          barcodeText: 'text-[11px]',
          categoryChips: 'px-3.5 py-1.5 text-xs font-semibold',
        };
      case 2: // 130% (Grande)
        return {
          gridCols: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-3.5',
          cardPadding: 'p-4 min-h-[9.5rem]',
          brandText: 'text-xs font-bold',
          stockBadge: 'text-xs px-2.5 py-1 font-black',
          nameText: 'text-base font-bold leading-snug line-clamp-2',
          priceText: 'text-lg font-black',
          barcodeText: 'text-xs font-mono font-medium',
          categoryChips: 'px-4 py-2 text-sm font-bold',
        };
      case 3: // 150% (Extra Grande)
        return {
          gridCols: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-4',
          cardPadding: 'p-4.5 min-h-[10.5rem]',
          brandText: 'text-sm font-black',
          stockBadge: 'text-sm px-3 py-1 font-black',
          nameText: 'text-lg font-black leading-snug line-clamp-2',
          priceText: 'text-xl font-black',
          barcodeText: 'text-sm font-mono font-semibold',
          categoryChips: 'px-4.5 py-2 text-base font-black',
        };
      case 0: // 100% (Normal)
      default:
        return {
          gridCols: 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5',
          cardPadding: 'p-3 min-h-[8rem]',
          brandText: 'text-[10px]',
          stockBadge: 'text-[10px] px-1.5 py-0.5',
          nameText: 'text-xs font-semibold leading-snug line-clamp-2',
          priceText: 'text-sm font-bold',
          barcodeText: 'text-[10px]',
          categoryChips: 'px-3 py-1.5 text-xs',
        };
    }
  }, [articlesZoomIndex]);

  // Configuración adaptable de comprobante de venta según zoom
  const cartZoomConfig = useMemo(() => {
    switch (cartZoomIndex) {
      case 1: // 115% (Medio)
        return {
          columnWidth: 'w-full lg:w-[520px] xl:w-[570px] 2xl:w-[620px]',
          headerTitle: 'text-sm sm:text-base font-extrabold',
          serviceBtn: 'px-3 py-1 text-xs sm:text-sm font-bold gap-1.5',
          serviceIcon: 'w-4 h-4',
          itemName: 'text-base font-bold',
          itemDetails: 'text-xs sm:text-sm font-medium',
          qtyBtn: 'w-8 h-8',
          qtyIcon: 'w-4 h-4',
          qtyText: 'w-8 text-base font-bold',
          itemSubtotal: 'text-base font-black',
          subtotalRow: 'text-sm font-semibold',
          subtotalVal: 'text-base font-black',
          totalLabel: 'text-lg font-black',
          totalVal: 'text-3xl font-black',
          actionBtn: 'py-3.5 text-sm sm:text-base font-black',
        };
      case 2: // 130% (Grande)
        return {
          columnWidth: 'w-full lg:w-[550px] xl:w-[610px] 2xl:w-[660px]',
          headerTitle: 'text-base sm:text-lg font-black',
          serviceBtn: 'px-3.5 py-1.5 text-sm font-black gap-2',
          serviceIcon: 'w-4 h-4',
          itemName: 'text-lg font-black leading-snug',
          itemDetails: 'text-sm font-semibold',
          qtyBtn: 'w-9 h-9',
          qtyIcon: 'w-4 h-4',
          qtyText: 'w-9 text-lg font-black',
          itemSubtotal: 'text-lg font-black',
          subtotalRow: 'text-base font-bold',
          subtotalVal: 'text-lg font-black',
          totalLabel: 'text-xl font-black',
          totalVal: 'text-4xl font-black',
          actionBtn: 'py-4 text-base sm:text-lg font-black',
        };
      case 3: // 150% (Extra Grande)
        return {
          columnWidth: 'w-full lg:w-[590px] xl:w-[660px] 2xl:w-[720px]',
          headerTitle: 'text-lg sm:text-xl font-black',
          serviceBtn: 'px-4 py-2 text-base font-black gap-2',
          serviceIcon: 'w-5 h-5',
          itemName: 'text-xl font-black leading-snug',
          itemDetails: 'text-base font-semibold',
          qtyBtn: 'w-10 h-10',
          qtyIcon: 'w-5 h-5',
          qtyText: 'w-10 text-xl font-black',
          itemSubtotal: 'text-xl font-black',
          subtotalRow: 'text-lg font-extrabold',
          subtotalVal: 'text-xl font-black',
          totalLabel: 'text-2xl font-black',
          totalVal: 'text-4xl sm:text-5xl font-black',
          actionBtn: 'py-4.5 text-lg sm:text-xl font-black',
        };
      case 0: // 100% (Normal)
      default:
        return {
          columnWidth: 'w-full lg:w-[490px] xl:w-[540px] 2xl:w-[580px]',
          headerTitle: 'text-xs sm:text-sm font-bold',
          serviceBtn: 'px-2.5 py-1 text-xs font-bold gap-1.5',
          serviceIcon: 'w-3.5 h-3.5',
          itemName: 'text-sm font-semibold',
          itemDetails: 'text-xs',
          qtyBtn: 'w-7 h-7',
          qtyIcon: 'w-3.5 h-3.5',
          qtyText: 'w-8 text-sm font-bold',
          itemSubtotal: 'text-sm font-bold',
          subtotalRow: 'text-sm',
          subtotalVal: 'text-sm font-bold',
          totalLabel: 'text-base font-black',
          totalVal: 'text-2xl font-black',
          actionBtn: 'py-3 text-sm font-bold',
        };
    }
  }, [cartZoomIndex]);

  // Parked Sales state (Ventas en Espera)
  const [parkedSales, setParkedSales] = useState<ParkedSale[]>(() => StorageService.getParkedSales());
  const [showParkedSalesModal, setShowParkedSalesModal] = useState(false);
  const [showParkPromptModal, setShowParkPromptModal] = useState(false);
  const [parkReference, setParkReference] = useState('');

  // Payment modal state
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('EFECTIVO');
  const [cashAmount, setCashAmount] = useState<string>('0');
  const [transferRef, setTransferRef] = useState<string>('');
  const [walletRef, setWalletRef] = useState<string>('');
  const [selectedClientId, setSelectedClientId] = useState<string>('');
  const [mpStep, setMpStep] = useState<'GENERATING' | 'READY' | 'APPROVED'>('READY');
  const [discountAmount, setDiscountAmount] = useState<number>(0);

  // Mercado Pago: Interruptor de recargo por porcentaje configurable (persiste la última posición)
  const [mpSurchargeEnabled, setMpSurchargeEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('pos_mp_surcharge_enabled');
      return saved !== null ? saved === 'true' : false;
    } catch {
      return false;
    }
  });

  const [mpSurchargePercent, setMpSurchargePercent] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('pos_mp_surcharge_percent');
      if (saved !== null) {
        const val = parseFloat(saved);
        if (!isNaN(val) && val >= 0) return val;
      }
    } catch {}
    return 10; // 10% por defecto
  });

  useEffect(() => {
    try {
      localStorage.setItem('pos_mp_surcharge_enabled', String(mpSurchargeEnabled));
    } catch {
      // ignore
    }
  }, [mpSurchargeEnabled]);

  useEffect(() => {
    try {
      localStorage.setItem('pos_mp_surcharge_percent', String(mpSurchargePercent));
    } catch {
      // ignore
    }
  }, [mpSurchargePercent]);

  // Mercado Pago Real-Time In-Store POS Order Sync
  const [mpLiveSync, setMpLiveSync] = useState<{
    status: 'idle' | 'transmitting' | 'waiting' | 'approved' | 'error';
    orderRef: string | null;
    paymentId?: string | number;
    errorMsg?: string;
  }>({ status: 'idle', orderRef: null });

  const [mpRetryTrigger, setMpRetryTrigger] = useState(0);
  const mpPollingTimerRef = useRef<any>(null);
  const activeMpOrderRef = useRef<string | null>(null);
  const lastSyncedMpParamsRef = useRef<{
    netTotal: number;
    token: string;
    userId: string;
    posId: string;
    retryCount: number;
  } | null>(null);

  // Unmount cleanup for MP polling timer
  useEffect(() => {
    return () => {
      if (mpPollingTimerRef.current) {
        clearInterval(mpPollingTimerRef.current);
        mpPollingTimerRef.current = null;
      }
    };
  }, []);

  // Payment configuration modal (Mercado Pago & Bank accounts)
  const [showPaymentConfigModal, setShowPaymentConfigModal] = useState(false);
  const [paymentConfig, setPaymentConfig] = useState<PaymentConfig>(() => StorageService.getPaymentConfig());
  const [selectedWalletId, setSelectedWalletId] = useState<string>(() => {
    const config = StorageService.getPaymentConfig();
    return (config.wallets && config.wallets.length > 0) ? config.wallets[0].id : '';
  });
  const [forceDigitalQr, setForceDigitalQr] = useState(false);

  // Sincronizar cambios en datos de cobro / QR en tiempo real
  useEffect(() => {
    const handleConfigUpdate = () => {
      setPaymentConfig(StorageService.getPaymentConfig());
    };
    const unsubscribe = StorageService.subscribeToSync((event) => {
      if (event.type === 'PAYMENT_CONFIG_UPDATED') {
        handleConfigUpdate();
      }
    });
    window.addEventListener('pos_payment_config_updated', handleConfigUpdate);
    return () => {
      unsubscribe();
      window.removeEventListener('pos_payment_config_updated', handleConfigUpdate);
    };
  }, []);

  useEffect(() => {
    if (showCheckoutModal) {
      setPaymentConfig(StorageService.getPaymentConfig());
    }
  }, [showCheckoutModal]);

  // Tarjeta / Posnet State (Modo Manual y Modo Automático)
  const [posnetMode, setPosnetMode] = useState<'MANUAL' | 'AUTOMATIC'>(() => {
    return StorageService.getPaymentConfig().posnetMode || 'MANUAL';
  });
  const [cardType, setCardType] = useState<'DEBITO' | 'CREDITO' | 'PREPAGA'>('DEBITO');
  const [cardBrand, setCardBrand] = useState<string>('Visa');
  const [cardLastFour, setCardLastFour] = useState<string>('');
  const [couponNumber, setCouponNumber] = useState<string>('');
  const [installments, setInstallments] = useState<number>(1);
  const [posnetAutoStatus, setPosnetAutoStatus] = useState<'IDLE' | 'WAITING_CARD' | 'PROCESSING' | 'APPROVED'>('IDLE');
  const [posnetAutoAuthCode, setPosnetAutoAuthCode] = useState<string>('');
  const [posnetAutoBatch, setPosnetAutoBatch] = useState<string>('LOTE-001');

  // Transferencias en Vivo por Alias (Recepción en tiempo real, parciales y totales)
  const [receivedTransfers, setReceivedTransfers] = useState<ReceivedTransferItem[]>([]);
  const [showTransferTotalAmount, setShowTransferTotalAmount] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('pos_show_transfer_total');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('pos_show_transfer_total', String(showTransferTotalAmount));
    } catch {
      // ignore
    }
  }, [showTransferTotalAmount]);

  // Pago Mixto (Transferencia Parcial + Efectivo Restante)
  const [payRemainingInCash, setPayRemainingInCash] = useState<boolean>(false);
  const [splitCashReceived, setSplitCashReceived] = useState<string>('');

  // Interruptor de Acreditación Automática vs Selección Manual por Cajero
  const [autoAccreditTransfers, setAutoAccreditTransfers] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('pos_auto_accredit_transfers');
      return saved !== null ? saved === 'true' : false;
    } catch {
      return false;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('pos_auto_accredit_transfers', String(autoAccreditTransfers));
    } catch {
      // ignore
    }
  }, [autoAccreditTransfers]);

  // Interruptor de Tiempo Límite / Auto-ocultar en Transferencias Detectadas
  const [transfersTimerEnabled, setTransfersTimerEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('pos_transfers_timer_enabled');
      return saved !== null ? saved === 'true' : false;
    } catch {
      return false;
    }
  });

  const [transfersTimeoutSeconds, setTransfersTimeoutSeconds] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('pos_transfers_timeout_seconds');
      if (saved !== null) {
        const val = parseInt(saved, 10);
        if (!isNaN(val) && val > 0) return val;
      }
    } catch {}
    return 60; // 60 segundos por defecto
  });

  useEffect(() => {
    try {
      localStorage.setItem('pos_transfers_timer_enabled', String(transfersTimerEnabled));
    } catch {
      // ignore
    }
  }, [transfersTimerEnabled]);

  useEffect(() => {
    try {
      localStorage.setItem('pos_transfers_timeout_seconds', String(transfersTimeoutSeconds));
    } catch {
      // ignore
    }
  }, [transfersTimeoutSeconds]);

  const [allRecentMpTransfers, setAllRecentMpTransfers] = useState<ReceivedTransferItem[]>([]);

  // Registro de tiempo de detección y temporizador en vivo para cuenta regresiva
  const transferFirstSeenRef = useRef<Record<string, number>>({});
  const [currentTickTime, setCurrentTickTime] = useState<number>(Date.now());

  useEffect(() => {
    const currentSeen = { ...transferFirstSeenRef.current };
    let changed = false;
    const now = Date.now();
    for (const t of allRecentMpTransfers) {
      if (!currentSeen[t.id]) {
        currentSeen[t.id] = now;
        changed = true;
      }
    }
    if (changed) {
      transferFirstSeenRef.current = currentSeen;
    }
  }, [allRecentMpTransfers]);

  useEffect(() => {
    if (!showCheckoutModal || paymentMethod !== 'TRANSFERENCIA' || !transfersTimerEnabled) {
      return;
    }
    const interval = setInterval(() => {
      setCurrentTickTime(Date.now());
    }, 1000);
    return () => clearInterval(interval);
  }, [showCheckoutModal, paymentMethod, transfersTimerEnabled]);

  // Transferencias descartadas / quitadas para esta terminal
  const [dismissedTransferIds, setDismissedTransferIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(`pos_dismissed_transfers_${currentTerminalId || 'TERM-01'}`);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const handleDismissTransfer = (id: string) => {
    setDismissedTransferIds(prev => {
      const next = [...prev, id];
      try {
        localStorage.setItem(`pos_dismissed_transfers_${currentTerminalId || 'TERM-01'}`, JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
  };

  // Transferencias ya acreditadas en ventas previas finalizadas
  const [accreditedTransferIds, setAccreditedTransferIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('pos_accredited_transfer_ids');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const isTransferAlreadyUsed = useCallback((transferId: string, reference?: string) => {
    if (accreditedTransferIds.includes(transferId)) return true;
    if (sales && sales.length > 0) {
      return sales.some(s => {
        const list = s.paymentDetails?.transfersList;
        if (list && Array.isArray(list)) {
          return list.some(t => t.id === transferId || (reference && t.reference && t.reference === reference));
        }
        return false;
      });
    }
    return false;
  }, [accreditedTransferIds, sales]);
  const [checkoutOpenedAt, setCheckoutOpenedAt] = useState<number>(Date.now());
  const [showRecentAccountHistory, setShowRecentAccountHistory] = useState(false);
  const [isCheckingTransfers, setIsCheckingTransfers] = useState(false);
  const [simulatedPlatform, setSimulatedPlatform] = useState<string>('Naranja X');
  const [simulatedPayer, setSimulatedPayer] = useState<string>('Juan Carlos Pérez');
  const [simulatedCustomAmount, setSimulatedCustomAmount] = useState<string>('');
  const [showCustomTransferForm, setShowCustomTransferForm] = useState(false);

  // External Services (Claro & SAT) and Extras in Comprobante / Checkout
  const [showExternalServiceModal, setShowExternalServiceModal] = useState(false);
  const [serviceType, setServiceType] = useState<'CLARO' | 'SAT' | 'EXTRAS'>('CLARO');
  const [serviceAmount, setServiceAmount] = useState<string>('');
  const [serviceNotes, setServiceNotes] = useState<string>('');
  const [extraArticles, setExtraArticles] = useState<string[]>(() => StorageService.getExtraArticles());
  const [showExtraSuggestions, setShowExtraSuggestions] = useState(false);
  const [selectedSuggestionIndex, setSelectedSuggestionIndex] = useState<number>(-1);
  const extraContainerRef = useRef<HTMLDivElement>(null);
  const serviceAmountInputRef = useRef<HTMLInputElement>(null);
  const articleInputRef = useRef<HTMLInputElement>(null);

  // Close extra suggestions dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (extraContainerRef.current && !extraContainerRef.current.contains(e.target as Node)) {
        setShowExtraSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Filtered extra articles for predictive typing (capped to top 10 like Marcas in Carga de artículos)
  const matchingExtraArticles = useMemo(() => {
    const query = serviceNotes.trim();
    if (!query) return extraArticles.slice(0, 10);
    const norm = query.toLowerCase();
    return extraArticles.filter(item => item.toLowerCase().includes(norm)).slice(0, 10);
  }, [extraArticles, serviceNotes]);

  const handleOpenServiceModal = (type: 'CLARO' | 'SAT' | 'EXTRAS') => {
    setServiceType(type);
    setServiceAmount('');
    setServiceNotes('');
    setShowExtraSuggestions(false);
    setSelectedSuggestionIndex(-1);
    setExtraArticles(StorageService.getExtraArticles());
    setShowExternalServiceModal(true);
    setTimeout(() => {
      serviceAmountInputRef.current?.focus();
      serviceAmountInputRef.current?.select();
    }, 50);
  };

  const handleServiceSubmit = (e?: React.FormEvent, customNotes?: string) => {
    if (e) e.preventDefault();
    const amount = parseFormattedNumber(serviceAmount);
    if (amount <= 0) return;

    const rawNotes = (typeof customNotes === 'string' ? customNotes : serviceNotes).trim();
    const notesToUse = serviceType === 'EXTRAS' ? toTitleCase(rawNotes) : rawNotes;

    // En Extras es obligatorio escribir o elegir un artículo antes de sumar
    if (serviceType === 'EXTRAS' && !notesToUse) {
      return;
    }

    // Registrar en servicios externos / extras del turno de caja
    addExternalServiceSale(serviceType, amount, notesToUse);

    // Si es un extra con nombre, guardarlo en el listado para futuras sugerencias (independiente de marcas del inventario)
    if (serviceType === 'EXTRAS' && notesToUse) {
      const updated = StorageService.saveExtraArticle(notesToUse);
      setExtraArticles(updated);
    }

    // Sumar al comprobante de compras (carrito) para que se sume a los productos que compra el cliente
    const serviceName = serviceType === 'CLARO' 
      ? `Recarga Claro${notesToUse ? ` - ${notesToUse}` : ''}`
      : serviceType === 'SAT'
      ? `Cobranza SAT${notesToUse ? ` - ${notesToUse}` : ''}`
      : (notesToUse || 'Artículo Extra');

    const serviceArticle: Article = {
      id: `svc_${serviceType.toLowerCase()}_${Date.now()}`,
      barcode: serviceType === 'EXTRAS' ? `EXT-${Date.now().toString().slice(-6)}` : `SRV-${serviceType}`,
      name: serviceName,
      costPrice: amount,
      salePrice: amount,
      stock: 99999,
      minStock: 0,
      unit: 'u',
      category: serviceType === 'EXTRAS' ? 'EXTRAS' : 'SERVICIOS',
      brand: serviceType === 'CLARO' ? 'Claro' : serviceType === 'SAT' ? 'SAT' : 'Extras',
      updatedAt: new Date().toISOString(),
    };

    addToCart(serviceArticle, 1);

    setShowExternalServiceModal(false);
    setShowExtraSuggestions(false);
    setSelectedSuggestionIndex(-1);
    setServiceAmount('');
    setServiceNotes('');
    DialogService.alert(
      serviceType === 'EXTRAS'
        ? `Artículo Extra "${serviceName}" por $${formatThousands(amount)} sumado al comprobante con éxito.`
        : `Servicio ${serviceType} por $${formatThousands(amount)} sumado al comprobante de compra exitosamente.`,
      'Sumado al Comprobante',
      'success'
    ).then(() => {
      focusBarcodeInput();
    });
  };

  // Reiniciar estado al abrir modal de cobro para que arranque en $0
  useEffect(() => {
    if (showCheckoutModal) {
      setCheckoutOpenedAt(Date.now() - 30000); // Ventana de gracia de 30s
      setReceivedTransfers([]);
      setTransferRef('');
      setPayRemainingInCash(false);
      setSplitCashReceived('');
    }
  }, [showCheckoutModal]);

  // Polling automático de transferencias / pagos reales entrantes en Mercado Pago
  useEffect(() => {
    if (!showCheckoutModal || paymentMethod !== 'TRANSFERENCIA' || !paymentConfig.mpAccessToken) {
      return;
    }

    let isSubscribed = true;

    const fetchTransfers = async () => {
      try {
        const transfers = await MercadoPagoService.getRecentTransfers(paymentConfig.mpAccessToken || '');
        if (!isSubscribed || !transfers || transfers.length === 0) return;

        setAllRecentMpTransfers(transfers);

        // Solo vincular automáticamente si el modo automático está activo
        if (autoAccreditTransfers) {
          setReceivedTransfers(prev => {
            const existingIds = new Set(prev.map(p => p.id));
            const newItems = transfers.filter(t => 
              !existingIds.has(t.id) && 
              t.timestamp >= checkoutOpenedAt && 
              !dismissedTransferIds.includes(t.id) &&
              !isTransferAlreadyUsed(t.id, t.reference)
            );
            if (newItems.length === 0) return prev;
            return [...prev, ...newItems];
          });
        }
      } catch {
        // Silencioso
      }
    };

    fetchTransfers();
    const interval = setInterval(fetchTransfers, 4000);

    return () => {
      isSubscribed = false;
      clearInterval(interval);
    };
  }, [showCheckoutModal, paymentMethod, paymentConfig.mpAccessToken, checkoutOpenedAt, autoAccreditTransfers, dismissedTransferIds, isTransferAlreadyUsed]);

  const handleManualCheckTransfers = async () => {
    if (!paymentConfig.mpAccessToken) {
      DialogService.alert('No hay Access Token de Mercado Pago configurado.', 'Información', 'info');
      return;
    }

    setIsCheckingTransfers(true);
    try {
      const transfers = await MercadoPagoService.getRecentTransfers(paymentConfig.mpAccessToken || '');
      if (transfers && transfers.length > 0) {
        setAllRecentMpTransfers(transfers);
        if (autoAccreditTransfers) {
          setReceivedTransfers(prev => {
            const existingIds = new Set(prev.map(p => p.id));
            const newItems = transfers.filter(t => 
              !existingIds.has(t.id) && 
              t.timestamp >= checkoutOpenedAt && 
              !dismissedTransferIds.includes(t.id) &&
              !isTransferAlreadyUsed(t.id, t.reference)
            );
            if (newItems.length === 0) {
              DialogService.alert('No se detectaron nuevas transferencias para esta venta puntual.', 'Sincronizado', 'info');
              return prev;
            }
            return [...prev, ...newItems];
          });
        } else {
          DialogService.alert('Transferencias consultadas en tiempo real. Revisa la lista de transferencias detectadas para elegir cuál acreditar.', 'Sincronizado', 'info');
        }
      } else {
        DialogService.alert('No se encontraron transferencias recientes en la cuenta.', 'Sincronizado', 'info');
      }
    } catch (e: any) {
      DialogService.alert(`Error al consultar cuenta: ${e.message || 'Error de conexión'}`, 'Error', 'error');
    } finally {
      setIsCheckingTransfers(false);
    }
  };

  const handleAddTransfer = (amount: number, payer: string, platform: string) => {
    if (amount <= 0) return;
    const newTr: ReceivedTransferItem = {
      id: `TR-${Date.now().toString().slice(-6)}-${Math.floor(100 + Math.random() * 900)}`,
      amount,
      payerName: payer.trim() || 'Juan Carlos Pérez',
      platform: platform.trim() || 'Naranja X',
      reference: `TR-${Math.floor(100000 + Math.random() * 900000)}`,
      timestamp: Date.now(),
    };
    setReceivedTransfers(prev => [...prev, newTr]);
  };

  const handleRemoveTransfer = (id: string) => {
    setReceivedTransfers(prev => prev.filter(t => t.id !== id));
  };

  // Reload payment config when storage changes
  useEffect(() => {
    const reloadConfig = (e: StorageEvent) => {
      // Only reload if the event is specifically for pos_payment_config_v1
      if (e.key && e.key !== 'pos_payment_config_v1') return;
      const cfg = StorageService.getPaymentConfig();
      setPaymentConfig(prev => {
        if (JSON.stringify(prev) === JSON.stringify(cfg)) return prev;
        return cfg;
      });
      const wallets = cfg.wallets;
      if (wallets && wallets.length > 0) {
        setSelectedWalletId(prev => (prev && wallets.some(w => w.id === prev) ? prev : wallets[0].id));
      }
    };
    window.addEventListener('storage', reloadConfig);
    return () => window.removeEventListener('storage', reloadConfig);
  }, []);

  const barcodeInputRef = useRef<HTMLInputElement>(null);
  // While a scan-result dialog is open, do not focus the hidden scanner field or
  // accept more scanner keystrokes. This prevents the next barcode being appended
  // to the previous one when the dialog is displayed.
  const scanDialogOpenRef = useRef(false);
  // Preserve every complete scan in arrival order. The queue is intentionally
  // in-memory only: it must never be persisted as business data.
  const pendingScansRef = useRef<string[]>([]);
  const processingScanRef = useRef(false);
  const ticketDoneButtonRef = useRef<HTMLButtonElement>(null);

  const isAnyModalOpen = showCheckoutModal || showTicketModal || showPaymentConfigModal || showParkedSalesModal || showParkPromptModal || !!quickStockArticle || showCustomTransferForm || showExternalServiceModal;
  const modalOpenRef = useRef(isAnyModalOpen);
  modalOpenRef.current = isAnyModalOpen;

  // Helper to reliably focus barcode input after returning to the POS.
  // Read the latest modal state so a button that opens a dialog cannot steal its focus.
  const focusBarcodeInput = () => {
    setTimeout(() => {
      if (!modalOpenRef.current && !scanDialogOpenRef.current) {
        const input = barcodeInputRef.current;
        if (input) {
          input.value = '';
          setBarcodeInput('');
          input.focus();
        }
      }
    }, 80);
  };

  // When the receipt opens, move keyboard focus into the modal instead of
  // leaving it on the barcode/search field behind the floating window.
  // Enter is handled by the existing shortcut as the "Listo / Nueva Venta" action.
  useEffect(() => {
    if (!showTicketModal) return;
    const timer = window.setTimeout(() => {
      ticketDoneButtonRef.current?.focus({ preventScroll: true });
    }, 0);
    return () => window.clearTimeout(timer);
  }, [showTicketModal, lastCompletedSale]);

  // Focus barcode input on mount and keep it focused
  useEffect(() => {
    focusBarcodeInput();
  }, []);

  // Refocus whenever any modal closes or cart changes
  useEffect(() => {
    if (!isAnyModalOpen) {
      focusBarcodeInput();
    }
  }, [isAnyModalOpen, cart]);

  // Click outside listener: refocus barcode if clicking neutral area
  useEffect(() => {
    const handleGlobalClick = (e: MouseEvent) => {
      if (modalOpenRef.current) return;
      const target = e.target as HTMLElement;
      // Let users type normally, but return focus to barcode after button/menu actions.
      if (target.closest('input, textarea, a')) return;
      focusBarcodeInput();
    };

    window.addEventListener('click', handleGlobalClick);
    return () => window.removeEventListener('click', handleGlobalClick);
  }, [isAnyModalOpen]);

  // Client accounts
  const clientAccounts = useMemo(() => accounts.filter(a => a.type === 'CLIENT'), [accounts]);

  // Ensure cash amount strictly starts at '0' when opening checkout modal (F2 or button)
  const prevShowCheckoutModalRef = useRef(false);
  useEffect(() => {
    if (showCheckoutModal && !prevShowCheckoutModalRef.current) {
      setCashAmount('0');
    }
    prevShowCheckoutModalRef.current = showCheckoutModal;
  }, [showCheckoutModal]);

  // Pre-fill client name or reference whenever park modal opens (F8 or button)
  const prevShowParkPromptModalRef = useRef(false);
  useEffect(() => {
    if (showParkPromptModal && !prevShowParkPromptModalRef.current) {
      const now = new Date();
      const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      const clientObj = clientAccounts.find(c => c.id === selectedClientId);
      const nextNumber = parkedSales.length + 1;
      const clientName = clientObj ? clientObj.name : `Cliente #${nextNumber}-${timeStr}`;
      setParkReference(clientName);
    }
    prevShowParkPromptModalRef.current = showParkPromptModal;
  }, [showParkPromptModal, selectedClientId, clientAccounts, parkedSales.length]);

  // Handlers for Parked Sales (Ventas en Espera)
  const handleOpenParkModal = () => {
    if (cart.length === 0) return;
    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const clientObj = clientAccounts.find(c => c.id === selectedClientId);
    const nextNumber = parkedSales.length + 1;
    const clientName = clientObj ? clientObj.name : `Cliente #${nextNumber}-${timeStr}`;
    setParkReference(clientName);
    setShowParkPromptModal(true);
  };

  const handleConfirmPark = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (cart.length === 0) return;
    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const matchedClient = clientAccounts.find(c => c.name.toLowerCase() === parkReference.trim().toLowerCase()) 
      || clientAccounts.find(c => c.id === selectedClientId);
    const refName = parkReference.trim() || matchedClient?.name || `Cliente #${parkedSales.length + 1}-${timeStr}`;
    const newParked: ParkedSale = {
      id: `park_${Date.now()}`,
      referenceName: refName,
      items: [...cart],
      discountAmount: discountAmount || 0,
      selectedClientId: matchedClient?.id || selectedClientId || undefined,
      total: Math.max(0, cartTotal - (discountAmount || 0)),
      timestamp: new Date().toISOString(),
      terminalId: currentTerminalId,
      itemsCount: cart.reduce((s, i) => s + i.quantity, 0),
    };
    StorageService.addParkedSale(newParked);
    setParkedSales(StorageService.getParkedSales());
    clearCart();
    setDiscountAmount(0);
    setSelectedClientId('');
    setParkReference('');
    setShowParkPromptModal(false);
    focusBarcodeInput();
  };

  const handleRestoreParkedSale = (parked: ParkedSale) => {
    // If current cart has items, auto-park current cart so no items are lost
    if (cart.length > 0) {
      const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const clientObj = clientAccounts.find(c => c.id === selectedClientId);
      const currentParked: ParkedSale = {
        id: `park_${Date.now()}`,
        referenceName: clientObj ? clientObj.name : `Venta desplazada - ${timeStr}`,
        items: [...cart],
        discountAmount: discountAmount || 0,
        selectedClientId: selectedClientId || undefined,
        total: Math.max(0, cartTotal - (discountAmount || 0)),
        timestamp: new Date().toISOString(),
        terminalId: currentTerminalId,
        itemsCount: cart.reduce((s, i) => s + i.quantity, 0),
      };
      StorageService.addParkedSale(currentParked);
    }

    loadCart(parked.items);
    setDiscountAmount(parked.discountAmount || 0);
    setSelectedClientId(parked.selectedClientId || '');
    if (parked.referenceName) {
      setParkReference(parked.referenceName);
    }
    StorageService.removeParkedSale(parked.id);
    setParkedSales(StorageService.getParkedSales());
    setShowParkedSalesModal(false);
    focusBarcodeInput();
  };

  const handleDeleteParkedSale = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    StorageService.removeParkedSale(id);
    setParkedSales(StorageService.getParkedSales());
  };

  // Checkout handling
  const handleOpenCheckout = () => {
    if (!currentShift) {
      DialogService.alert('Debe abrir la caja registradora en esta terminal antes de poder cobrar una venta.', 'Caja Cerrada', 'warning');
      return;
    }
    if (cart.length === 0) return;
    setCashAmount('0');
    setDiscountAmount(0);
    setPaymentMethod('EFECTIVO');
    setMpStep('READY');
    setShowCheckoutModal(true);
  };

  const handleCloseCheckout = () => {
    setShowCheckoutModal(false);
    setCashAmount('0');
    setReceivedTransfers([]);
    setTransferRef('');
    setCardLastFour('');
    setCouponNumber('');
    setInstallments(1);
    setPosnetAutoStatus('IDLE');
    setPosnetAutoAuthCode('');
    focusBarcodeInput();
  };

  // Keyboard Shortcuts Action Dispatcher
  useEffect(() => {
    const handleShortcut = (e: any) => {
      const action = e.detail;
      if (action === 'focus_search') {
        setBarcodeInput('');
        barcodeInputRef.current?.focus();
      } else if (action === 'checkout') {
        if (cart.length > 0) {
          handleOpenCheckout();
        }
      } else if (action === 'quick_cash') {
        if (showCheckoutModal) {
          handleSelectPaymentMethod('EFECTIVO');
        } else if (cart.length > 0) {
          handleOpenCheckout();
          handleSelectPaymentMethod('EFECTIVO');
        }
      } else if (action === 'quick_mp') {
        if (showCheckoutModal) {
          handleSelectPaymentMethod('MERCADO_PAGO_QR');
        } else if (cart.length > 0) {
          handleOpenCheckout();
          handleSelectPaymentMethod('MERCADO_PAGO_QR');
        }
      } else if (action === 'quick_card') {
        if (showCheckoutModal) {
          handleSelectPaymentMethod('TARJETA_POSNET');
        } else if (cart.length > 0) {
          handleOpenCheckout();
          handleSelectPaymentMethod('TARJETA_POSNET');
        }
      } else if (action === 'quick_transfer') {
        if (showCheckoutModal) {
          handleSelectPaymentMethod('TRANSFERENCIA');
        } else if (cart.length > 0) {
          handleOpenCheckout();
          handleSelectPaymentMethod('TRANSFERENCIA');
        }
      } else if (action === 'quick_account') {
        if (showCheckoutModal) {
          handleSelectPaymentMethod('CUENTA_CORRIENTE');
        } else if (cart.length > 0) {
          handleOpenCheckout();
          handleSelectPaymentMethod('CUENTA_CORRIENTE');
        }
      } else if (action === 'reprint_ticket') {
        if (lastCompletedSale) {
          setShowTicketModal(true);
          setTimeout(() => {
            window.print();
          }, 300);
        }
      } else if (action === 'park_sale') {
        if (cart.length > 0) {
          handleOpenParkModal();
        } else if (parkedSales.length > 0) {
          setShowParkedSalesModal(true);
        }
      } else if (action === 'cancel') {
        if (showCheckoutModal) handleCloseCheckout();
        else if (showTicketModal) setShowTicketModal(false);
        else if (showParkPromptModal) setShowParkPromptModal(false);
        else if (showParkedSalesModal) setShowParkedSalesModal(false);
        else if (cart.length > 0) {
          clearCart();
        }
        focusBarcodeInput();
      }
    };

    window.addEventListener('pos-shortcut', handleShortcut);
    return () => window.removeEventListener('pos-shortcut', handleShortcut);
  }, [cart, showCheckoutModal, showTicketModal, showParkPromptModal, showParkedSalesModal, parkedSales.length, lastCompletedSale, currentShift, selectedClientId, clientAccounts]);

  // Real-time synchronization with Customer Display (2nd Screen)
  const getCashierActiveQrInfo = (termId?: string) => {
    const normTerm = (termId || currentTerminalId || 'TERM-01').toUpperCase().trim();
    const curPosId = paymentConfig.mpPosId || 'default';
    const posSaved = paymentConfig.mpPosQrs?.[normTerm] 
      || paymentConfig.mpPosQrs?.[normTerm.replace('TERM-', '')]
      || paymentConfig.mpPosQrs?.[curPosId]
      || (paymentConfig.mpPosQrs && Object.values(paymentConfig.mpPosQrs)[0]);
      
    const activePhotoUrl = posSaved?.qrImage || paymentConfig.mpQrImage;

    const showCartelPhoto = !forceDigitalQr && Boolean(activePhotoUrl);

    const digitalQrData = posSaved?.qrData || paymentConfig.mpQrData || paymentConfig.mpQrText || generateArgentinaInteroperableQr({
      merchantName: paymentConfig.mpHolder || 'Manuel Silva',
      cvuOrCbu: paymentConfig.mpCvu || '0000003100084920194820',
      alias: paymentConfig.mpAlias || 'MANUELSILVA2003.MP'
    });

    const digitalQrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(digitalQrData)}`;
    const finalQrUrl = (showCartelPhoto && activePhotoUrl) ? activePhotoUrl : digitalQrUrl;

    return {
      qrImageUrl: finalQrUrl,
      qrData: digitalQrData,
    };
  };

  const handleSelectPaymentMethod = (method: PaymentMethod) => {
    setPaymentMethod(method);
    if (showCheckoutModal && cart.length > 0) {
      const baseNetTotal = Math.max(0, cartTotal - discountAmount);
      const mpSurchargeAmount = (method === 'MERCADO_PAGO_QR' && mpSurchargeEnabled)
        ? Math.round((baseNetTotal * mpSurchargePercent) / 100)
        : 0;
      const netTotal = baseNetTotal + mpSurchargeAmount;
      const received = parseFormattedNumber(cashAmount);
      const change = Math.max(0, received - netTotal);
      const qrInfo = getCashierActiveQrInfo(currentTerminalId);

      StorageService.updateCustomerDisplayState({
        status: 'PAYING',
        items: cart.map(item => ({
          name: item.article.name,
          quantity: item.quantity,
          unitPrice: item.customPrice ?? item.article.salePrice,
          total: (item.customPrice ?? item.article.salePrice) * item.quantity,
        })),
        subtotal: cartTotal,
        discount: discountAmount,
        total: netTotal,
        paymentMethod: method,
        cashReceived: method === 'EFECTIVO' ? received : undefined,
        cashChange: method === 'EFECTIVO' ? change : undefined,
        activeWalletId: method === 'BILLETERA_VIRTUAL' ? (selectedWalletId || (paymentConfig.wallets && paymentConfig.wallets[0]?.id)) : undefined,
        transfersReceived: method === 'TRANSFERENCIA' ? receivedTransfers : undefined,
        transfersTotalReceived: method === 'TRANSFERENCIA' ? receivedTransfers.reduce((s, t) => s + t.amount, 0) : undefined,
        posnetMode: (method === 'TARJETA_POSNET' || method === 'BILLETERA_VIRTUAL') ? posnetMode : undefined,
        posnetStatus: (method === 'TARJETA_POSNET' || method === 'BILLETERA_VIRTUAL') ? (posnetMode === 'AUTOMATIC' ? (posnetAutoStatus === 'WAITING_CARD' ? 'WAITING_CARD' : posnetAutoStatus === 'PROCESSING' ? 'PROCESSING' : posnetAutoStatus === 'APPROVED' ? 'APPROVED' : 'WAITING_CARD') : 'MANUAL_READY') : undefined,
        posnetCardType: (method === 'TARJETA_POSNET' || method === 'BILLETERA_VIRTUAL') ? cardType : undefined,
        posnetCardBrand: (method === 'TARJETA_POSNET' || method === 'BILLETERA_VIRTUAL') ? cardBrand : undefined,
        paymentConfig: paymentConfig,
        qrImageUrl: qrInfo.qrImageUrl,
        qrData: qrInfo.qrData,
        terminalId: currentTerminalId,
        timestamp: Date.now(),
      });
    }
  };

  useEffect(() => {
    if (cart.length === 0 && !showCheckoutModal && !lastCompletedSale) {
      StorageService.updateCustomerDisplayState({
        status: 'WELCOME',
        items: [],
        subtotal: 0,
        discount: 0,
        total: 0,
        paymentMethod: null,
        terminalId: currentTerminalId,
        timestamp: Date.now(),
      });
      return;
    }

    if (showCheckoutModal) {
      const baseNetTotal = Math.max(0, cartTotal - discountAmount);
      const mpSurchargeAmount = (paymentMethod === 'MERCADO_PAGO_QR' && mpSurchargeEnabled)
        ? Math.round((baseNetTotal * mpSurchargePercent) / 100)
        : 0;
      const netTotal = baseNetTotal + mpSurchargeAmount;
      const received = parseFormattedNumber(cashAmount);
      const change = Math.max(0, received - netTotal);
      const qrInfo = getCashierActiveQrInfo(currentTerminalId);

      StorageService.updateCustomerDisplayState({
        status: 'PAYING',
        items: cart.map(item => ({
          name: item.article.name,
          quantity: item.quantity,
          unitPrice: item.customPrice ?? item.article.salePrice,
          total: (item.customPrice ?? item.article.salePrice) * item.quantity,
        })),
        subtotal: cartTotal,
        discount: discountAmount,
        total: netTotal,
        paymentMethod,
        cashReceived: paymentMethod === 'EFECTIVO' ? received : undefined,
        cashChange: paymentMethod === 'EFECTIVO' ? change : undefined,
        activeWalletId: paymentMethod === 'BILLETERA_VIRTUAL' ? (selectedWalletId || (paymentConfig.wallets && paymentConfig.wallets[0]?.id)) : undefined,
        transfersReceived: paymentMethod === 'TRANSFERENCIA' ? receivedTransfers : undefined,
        transfersTotalReceived: paymentMethod === 'TRANSFERENCIA' ? receivedTransfers.reduce((s, t) => s + t.amount, 0) : undefined,
        posnetMode: (paymentMethod === 'TARJETA_POSNET' || paymentMethod === 'BILLETERA_VIRTUAL') ? posnetMode : undefined,
        posnetStatus: (paymentMethod === 'TARJETA_POSNET' || paymentMethod === 'BILLETERA_VIRTUAL') ? (posnetMode === 'AUTOMATIC' ? (posnetAutoStatus === 'WAITING_CARD' ? 'WAITING_CARD' : posnetAutoStatus === 'PROCESSING' ? 'PROCESSING' : posnetAutoStatus === 'APPROVED' ? 'APPROVED' : 'WAITING_CARD') : 'MANUAL_READY') : undefined,
        posnetCardType: (paymentMethod === 'TARJETA_POSNET' || paymentMethod === 'BILLETERA_VIRTUAL') ? cardType : undefined,
        posnetCardBrand: (paymentMethod === 'TARJETA_POSNET' || paymentMethod === 'BILLETERA_VIRTUAL') ? cardBrand : undefined,
        paymentConfig: paymentConfig,
        qrImageUrl: qrInfo.qrImageUrl,
        qrData: qrInfo.qrData,
        terminalId: currentTerminalId,
        timestamp: Date.now(),
      });
    } else if (cart.length > 0) {
      const netTotal = Math.max(0, cartTotal - discountAmount);
      StorageService.updateCustomerDisplayState({
        status: 'SCANNING',
        items: cart.map(item => ({
          name: item.article.name,
          quantity: item.quantity,
          unitPrice: item.customPrice ?? item.article.salePrice,
          total: (item.customPrice ?? item.article.salePrice) * item.quantity,
        })),
        subtotal: cartTotal,
        discount: discountAmount,
        total: netTotal,
        paymentMethod: null,
        terminalId: currentTerminalId,
        timestamp: Date.now(),
      });
    }
  }, [cart, cartTotal, discountAmount, showCheckoutModal, paymentMethod, cashAmount, selectedWalletId, paymentConfig, currentTerminalId, lastCompletedSale, receivedTransfers, posnetMode, posnetAutoStatus, cardType, cardBrand, mpSurchargeEnabled, mpSurchargePercent]);

  const handleConfirmSaleRef = useRef<(forcedMpId?: string | number) => void>(() => {});

  // Live POS Order Sync with Mercado Pago API
  useEffect(() => {
    // If not in checkout or not Mercado Pago QR, cancel active order and cleanup
    if (!showCheckoutModal || paymentMethod !== 'MERCADO_PAGO_QR') {
      lastSyncedMpParamsRef.current = null;
      if (mpPollingTimerRef.current) {
        clearInterval(mpPollingTimerRef.current);
        mpPollingTimerRef.current = null;
      }
      if (activeMpOrderRef.current && paymentConfig.mpAccessToken && paymentConfig.mpUserId && paymentConfig.mpPosId) {
        MercadoPagoService.deleteQrOrder(
          paymentConfig.mpAccessToken,
          paymentConfig.mpUserId,
          paymentConfig.mpPosId
        );
        activeMpOrderRef.current = null;
      }
      setMpLiveSync({ status: 'idle', orderRef: null });
      return;
    }

    const token = paymentConfig.mpAccessToken?.trim();
    const userId = paymentConfig.mpUserId?.trim();
    const posId = paymentConfig.mpPosId?.trim();
    const autoSync = paymentConfig.mpAutoSync !== false;

    if (!token || !userId || !posId || !autoSync) {
      lastSyncedMpParamsRef.current = null;
      setMpLiveSync({ status: 'idle', orderRef: null });
      return;
    }

    const baseNetTotal = Math.max(0, cartTotal - discountAmount);
    const surchargeAmount = mpSurchargeEnabled ? Math.round((baseNetTotal * mpSurchargePercent) / 100) : 0;
    const netTotal = baseNetTotal + surchargeAmount;
    if (netTotal <= 0) {
      lastSyncedMpParamsRef.current = null;
      setMpLiveSync({ status: 'idle', orderRef: null });
      return;
    }

    // Prevent reconnect/disconnect loop if parameters haven't actually changed
    const prev = lastSyncedMpParamsRef.current;
    if (
      prev &&
      prev.netTotal === netTotal &&
      prev.token === token &&
      prev.userId === userId &&
      prev.posId === posId &&
      prev.retryCount === mpRetryTrigger &&
      activeMpOrderRef.current &&
      (mpLiveSync.status === 'waiting' || mpLiveSync.status === 'transmitting')
    ) {
      return;
    }

    lastSyncedMpParamsRef.current = {
      netTotal,
      token,
      userId,
      posId,
      retryCount: mpRetryTrigger,
    };

    const orderRef = `POS-${Date.now()}`;
    activeMpOrderRef.current = orderRef;
    setMpLiveSync({ status: 'transmitting', orderRef });

    MercadoPagoService.createQrOrder({
      accessToken: token,
      userId,
      posId,
      total: netTotal,
      externalReference: orderRef,
      title: `Venta POS #${orderRef.slice(-6)}`,
      items: [
        ...cart.map(it => ({
          barcode: it.article.barcode,
          name: it.article.name,
          brand: it.article.brand,
          unitPrice: it.customPrice ?? it.article.salePrice,
          quantity: it.quantity,
          total: (it.customPrice ?? it.article.salePrice) * it.quantity,
        })),
        ...(surchargeAmount > 0 ? [{
          barcode: 'RECARGO-MP',
          name: `Recargo MP (${mpSurchargePercent}%)`,
          brand: 'Recargo',
          unitPrice: surchargeAmount,
          quantity: 1,
          total: surchargeAmount,
        }] : []),
      ],
    }).then(res => {
      if (activeMpOrderRef.current !== orderRef) return;

      if (!res.success) {
        let friendlyError = res.error || 'No se pudo sincronizar con Mercado Pago';
        if (friendlyError.includes('Invalid total amount')) {
          friendlyError = 'El total de la orden difería por el descuento. Se corrigió para coincidir exactamente. Presiona Reintentar.';
        }
        setMpLiveSync({
          status: 'error',
          orderRef,
          errorMsg: friendlyError,
        });
        return;
      }

      setMpLiveSync({ status: 'waiting', orderRef });

      if (mpPollingTimerRef.current) clearInterval(mpPollingTimerRef.current);
      mpPollingTimerRef.current = setInterval(async () => {
        if (!activeMpOrderRef.current || activeMpOrderRef.current !== orderRef) return;
        const statusRes = await MercadoPagoService.checkOrderStatus(orderRef, token);
        if (statusRes.paid) {
          clearInterval(mpPollingTimerRef.current);
          mpPollingTimerRef.current = null;
          setMpLiveSync({
            status: 'approved',
            orderRef,
            paymentId: statusRes.paymentId,
          });
          setTimeout(() => {
            handleConfirmSaleRef.current(statusRes.paymentId);
          }, 600);
        }
      }, 2000);
    });
  }, [
    showCheckoutModal,
    paymentMethod,
    cartTotal,
    discountAmount,
    paymentConfig.mpAccessToken,
    paymentConfig.mpUserId,
    paymentConfig.mpPosId,
    paymentConfig.mpAutoSync,
    mpRetryTrigger,
    mpSurchargeEnabled,
    mpSurchargePercent,
  ]);

  // Global keydown: ESC to close modals, Enter for confirm sale or next sale, plus barcode scanner
  useEffect(() => {
    let buffer = '';
    let lastKeyTime = Date.now();

    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore scanner keystrokes until the current result dialog is dismissed.
      if (scanDialogOpenRef.current) return;

      // F1 shortcut: Clear search and focus input
      if (e.key === 'F1') {
        e.preventDefault();
        setBarcodeInput('');
        focusBarcodeInput();
        return;
      }

      if (e.key === 'Escape') {
        if (showTicketModal) {
          setShowTicketModal(false);
          setLastCompletedSale(null);
        }
        if (showCheckoutModal) setShowCheckoutModal(false);
        if (showParkedSalesModal) setShowParkedSalesModal(false);
        if (showParkPromptModal) setShowParkPromptModal(false);
        focusBarcodeInput();
        return;
      }

      // F8 shortcut: Toggle parked sales or park current cart
      if (e.key === 'F8') {
        e.preventDefault();
        if (cart.length > 0) {
          handleOpenParkModal();
        } else if (parkedSales.length > 0) {
          setShowParkedSalesModal(true);
        }
        return;
      }

      // 1. If Ticket/Receipt modal is open, Enter activates the same button
      // as clicking "Listo / Nueva Venta". Prevent the browser's native
      // Enter behavior from triggering a second action.
      if (showTicketModal && e.key === 'Enter') {
        e.preventDefault();
        e.stopPropagation();
        if (ticketDoneButtonRef.current) {
          ticketDoneButtonRef.current.click();
        } else {
          setShowTicketModal(false);
          setLastCompletedSale(null);
          focusBarcodeInput();
        }
        return;
      }

      // 2. If Checkout modal is open, Enter finalizes the sale and opens receipt/ticket
      if (showCheckoutModal && e.key === 'Enter') {
        const targetTag = (e.target as HTMLElement)?.tagName;
        if (targetTag !== 'TEXTAREA') {
          e.preventDefault();
          handleConfirmSaleRef.current();
          return;
        }
      }

      // Ignore if user is currently focused on an input element
      const targetTag = (e.target as HTMLElement)?.tagName;
      if (targetTag === 'INPUT' || targetTag === 'TEXTAREA' || targetTag === 'SELECT') {
        return;
      }

      const now = Date.now();
      if (now - lastKeyTime > 150) {
        buffer = ''; // reset buffer if typing is too slow (human typing)
      }
      lastKeyTime = now;

      if (e.key === 'Enter') {
        if (buffer.length >= 4) {
          enqueueBarcodeScan(buffer.trim());
          buffer = '';
          e.preventDefault();
        }
      } else if (e.key.length === 1) {
        buffer += e.key;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [articles, showTicketModal, showCheckoutModal, showParkedSalesModal, showParkPromptModal, cart, parkedSales]);

  // Subscribe to parked sales and extra articles updates (multi-window / sync)
  useEffect(() => {
    const unsubscribe = StorageService.subscribeToSync((event) => {
      if (event.type === 'PARKED_SALES_UPDATED') {
        setParkedSales(StorageService.getParkedSales());
      }
      if (event.type === 'EXTRA_ARTICLES_UPDATED') {
        setExtraArticles(StorageService.getExtraArticles());
      }
    });
    return unsubscribe;
  }, []);

  // O(1) instant barcode lookup map for physical scanners
  const articleBarcodeMap = useMemo(() => {
    const map = new Map<string, Article>();
    for (const a of articles) {
      const code = a.barcode.trim().toLowerCase();
      if (code && !map.has(code)) {
        map.set(code, a);
      }
    }
    return map;
  }, [articles]);

  const offerStockAdjustment = (article: Article) => {
    scanDialogOpenRef.current = true;
    if (barcodeInputRef.current) {
      barcodeInputRef.current.value = '';
      barcodeInputRef.current.blur();
    }
    setBarcodeInput('');
    void DialogService.confirm(
      `El artículo "${article.name}" no tiene stock disponible. ¿Querés abrir el Ajuste Manual de Stock para cargar unidades?`,
      'Sin Stock',
      'Cargar stock',
      'Continuar sin cargar',
      'warning'
    ).then((openAdjustment) => {
      if (openAdjustment) {
        setQuickStockArticle(article);
        setQuickStockAmount('');
      }
    }).finally(() => {
      scanDialogOpenRef.current = false;
      focusBarcodeInput();
    });
  };

  // Always clear the scanner field immediately, before processing any result.
  // Clearing both React state and the DOM value prevents rapid scans from concatenating codes.
  const clearBarcodeInput = () => {
    setBarcodeInput('');
    if (barcodeInputRef.current) barcodeInputRef.current.value = '';
  };

  const handleBarcodeScanned = (codeOrText: string) => {
    const clean = codeOrText.trim().toLowerCase();
    if (!clean) {
      clearBarcodeInput();
      return;
    }

    // A scan is a one-shot operation: never leave its text in the field,
    // whether the article exists, has stock, or matches multiple results.
    clearBarcodeInput();

    // 1. Exact match by barcode (fast path for barcode scanners)
    const barcodeArticle = articleBarcodeMap.get(clean) || articles.find(a => a.barcode.trim().toLowerCase() === clean);
    if (barcodeArticle) {
      if (barcodeArticle.stock <= 0) {
        offerStockAdjustment(barcodeArticle);
      }
      addToCart(barcodeArticle, 1);
      focusBarcodeInput();
      return;
    }

    // 2. Exact match by full name
    const exactNameArticle = articles.find(a => 
      a.name.trim().toLowerCase() === clean
    );
    if (exactNameArticle) {
      if (exactNameArticle.stock <= 0) {
        offerStockAdjustment(exactNameArticle);
      }
      addToCart(exactNameArticle, 1);
      focusBarcodeInput();
      return;
    }

    // 3. Search articles matching text (name, brand, category, barcode)
    const matchingArticles = articles.filter(a => 
      a.name.toLowerCase().includes(clean) ||
      a.brand.toLowerCase().includes(clean) ||
      a.barcode.toLowerCase().includes(clean) ||
      (a.category && a.category.toLowerCase().includes(clean))
    );

    if (matchingArticles.length === 1) {
      const matched = matchingArticles[0];
      if (matched.stock <= 0) {
        offerStockAdjustment(matched);
      }
      addToCart(matched, 1);
    } else if (matchingArticles.length > 1) {
      // Leave the scanner field empty even when several articles match.
    } else {
      scanDialogOpenRef.current = true;
      if (barcodeInputRef.current) {
        barcodeInputRef.current.value = '';
        barcodeInputRef.current.blur();
      }
      setBarcodeInput('');
      setNotFoundCode(codeOrText);
      setNotFoundButtonIndex(1);
      setShowArticleNotFound(true);
      return;
    }
    focusBarcodeInput();
  };

  // Drain scanner input in separate browser turns. A synchronous while-loop can
  // trigger many React updates in one event and overwhelm slower shop PCs.
  // Every complete code is kept in arrival order and processed exactly once.
  const drainBarcodeQueue = () => {
    if (processingScanRef.current || scanDialogOpenRef.current) return;
    const nextCode = pendingScansRef.current.shift();
    if (!nextCode) return;

    processingScanRef.current = true;
    try {
      handleBarcodeScanned(nextCode);
    } finally {
      window.setTimeout(() => {
        processingScanRef.current = false;
        // Do not pass subsequent codes into a dialog or data-entry form.
        if (!scanDialogOpenRef.current) drainBarcodeQueue();
      }, 0);
    }
  };

  const enqueueBarcodeScan = (rawCode: string) => {
    const code = rawCode.trim();
    if (!code) return;
    pendingScansRef.current.push(code);
    drainBarcodeQueue();
  };

  // Resume queued scans only after a result dialog/form has been dismissed.
  useEffect(() => {
    if (!scanDialogOpenRef.current) drainBarcodeQueue();
  }, [showArticleNotFound, showQuickAddArticle, quickStockArticle]);

  const handleBarcodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const scannedCode = barcodeInput.trim();
    clearBarcodeInput();
    if (!scannedCode) {
      focusBarcodeInput();
      return;
    }
    enqueueBarcodeScan(scannedCode);
  };

  // Virtualized rendering limit for ultra-fast performance with 10.000+ items
  const [salesDisplayLimit, setSalesDisplayLimit] = useState(48);

  // Filter top categories with useMemo to keep DOM lightweight and instantaneous
  const categories = useMemo(() => {
    const counts = new Map<string, number>();
    for (const a of articles) {
      if (a.category) {
        counts.set(a.category, (counts.get(a.category) || 0) + 1);
      }
    }
    const sorted = Array.from(counts.entries())
      .sort((a, b) => b[1] - a[1])
      .map(entry => entry[0]);
    // Display top 24 most common categories to avoid excessive horizontal DOM chips
    const top = sorted.slice(0, 24);
    if (selectedCategory !== 'TODOS' && !top.includes(selectedCategory)) {
      top.push(selectedCategory);
    }
    return ['TODOS', ...top];
  }, [articles, selectedCategory]);

  const filteredArticles = useMemo(() => {
    const rawBarcode = barcodeInput.trim().toLowerCase();

    // Fast path: if no search query and all categories selected, return immediately (0ms latency)
    if (!rawBarcode && selectedCategory === 'TODOS') {
      return articles;
    }

    return articles.filter(art => {
      const matchesCat = selectedCategory === 'TODOS' || art.category === selectedCategory;
      if (!matchesCat) return false;

      // Filter by barcode or name/brand entered in the input
      if (rawBarcode) {
        const matchesBarcodeField = (
          art.barcode.toLowerCase().includes(rawBarcode) ||
          art.name.toLowerCase().includes(rawBarcode) ||
          art.brand.toLowerCase().includes(rawBarcode) ||
          (art.category && art.category.toLowerCase().includes(rawBarcode))
        );
        if (!matchesBarcodeField) return false;
      }

      return true;
    });
  }, [articles, barcodeInput, selectedCategory]);

  const visibleArticles = useMemo(() => {
    return filteredArticles.slice(0, salesDisplayLimit);
  }, [filteredArticles, salesDisplayLimit]);

  useEffect(() => {
    setSalesDisplayLimit(48);
  }, [barcodeInput, selectedCategory]);

  const handleConfirmSale = (forcedMpTransactionId?: string | number | React.MouseEvent) => {
    let paymentDetails: any = {};

    if (paymentMethod === 'EFECTIVO') {
      const received = parseFormattedNumber(cashAmount);
      const totalDue = cartTotal - discountAmount;
      if (received < totalDue) {
        DialogService.alert('El importe recibido no puede ser inferior al total a pagar de la venta.', 'Importe Insuficiente', 'warning');
        return;
      }
      paymentDetails = {
        cashReceived: received,
        cashChange: received - totalDue,
      };
    } else if (paymentMethod === 'MERCADO_PAGO_QR') {
      const isForcedValid = typeof forcedMpTransactionId === 'string' || typeof forcedMpTransactionId === 'number';
      const txId = isForcedValid 
        ? String(forcedMpTransactionId) 
        : (mpLiveSync.paymentId ? String(mpLiveSync.paymentId) : `MP-${Math.floor(100000000 + Math.random() * 900000000)}`);
      const baseNet = Math.max(0, cartTotal - discountAmount);
      const surcharge = mpSurchargeEnabled ? Math.round((baseNet * mpSurchargePercent) / 100) : 0;
      paymentDetails = {
        mpTransactionId: txId,
        mpSurchargeEnabled,
        mpSurchargePercent: mpSurchargeEnabled ? mpSurchargePercent : 0,
        mpSurchargeAmount: surcharge,
      };
    } else if (paymentMethod === 'TRANSFERENCIA') {
      const netTotal = Math.max(0, cartTotal - discountAmount);
      const totalRec = receivedTransfers.reduce((s, t) => s + t.amount, 0);

      if (receivedTransfers.length > 0) {
        if (payRemainingInCash) {
          const cashPortion = netTotal - totalRec;
          const cashRec = parseFormattedNumber(splitCashReceived || '0');
          if (cashRec < cashPortion) {
            DialogService.alert(
              `El efectivo recibido ($${cashRec.toLocaleString('es-AR')}) no alcanza para cubrir el saldo restante ($${cashPortion.toLocaleString('es-AR')}).`,
              'Efectivo Insuficiente',
              'warning'
            );
            return;
          }
          const cashChange = Math.max(0, cashRec - cashPortion);
          paymentDetails = {
            isMixedPayment: true,
            mixedDetails: {
              transferAmount: totalRec,
              cashAmount: cashPortion,
              cashReceived: cashRec,
              cashChange,
            },
            cashReceived: cashRec,
            cashChange,
            transferRef: receivedTransfers.map(t => `${t.platform} (#${t.reference}): $${t.amount.toLocaleString('es-AR')}`).join(' | '),
            transfersList: receivedTransfers,
          };
        } else {
          if (totalRec < netTotal) {
            const remaining = netTotal - totalRec;
            const confirmPartial = window.confirm(
              `Atención: El total acreditado ($${totalRec.toLocaleString('es-AR')}) es inferior al total de la venta ($${netTotal.toLocaleString('es-AR')}). Faltan cobrar $${remaining.toLocaleString('es-AR')}.\n\n¿Desea confirmar y emitir el ticket de todos modos?`
            );
            if (!confirmPartial) return;
          }

          paymentDetails = {
            transferRef: receivedTransfers.map(t => `${t.platform} (#${t.reference}): $${t.amount.toLocaleString('es-AR')}`).join(' | '),
            transfersList: receivedTransfers,
          };
        }
      } else {
        paymentDetails = {
          transferRef: transferRef.trim() || 'Acreditación Directa',
        };
      }
    } else if (paymentMethod === 'TARJETA_POSNET' || paymentMethod === 'BILLETERA_VIRTUAL') {
      const auth = posnetMode === 'AUTOMATIC' 
        ? (posnetAutoAuthCode || `AUT-${Math.floor(100000 + Math.random() * 900000)}`) 
        : (couponNumber.trim() || undefined);
      const batch = posnetMode === 'AUTOMATIC' 
        ? posnetAutoBatch 
        : (paymentConfig.posnetTerminalId || 'POS-01');
      paymentDetails = {
        posnetMode,
        cardType,
        cardBrand,
        cardLastFour: cardLastFour.trim() || undefined,
        couponNumber: auth,
        batchNumber: batch,
        installments: cardType === 'DEBITO' ? 1 : installments,
        posnetTerminalId: paymentConfig.posnetTerminalId || 'POS-01',
      };
    } else if (paymentMethod === 'CUENTA_CORRIENTE') {
      if (!selectedClientId) {
        DialogService.alert('Debe seleccionar un cliente para cargar la venta a su cuenta corriente.', 'Cliente Requerido', 'warning');
        return;
      }
      const client = clientAccounts.find(c => c.id === selectedClientId);
      paymentDetails = {
        clientAccountId: selectedClientId,
      };
    }

    const clientObj = clientAccounts.find(c => c.id === selectedClientId);

    const baseNet = Math.max(0, cartTotal - discountAmount);
    const mpSurcharge = (paymentMethod === 'MERCADO_PAGO_QR' && mpSurchargeEnabled)
      ? Math.round((baseNet * mpSurchargePercent) / 100)
      : 0;

    const result = processSale({
      paymentMethod,
      paymentDetails,
      clientId: selectedClientId || undefined,
      clientName: clientObj?.name,
      discount: discountAmount,
      surcharge: mpSurcharge,
    });

    if (result.success && result.sale) {
      if (receivedTransfers.length > 0) {
        const newlyAccreditedIds = receivedTransfers.map(t => t.id);
        setAccreditedTransferIds(prev => {
          const merged = Array.from(new Set([...prev, ...newlyAccreditedIds]));
          try {
            localStorage.setItem('pos_accredited_transfer_ids', JSON.stringify(merged));
          } catch {
            // ignore
          }
          return merged;
        });
      }
      setShowCheckoutModal(false);
      setCashAmount('0');
      setReceivedTransfers([]);
      setPayRemainingInCash(false);
      setSplitCashReceived('');
      setTransferRef('');
      setCardLastFour('');
      setCouponNumber('');
      setInstallments(1);
      setPosnetAutoStatus('IDLE');
      setPosnetAutoAuthCode('');
      setLastCompletedSale(result.sale);
      setShowTicketModal(true);
      barcodeInputRef.current?.focus();

      const printerCfg = StorageService.getPrinterConfig();
      if (printerCfg.enabled && printerCfg.autoPrintOnSale) {
        setTimeout(() => {
          window.print();
        }, 350);
      }

      StorageService.updateCustomerDisplayState({
        status: 'COMPLETED',
        items: result.sale.items.map(i => ({
          name: i.name,
          quantity: i.quantity,
          unitPrice: i.unitPrice,
          total: i.total,
        })),
        subtotal: result.sale.subtotal,
        discount: result.sale.discount,
        total: result.sale.total,
        paymentMethod: result.sale.paymentMethod,
        cashReceived: result.sale.paymentDetails?.cashReceived,
        cashChange: result.sale.paymentDetails?.cashChange,
        receiptNumber: result.sale.receiptNumber,
        terminalId: currentTerminalId,
        timestamp: Date.now(),
      });
    } else {
      DialogService.alert(result.message || 'Error al procesar la venta', 'Error en Venta', 'error');
    }
  };
  handleConfirmSaleRef.current = handleConfirmSale;

  const cashReceivedNum = parseFormattedNumber(cashAmount);
  const cashChangeNum = Math.max(0, cashReceivedNum - (cartTotal - discountAmount));

  const saveQuickStockAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickStockArticle) return;
    const delta = parseInt(quickStockAmount, 10) || 0;
    if (delta !== 0) adjustStock(quickStockArticle.id, delta);
    setQuickStockArticle(null);
    setQuickStockAmount('');
    setTimeout(() => focusBarcodeInput(), 50);
  };

  return (
    <>
      {quickStockArticle && (
        <div className="fixed inset-0 z-[10000] flex items-center justify-center bg-black/60 p-4" role="dialog" aria-modal="true" aria-labelledby="quick-stock-title">
          <form onSubmit={saveQuickStockAdjustment} className="w-full max-w-md overflow-hidden rounded-2xl border border-neutral-200 bg-white shadow-2xl dark:border-neutral-700 dark:bg-neutral-900">
            <div className="border-b border-neutral-200 px-5 py-4 dark:border-neutral-800">
              <h2 id="quick-stock-title" className="text-base font-black text-neutral-900 dark:text-white">Ajuste Manual de Stock</h2>
              <p className="mt-1 text-sm text-neutral-600 dark:text-neutral-300">{quickStockArticle.name}</p>
            </div>
            <div className="space-y-4 p-5">
              <div className="rounded-lg bg-neutral-100 p-3 text-sm dark:bg-neutral-800">Stock actual: <strong>{quickStockArticle.stock}</strong></div>
              <label className="block text-sm font-bold text-neutral-700 dark:text-neutral-200" htmlFor="quick-stock-amount">Cantidad a ajustar (usar un número negativo para descontar)</label>
              <input
                id="quick-stock-amount"
                autoFocus
                type="number"
                inputMode="numeric"
                step="1"
                value={quickStockAmount}
                onChange={e => setQuickStockAmount(e.target.value)}
                onKeyDown={e => {
                  const now = Date.now();
                  const burst = quickStockKeyBurstRef.current.filter(item => now - item.at <= 600);
                  if (/^\d$/.test(e.key)) burst.push({ key: e.key, at: now });
                  if (e.key === 'Enter') {
                    const digitKeys = burst.filter(item => /^\d$/.test(item.key));
                    if (digitKeys.length >= 7 && digitKeys[digitKeys.length - 1].at - digitKeys[0].at <= 600) {
                      e.preventDefault();
                      e.stopPropagation();
                      setQuickStockAmount('');
                    }
                    quickStockKeyBurstRef.current = [];
                    return;
                  }
                  if (e.key === 'Backspace' || e.key === 'Delete' || e.key === '-' || e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
                    quickStockKeyBurstRef.current = [];
                    return;
                  }
                  quickStockKeyBurstRef.current = burst;
                }}
                className="w-full rounded-xl border border-neutral-300 bg-white px-3 py-3 text-base text-neutral-900 outline-none focus:border-emerald-500 dark:border-neutral-700 dark:bg-neutral-950 dark:text-white"
                placeholder="Escribí la cantidad con el teclado"
              />
            </div>
            <div className="flex justify-end gap-2 border-t border-neutral-200 bg-neutral-50 px-5 py-4 dark:border-neutral-800 dark:bg-neutral-800/40">
              <button type="button" onClick={() => { setQuickStockArticle(null); setQuickStockAmount(''); setTimeout(() => focusBarcodeInput(), 50); }} className="rounded-xl border border-neutral-300 px-4 py-2 text-sm font-bold text-neutral-700 hover:bg-neutral-100 dark:border-neutral-700 dark:text-neutral-200">Cancelar</button>
              <button type="submit" className="rounded-xl bg-neutral-900 px-4 py-2 text-sm font-bold text-white hover:bg-neutral-800 dark:bg-emerald-600">Guardar ajuste</button>
            </div>
          </form>
        </div>
      )}
      <div className="h-full flex-1 flex flex-col lg:flex-row gap-3 w-full min-h-0 overflow-hidden sales-grid-interactive print:hidden">
      {/* LEFT COLUMN: Catalog & Barcode Scanner */}
      <div className="flex-1 flex flex-col min-w-0 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl overflow-hidden shadow-xs min-h-0">
        {/* Top Search & Barcode Bar */}
        <div className="p-3 md:p-4 border-b border-neutral-100 dark:border-neutral-800 bg-neutral-50/70 dark:bg-neutral-900/60 space-y-3">
          <div className="flex items-center gap-2">
            {/* Direct Barcode & Text Search Entry */}
            <form onSubmit={handleBarcodeSubmit} className="flex-1 relative">
              <div className="relative flex items-center">
                <Barcode className="absolute left-3 w-5 h-5 text-neutral-400" />
                <input
                  ref={barcodeInputRef}
                  type="text"
                  placeholder="Escanear código de barra o escribir producto/letras (Enter)..."
                  value={barcodeInput}
                  onChange={(e) => setBarcodeInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'F1') {
                      e.preventDefault();
                      clearBarcodeInput();
                      return;
                    }
                    if (e.key === 'Enter') {
                      // Read the actual DOM value, clear it synchronously, and process
                      // this scan exactly once before React can retain stale input text.
                      e.preventDefault();
                      e.stopPropagation();
                      const scannedCode = e.currentTarget.value;
                      clearBarcodeInput();
                      if (scannedCode.trim()) enqueueBarcodeScan(scannedCode);
                      else focusBarcodeInput();
                    }
                  }}
                  className="w-full pl-10 pr-9 py-2.5 bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-neutral-900 dark:focus:ring-neutral-400 focus:border-neutral-900 text-neutral-900 dark:text-white"
                />
                {barcodeInput ? (
                  <button
                    type="button"
                    title="Limpiar búsqueda"
                    onClick={() => {
                      setBarcodeInput('');
                      focusBarcodeInput();
                    }}
                    className="absolute right-2.5 p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded-md cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                ) : null}
              </div>
            </form>

          </div>

          {/* Quick Category Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`${articlesZoomConfig.categoryChips} rounded-full font-medium whitespace-nowrap transition-colors cursor-pointer ${
                  selectedCategory === cat
                    ? 'category-chip-active bg-neutral-900 text-white font-bold'
                    : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-100 dark:bg-neutral-800 dark:border-neutral-700 dark:text-neutral-300 dark:hover:bg-neutral-700'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Articles Grid / List */}
        <div className={`flex-1 overflow-y-auto p-3 grid ${articlesZoomConfig.gridCols} content-start`}>
          {visibleArticles.map((article) => {
            const isLowStock = article.stock <= article.minStock;
            const isOutOfStock = article.stock <= 0;

            return (
              <button
                key={article.id}
                onClick={() => addToCart(article, 1)}
                disabled={isOutOfStock}
                className={`${articlesZoomConfig.cardPadding} text-left rounded-xl border transition-all flex flex-col justify-between group cursor-pointer ${
                  isOutOfStock
                    ? 'bg-neutral-50 dark:bg-neutral-900/40 border-neutral-200 dark:border-neutral-800 opacity-60 cursor-not-allowed'
                    : 'bg-white dark:bg-neutral-800 border-neutral-200 dark:border-neutral-700 hover:border-neutral-900 dark:hover:border-neutral-400 hover:shadow-xs'
                }`}
              >
                <div className="space-y-1 w-full">
                  <div className="flex items-center justify-between gap-1">
                    <span className={`${articlesZoomConfig.brandText} uppercase font-semibold tracking-wider text-neutral-400 dark:text-neutral-400 truncate`}>
                      {article.brand}
                    </span>
                    <span className={`${articlesZoomConfig.stockBadge} rounded font-mono ${
                      isOutOfStock 
                        ? 'bg-rose-100 text-rose-700 font-bold dark:bg-rose-950/60 dark:text-rose-300' 
                        : isLowStock 
                        ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300' 
                        : 'bg-neutral-100 text-neutral-600 dark:bg-neutral-700 dark:text-neutral-300'
                    }`}>
                      {isOutOfStock ? 'Sin Stock' : `Stock: ${article.stock}`}
                    </span>
                  </div>
                  <h4 className={`${articlesZoomConfig.nameText} text-neutral-900 dark:text-neutral-100 group-hover:text-neutral-900 dark:group-hover:text-white`}>
                    {article.name}
                  </h4>
                </div>

                <div className="flex items-end justify-between pt-2 border-t border-neutral-100 dark:border-neutral-700/60 w-full mt-2">
                  <span className={`${articlesZoomConfig.priceText} text-neutral-900 dark:text-white`}>
                    ${formatThousands(article.salePrice)}
                  </span>
                  <span className={`${articlesZoomConfig.barcodeText} text-neutral-400 font-mono`}>
                    {article.barcode.slice(-4)}
                  </span>
                </div>
              </button>
            );
          })}

          {filteredArticles.length > visibleArticles.length && (
            <div className="col-span-full p-3 bg-neutral-100 dark:bg-neutral-800/80 rounded-xl border border-neutral-200 dark:border-neutral-700 flex flex-col sm:flex-row items-center justify-between gap-2">
              <span className="text-xs text-neutral-600 dark:text-neutral-300 font-medium">
                Mostrando {visibleArticles.length} de {formatThousands(filteredArticles.length)} artículos encontrados
              </span>
              <button
                type="button"
                onClick={() => setSalesDisplayLimit(prev => prev + 48)}
                className="px-4 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95"
              >
                Cargar más artículos (+48)
              </button>
            </div>
          )}

          {filteredArticles.length === 0 && (
            <div className="col-span-full py-12 text-center text-neutral-400">
              <AlertCircle className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm font-medium">No se encontraron artículos con ese criterio.</p>
              <p className="text-xs mt-1">Escriba otro nombre o escanee el código de barra.</p>
            </div>
          )}
        </div>
      </div>

      {/* RIGHT COLUMN: POS Cart & Checkout */}
      <div className={`${cartZoomConfig.columnWidth} flex flex-col bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl overflow-hidden shadow-xs min-h-0 flex-shrink-0 transition-all duration-150`}>
        {/* Cart Header */}
        <div className="p-3 sm:p-4 border-b border-neutral-100 dark:border-neutral-800 bg-neutral-900 text-white flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <Receipt className="w-5 h-5 text-emerald-400 shrink-0" />
            <h3 className={`${cartZoomConfig.headerTitle} tracking-tight leading-tight flex flex-col shrink-0`}>
              <span className="whitespace-nowrap">Comprobante de</span>
              <span className="whitespace-nowrap">Venta</span>
            </h3>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setShowParkedSalesModal(true)}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                parkedSales.length > 0 
                  ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-xs ring-2 ring-amber-400/50' 
                  : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300 border border-neutral-700'
              }`}
              title="Ver y recuperar ventas dejadas en espera (F8)"
            >
              <Clock className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">En Espera</span>
              {parkedSales.length > 0 && (
                <span className="px-1.5 py-0.2 bg-black/30 dark:bg-black/40 text-white rounded-full text-[10px] font-black">
                  {parkedSales.length}
                </span>
              )}
            </button>
            <span className="text-xs px-2.5 py-1 bg-neutral-800 rounded-lg font-mono font-bold text-neutral-200 whitespace-nowrap">
              {cart.reduce((s, i) => s + i.quantity, 0)} ítems
            </span>

            {/* Controles de Zoom / Tamaño de texto para el Comprobante (+ y -) al lado de items */}
            <div className="flex items-center bg-neutral-800 border border-neutral-700 rounded-lg p-0.5 shadow-xs shrink-0">
              <button
                type="button"
                onClick={() => handleCartZoomChange(cartZoomIndex - 1)}
                disabled={cartZoomIndex <= 0}
                title="Reducir tamaño de texto en comprobante (-)"
                className="w-6 h-6 flex items-center justify-center rounded text-neutral-300 hover:text-white hover:bg-neutral-700 disabled:opacity-30 disabled:cursor-not-allowed font-bold transition-colors cursor-pointer"
              >
                <Minus className="w-3 h-3" />
              </button>
              <button
                type="button"
                onClick={() => handleCartZoomChange(0)}
                title="Restablecer tamaño normal (100%)"
                className="px-1 text-[11px] font-mono font-bold text-neutral-300 hover:text-white cursor-pointer select-none"
              >
                {ZOOM_LEVELS[cartZoomIndex].label}
              </button>
              <button
                type="button"
                onClick={() => handleCartZoomChange(cartZoomIndex + 1)}
                disabled={cartZoomIndex >= ZOOM_LEVELS.length - 1}
                title="Agrandar tamaño de texto en comprobante (+)"
                className="w-6 h-6 flex items-center justify-center rounded text-neutral-300 hover:text-white hover:bg-neutral-700 disabled:opacity-30 disabled:cursor-not-allowed font-bold transition-colors cursor-pointer"
              >
                <Plus className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>

        {/* Botones de Servicios Claro, SAT y Extras en Comprobante de Compras */}
        <div className="px-3.5 py-2 bg-neutral-100 dark:bg-neutral-800/90 border-b border-neutral-200 dark:border-neutral-700/80 flex items-center justify-between gap-2">
          <span className="text-[11px] font-bold text-neutral-600 dark:text-neutral-300 uppercase tracking-wider flex items-center gap-1.5 shrink-0">
            <span>Servicios:</span>
          </span>
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              type="button"
              onClick={() => handleOpenServiceModal('CLARO')}
              className={`${cartZoomConfig.serviceBtn} bg-red-600 hover:bg-red-700 active:scale-95 text-white rounded-lg font-bold flex items-center shadow-xs transition-transform cursor-pointer`}
              title="Sumar recarga o pago Claro al comprobante de compras"
            >
              <Smartphone className={cartZoomConfig.serviceIcon} />
              <span>+ Claro</span>
            </button>
            <button
              type="button"
              onClick={() => handleOpenServiceModal('SAT')}
              className={`${cartZoomConfig.serviceBtn} bg-sky-700 hover:bg-sky-800 active:scale-95 text-white rounded-lg font-bold flex items-center shadow-xs transition-transform cursor-pointer`}
              title="Sumar cobranza o servicio SAT al comprobante de compras"
            >
              <FileText className={cartZoomConfig.serviceIcon} />
              <span>+ SAT</span>
            </button>
            <button
              type="button"
              onClick={() => handleOpenServiceModal('EXTRAS')}
              className={`${cartZoomConfig.serviceBtn} bg-amber-600 hover:bg-amber-700 active:scale-95 text-white rounded-lg font-bold flex items-center shadow-xs transition-transform cursor-pointer`}
              title="Sumar artículo o concepto extra al comprobante de compras"
            >
              <Sparkles className={cartZoomConfig.serviceIcon} />
              <span>+ Extras</span>
            </button>
          </div>
        </div>

        {/* Parked Sales Quick Notification Banner */}
        {parkedSales.length > 0 && (
          <div className="bg-amber-50 dark:bg-amber-950/40 border-b border-amber-200 dark:border-amber-800/60 px-3.5 py-2 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs text-amber-900 dark:text-amber-200 font-bold">
              <Clock className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              <span>
                {parkedSales.length} {parkedSales.length === 1 ? 'cliente pausado en espera' : 'clientes pausados en espera'}
              </span>
            </div>
            <button
              type="button"
              onClick={() => setShowParkedSalesModal(true)}
              className="text-xs px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-white rounded-lg font-bold transition-colors shadow-xs"
            >
              Ver / Recuperar
            </button>
          </div>
        )}

        {/* Cart Line Items */}
        <div className="flex-1 overflow-y-auto p-3.5 divide-y divide-neutral-100 dark:divide-neutral-800">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-neutral-400">
              <Barcode className="w-14 h-14 stroke-[1.5] mb-2 opacity-40 text-neutral-500" />
              <p className="text-sm font-semibold text-neutral-700 dark:text-neutral-300">Carrito de venta listo</p>
              <p className="text-xs mt-1 max-w-[220px]">
                Escanee con la lectora o haga clic en los artículos para agregarlos
              </p>
            </div>
          ) : (
            cart.map((item) => (
              <div key={item.article.id} className="py-3 flex items-center justify-between gap-2.5">
                <div className="min-w-0 flex-1">
                  <h5 className={`${cartZoomConfig.itemName} text-neutral-800 dark:text-neutral-100 truncate`}>
                    {item.article.name}
                  </h5>
                  <div className={`${cartZoomConfig.itemDetails} text-neutral-500 dark:text-neutral-400 flex items-center gap-2 mt-0.5`}>
                    <span className="font-semibold text-neutral-700 dark:text-neutral-300">${formatThousands(item.article.salePrice)} c/u</span>
                    <span className="text-neutral-300 dark:text-neutral-600">•</span>
                    <span className="font-mono text-neutral-400">{item.article.brand}</span>
                  </div>
                </div>

                {/* Quantity Controls */}
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => updateCartQuantity(item.article.id, item.quantity - 1)}
                    className={`${cartZoomConfig.qtyBtn} flex items-center justify-center rounded-lg bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-200 font-bold cursor-pointer transition-colors`}
                  >
                    <Minus className={cartZoomConfig.qtyIcon} />
                  </button>
                  <span className={`${cartZoomConfig.qtyText} text-center font-mono font-bold text-neutral-800 dark:text-white`}>
                    {item.quantity}
                  </span>
                  <button
                    type="button"
                    onClick={() => updateCartQuantity(item.article.id, item.quantity + 1)}
                    className={`${cartZoomConfig.qtyBtn} flex items-center justify-center rounded-lg bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-200 font-bold cursor-pointer transition-colors`}
                  >
                    <Plus className={cartZoomConfig.qtyIcon} />
                  </button>
                </div>

                {/* Subtotal & Delete */}
                <div className="text-right pl-2 shrink-0">
                  <div className={`${cartZoomConfig.itemSubtotal} font-mono text-neutral-900 dark:text-white`}>
                    ${formatThousands(item.article.salePrice * item.quantity)}
                  </div>
                  <button
                    type="button"
                    onClick={() => removeFromCart(item.article.id)}
                    className="text-xs text-rose-500 hover:text-rose-700 dark:text-rose-400 dark:hover:text-rose-300 hover:underline mt-0.5 inline-block cursor-pointer"
                  >
                    Quitar
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Cart Bottom Summary & Checkout Action */}
        <div className="p-4 border-t border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 space-y-3">
          <div className="space-y-1.5 text-xs text-neutral-600 dark:text-neutral-300">
            <div className="flex justify-between items-baseline pt-2 border-t border-neutral-200 dark:border-neutral-800">
              <span className={`${cartZoomConfig.totalLabel} text-neutral-900 dark:text-white`}>TOTAL A COBRAR</span>
              <span className={`${cartZoomConfig.totalVal} font-mono text-neutral-900 dark:text-white`}>
                ${formatThousands(cartTotal)}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-6 gap-2 pt-1">
            <button
              type="button"
              onClick={handleOpenParkModal}
              disabled={cart.length === 0}
              className={`col-span-2 ${cartZoomConfig.actionBtn} px-2 bg-amber-500 hover:bg-amber-600 disabled:opacity-40 text-white rounded-xl font-bold flex items-center justify-center gap-1.5 shadow-xs transition-colors cursor-pointer`}
              title="Poner venta actual en espera para atender a otro cliente (F8)"
            >
              <Pause className="w-3.5 h-3.5 fill-current" />
              <span>En Espera</span>
              <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono font-bold bg-white/20 rounded border border-white/30 text-white">F8</kbd>
            </button>
            <button
              type="button"
              onClick={clearCart}
              disabled={cart.length === 0}
              className={`col-span-1 ${cartZoomConfig.actionBtn} px-2 bg-white dark:bg-white border border-white dark:border-white text-black dark:text-black rounded-xl font-bold disabled:opacity-40 disabled:hover:shadow-none disabled:cursor-not-allowed shadow-xs hover:shadow-md hover:shadow-neutral-400/40 dark:hover:shadow-black/70 transition-all duration-150 cursor-pointer`}
            >
              Vaciar
            </button>
            <button
              type="button"
              onClick={handleOpenCheckout}
              disabled={cart.length === 0}
              className={`col-span-3 ${cartZoomConfig.actionBtn} px-3 bg-neutral-900 dark:bg-emerald-600 hover:bg-neutral-800 dark:hover:bg-emerald-500 text-white rounded-xl font-bold tracking-wide uppercase disabled:opacity-40 flex items-center justify-center gap-2 transition-colors shadow-xs cursor-pointer`}
            >
              <CreditCard className="w-4 h-4 text-emerald-400 dark:text-white" />
              <span>Cobrar Venta</span>
            </button>
          </div>

          {/* Quick Keyboard Shortcuts toolbar */}
          <div className="mt-2.5 pt-2 border-t border-neutral-200 dark:border-neutral-700 flex flex-wrap items-center justify-between gap-1 text-[10px] text-neutral-500 dark:text-neutral-400">
            <span className="font-bold uppercase tracking-wider text-neutral-400 dark:text-neutral-500">Atajos de teclado:</span>
            <div className="flex flex-wrap items-center gap-1 font-medium">
              <span className="inline-flex items-center gap-1 bg-neutral-100 dark:bg-neutral-800 px-1.5 py-0.5 rounded border border-neutral-200 dark:border-neutral-700">
                <kbd className="font-mono font-bold text-neutral-800 dark:text-neutral-200">F1</kbd>
                <span>Buscar</span>
              </span>
              <span className="inline-flex items-center gap-1 bg-neutral-100 dark:bg-neutral-800 px-1.5 py-0.5 rounded border border-neutral-200 dark:border-neutral-700">
                <kbd className="font-mono font-bold text-emerald-600 dark:text-emerald-400">F2</kbd>
                <span>Efectivo</span>
              </span>
              <span className="inline-flex items-center gap-1 bg-neutral-100 dark:bg-neutral-800 px-1.5 py-0.5 rounded border border-neutral-200 dark:border-neutral-700">
                <kbd className="font-mono font-bold text-sky-600 dark:text-sky-400">F3</kbd>
                <span>Mercado Pago</span>
              </span>
              <span className="inline-flex items-center gap-1 bg-neutral-100 dark:bg-neutral-800 px-1.5 py-0.5 rounded border border-neutral-200 dark:border-neutral-700">
                <kbd className="font-mono font-bold text-violet-600 dark:text-violet-400">F4</kbd>
                <span>Posnet/Tarjeta</span>
              </span>
              <span className="inline-flex items-center gap-1 bg-neutral-100 dark:bg-neutral-800 px-1.5 py-0.5 rounded border border-neutral-200 dark:border-neutral-700">
                <kbd className="font-mono font-bold text-emerald-600 dark:text-emerald-400">F5</kbd>
                <span>Transferencia</span>
              </span>
              <span className="inline-flex items-center gap-1 bg-neutral-100 dark:bg-neutral-800 px-1.5 py-0.5 rounded border border-neutral-200 dark:border-neutral-700">
                <kbd className="font-mono font-bold text-indigo-600 dark:text-indigo-400">F6</kbd>
                <span>Cta. Cte.</span>
              </span>
              <span className="inline-flex items-center gap-1 bg-neutral-100 dark:bg-neutral-800 px-1.5 py-0.5 rounded border border-neutral-200 dark:border-neutral-700">
                <kbd className="font-mono font-bold text-rose-600 dark:text-rose-400">Esc</kbd>
                <span>Cancelar</span>
              </span>
            </div>
          </div>
        </div>
      </div>
      {/* End of interactive sales grid (isolated from ticket print) */}
    </div>

      {/* CHECKOUT MODAL */}
      {showCheckoutModal && (
        <div className="no-print fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white dark:bg-neutral-900 rounded-2xl max-w-4xl xl:max-w-5xl w-full overflow-hidden shadow-2xl border border-neutral-200 dark:border-neutral-800 animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="p-4 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between bg-neutral-50 dark:bg-neutral-850">
              <div>
                <h3 className="font-bold text-base text-neutral-900">Cobrar Venta</h3>
                <p className="text-xs text-neutral-500 mt-0.5">Seleccione método de pago y confirme la transacción</p>
              </div>
              <button
                type="button"
                onClick={handleCloseCheckout}
                className="p-1 rounded-full text-neutral-400 hover:text-neutral-700 hover:bg-neutral-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 max-h-[80vh] overflow-y-auto">
              {/* Big Total Box */}
              <div className="p-4 bg-neutral-900 text-white rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-xs uppercase tracking-wider text-neutral-400">Total a abonar</span>
                  <div className="text-2xl font-black font-mono mt-0.5 flex items-baseline gap-2">
                    ${formatThousands(
                      paymentMethod === 'MERCADO_PAGO_QR' && mpSurchargeEnabled
                        ? Math.max(0, cartTotal - discountAmount) + Math.round((Math.max(0, cartTotal - discountAmount) * mpSurchargePercent) / 100)
                        : cartTotal - discountAmount
                    )}
                    {paymentMethod === 'MERCADO_PAGO_QR' && mpSurchargeEnabled && (
                      <span className="text-xs font-sans font-bold text-sky-400 bg-sky-950/80 px-2 py-0.5 rounded-md border border-sky-600/40">
                        +{mpSurchargePercent}% Recargo
                      </span>
                    )}
                  </div>
                </div>
                {hasPermission('canGiveDiscounts') && (
                  <div className="text-right">
                    <label className="text-[11px] text-white font-bold block mb-1">Descuento $</label>
                    <input
                      type="number"
                      value={discountAmount || ''}
                      onChange={(e) => setDiscountAmount(Math.max(0, parseFloat(e.target.value) || 0))}
                      placeholder="0"
                      className="w-20 px-2 py-1 bg-neutral-800 text-white text-xs rounded border border-neutral-700 font-mono text-right"
                    />
                  </div>
                )}
              </div>

              {/* Payment Methods Tabs */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                <button
                  type="button"
                  onClick={() => handleSelectPaymentMethod('EFECTIVO')}
                  className={`p-2.5 rounded-xl border text-center transition-all flex flex-col items-center gap-1 relative ${
                    paymentMethod === 'EFECTIVO'
                      ? 'border-neutral-900 bg-neutral-900 text-white shadow-xs'
                      : 'border-neutral-300 bg-white text-neutral-800 hover:bg-neutral-100 font-bold'
                  }`}
                >
                  <span className={`absolute top-1.5 right-1.5 px-1 py-0.2 font-mono text-[9px] font-bold rounded ${
                    paymentMethod === 'EFECTIVO' ? 'bg-white/20 text-white' : 'bg-neutral-100 dark:bg-neutral-700 text-neutral-500'
                  }`}>F2</span>
                  <Banknote className="w-5 h-5 text-emerald-600" />
                  <span className="text-xs font-bold">Efectivo</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSelectPaymentMethod('MERCADO_PAGO_QR')}
                  className={`p-2.5 rounded-xl border text-center transition-all flex flex-col items-center gap-1 relative ${
                    paymentMethod === 'MERCADO_PAGO_QR'
                      ? 'border-sky-600 bg-sky-600 text-white shadow-xs'
                      : 'border-neutral-300 bg-white text-neutral-800 hover:bg-neutral-100 font-bold'
                  }`}
                >
                  <span className={`absolute top-1.5 right-1.5 px-1 py-0.2 font-mono text-[9px] font-bold rounded ${
                    paymentMethod === 'MERCADO_PAGO_QR' ? 'bg-white/20 text-white' : 'bg-neutral-100 dark:bg-neutral-700 text-neutral-500'
                  }`}>F3</span>
                  <QrCode className="w-5 h-5 text-sky-500" />
                  <span className="text-xs font-bold">Mercado Pago</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSelectPaymentMethod('TARJETA_POSNET')}
                  className={`p-2.5 rounded-xl border text-center transition-all flex flex-col items-center gap-1 relative ${
                    paymentMethod === 'TARJETA_POSNET' || paymentMethod === 'BILLETERA_VIRTUAL'
                      ? 'border-violet-600 bg-violet-600 text-white shadow-xs'
                      : 'border-neutral-300 bg-white text-neutral-800 hover:bg-neutral-100 font-bold'
                  }`}
                >
                  <span className={`absolute top-1.5 right-1.5 px-1 py-0.2 font-mono text-[9px] font-bold rounded ${
                    paymentMethod === 'TARJETA_POSNET' || paymentMethod === 'BILLETERA_VIRTUAL' ? 'bg-white/20 text-white' : 'bg-neutral-100 dark:bg-neutral-700 text-neutral-500'
                  }`}>F4</span>
                  <CreditCard className="w-5 h-5 text-violet-500" />
                  <span className="text-xs font-bold">Posnet/Tarjeta</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSelectPaymentMethod('TRANSFERENCIA')}
                  className={`p-2.5 rounded-xl border text-center transition-all flex flex-col items-center gap-1 relative ${
                    paymentMethod === 'TRANSFERENCIA'
                      ? 'border-emerald-600 bg-emerald-600 text-white shadow-xs'
                      : 'border-neutral-300 bg-white text-neutral-800 hover:bg-neutral-100 font-bold'
                  }`}
                >
                  <span className={`absolute top-1.5 right-1.5 px-1 py-0.2 font-mono text-[9px] font-bold rounded ${
                    paymentMethod === 'TRANSFERENCIA' ? 'bg-white/20 text-white' : 'bg-neutral-100 dark:bg-neutral-700 text-neutral-500'
                  }`}>F5</span>
                  <CreditCard className="w-5 h-5 text-emerald-500" />
                  <span className="text-xs font-bold">Transferencia</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSelectPaymentMethod('CUENTA_CORRIENTE')}
                  className={`p-2.5 rounded-xl border text-center transition-all flex flex-col items-center gap-1 relative ${
                    paymentMethod === 'CUENTA_CORRIENTE'
                      ? 'border-indigo-600 bg-indigo-600 text-white shadow-xs'
                      : 'border-neutral-300 bg-white text-neutral-800 hover:bg-neutral-100 font-bold'
                  }`}
                >
                  <span className={`absolute top-1.5 right-1.5 px-1 py-0.2 font-mono text-[9px] font-bold rounded ${
                    paymentMethod === 'CUENTA_CORRIENTE' ? 'bg-white/20 text-white' : 'bg-neutral-100 dark:bg-neutral-700 text-neutral-500'
                  }`}>F6</span>
                  <UserCheck className="w-5 h-5 text-indigo-500" />
                  <span className="text-xs font-bold">Cta. Cte.</span>
                </button>
              </div>

              {/* Specific Payment Method Content */}
              {paymentMethod === 'EFECTIVO' && (
                <div className="space-y-3 p-4 bg-neutral-100/90 dark:bg-neutral-800/90 rounded-xl border-2 border-neutral-300 dark:border-neutral-700 shadow-xs">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-black text-neutral-950 dark:text-white uppercase tracking-wider">
                      Monto Recibido
                    </label>
                  </div>

                  <div className="relative">
                    <span className="absolute left-3.5 top-2.5 text-neutral-950 dark:text-white font-mono text-2xl font-black">$</span>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={cashAmount}
                      onFocus={(e) => {
                        if (cashAmount === '0') {
                          e.target.select();
                        }
                      }}
                      onChange={(e) => {
                        const raw = e.target.value;
                        if (raw === '') {
                          setCashAmount('0');
                          return;
                        }
                        setCashAmount(formatThousands(raw));
                      }}
                      className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-neutral-900 border-2 border-neutral-400 dark:border-neutral-600 rounded-xl text-2xl font-mono font-black text-neutral-950 dark:text-white placeholder:text-neutral-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 shadow-xs"
                      placeholder="0"
                      autoFocus
                    />
                  </div>

                  <div className="p-3.5 bg-white dark:bg-neutral-900 rounded-xl border-2 border-neutral-300 dark:border-neutral-700 flex justify-between items-center shadow-xs">
                    <span className="text-xs font-black text-neutral-950 dark:text-white uppercase tracking-wider">Vuelto / Cambio:</span>
                    <span className="text-2xl font-black font-mono text-emerald-700 dark:text-emerald-400">
                      ${formatThousands(cashChangeNum)}
                    </span>
                  </div>
                </div>
              )}

              {paymentMethod === 'MERCADO_PAGO_QR' && (() => {
                const baseNetTotal = Math.max(0, cartTotal - discountAmount);
                const mpSurchargeAmount = mpSurchargeEnabled ? Math.round((baseNetTotal * mpSurchargePercent) / 100) : 0;
                const mpEffectiveTotal = baseNetTotal + mpSurchargeAmount;

                return (
                  <div className="p-4 bg-sky-50 rounded-xl border-2 border-sky-200 text-center space-y-3">
                    {/* INTERRUPTOR: RECARGO POR PORCENTAJE MERCADO PAGO */}
                    <div className="p-3 bg-white dark:bg-neutral-900 rounded-xl border-2 border-sky-300 dark:border-sky-700 shadow-xs space-y-2.5 text-left">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <Percent className={`w-4 h-4 ${mpSurchargeEnabled ? 'text-sky-600 dark:text-sky-400' : 'text-neutral-400'}`} />
                          <div>
                            <span className="text-xs font-black text-neutral-900 dark:text-white block">
                              Recargo por Porcentaje: <span className={mpSurchargeEnabled ? 'text-sky-600 dark:text-sky-400' : 'text-neutral-500'}>{mpSurchargeEnabled ? 'ACTIVADO' : 'DESACTIVADO'}</span>
                            </span>
                            <span className="text-[10px] text-neutral-500 dark:text-neutral-400 block">
                              {mpSurchargeEnabled
                                ? `Se aplica un recargo del ${mpSurchargePercent}% al total cobrado por Mercado Pago`
                                : 'Cobro por Mercado Pago al precio regular de la venta'}
                            </span>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => setMpSurchargeEnabled(prev => !prev)}
                          className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 text-neutral-800 dark:text-neutral-200 text-xs font-bold transition-all cursor-pointer shadow-2xs"
                          title={mpSurchargeEnabled ? 'Desactivar recargo Mercado Pago' : 'Activar recargo Mercado Pago'}
                        >
                          <span
                            className={`w-7 h-3.5 flex items-center rounded-full p-0.5 transition-colors ${
                              mpSurchargeEnabled ? 'bg-sky-600' : 'bg-neutral-400 dark:bg-neutral-600'
                            }`}
                          >
                            <span
                              className={`bg-white w-2.5 h-2.5 rounded-full shadow-xs transform transition-transform ${
                                mpSurchargeEnabled ? 'translate-x-3.5' : 'translate-x-0'
                              }`}
                            />
                          </span>
                          <span className="text-[10px] font-mono font-bold">
                            {mpSurchargeEnabled ? 'ON' : 'OFF'}
                          </span>
                        </button>
                      </div>

                      {mpSurchargeEnabled && (
                        <div className="pt-2 border-t border-dashed border-sky-200 dark:border-sky-800 flex flex-wrap items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <label className="text-[11px] font-bold text-neutral-700 dark:text-neutral-300">
                              Porcentaje:
                            </label>
                            <div className="relative inline-flex items-center">
                              <input
                                type="number"
                                min="0"
                                max="100"
                                step="1"
                                value={mpSurchargePercent}
                                onChange={(e) => {
                                  const val = parseFloat(e.target.value);
                                  setMpSurchargePercent(isNaN(val) || val < 0 ? 0 : val);
                                }}
                                className="w-16 px-2 py-1 pr-5 text-xs font-mono font-bold text-right bg-sky-50 dark:bg-neutral-800 border border-sky-300 dark:border-sky-700 rounded-lg text-sky-950 dark:text-sky-200 focus:outline-hidden focus:ring-1 focus:ring-sky-500"
                              />
                              <span className="absolute right-1.5 text-xs font-bold text-sky-700 dark:text-sky-400 pointer-events-none">%</span>
                            </div>

                            <div className="flex items-center gap-1">
                              {[5, 10, 15, 20].map((pct) => (
                                <button
                                  key={pct}
                                  type="button"
                                  onClick={() => setMpSurchargePercent(pct)}
                                  className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold transition-colors cursor-pointer ${
                                    mpSurchargePercent === pct
                                      ? 'bg-sky-600 text-white'
                                      : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-sky-100 dark:hover:bg-neutral-700'
                                  }`}
                                >
                                  {pct}%
                                </button>
                              ))}
                            </div>
                          </div>

                          <div className="text-right text-xs">
                            <span className="text-[10px] text-neutral-500 dark:text-neutral-400 block">
                              Monto original: ${formatThousands(baseNetTotal)} • Recargo (+{mpSurchargePercent}%): +${formatThousands(mpSurchargeAmount)}
                            </span>
                            <span className="font-mono font-black text-sky-700 dark:text-sky-400 text-sm">
                              Total con Recargo: ${formatThousands(mpEffectiveTotal)}
                            </span>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* LIVE MERCADO PAGO POS SYNCHRONIZATION STATUS */}
                    {paymentConfig.mpAccessToken ? (
                      <div className="space-y-2">
                        {mpLiveSync.status === 'transmitting' && (
                          <div className="p-3 bg-sky-100 rounded-xl border border-sky-300 flex items-center justify-center gap-2 text-xs font-bold text-sky-950">
                            <RefreshCw className="w-4 h-4 animate-spin text-sky-600" />
                            <span>Transmitiendo ${formatThousands(mpEffectiveTotal)} a Caja {paymentConfig.mpPosName || 'QR #01'}...</span>
                          </div>
                        )}

                        {mpLiveSync.status === 'waiting' && (
                          <div className="p-3 bg-gradient-to-r from-sky-100 via-white to-sky-100 rounded-xl border-2 border-sky-400 text-left space-y-2 shadow-xs">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2 text-xs font-black text-sky-950">
                                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                                <span>Monto transmitido al QR (${formatThousands(mpEffectiveTotal)})</span>
                              </div>
                              <span className="text-[10px] font-mono font-bold bg-sky-200 text-sky-950 px-2 py-0.5 rounded-full">
                                Caja: {paymentConfig.mpPosName || 'QR #01'}
                              </span>
                            </div>
                            <p className="text-[11px] text-sky-900 leading-snug">
                              El cliente ya puede escanear con <strong>Ualá</strong>, <strong>Mercado Pago</strong> o cualquier banco. Al pagar, el sistema confirmará automáticamente la venta.
                            </p>
                            <div className="flex items-center justify-between gap-2 pt-1 border-t border-sky-200 text-xs">
                              <button
                                type="button"
                                onClick={async () => {
                                  if (activeMpOrderRef.current && paymentConfig.mpAccessToken) {
                                    const res = await MercadoPagoService.checkOrderStatus(activeMpOrderRef.current, paymentConfig.mpAccessToken);
                                    if (res.paid) {
                                      handleConfirmSale(res.paymentId);
                                    } else {
                                      DialogService.alert('Aún no se ha registrado el pago en Mercado Pago. Pide al cliente que confirme en su app.', 'Aguardando Pago', 'info');
                                    }
                                  }
                                }}
                                className="px-2.5 py-1 bg-white hover:bg-sky-50 text-sky-950 border border-sky-300 rounded-lg font-bold flex items-center gap-1.5 shadow-xs"
                              >
                                <RefreshCw className="w-3.5 h-3.5 text-sky-600" />
                                Verificar Pago Ahora
                              </button>
                              <button
                                type="button"
                                onClick={() => handleConfirmSale()}
                                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold flex items-center gap-1.5 shadow-xs"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                Confirmar Manual
                              </button>
                            </div>
                          </div>
                        )}

                        {mpLiveSync.status === 'approved' && (
                          <div className="p-3 bg-emerald-100 rounded-xl border-2 border-emerald-500 flex items-center gap-3 text-left">
                            <CheckCircle2 className="w-6 h-6 text-emerald-600 flex-shrink-0 animate-bounce" />
                            <div>
                              <div className="text-xs font-black text-emerald-950">
                                ¡Pago de ${formatThousands(mpEffectiveTotal)} Confirmado por Mercado Pago!
                              </div>
                              <div className="text-[10px] text-emerald-800 font-mono">
                                Comprobante N° {mpLiveSync.paymentId}
                              </div>
                            </div>
                          </div>
                        )}

                      {mpLiveSync.status === 'error' && (
                        <div className="p-3 bg-amber-50 rounded-xl border-2 border-amber-300 text-left text-xs space-y-1 text-amber-950">
                          <div className="font-bold flex items-center gap-1.5 text-amber-900">
                            <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0" />
                            Aviso de sincronización en vivo
                          </div>
                          <p className="text-[11px] text-amber-900">{mpLiveSync.errorMsg}</p>
                          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-amber-200">
                            <div className="flex items-center gap-2">
                              <button
                                type="button"
                                onClick={() => setMpRetryTrigger(c => c + 1)}
                                className="px-2.5 py-1 bg-sky-600 hover:bg-sky-700 text-white rounded font-bold text-xs flex items-center gap-1 shadow-xs transition-colors"
                              >
                                <RefreshCw className="w-3.5 h-3.5" />
                                Reintentar Transmisión
                              </button>
                              <button
                                type="button"
                                onClick={() => setShowPaymentConfigModal(true)}
                                className="text-[10px] font-bold text-sky-900 underline hover:text-sky-950"
                              >
                                Configurar MP
                              </button>
                            </div>
                            <button
                              type="button"
                              onClick={() => handleConfirmSale()}
                              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-bold text-xs"
                            >
                              Aprobar Venta Manualmente
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="p-2.5 bg-amber-50 rounded-xl border border-amber-300 text-left text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold flex items-center gap-1.5 text-amber-950">
                          <Zap className="w-3.5 h-3.5 text-amber-600" />
                          ¿Quieres que el monto viaje solo al celular del cliente?
                        </span>
                        <button
                          type="button"
                          onClick={() => setShowPaymentConfigModal(true)}
                          className="px-2 py-0.5 bg-amber-600 hover:bg-amber-700 text-white rounded font-bold text-[10px]"
                        >
                          Conectar MP
                        </button>
                      </div>
                      <p className="text-[10px] text-amber-900">
                        Conecta tu Access Token y Caja ({paymentConfig.mpPosName || 'QR #01'}) para automatizar cobros.
                      </p>
                    </div>
                  )}

                  {(() => {
                    const normTerm = (currentTerminalId || 'TERM-01').toUpperCase().trim();
                    const curPosId = paymentConfig.mpPosId || 'default';
                    const posSaved = paymentConfig.mpPosQrs?.[normTerm]
                      || paymentConfig.mpPosQrs?.[normTerm.replace('TERM-', '')]
                      || paymentConfig.mpPosQrs?.[curPosId];
                    const cajaName = paymentConfig.mpPosName || normTerm;
                    
                    const activePhotoUrl = posSaved?.qrImage || paymentConfig.mpQrImage;
                    const showCartelPhoto = !forceDigitalQr && Boolean(activePhotoUrl);

                    const digitalQrData = posSaved?.qrData || paymentConfig.mpQrData || paymentConfig.mpQrText || generateArgentinaInteroperableQr({
                      merchantName: paymentConfig.mpHolder || 'Manuel Silva',
                      cvuOrCbu: paymentConfig.mpCvu || '0000003100084920194820',
                      alias: paymentConfig.mpAlias || 'MANUELSILVA2003.MP'
                    });
                    const digitalQrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=${encodeURIComponent(digitalQrData)}`;

                    return (
                      <>
                        <div className="inline-block p-3 bg-white rounded-xl shadow-xs border-2 border-sky-200">
                          {showCartelPhoto && activePhotoUrl ? (
                            <div className="space-y-1.5">
                              <img
                                src={activePhotoUrl}
                                alt={`Cartel Mercado Pago - ${cajaName}`}
                                className="w-40 h-40 mx-auto object-contain rounded-lg border border-neutral-200"
                                referrerPolicy="no-referrer"
                              />
                              <div className="flex flex-wrap items-center justify-center gap-2 pt-1 border-t border-neutral-100">
                                <span className="text-[10px] text-neutral-600 font-medium">Foto de cartel ({cajaName})</span>
                                <button
                                  type="button"
                                  onClick={() => setForceDigitalQr(true)}
                                  className="text-[10px] font-bold text-sky-800 hover:text-sky-950 underline flex items-center gap-1 cursor-pointer"
                                  title="Mostrar el código QR digital oficial generado por Mercado Pago"
                                >
                                  <QrCode className="w-3 h-3 text-sky-600" />
                                  Ver QR digital generado
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    const updatedPosQrs = { ...(paymentConfig.mpPosQrs || {}) };
                                    if (updatedPosQrs[curPosId]) {
                                      updatedPosQrs[curPosId] = { ...updatedPosQrs[curPosId], qrImage: '' };
                                    }
                                    const updated = { ...paymentConfig, mpQrImage: '', mpPosQrs: updatedPosQrs };
                                    setPaymentConfig(updated);
                                    StorageService.savePaymentConfig(updated);
                                  }}
                                  className="text-[10px] font-bold text-rose-700 hover:underline flex items-center gap-1 cursor-pointer"
                                  title="Quitar foto de esta caja y usar QR oficial generado"
                                >
                                  <Trash2 className="w-3 h-3" />
                                  Quitar foto
                                </button>
                              </div>
                            </div>
                          ) : (
                            <div className="space-y-1.5">
                              <img
                                src={digitalQrUrl}
                                alt={`QR Oficial Mercado Pago - ${cajaName}`}
                                className="w-36 h-36 mx-auto rounded-lg shadow-xs"
                                referrerPolicy="no-referrer"
                              />
                              <div className="flex flex-wrap items-center justify-center gap-2 pt-1 border-t border-neutral-100">
                                <span className="text-[10px] text-emerald-800 font-bold flex items-center gap-1">
                                  <CheckCircle2 className="w-3 h-3 text-emerald-600" /> QR Digital {cajaName}
                                </span>
                                {forceDigitalQr && activePhotoUrl && (
                                  <button
                                    type="button"
                                    onClick={() => setForceDigitalQr(false)}
                                    className="text-[10px] font-bold text-sky-800 hover:underline flex items-center gap-1 cursor-pointer"
                                  >
                                    Ver foto de cartel
                                  </button>
                                )}
                                <label className="text-[10px] font-bold text-sky-800 hover:text-sky-950 underline flex items-center gap-1 cursor-pointer">
                                  <Camera className="w-3 h-3 text-sky-600" />
                                  Subir cartel {cajaName}
                                  <input
                                    type="file"
                                    accept="image/*"
                                    className="hidden"
                                    onChange={async (e) => {
                                      const file = e.target.files?.[0];
                                      if (!file) return;
                                      const reader = new FileReader();
                                      reader.onload = async () => {
                                        const dataUrl = reader.result as string;
                                        const updatedPosQrs = {
                                          ...(paymentConfig.mpPosQrs || {}),
                                          [curPosId]: {
                                            posName: cajaName,
                                            qrImage: dataUrl,
                                            qrData: paymentConfig.mpQrData,
                                            qrText: paymentConfig.mpQrText
                                          }
                                        };
                                        const updated = {
                                          ...paymentConfig,
                                          mpQrImage: dataUrl,
                                          mpPosQrs: updatedPosQrs
                                        };
                                        setPaymentConfig(updated);
                                        StorageService.savePaymentConfig(updated);
                                        setForceDigitalQr(false);
                                        DialogService.alert(`¡Cartel físico guardado para ${cajaName}!`, 'Cartel Guardado', 'success');
                                      };
                                      reader.readAsDataURL(file);
                                    }}
                                  />
                                </label>
                              </div>
                            </div>
                          )}
                        </div>
                        <div>
                          <div className="text-xs font-black text-sky-950">
                            {showCartelPhoto ? `Cartel Oficial de Mercado Pago (${cajaName})` : `QR Digital Oficial (${cajaName})`}
                          </div>
                          <p className="text-xs text-neutral-800 mt-0.5">
                            Alias MP: <strong className="font-mono text-sky-950 font-black">{paymentConfig.mpAlias || 'MANUELSILVA2003.MP'}</strong> • {paymentConfig.mpHolder || 'Comercio'}
                          </p>
                        </div>
                        {!showCartelPhoto && !posSaved?.qrData && !paymentConfig.mpQrData && (
                          <div className="p-2 bg-amber-50 border border-amber-200 rounded-lg text-[11px] text-amber-900 text-left">
                            <strong>⚠️ Cartel de {cajaName} pendiente:</strong>
                            <div className="text-[10px] text-amber-800 mt-0.5">
                              Para que tu app de Mercado Pago lo escanee y detecte el cobro exactamente igual que en la Caja 1, sube una foto o imagen del cartel de esta caja con el botón azul <strong>"Subir cartel {cajaName}"</strong> de arriba.
                            </div>
                          </div>
                        )}
                      </>
                    );
                  })()}
                  <div className="flex items-center justify-between gap-2 pt-1 border-t border-sky-200">
                    <div className="flex items-center gap-1.5 text-xs text-emerald-800 font-bold">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      QR Listo en 2da Pantalla
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowPaymentConfigModal(true)}
                      className="text-xs font-bold text-sky-800 hover:text-sky-950 hover:underline flex items-center gap-1"
                    >
                      <Settings className="w-3 h-3" />
                      Configurar Mercado Pago
                    </button>
                  </div>
                </div>
              );
            })()}

              {(paymentMethod === 'TARJETA_POSNET' || paymentMethod === 'BILLETERA_VIRTUAL') && (() => {
                const netTotal = Math.max(0, cartTotal - discountAmount);

                const handleStartAutoFlow = () => {
                  setPosnetAutoStatus('WAITING_CARD');
                  StorageService.updateCustomerDisplayState({
                    status: 'PAYING',
                    items: cart.map(item => ({
                      name: item.article.name,
                      quantity: item.quantity,
                      unitPrice: item.customPrice ?? item.article.salePrice,
                      total: (item.customPrice ?? item.article.salePrice) * item.quantity,
                    })),
                    subtotal: cartTotal,
                    discount: discountAmount,
                    total: netTotal,
                    paymentMethod: 'TARJETA_POSNET',
                    posnetMode: 'AUTOMATIC',
                    posnetStatus: 'WAITING_CARD',
                    posnetCardType: cardType,
                    posnetCardBrand: cardBrand,
                    terminalId: currentTerminalId,
                    timestamp: Date.now(),
                  });
                };

                const handleSimulateCardRead = () => {
                  setPosnetAutoStatus('PROCESSING');
                  StorageService.updateCustomerDisplayState({
                    status: 'PAYING',
                    items: cart.map(item => ({
                      name: item.article.name,
                      quantity: item.quantity,
                      unitPrice: item.customPrice ?? item.article.salePrice,
                      total: (item.customPrice ?? item.article.salePrice) * item.quantity,
                    })),
                    subtotal: cartTotal,
                    discount: discountAmount,
                    total: netTotal,
                    paymentMethod: 'TARJETA_POSNET',
                    posnetMode: 'AUTOMATIC',
                    posnetStatus: 'PROCESSING',
                    posnetCardType: cardType,
                    posnetCardBrand: cardBrand,
                    terminalId: currentTerminalId,
                    timestamp: Date.now(),
                  });

                  setTimeout(() => {
                    const code = `AUT-${Math.floor(100000 + Math.random() * 900000)}`;
                    const batch = `LOTE-${(Math.floor(Math.random() * 5) + 1).toString().padStart(3, '0')}`;
                    setPosnetAutoAuthCode(code);
                    setPosnetAutoBatch(batch);
                    setPosnetAutoStatus('APPROVED');

                    StorageService.updateCustomerDisplayState({
                      status: 'PAYING',
                      items: cart.map(item => ({
                        name: item.article.name,
                        quantity: item.quantity,
                        unitPrice: item.customPrice ?? item.article.salePrice,
                        total: (item.customPrice ?? item.article.salePrice) * item.quantity,
                      })),
                      subtotal: cartTotal,
                      discount: discountAmount,
                      total: netTotal,
                      paymentMethod: 'TARJETA_POSNET',
                      posnetMode: 'AUTOMATIC',
                      posnetStatus: 'APPROVED',
                      posnetCardType: cardType,
                      posnetCardBrand: cardBrand,
                      terminalId: currentTerminalId,
                      timestamp: Date.now(),
                    });
                  }, 900);
                };

                return (
                  <div className="space-y-3.5 p-4 bg-violet-50/70 rounded-xl border-2 border-violet-200 text-xs">
                    {/* Header: Terminal activa y config */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-violet-200/80">
                      <div className="flex items-center gap-2">
                        <div className="p-1.5 bg-violet-600 text-white rounded-lg">
                          <CreditCard className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="font-extrabold text-violet-950 text-xs flex items-center gap-1.5">
                            <span>Cobro con Tarjeta / Posnet</span>
                            <span className="text-[10px] font-bold px-2 py-0.2 bg-violet-200 text-violet-900 rounded-full">
                              {paymentConfig.posnetBrand || 'Payway / Posnet'} ({paymentConfig.posnetTerminalId || 'POS-01'})
                            </span>
                          </div>
                          <p className="text-[10px] text-neutral-600">
                            Total a cobrar: <strong className="font-mono text-violet-900">${formatThousands(netTotal)}</strong>
                          </p>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => setShowPaymentConfigModal(true)}
                        className="text-xs font-bold text-violet-800 hover:text-violet-950 hover:underline flex items-center gap-1 self-start sm:self-auto"
                      >
                        <Settings className="w-3.5 h-3.5" />
                        Configurar Posnet
                      </button>
                    </div>

                    {/* Selector de los 2 modos: Manual o Automático */}
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="font-black text-violet-950 uppercase tracking-wide text-[11px]">
                          Elegir Modo de Cobro:
                        </span>
                        <span className="text-[10px] text-neutral-500">
                          {posnetMode === 'MANUAL' ? 'Operación en terminal física' : 'Transmisión interactiva'}
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setPosnetMode('MANUAL');
                            setPosnetAutoStatus('IDLE');
                          }}
                          className={`py-2 px-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all ${
                            posnetMode === 'MANUAL'
                              ? 'bg-violet-700 text-white shadow-xs scale-102 ring-2 ring-violet-400'
                              : 'bg-white border-2 border-neutral-300 text-neutral-700 hover:bg-neutral-100'
                          }`}
                        >
                          <CreditCard className="w-4 h-4" />
                          <span>Modo Manual (Posnet Físico)</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setPosnetMode('AUTOMATIC');
                            if (posnetAutoStatus === 'IDLE') {
                              handleStartAutoFlow();
                            }
                          }}
                          className={`py-2 px-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all ${
                            posnetMode === 'AUTOMATIC'
                              ? 'bg-violet-700 text-white shadow-xs scale-102 ring-2 ring-violet-400'
                              : 'bg-white border-2 border-neutral-300 text-neutral-700 hover:bg-neutral-100'
                          }`}
                        >
                          <Zap className="w-4 h-4" />
                          <span>Modo Automático (Lector / Point)</span>
                        </button>
                      </div>
                    </div>

                    {/* VISTA MODO MANUAL */}
                    {posnetMode === 'MANUAL' && (
                      <div className="space-y-3 animate-in fade-in">
                        <div className="p-2.5 bg-white rounded-xl border border-violet-200 flex items-center gap-2 text-violet-900 text-xs">
                          <CheckCircle2 className="w-4 h-4 text-violet-600 flex-shrink-0" />
                          <span>
                            Pase la tarjeta en el <strong>Posnet físico</strong> del mostrador por <strong>${formatThousands(netTotal)}</strong>. Registre los datos para el comprobante:
                          </span>
                        </div>

                        {/* Tipo de Tarjeta */}
                        <div>
                          <label className="block font-black text-neutral-900 uppercase tracking-wide mb-1 text-[11px]">
                            Tipo de Tarjeta:
                          </label>
                          <div className="grid grid-cols-3 gap-1.5">
                            {(['DEBITO', 'CREDITO', 'PREPAGA'] as const).map(type => (
                              <button
                                key={type}
                                type="button"
                                onClick={() => setCardType(type)}
                                className={`py-1.5 px-2 rounded-lg font-bold text-xs transition-all ${
                                  cardType === type
                                    ? 'bg-violet-600 text-white shadow-xs'
                                    : 'bg-white border border-neutral-300 text-neutral-800 hover:bg-neutral-100'
                                }`}
                              >
                                {type === 'DEBITO' ? 'Débito' : type === 'CREDITO' ? 'Crédito' : 'Prepaga'}
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* Marca de Tarjeta */}
                        <div>
                          <label className="block font-black text-neutral-900 uppercase tracking-wide mb-1 text-[11px]">
                            Marca / Emisor de la Tarjeta:
                          </label>
                          <div className="flex flex-wrap gap-1.5">
                            {['Visa', 'Mastercard', 'Cabal', 'Maestro', 'Amex', 'Naranja', 'Otra'].map(brand => (
                              <button
                                key={brand}
                                type="button"
                                onClick={() => setCardBrand(brand)}
                                className={`px-2.5 py-1 rounded-lg font-bold text-xs transition-all ${
                                  cardBrand === brand
                                    ? 'bg-violet-800 text-white shadow-xs'
                                    : 'bg-white border border-neutral-300 text-neutral-800 hover:bg-neutral-100'
                                }`}
                              >
                                {brand}
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* Cuotas (si es Crédito) */}
                        {cardType === 'CREDITO' && (
                          <div className="p-2.5 bg-white rounded-xl border border-violet-200">
                            <label className="block font-black text-neutral-900 uppercase tracking-wide mb-1 text-[11px]">
                              Cantidad de Cuotas:
                            </label>
                            <div className="grid grid-cols-4 gap-1.5">
                              {[1, 3, 6, 12].map(num => (
                                <button
                                  key={num}
                                  type="button"
                                  onClick={() => setInstallments(num)}
                                  className={`py-1 px-2 rounded-lg font-bold text-xs transition-all ${
                                    installments === num
                                      ? 'bg-violet-700 text-white shadow-xs'
                                      : 'bg-neutral-100 border border-neutral-300 text-neutral-800 hover:bg-neutral-200'
                                  }`}
                                >
                                  {num === 1 ? '1 Pago' : `${num} Cuotas`}
                                </button>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Datos de cupón / tarjeta para arqueo */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          <div>
                            <label className="block font-black text-neutral-900 uppercase tracking-wide mb-1 text-[11px]">
                              N° de Cupón / Autorización (Opcional):
                            </label>
                            <input
                              type="text"
                              placeholder="Ej: 4821"
                              value={couponNumber}
                              onChange={(e) => setCouponNumber(e.target.value.replace(/\D/g, ''))}
                              className="w-full px-3 py-2 bg-white border-2 border-neutral-300 rounded-lg font-mono text-xs font-bold text-neutral-950 focus:outline-hidden focus:ring-2 focus:ring-violet-500"
                            />
                          </div>

                          <div>
                            <label className="block font-black text-neutral-900 uppercase tracking-wide mb-1 text-[11px]">
                              Últimos 4 Dígitos de Tarjeta (Opcional):
                            </label>
                            <input
                              type="text"
                              maxLength={4}
                              placeholder="Ej: 1234"
                              value={cardLastFour}
                              onChange={(e) => setCardLastFour(e.target.value.replace(/\D/g, ''))}
                              className="w-full px-3 py-2 bg-white border-2 border-neutral-300 rounded-lg font-mono text-xs font-bold text-neutral-950 focus:outline-hidden focus:ring-2 focus:ring-violet-500"
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {/* VISTA MODO AUTOMÁTICO */}
                    {posnetMode === 'AUTOMATIC' && (
                      <div className="space-y-3 animate-in fade-in">
                        {posnetAutoStatus === 'IDLE' && (
                          <div className="p-4 bg-white rounded-xl border border-violet-200 text-center space-y-2.5">
                            <div className="w-10 h-10 mx-auto rounded-full bg-violet-100 flex items-center justify-center text-violet-700">
                              <Radio className="w-5 h-5" />
                            </div>
                            <div>
                              <h5 className="font-extrabold text-sm text-neutral-900">
                                Terminal Lista: {paymentConfig.posnetBrand || 'Payway / Posnet'}
                              </h5>
                              <p className="text-xs text-neutral-600">
                                Transmita el monto de <strong>${formatThousands(netTotal)}</strong> al lector para que el cliente pase su tarjeta.
                              </p>
                            </div>
                            <button
                              type="button"
                              onClick={handleStartAutoFlow}
                              className="px-4 py-2 bg-violet-700 hover:bg-violet-800 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 mx-auto shadow-xs active:scale-95 transition-all"
                            >
                              <Zap className="w-4 h-4" />
                              Transmitir Cobro a Terminal Posnet
                            </button>
                          </div>
                        )}

                        {posnetAutoStatus === 'WAITING_CARD' && (
                          <div className="p-4 bg-white rounded-xl border-2 border-violet-400 text-center space-y-3">
                            <div className="relative w-12 h-12 mx-auto">
                              <div className="absolute inset-0 rounded-full bg-violet-400 animate-ping opacity-40" />
                              <div className="relative w-12 h-12 rounded-full bg-violet-600 flex items-center justify-center text-white shadow-xs">
                                <CreditCard className="w-6 h-6 animate-pulse" />
                              </div>
                            </div>
                            <div>
                              <span className="font-extrabold text-sm text-violet-950 block">
                                Esperando Tarjeta en la Terminal Posnet...
                              </span>
                              <span className="text-xs text-neutral-600 block mt-0.5">
                                El cliente debe acercar (Contactless), insertar Chip o deslizar su tarjeta
                              </span>
                              <div className="font-mono text-lg font-black text-violet-900 mt-1">
                                ${formatThousands(netTotal)}
                              </div>
                            </div>

                            <div className="flex flex-col sm:flex-row items-center justify-center gap-2 pt-1">
                              <button
                                type="button"
                                onClick={handleSimulateCardRead}
                                className="w-full sm:w-auto px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-all active:scale-95"
                              >
                                <Check className="w-4 h-4" />
                                Simular Lectura de Tarjeta (Chip/Contactless)
                              </button>

                              <button
                                type="button"
                                onClick={() => setPosnetMode('MANUAL')}
                                className="w-full sm:w-auto px-3 py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 rounded-xl font-bold text-xs"
                              >
                                Cambiar a Modo Manual
                              </button>
                            </div>
                          </div>
                        )}

                        {posnetAutoStatus === 'PROCESSING' && (
                          <div className="p-5 bg-white rounded-xl border border-violet-200 text-center space-y-2">
                            <RefreshCw className="w-8 h-8 text-violet-600 animate-spin mx-auto" />
                            <h5 className="font-bold text-neutral-900 text-sm">
                              Comunicando con la Entidad Emisora...
                            </h5>
                            <p className="text-xs text-neutral-500">
                              Validando PIN y autorización con la red de pagos
                            </p>
                          </div>
                        )}

                        {posnetAutoStatus === 'APPROVED' && (
                          <div className="p-4 bg-emerald-50 rounded-xl border-2 border-emerald-400 text-center space-y-2">
                            <div className="w-10 h-10 mx-auto rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-xs">
                              <Check className="w-6 h-6" />
                            </div>
                            <div>
                              <h5 className="font-black text-sm text-emerald-950">
                                ¡Pago Aprobado por la Terminal Posnet!
                              </h5>
                              <div className="text-xs text-emerald-800 font-mono mt-1 space-x-2">
                                <span><strong>Autorización:</strong> {posnetAutoAuthCode}</span>
                                <span>• <strong>Lote:</strong> {posnetAutoBatch}</span>
                              </div>
                            </div>
                            <p className="text-[11px] text-emerald-700 font-medium">
                              La transacción fue acreditada en el Posnet. Puede presionar "Finalizar Venta e Imprimir" abajo.
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })()}

              {paymentMethod === 'TRANSFERENCIA' && (() => {
                const netTotal = Math.max(0, cartTotal - discountAmount);
                const totalRec = receivedTransfers.reduce((s, t) => s + t.amount, 0);
                const remaining = Math.max(0, netTotal - totalRec);
                const isCovered = totalRec >= netTotal && netTotal > 0;
                const progressPct = netTotal > 0 ? Math.min(100, Math.round((totalRec / netTotal) * 100)) : 0;
                const last5Transfers = receivedTransfers.slice(-5).reverse();
                const allDetectedTransfers = allRecentMpTransfers.filter(
                  t => !receivedTransfers.some(rt => rt.id === t.id) && 
                       !dismissedTransferIds.includes(t.id) &&
                       !isTransferAlreadyUsed(t.id, t.reference)
                );

                const detectedPendingTransfers = allDetectedTransfers.filter(t => {
                  if (!transfersTimerEnabled) return true;
                  const firstSeen = transferFirstSeenRef.current[t.id] || t.timestamp || Date.now();
                  const elapsedSec = (currentTickTime - firstSeen) / 1000;
                  return elapsedSec < transfersTimeoutSeconds;
                });

                const expiredByTimerCount = allDetectedTransfers.length - detectedPendingTransfers.length;

                return (
                  <div className="space-y-3.5 p-4 bg-emerald-50/70 dark:bg-neutral-850 rounded-2xl border-2 border-emerald-300 dark:border-emerald-600/40 text-xs">
                    {/* MONITOR DE RECEPCIÓN EN TIEMPO REAL */}
                    <div className="p-3.5 bg-white dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700 shadow-xs space-y-3">
                      {/* Cabecera de Estado y Montos */}
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs uppercase font-extrabold text-neutral-500 dark:text-neutral-400">
                              Total a Cobrar:
                            </span>
                            <button
                              type="button"
                              onClick={() => setShowTransferTotalAmount(prev => !prev)}
                              className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-750 dark:hover:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 text-neutral-700 dark:text-neutral-300 text-[11px] font-bold transition-all cursor-pointer shadow-2xs"
                              title={showTransferTotalAmount ? 'Ocultar precio a cobrar' : 'Mostrar precio a cobrar'}
                            >
                              <span
                                className={`w-7 h-3.5 flex items-center rounded-full p-0.5 transition-colors ${
                                  showTransferTotalAmount ? 'bg-emerald-600' : 'bg-neutral-400 dark:bg-neutral-600'
                                }`}
                              >
                                <span
                                  className={`bg-white w-2.5 h-2.5 rounded-full shadow-xs transform transition-transform ${
                                    showTransferTotalAmount ? 'translate-x-3.5' : 'translate-x-0'
                                  }`}
                                />
                              </span>
                              {showTransferTotalAmount ? (
                                <Eye className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                              ) : (
                                <EyeOff className="w-3.5 h-3.5 text-neutral-500" />
                              )}
                            </button>
                          </div>
                          <div className="text-2xl font-black font-mono text-neutral-900 dark:text-white">
                            {showTransferTotalAmount ? `$${formatThousands(netTotal)}` : '••••••'}
                          </div>
                        </div>

                        <div className="text-right">
                          <div className="text-xs uppercase font-extrabold text-neutral-500 dark:text-neutral-400 mb-1">
                            Total Acreditado:
                          </div>
                          <div className="text-2xl font-black font-mono text-emerald-600 dark:text-emerald-400">
                            ${formatThousands(totalRec)}
                          </div>
                        </div>
                      </div>

                      {/* INTERRUPTOR: MODO DE ACREDITACIÓN (AUTOMÁTICA O MANUAL POR CAJERO) */}
                      <div className="flex items-center justify-between p-2 sm:p-2.5 bg-neutral-100/90 dark:bg-neutral-900/80 rounded-xl border border-neutral-300 dark:border-neutral-700">
                        <div className="flex items-center gap-2">
                          <Zap className={`w-4 h-4 ${autoAccreditTransfers ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-500'}`} />
                          <div>
                            <span className="text-xs font-black text-neutral-900 dark:text-white block">
                              Modo de Acreditación: <span className={autoAccreditTransfers ? 'text-emerald-700 dark:text-emerald-400' : 'text-amber-700 dark:text-amber-400'}>{autoAccreditTransfers ? 'Automática' : 'Elegir por Cajero (Manual)'}</span>
                            </span>
                            <span className="text-[10px] text-neutral-500 dark:text-neutral-400 block">
                              {autoAccreditTransfers
                                ? 'Las transferencias se acreditan automáticamente al ingresar'
                                : 'Detecta siempre en vivo y el cajero elige cuál acreditar'}
                            </span>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => setAutoAccreditTransfers(prev => !prev)}
                          className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-600 text-neutral-800 dark:text-neutral-200 text-xs font-bold transition-all cursor-pointer shadow-2xs hover:bg-neutral-50 dark:hover:bg-neutral-700"
                          title={autoAccreditTransfers ? 'Cambiar a selección manual por cajero' : 'Cambiar a acreditación automática'}
                        >
                          <span
                            className={`w-7 h-3.5 flex items-center rounded-full p-0.5 transition-colors ${
                              autoAccreditTransfers ? 'bg-emerald-600' : 'bg-neutral-400 dark:bg-neutral-600'
                            }`}
                          >
                            <span
                              className={`bg-white w-2.5 h-2.5 rounded-full shadow-xs transform transition-transform ${
                                autoAccreditTransfers ? 'translate-x-3.5' : 'translate-x-0'
                              }`}
                            />
                          </span>
                          <span className="text-[10px] font-mono">
                            {autoAccreditTransfers ? 'AUTO' : 'MANUAL'}
                          </span>
                        </button>
                      </div>

                      {/* Barra de Progreso */}
                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px] font-bold">
                          <span className={isCovered ? 'text-emerald-700 dark:text-emerald-400' : 'text-neutral-600 dark:text-neutral-400'}>
                            {progressPct}% Cubierto
                          </span>
                          {!isCovered && remaining > 0 ? (
                            <span className="text-amber-700 dark:text-amber-400 font-extrabold animate-pulse">
                              Resta cobrar: ${formatThousands(remaining)}
                            </span>
                          ) : (
                            <span className="text-emerald-600 dark:text-emerald-400 font-extrabold flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5" /> Pago Completo
                            </span>
                          )}
                        </div>
                        <div className="w-full bg-neutral-200 dark:bg-neutral-700 h-2.5 rounded-full overflow-hidden">
                          <div
                            className={`h-full transition-all duration-500 rounded-full ${
                              isCovered
                                ? 'bg-emerald-500'
                                : totalRec > 0
                                ? 'bg-amber-500'
                                : 'bg-neutral-300'
                            }`}
                            style={{ width: `${progressPct}%` }}
                          />
                        </div>
                      </div>

                      {/* Banner de Estado Dinámico */}
                      {isCovered ? (
                        <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950/80 border border-emerald-400 dark:border-emerald-600 rounded-lg text-emerald-900 dark:text-emerald-200 flex items-center justify-between text-xs font-bold">
                          <span className="flex items-center gap-2">
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                            ¡PAGO TOTAL 100% CUBIERTO Y APROBADO!
                          </span>
                          <span className="text-[11px] bg-emerald-200 dark:bg-emerald-900 px-2 py-0.5 rounded text-emerald-950 dark:text-emerald-100">
                            Listo para Confirmar
                          </span>
                        </div>
                      ) : totalRec > 0 ? (
                        <div className="space-y-2">
                          <div className="p-2.5 bg-amber-50 dark:bg-amber-950/70 border border-amber-300 dark:border-amber-700 rounded-lg text-amber-900 dark:text-amber-200 flex items-center justify-between text-xs font-semibold">
                            <span className="flex items-center gap-2">
                              <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping" />
                              Pago parcial recibido. Esperando ${formatThousands(remaining)} restante...
                            </span>
                          </div>

                          {/* COBRAR RESTANTE EN EFECTIVO (PAGO MIXTO) */}
                          <div className="p-3 bg-orange-50 dark:bg-orange-950/40 rounded-xl border-2 border-orange-400 dark:border-orange-500 shadow-xs space-y-2.5">
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                              <div className="flex items-center gap-2">
                                <Banknote className="w-4 h-4 text-orange-600 dark:text-orange-400 flex-shrink-0" />
                                <span className="font-extrabold text-xs text-orange-950 dark:text-orange-100">
                                  ¿Cobrar restante en Efectivo (${formatThousands(remaining)})?
                                </span>
                              </div>
                              <button
                                type="button"
                                onClick={() => {
                                  setPayRemainingInCash(prev => {
                                    const next = !prev;
                                    if (next) {
                                      setSplitCashReceived(formatThousands(remaining));
                                    } else {
                                      setSplitCashReceived('');
                                    }
                                    return next;
                                  });
                                }}
                                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer shadow-xs flex items-center gap-1.5 ${
                                  payRemainingInCash
                                    ? 'bg-orange-600 hover:bg-orange-700 text-white ring-2 ring-orange-400'
                                    : 'bg-white dark:bg-neutral-800 border border-orange-300 dark:border-orange-600 text-orange-950 dark:text-orange-200 hover:bg-orange-100/60'
                                }`}
                              >
                                {payRemainingInCash ? '✓ Efectivo Activado' : '+ Cobrar Resto en Efectivo'}
                              </button>
                            </div>

                            {payRemainingInCash && (() => {
                              const cashRecNum = parseFormattedNumber(splitCashReceived || '0');
                              const cashChangeVal = Math.max(0, cashRecNum - remaining);
                              return (
                                <div className="pt-2 border-t border-orange-200 dark:border-orange-900/60 grid grid-cols-1 sm:grid-cols-2 gap-2.5 animate-in fade-in">
                                  <div>
                                    <label className="block text-[11px] font-black text-orange-950 dark:text-orange-200 uppercase mb-1">
                                      Efectivo Recibido:
                                    </label>
                                    <div className="relative">
                                      <span className="absolute left-3 top-2 text-neutral-900 dark:text-white font-mono text-base font-bold">$</span>
                                      <input
                                        type="text"
                                        inputMode="decimal"
                                        value={splitCashReceived}
                                        onFocus={(e) => {
                                          if (splitCashReceived === '0') {
                                            e.target.select();
                                          }
                                        }}
                                        onChange={(e) => {
                                          const raw = e.target.value;
                                          if (raw === '') {
                                            setSplitCashReceived('0');
                                            return;
                                          }
                                          setSplitCashReceived(formatThousands(raw));
                                        }}
                                        className="w-full pl-7 pr-3 py-1.5 bg-white dark:bg-neutral-900 border-2 border-orange-300 dark:border-orange-600 rounded-lg text-base font-mono font-black text-neutral-950 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-orange-500 shadow-xs"
                                        placeholder={formatThousands(remaining)}
                                        autoFocus
                                      />
                                    </div>
                                  </div>

                                  <div className="flex flex-col justify-between p-2.5 bg-white dark:bg-neutral-900 rounded-lg border border-orange-300 dark:border-orange-700/60 shadow-2xs">
                                    <span className="text-[10px] font-black uppercase text-orange-900 dark:text-orange-300">
                                      Vuelto / Cambio a entregar:
                                    </span>
                                    <div className="text-xl font-black font-mono text-orange-600 dark:text-orange-400">
                                      ${formatThousands(cashChangeVal)}
                                    </div>
                                    <span className="text-[10px] text-neutral-500 dark:text-neutral-400">
                                      Cubre los ${formatThousands(remaining)} restantes
                                    </span>
                                  </div>
                                </div>
                              );
                            })()}
                          </div>
                        </div>
                      ) : (
                        <div className="p-2.5 bg-neutral-100 dark:bg-neutral-900/80 border border-neutral-200 dark:border-neutral-700 rounded-lg text-neutral-700 dark:text-neutral-300 flex items-center justify-between text-xs">
                          <span className="flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                            Esperando transferencias al Alias... (Detección en tiempo real)
                          </span>
                          {paymentConfig.mpAccessToken && (
                            <button
                              type="button"
                              onClick={handleManualCheckTransfers}
                              disabled={isCheckingTransfers}
                              className="text-[10px] font-bold text-emerald-700 dark:text-emerald-400 hover:underline flex items-center gap-1"
                            >
                              <RefreshCw className={`w-3 h-3 ${isCheckingTransfers ? 'animate-spin' : ''}`} />
                              Actualizar
                            </button>
                          )}
                        </div>
                      )}

                      {/* TRANSFERENCIAS DETECTADAS EN VIVO PENDIENTES DE ELECCIÓN POR EL CAJERO */}
                      {!autoAccreditTransfers && (
                        <div className="p-3 bg-amber-50/90 dark:bg-amber-950/40 rounded-xl border-2 border-amber-400 dark:border-amber-600/70 shadow-xs space-y-2.5">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <div className="flex items-center gap-2">
                              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
                              <span className="font-black text-xs text-amber-950 dark:text-amber-200 uppercase tracking-wide">
                                Transferencias Detectadas ({detectedPendingTransfers.length}):
                              </span>
                            </div>
                            <span className="text-[10px] font-bold text-amber-900 dark:text-amber-300">
                              Elige cuál acreditar a esta venta:
                            </span>
                          </div>

                          {/* INTERRUPTOR: AUTO-OCULTAR POR TIEMPO */}
                          <div className="p-2.5 bg-white dark:bg-neutral-900 rounded-xl border border-amber-300 dark:border-neutral-700 space-y-2">
                            <div className="flex flex-wrap items-center justify-between gap-2">
                              <div className="flex items-center gap-2">
                                <Clock className={`w-4 h-4 ${transfersTimerEnabled ? 'text-amber-600 dark:text-amber-400' : 'text-neutral-400'}`} />
                                <div>
                                  <span className="text-xs font-black text-neutral-900 dark:text-white block">
                                    Auto-ocultar por Tiempo: <span className={transfersTimerEnabled ? 'text-amber-700 dark:text-amber-400 font-bold' : 'text-neutral-500'}>{transfersTimerEnabled ? 'ACTIVADO' : 'DESACTIVADO'}</span>
                                  </span>
                                  <span className="text-[10px] text-neutral-500 dark:text-neutral-400 block">
                                    {transfersTimerEnabled
                                      ? `Las transferencias se van ocultando en orden tras ${transfersTimeoutSeconds >= 60 ? `${Math.floor(transfersTimeoutSeconds / 60)} min` : `${transfersTimeoutSeconds} seg`} para agilizar el cobro`
                                      : 'Permanecen visibles sin límite de tiempo'}
                                  </span>
                                </div>
                              </div>

                              <button
                                type="button"
                                onClick={() => setTransfersTimerEnabled(prev => !prev)}
                                className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 text-neutral-800 dark:text-neutral-200 text-xs font-bold transition-all cursor-pointer shadow-2xs"
                                title={transfersTimerEnabled ? 'Desactivar auto-ocultar por tiempo' : 'Activar auto-ocultar por tiempo'}
                              >
                                <span
                                  className={`w-7 h-3.5 flex items-center rounded-full p-0.5 transition-colors ${
                                    transfersTimerEnabled ? 'bg-amber-500' : 'bg-neutral-400 dark:bg-neutral-600'
                                  }`}
                                >
                                  <span
                                    className={`bg-white w-2.5 h-2.5 rounded-full shadow-xs transform transition-transform ${
                                      transfersTimerEnabled ? 'translate-x-3.5' : 'translate-x-0'
                                    }`}
                                  />
                                </span>
                                <span className="text-[10px] font-mono font-bold">
                                  {transfersTimerEnabled ? 'ON' : 'OFF'}
                                </span>
                              </button>
                            </div>

                            {transfersTimerEnabled && (
                              <div className="pt-2 border-t border-dashed border-amber-200 dark:border-neutral-700 flex flex-wrap items-center justify-between gap-2 animate-in fade-in">
                                <div className="flex flex-wrap items-center gap-2">
                                  <label className="text-[11px] font-bold text-neutral-700 dark:text-neutral-300">
                                    Ocultar en orden cada:
                                  </label>
                                  <div className="flex items-center gap-1">
                                    {[
                                      { sec: 30, label: '30 seg' },
                                      { sec: 60, label: '1 min' },
                                      { sec: 120, label: '2 min' },
                                      { sec: 180, label: '3 min' },
                                      { sec: 300, label: '5 min' },
                                    ].map(opt => (
                                      <button
                                        key={opt.sec}
                                        type="button"
                                        onClick={() => setTransfersTimeoutSeconds(opt.sec)}
                                        className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold transition-colors cursor-pointer ${
                                          transfersTimeoutSeconds === opt.sec
                                            ? 'bg-amber-500 text-white shadow-xs'
                                            : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-amber-100 dark:hover:bg-neutral-700'
                                        }`}
                                      >
                                        {opt.label}
                                      </button>
                                    ))}
                                  </div>
                                </div>

                                <div className="flex items-center gap-1.5">
                                  <span className="text-[10px] font-medium text-neutral-500 dark:text-neutral-400">Segundos:</span>
                                  <input
                                    type="number"
                                    min="10"
                                    max="1800"
                                    step="5"
                                    value={transfersTimeoutSeconds}
                                    onChange={(e) => {
                                      const val = parseInt(e.target.value, 10);
                                      setTransfersTimeoutSeconds(isNaN(val) || val < 5 ? 5 : val);
                                    }}
                                    className="w-14 px-1.5 py-0.5 text-xs font-mono font-bold text-right bg-amber-50 dark:bg-neutral-800 border border-amber-300 dark:border-neutral-700 rounded text-neutral-900 dark:text-white focus:outline-hidden focus:ring-1 focus:ring-amber-500"
                                  />
                                </div>
                              </div>
                            )}
                          </div>

                          {detectedPendingTransfers.length === 0 ? (
                            <div className="p-3 bg-white/80 dark:bg-neutral-900/60 rounded-lg border border-dashed border-amber-300 dark:border-neutral-700 text-center text-xs text-neutral-500">
                              Detectando en vivo... Las transferencias que ingresen aparecerán aquí para que las acredites.
                            </div>
                          ) : (
                            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                              {detectedPendingTransfers.slice(0, 8).map((item) => {
                                const firstSeen = transferFirstSeenRef.current[item.id] || item.timestamp || Date.now();
                                const elapsedSec = (currentTickTime - firstSeen) / 1000;
                                const remainingSec = Math.max(0, Math.ceil(transfersTimeoutSeconds - elapsedSec));
                                const remainingPct = Math.max(0, Math.min(100, Math.round((remainingSec / transfersTimeoutSeconds) * 100)));

                                return (
                                  <div
                                    key={item.id}
                                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 bg-white dark:bg-neutral-900 rounded-xl border-2 border-amber-300 dark:border-neutral-700 shadow-xs hover:border-amber-400 transition-all"
                                  >
                                    <div className="space-y-1 min-w-0 flex-1">
                                      <div className="flex flex-wrap items-center gap-2">
                                        <span className="px-2 py-0.5 bg-amber-200 dark:bg-amber-900 text-amber-950 dark:text-amber-200 rounded text-[10px] font-black uppercase tracking-wide flex-shrink-0">
                                          {item.platform}
                                        </span>
                                        <span className="font-extrabold text-neutral-950 dark:text-white text-sm sm:text-base break-words">
                                          {item.payerName}
                                        </span>
                                        {transfersTimerEnabled && (
                                          <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-mono font-black ${
                                            remainingSec <= 15
                                              ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 animate-pulse border border-rose-300 dark:border-rose-700'
                                              : remainingSec <= 30
                                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border border-amber-300 dark:border-amber-700'
                                              : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700'
                                          }`}>
                                            <Clock className="w-3 h-3" />
                                            Expira en {remainingSec >= 60 ? `${Math.floor(remainingSec / 60)}m ${remainingSec % 60}s` : `${remainingSec}s`}
                                          </span>
                                        )}
                                      </div>
                                      <div className="text-xs text-neutral-600 dark:text-neutral-400 flex flex-wrap items-center gap-x-2 gap-y-0.5 font-medium">
                                        <span>Ref: <strong className="font-mono text-neutral-800 dark:text-neutral-200">{item.reference}</strong></span>
                                        <span>•</span>
                                        <span>Hora: <strong className="font-mono">{new Date(item.timestamp).toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</strong></span>
                                      </div>

                                      {transfersTimerEnabled && (
                                        <div className="w-full bg-neutral-100 dark:bg-neutral-800 h-1 rounded-full overflow-hidden mt-1">
                                          <div
                                            className={`h-full transition-all duration-1000 rounded-full ${
                                              remainingSec <= 15 ? 'bg-rose-500' : remainingSec <= 30 ? 'bg-amber-500' : 'bg-emerald-500'
                                            }`}
                                            style={{ width: `${remainingPct}%` }}
                                          />
                                        </div>
                                      )}
                                    </div>

                                    <div className="flex items-center justify-between sm:justify-end gap-3 flex-shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-amber-100 dark:border-neutral-800">
                                      <span className="font-mono text-lg sm:text-xl font-black text-neutral-950 dark:text-white mr-1">
                                        ${formatThousands(item.amount)}
                                      </span>
                                      <div className="flex items-center gap-2">
                                        <button
                                          type="button"
                                          onClick={() => {
                                            setReceivedTransfers(prev => [...prev, item]);
                                          }}
                                          className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer active:scale-95"
                                          title="Acreditar a esta venta"
                                        >
                                          <Check className="w-4 h-4" />
                                          Acreditar
                                        </button>
                                        <button
                                          type="button"
                                          onClick={() => handleDismissTransfer(item.id)}
                                          className="p-1.5 text-neutral-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 rounded-lg transition-colors cursor-pointer border border-transparent hover:border-rose-200 dark:hover:border-rose-800"
                                          title="Quitar / descartar de esta terminal"
                                        >
                                          <Trash2 className="w-4 h-4" />
                                        </button>
                                      </div>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          )}

                          {expiredByTimerCount > 0 && (
                            <div className="p-2.5 bg-white dark:bg-neutral-900 rounded-xl border border-amber-300 dark:border-neutral-700 flex flex-wrap items-center justify-between gap-2 text-xs text-neutral-600 dark:text-neutral-400 animate-in fade-in">
                              <span className="flex items-center gap-1.5 font-bold text-amber-800 dark:text-amber-300">
                                <Clock className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                                {expiredByTimerCount} transferencia(s) ocultada(s) por tiempo límite
                              </span>
                              <button
                                type="button"
                                onClick={() => {
                                  const now = Date.now();
                                  const updated = { ...transferFirstSeenRef.current };
                                  allDetectedTransfers.forEach(t => {
                                    updated[t.id] = now;
                                  });
                                  transferFirstSeenRef.current = updated;
                                  setCurrentTickTime(now);
                                }}
                                className="px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-xs font-bold cursor-pointer transition-colors shadow-2xs flex items-center gap-1"
                              >
                                <RefreshCw className="w-3 h-3" />
                                Restablecer y Mostrar Todas
                              </button>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Lista de Transferencias Acreditadas (Más grandes y últimas 5) */}
                      <div className="space-y-2 pt-1">
                        <div className="flex items-center justify-between">
                          <div className="text-xs font-extrabold text-neutral-700 dark:text-neutral-300 uppercase tracking-wider">
                            Transferencias Acreditadas ({receivedTransfers.length}):
                          </div>
                          {receivedTransfers.length > 5 && (
                            <span className="text-[11px] text-neutral-500 font-medium">
                              (Mostrando las últimas 5)
                            </span>
                          )}
                        </div>
                        {receivedTransfers.length === 0 ? (
                          <div className="text-center py-6 text-neutral-400 dark:text-neutral-500 bg-neutral-50 dark:bg-neutral-900/40 rounded-xl border border-dashed border-neutral-300 dark:border-neutral-700 text-xs">
                            Aún no se han acreditado transferencias para esta venta.
                          </div>
                        ) : (
                          <div className="space-y-2">
                            {last5Transfers.map((tr) => {
                              const itemIndex = receivedTransfers.findIndex(t => t.id === tr.id);
                              const num = itemIndex !== -1 ? itemIndex + 1 : 1;
                              return (
                                <div
                                  key={tr.id}
                                  className="flex items-center justify-between p-3.5 bg-emerald-50/80 dark:bg-neutral-900 border-2 border-emerald-300 dark:border-neutral-700 rounded-xl shadow-xs"
                                >
                                  <div className="space-y-1">
                                    <div className="flex items-center gap-2">
                                      <span className="px-1.5 py-0.5 bg-neutral-200 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 rounded text-[11px] font-mono font-black">
                                        #{num}
                                      </span>
                                      <span className="px-2 py-0.5 bg-emerald-200 dark:bg-emerald-900/90 text-emerald-950 dark:text-emerald-200 rounded-md text-[11px] font-black uppercase tracking-wide">
                                        {tr.platform}
                                      </span>
                                      <span className="font-extrabold text-neutral-950 dark:text-white text-sm sm:text-base">
                                        {tr.payerName}
                                      </span>
                                    </div>
                                    <div className="text-xs text-neutral-600 dark:text-neutral-400 font-medium">
                                      Ref: <span className="font-mono">{tr.reference}</span> • {new Date(tr.timestamp).toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                                    </div>
                                  </div>

                                <div className="flex items-center gap-3">
                                  <span className="text-lg sm:text-xl font-black font-mono text-emerald-700 dark:text-emerald-400">
                                    +${formatThousands(tr.amount)}
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => handleRemoveTransfer(tr.id)}
                                    title="Quitar transferencia"
                                    className="p-1.5 text-neutral-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 rounded-lg transition-colors cursor-pointer"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                      </div>

                      {/* Historial de Cobros Recientes de la cuenta */}
                      {allRecentMpTransfers.length > 0 && (
                        <div className="pt-2 border-t border-neutral-200 dark:border-neutral-700">
                          <button
                            type="button"
                            onClick={() => setShowRecentAccountHistory(prev => !prev)}
                            className="text-[10px] font-bold text-neutral-600 dark:text-neutral-400 hover:text-emerald-600 flex items-center justify-between w-full"
                          >
                            <span>📜 Ver últimos {allRecentMpTransfers.length} pagos registrados en tu cuenta</span>
                            <span>{showRecentAccountHistory ? '▲ Ocultar' : '▼ Mostrar'}</span>
                          </button>

                          {showRecentAccountHistory && (
                            <div className="mt-2 space-y-1 max-h-36 overflow-y-auto pr-1">
                              <div className="text-[10px] text-neutral-500 italic mb-1">
                                Si el cliente pagó minutos antes de abrir esta ventana, puedes vincularlo con 1 clic:
                              </div>
                              {allRecentMpTransfers.map((item) => {
                                const alreadyAdded = receivedTransfers.some(t => t.id === item.id);
                                const alreadyUsedInPast = isTransferAlreadyUsed(item.id, item.reference);
                                return (
                                  <div
                                    key={item.id}
                                    className="flex items-center justify-between p-1.5 bg-neutral-50 dark:bg-neutral-900 rounded border border-neutral-200 dark:border-neutral-800 text-[10px]"
                                  >
                                    <div>
                                      <span className="font-bold">{item.platform}</span> - {item.payerName}
                                      <span className="text-neutral-500 ml-1">({new Date(item.timestamp).toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })})</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <span className="font-mono font-bold text-emerald-600">${formatThousands(item.amount)}</span>
                                      {alreadyAdded ? (
                                        <span className="text-[9px] text-emerald-700 font-bold">✓ Vinculado</span>
                                      ) : alreadyUsedInPast ? (
                                        <span className="text-[9px] text-neutral-400 dark:text-neutral-500 font-bold">✓ Ya Acreditado</span>
                                      ) : (
                                        <button
                                          type="button"
                                          onClick={() => setReceivedTransfers(prev => [...prev, item])}
                                          className="px-1.5 py-0.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[9px] font-bold cursor-pointer"
                                        >
                                          + Vincular
                                        </button>
                                      )}
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })()}

              {paymentMethod === 'CUENTA_CORRIENTE' && (
                <div className="space-y-3 p-4 bg-amber-50/60 rounded-xl border border-amber-200 text-xs">
                  <div>
                    <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                      Seleccionar Cliente con Cuenta
                    </label>
                    <select
                      value={selectedClientId}
                      onChange={(e) => setSelectedClientId(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-neutral-300 rounded-lg text-xs focus:outline-hidden focus:ring-2 focus:ring-amber-600 font-bold text-neutral-900"
                    >
                      <option value="">-- Seleccionar cliente --</option>
                      {clientAccounts.map(client => (
                        <option key={client.id} value={client.id}>
                          {client.name} (Saldo actual: ${formatThousands(client.currentBalance)} / Límite: ${formatThousands(client.creditLimit)})
                        </option>
                      ))}
                    </select>
                  </div>
                  {selectedClientId && (
                    <div className="p-2.5 bg-white rounded-lg border border-amber-100 text-[11px] space-y-1">
                      <div className="text-neutral-700">
                        El importe de <strong>${formatThousands(cartTotal - discountAmount)}</strong> se sumará al saldo deudor del cliente.
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Modal Actions */}
            <div className="p-4 border-t border-neutral-100 bg-neutral-50 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={handleCloseCheckout}
                className="px-4 py-2 border border-neutral-300 bg-white hover:bg-neutral-100 rounded-lg text-xs font-semibold text-neutral-700"
              >
                Cancelar
              </button>
              {(() => {
                const netTotal = Math.max(0, cartTotal - discountAmount);
                const totalRec = receivedTransfers.reduce((s, t) => s + t.amount, 0);
                const isTransferCovered = paymentMethod === 'TRANSFERENCIA' && totalRec >= netTotal && netTotal > 0;
                const cashRecNum = parseFormattedNumber(splitCashReceived || '0');
                const isSplitCovered = paymentMethod === 'TRANSFERENCIA' && payRemainingInCash && totalRec > 0 && cashRecNum >= (netTotal - totalRec);
                const cashReceivedForSale = parseFormattedNumber(cashAmount || '0');
                const isCashCovered = paymentMethod === 'EFECTIVO' && netTotal > 0 && cashReceivedForSale >= netTotal;
                const isAccountCovered = paymentMethod === 'CUENTA_CORRIENTE' && selectedClientId !== '';
                const isFullyCovered = isTransferCovered || isSplitCovered || isCashCovered || isAccountCovered;

                return (
                  <button
                    type="button"
                    onClick={() => handleConfirmSale()}
                    className={`px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-xs transition-all cursor-pointer ${
                      isFullyCovered
                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white ring-2 ring-emerald-400 ring-offset-2'
                        : 'bg-neutral-900 hover:bg-neutral-800 text-white'
                    }`}
                  >
                    <CheckCircle2 className={`w-4 h-4 ${isFullyCovered ? 'text-white' : 'text-emerald-400'}`} />
                    {isSplitCovered
                      ? 'Confirmar Pago Mixto (Transf. + Efectivo) e Imprimir'
                      : isTransferCovered
                      ? 'Confirmar Cobro Acreditado e Imprimir'
                      : 'Finalizar Venta e Imprimir'}
                  </button>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* TICKET / RECEIPT MODAL */}
      {showTicketModal && lastCompletedSale && (() => {
        const businessInfo = StorageService.getBusinessInfo();
        const printerCfg = StorageService.getPrinterConfig();
        const is58mm = printerCfg.paperWidth === '58mm';

        return (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 print:static print:bg-transparent print:p-0 print:block print:w-full">
            <div className="ticket-modal-card bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-neutral-200 print:border-none print:shadow-none print:rounded-none print:w-full print:max-w-none print:m-0 print:p-0 print:bg-white">
              <div className="no-print p-4 bg-neutral-900 text-white flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Printer className="w-5 h-5 text-emerald-400" />
                  <div>
                    <span className="text-sm font-bold tracking-wide uppercase block">Comprobante / Ticket de Venta</span>
                    <span className="text-[10px] text-neutral-400">
                      {printerCfg.printerName} ({printerCfg.paperWidth}) {printerCfg.copies > 1 ? `• ${printerCfg.copies} Copias` : ''}
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setShowTicketModal(false);
                    setLastCompletedSale(null);
                    focusBarcodeInput();
                  }}
                  className="text-neutral-400 hover:text-white p-1 rounded-lg hover:bg-neutral-800 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Printable Ticket */}
              <div 
                id="printable-sale-ticket" 
                className={`thermal-ticket-container ticket-print-pure ${is58mm ? 'thermal-ticket-58mm' : ''} p-6 md:p-8 font-mono text-sm bg-white space-y-4 text-neutral-900 border-b border-neutral-200 max-h-[75vh] overflow-y-auto print:p-0 print:m-0 print:border-none print:bg-white print:text-black print:space-y-1.5 print:max-h-none print:overflow-visible ${is58mm ? 'max-w-[320px] mx-auto text-xs' : ''}`}
              >
                <div className="text-center border-b border-dashed border-neutral-400 print:border-black pb-2 space-y-0.5 print:pb-1">
                  <h4 className="font-black text-lg tracking-wider text-neutral-900 print:text-black uppercase">
                    {businessInfo.name || 'COMERCIO POS CENTRAL'}
                  </h4>
                  <p className="text-xs font-semibold text-neutral-800 print:text-black">CUIT: {businessInfo.cuit || '30-71458999-9'}</p>
                  <p className="text-xs font-semibold text-neutral-800 print:text-black">{businessInfo.address || 'Av. Libertador 4500, CABA'}</p>
                  {businessInfo.phone && <p className="text-xs font-semibold text-neutral-800 print:text-black">TEL: {businessInfo.phone}</p>}
                  {businessInfo.ticketHeader && (
                    <p className="text-xs italic font-semibold text-neutral-800 print:text-black pt-0.5">"{businessInfo.ticketHeader}"</p>
                  )}
                  
                  <div className="pt-1.5 border-t border-dashed border-neutral-300 print:border-black mt-1 space-y-0.5">
                    <div className="text-xs text-center text-neutral-900 print:text-black font-black tracking-wider">
                      TICKET FACTURA #{lastCompletedSale.receiptNumber}
                    </div>
                    <div className="flex justify-between items-center text-[11px] font-bold text-neutral-900 print:text-black pt-0.5">
                      <span>FECHA: {new Date(lastCompletedSale.timestamp).toLocaleDateString('es-AR')}</span>
                      <span>HORA: {new Date(lastCompletedSale.timestamp).toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
                    </div>
                    <div className="flex justify-between items-center text-[11px] font-bold text-neutral-900 print:text-black">
                      <span>TERMINAL: {lastCompletedSale.terminalId}</span>
                      <span>CAJERO: {lastCompletedSale.userName}</span>
                    </div>
                  </div>
                </div>

                {/* Items List */}
                <div className="space-y-1 py-2 print:py-1 border-b border-dashed border-neutral-400 print:border-black">
                  <div className="flex justify-between text-xs font-black text-neutral-900 print:text-black uppercase">
                    <span>Cant. / Detalle</span>
                    <span>Importe</span>
                  </div>
                  {lastCompletedSale.items.map((item, idx) => (
                    <div key={idx} className="flex justify-between items-start text-sm gap-2 print:gap-1">
                      <span className="text-neutral-900 print:text-black font-bold leading-tight">
                        {item.quantity}x {item.name}
                      </span>
                      <span className="font-black font-mono text-neutral-900 print:text-black whitespace-nowrap">
                        ${formatThousands(item.total)}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Totals */}
                <div className="space-y-1 text-sm pt-1 border-b border-dashed border-neutral-400 print:border-black pb-2 print:pb-1">
                  {lastCompletedSale.discount > 0 && (
                    <div className="flex justify-between text-rose-600 print:text-black font-bold">
                      <span>Descuento aplicado:</span>
                      <span className="font-mono font-black">-${formatThousands(lastCompletedSale.discount)}</span>
                    </div>
                  )}
                  {Boolean(lastCompletedSale.surcharge && lastCompletedSale.surcharge > 0) && (
                    <div className="flex justify-between text-sky-700 print:text-black font-bold">
                      <span>Recargo aplicado:</span>
                      <span className="font-mono font-black">+${formatThousands(lastCompletedSale.surcharge)}</span>
                    </div>
                  )}
                  <div className="flex justify-between items-baseline font-black text-xl text-neutral-900 print:text-black pt-1 border-t border-dashed border-neutral-400 print:border-black">
                    <span>TOTAL:</span>
                    <span className="text-2xl font-mono font-black print:text-black">${formatThousands(lastCompletedSale.total)}</span>
                  </div>
                  <div className="flex justify-between text-xs font-bold text-neutral-800 print:text-black pt-0.5">
                    <span>Método de Pago:</span>
                    <span className="font-black uppercase text-neutral-900 print:text-black">
                      {lastCompletedSale.paymentDetails?.isMixedPayment
                        ? 'PAGO MIXTO (TRANSFERENCIA + EFECTIVO)'
                        : (lastCompletedSale.paymentMethod === 'TARJETA_POSNET' || lastCompletedSale.paymentMethod === 'BILLETERA_VIRTUAL')
                        ? 'TARJETA / POSNET'
                        : lastCompletedSale.paymentMethod}
                    </span>
                  </div>
                  {lastCompletedSale.paymentDetails?.isMixedPayment && lastCompletedSale.paymentDetails.mixedDetails && (
                    <div className="pt-1 text-[10px] space-y-1 border-t border-dashed border-neutral-300 print:border-black text-neutral-800 print:text-black">
                      <div className="font-bold uppercase tracking-wider text-[9px] text-neutral-600 print:text-black">
                        Detalle Pago Mixto:
                      </div>
                      <div className="flex justify-between items-center text-[10px]">
                        <span>• Transferencia recibida:</span>
                        <span className="font-mono font-bold">${formatThousands(lastCompletedSale.paymentDetails.mixedDetails.transferAmount)}</span>
                      </div>
                      <div className="flex justify-between items-center text-[10px]">
                        <span>• Efectivo abonado:</span>
                        <span className="font-mono font-bold">${formatThousands(lastCompletedSale.paymentDetails.mixedDetails.cashAmount)}</span>
                      </div>
                      {lastCompletedSale.paymentDetails.mixedDetails.cashReceived !== undefined && lastCompletedSale.paymentDetails.mixedDetails.cashReceived > 0 && (
                        <div className="flex justify-between items-center text-[9px] text-neutral-600 print:text-black">
                          <span>Efectivo entregado:</span>
                          <span className="font-mono">${formatThousands(lastCompletedSale.paymentDetails.mixedDetails.cashReceived)}</span>
                        </div>
                      )}
                    </div>
                  )}
                  {(lastCompletedSale.paymentMethod === 'TARJETA_POSNET' || lastCompletedSale.paymentMethod === 'BILLETERA_VIRTUAL') && lastCompletedSale.paymentDetails && (
                    <div className="pt-1 text-[10px] space-y-0.5 border-t border-dashed border-neutral-300 print:border-black text-neutral-800 print:text-black">
                      <div className="flex justify-between">
                        <span>Tarjeta:</span>
                        <span className="font-bold">
                          {lastCompletedSale.paymentDetails.cardType || 'Débito'} {lastCompletedSale.paymentDetails.cardBrand || ''}
                          {lastCompletedSale.paymentDetails.cardLastFour ? ` (**** ${lastCompletedSale.paymentDetails.cardLastFour})` : ''}
                        </span>
                      </div>
                      {lastCompletedSale.paymentDetails.installments && lastCompletedSale.paymentDetails.installments > 1 && (
                        <div className="flex justify-between">
                          <span>Plan:</span>
                          <span className="font-bold">{lastCompletedSale.paymentDetails.installments} Cuotas</span>
                        </div>
                      )}
                      {lastCompletedSale.paymentDetails.couponNumber && (
                        <div className="flex justify-between font-mono">
                          <span>Cupón / Autorización:</span>
                          <span>#{lastCompletedSale.paymentDetails.couponNumber}</span>
                        </div>
                      )}
                      {lastCompletedSale.paymentDetails.batchNumber && (
                        <div className="flex justify-between font-mono text-[9px] text-neutral-600 print:text-black">
                          <span>Terminal / Lote:</span>
                          <span>{lastCompletedSale.paymentDetails.posnetTerminalId || 'POS-01'} • {lastCompletedSale.paymentDetails.batchNumber}</span>
                        </div>
                      )}
                    </div>
                  )}
                  {lastCompletedSale.paymentMethod === 'TRANSFERENCIA' && lastCompletedSale.paymentDetails?.transfersList && lastCompletedSale.paymentDetails.transfersList.length > 0 && (
                    <div className="pt-1 text-[10px] space-y-0.5 border-t border-dashed border-neutral-300 print:border-black text-neutral-800 print:text-black">
                      <div className="font-bold uppercase tracking-wider text-[9px] text-neutral-600 print:text-black">Transferencias Acreditadas:</div>
                      {lastCompletedSale.paymentDetails.transfersList.map((tr, idx) => (
                        <div key={idx} className="flex justify-between items-center text-[10px]">
                          <span>• {tr.platform} ({tr.payerName}):</span>
                          <span className="font-mono font-bold">${formatThousands(tr.amount)}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  {lastCompletedSale.paymentMethod === 'TRANSFERENCIA' && (!lastCompletedSale.paymentDetails?.transfersList || lastCompletedSale.paymentDetails.transfersList.length === 0) && lastCompletedSale.paymentDetails?.transferRef && (
                    <div className="text-[10px] text-neutral-700 print:text-black pt-0.5">
                      <span>Ref: {lastCompletedSale.paymentDetails.transferRef}</span>
                    </div>
                  )}
                  {lastCompletedSale.paymentDetails?.mpSurchargeEnabled && (
                    <div className="text-[10px] text-sky-800 print:text-black pt-0.5 font-bold flex justify-between">
                      <span>Recargo MP (+{lastCompletedSale.paymentDetails.mpSurchargePercent}%):</span>
                      <span className="font-mono">+${formatThousands(lastCompletedSale.paymentDetails.mpSurchargeAmount || 0)}</span>
                    </div>
                  )}
                  {lastCompletedSale.paymentDetails?.cashChange !== undefined && (
                    <div className="flex justify-between text-xs text-emerald-800 print:text-black font-bold bg-emerald-50 print:bg-transparent p-1.5 rounded-lg border border-emerald-300 print:border-black mt-1">
                      <span>Vuelto en efectivo:</span>
                      <span className="font-mono text-sm font-black">${formatThousands(lastCompletedSale.paymentDetails.cashChange)}</span>
                    </div>
                  )}
                </div>

                <div className="text-center space-y-1 pt-1 font-semibold">
                  <p className="text-xs font-bold text-neutral-800 print:text-black">
                    {businessInfo.ticketFooter || '¡Muchas gracias por su compra!'}
                  </p>
                  {printerCfg.printBarcode && (
                    <div className="py-1">
                      <div className="inline-block bg-neutral-900 print:bg-black text-white font-mono text-[9px] px-3 py-1 tracking-widest rounded">
                        ||| | | |||| | ||| | |||
                      </div>
                    </div>
                  )}
                  <div className="pt-1 text-center font-bold text-neutral-900 print:text-black space-y-0.5">
                    <p className="uppercase tracking-wider text-[11px] font-bold">Comprobante de Control</p>
                    <p className="text-xs font-bold text-neutral-900 print:text-black">Terminal: {lastCompletedSale.terminalId} • Sistema POS</p>
                  </div>
                </div>
              </div>

              <div className="ticket-modal-footer no-print p-4 bg-white flex justify-end gap-3 border-t border-neutral-200">
                <button
                  type="button"
                  onClick={() => {
                    window.print();
                  }}
                  className="px-4 py-2.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 rounded-xl text-sm font-semibold flex items-center gap-2 transition-colors"
                >
                  <Printer className="w-4 h-4 text-emerald-600" />
                  Imprimir Comprobante
                </button>
                <button
                  ref={ticketDoneButtonRef}
                  type="button"
                  onClick={() => {
                    setShowTicketModal(false);
                    setLastCompletedSale(null);
                    focusBarcodeInput();
                  }}
                  className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-sm font-bold transition-colors shadow-xs"
                >
                  Listo / Nueva Venta
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Payment Configuration Modal */}
      <PaymentConfigModal
        isOpen={showPaymentConfigModal}
        onClose={() => {
          setShowPaymentConfigModal(false);
          setPaymentConfig(StorageService.getPaymentConfig());
        }}
        onSaved={(newCfg) => {
          setPaymentConfig(newCfg);
        }}
      />

      {/* MODAL: PONER VENTA EN ESPERA */}
      {showParkPromptModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-neutral-900 rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-neutral-200 dark:border-neutral-700 animate-in fade-in zoom-in-95">
            <div className="p-4 border-b border-amber-600 bg-amber-500 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Pause className="w-5 h-5 fill-current" />
                <h3 className="font-bold text-base">Poner Venta en Espera</h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowParkPromptModal(false);
                  focusBarcodeInput();
                }}
                className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-amber-600 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleConfirmPark} className="p-5 space-y-4">
              <div className="p-3 bg-neutral-50 dark:bg-neutral-800/80 rounded-xl border border-neutral-200 dark:border-neutral-700 flex justify-between items-center text-xs">
                <div>
                  <span className="text-neutral-500 dark:text-neutral-400 block font-medium">Productos a pausar</span>
                  <span className="font-bold text-sm text-neutral-900 dark:text-white">
                    {cart.reduce((s, i) => s + i.quantity, 0)} artículos
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-neutral-500 dark:text-neutral-400 block font-medium">Total acumulado</span>
                  <span className="font-mono font-bold text-base text-neutral-900 dark:text-white">
                    ${formatThousands(cartTotal - discountAmount)}
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-800 dark:text-neutral-200 uppercase mb-1.5">
                  Nombre o Referencia del Cliente (Opcional)
                </label>
                <div className="relative">
                  <input
                    type="text"
                    list="registered-clients-list"
                    value={parkReference}
                    onChange={(e) => {
                      const val = e.target.value;
                      setParkReference(val);
                      const matched = clientAccounts.find(c => c.name.toLowerCase() === val.trim().toLowerCase());
                      if (matched) {
                        setSelectedClientId(matched.id);
                      }
                    }}
                    placeholder="Ej: Cliente 1, Campera roja, etc."
                    autoFocus
                    onFocus={(e) => e.target.select()}
                    className="w-full px-3.5 py-2.5 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-700 rounded-xl text-sm font-semibold text-neutral-900 dark:text-white focus:outline-hidden focus:border-amber-500"
                  />
                  <datalist id="registered-clients-list">
                    {clientAccounts.map(client => (
                      <option key={client.id} value={client.name} />
                    ))}
                  </datalist>
                </div>
                <p className="text-[11px] text-neutral-500 dark:text-neutral-400 mt-1.5 leading-relaxed">
                  Presione <span className="font-bold text-neutral-700 dark:text-neutral-300">Enter</span> para pausar inmediatamente y atender al siguiente cliente en la fila.
                </p>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-neutral-100 dark:border-neutral-800">
                <button
                  type="button"
                  onClick={() => {
                    setShowParkPromptModal(false);
                    focusBarcodeInput();
                  }}
                  className="px-4 py-2.5 border border-neutral-300 dark:border-neutral-700 rounded-xl text-xs font-semibold text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-xs transition-colors"
                >
                  <Pause className="w-3.5 h-3.5 fill-current" />
                  Guardar en Espera (Enter)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: LISTA DE VENTAS EN ESPERA */}
      {showParkedSalesModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-neutral-900 rounded-2xl max-w-xl w-full overflow-hidden shadow-2xl border border-neutral-200 dark:border-neutral-700 flex flex-col max-h-[85vh] animate-in fade-in zoom-in-95">
            <div className="p-4 border-b border-neutral-100 dark:border-neutral-800 bg-neutral-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Clock className="w-5 h-5 text-amber-400" />
                <div>
                  <h3 className="font-bold text-base">Ventas en Espera</h3>
                  <p className="text-xs text-neutral-400">
                    {parkedSales.length === 0
                      ? 'No hay clientes en espera'
                      : `${parkedSales.length} ${parkedSales.length === 1 ? 'cliente pausado en la fila' : 'clientes pausados en la fila'}`}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowParkedSalesModal(false);
                  focusBarcodeInput();
                }}
                className="text-neutral-400 hover:text-white p-1 rounded-lg hover:bg-neutral-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto space-y-3 flex-1 divide-y divide-neutral-100 dark:divide-neutral-800">
              {parkedSales.length === 0 ? (
                <div className="py-12 text-center text-neutral-400 space-y-2">
                  <Clock className="w-10 h-10 mx-auto text-neutral-300 dark:text-neutral-600 opacity-60" />
                  <p className="text-sm font-semibold text-neutral-700 dark:text-neutral-300">
                    No hay ninguna venta en espera
                  </p>
                  <p className="text-xs max-w-xs mx-auto text-neutral-400">
                    Cuando un cliente necesite buscar otro producto, haga clic en &quot;En Espera&quot; en el carrito para pausar su compra y atender a la siguiente persona.
                  </p>
                </div>
              ) : (
                parkedSales.map((sale) => (
                  <div
                    key={sale.id}
                    className="pt-3 first:pt-0 bg-neutral-50 dark:bg-neutral-800/60 p-3.5 rounded-xl border border-neutral-200 dark:border-neutral-700 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1 min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-neutral-900 dark:text-white truncate">
                          {sale.referenceName}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 bg-neutral-200 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300 rounded-full font-mono">
                          {new Date(sale.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-xs text-neutral-500 dark:text-neutral-400 line-clamp-1">
                        {sale.itemsCount} productos: {sale.items.map(i => `${i.quantity}x ${i.article.name}`).join(', ')}
                      </p>
                      <div className="text-base font-mono font-black text-emerald-600 dark:text-emerald-400">
                        ${formatThousands(sale.total)}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                      <button
                        type="button"
                        onClick={(e) => handleDeleteParkedSale(sale.id, e)}
                        className="p-2 text-rose-500 hover:text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-colors"
                        title="Descartar venta en espera"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleRestoreParkedSale(sale)}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>Recuperar / Cobrar</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="p-3 bg-neutral-50 dark:bg-neutral-950 border-t border-neutral-100 dark:border-neutral-800 flex justify-between items-center text-xs text-neutral-500">
              <span className="text-[11px]">Al recuperar una venta, si hay productos en el carrito actual, se guardarán automáticamente en espera.</span>
              <button
                type="button"
                onClick={() => {
                  setShowParkedSalesModal(false);
                  focusBarcodeInput();
                }}
                className="px-3 py-1.5 bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-300 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 rounded-lg font-semibold transition-colors"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL SERVICIOS EXTERNOS (CLARO / SAT) Y EXTRAS */}
      {showExternalServiceModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-neutral-900 rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl border border-neutral-200 dark:border-neutral-700 animate-in fade-in zoom-in-95">
            <div className={`p-4 text-white flex items-center justify-between ${
              serviceType === 'CLARO' ? 'bg-red-600' : serviceType === 'SAT' ? 'bg-sky-700' : 'bg-amber-600'
            }`}>
              <div className="flex items-center gap-2">
                {serviceType === 'CLARO' ? (
                  <Smartphone className="w-5 h-5" />
                ) : serviceType === 'SAT' ? (
                  <FileText className="w-5 h-5" />
                ) : (
                  <Sparkles className="w-5 h-5" />
                )}
                <div>
                  <h3 className="font-extrabold text-sm uppercase tracking-wide">
                    {serviceType === 'EXTRAS' ? 'Venta de Extras' : `Venta de Servicio: ${serviceType === 'CLARO' ? 'Claro' : 'SAT'}`}
                  </h3>
                  <p className="text-[11px] text-white/80">
                    {serviceType === 'CLARO'
                      ? 'Recargas y pagos de telefonía / internet'
                      : serviceType === 'SAT'
                      ? 'Cobranza y servicios SAT'
                      : 'Cargar artículo o concepto extra al comprobante'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowExternalServiceModal(false)}
                className="text-white/80 hover:text-white p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleServiceSubmit} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block text-[11px] font-black text-neutral-900 dark:text-white uppercase mb-1">
                  Monto de la Operación ($)
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2 text-neutral-950 dark:text-white font-mono text-xl font-bold">$</span>
                  <input
                    ref={serviceAmountInputRef}
                    type="text"
                    inputMode="decimal"
                    autoFocus
                    required
                    value={serviceAmount}
                    onChange={(e) => setServiceAmount(formatThousands(e.target.value))}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        if (serviceType === 'EXTRAS') {
                          // Solo en el botón extra, cuando ponga el monto y apriete Enter pasa a "Artículos"
                          articleInputRef.current?.focus();
                          articleInputRef.current?.select();
                        } else {
                          // En Claro y SAT, con Enter pasa directamente a sumar al comprobante
                          handleServiceSubmit();
                        }
                      }
                    }}
                    placeholder="0"
                    className="w-full pl-8 pr-3 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-400 dark:border-neutral-600 rounded-xl text-xl font-mono font-black text-neutral-950 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-neutral-900 dark:focus:ring-white shadow-xs"
                  />
                </div>
              </div>

              <div ref={extraContainerRef} className="relative">
                <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                  {serviceType === 'EXTRAS' ? 'Artículos:' : 'N° Línea / Factura o Referencia (Opcional):'}
                </label>
                <input
                  ref={articleInputRef}
                  type="text"
                  value={serviceNotes}
                  onFocus={() => {
                    if (serviceType === 'EXTRAS' && extraArticles.length > 0) {
                      setShowExtraSuggestions(true);
                    }
                  }}
                  onChange={(e) => {
                    const input = e.target;
                    const start = input.selectionStart;
                    const end = input.selectionEnd;
                    const val = serviceType === 'EXTRAS' ? toTitleCase(input.value) : input.value;
                    setServiceNotes(val);
                    if (serviceType === 'EXTRAS') {
                      setShowExtraSuggestions(true);
                      setSelectedSuggestionIndex(-1);
                      if (start !== null && end !== null) {
                        requestAnimationFrame(() => {
                          input.setSelectionRange(start, end);
                        });
                      }
                    }
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'ArrowDown' && showExtraSuggestions && matchingExtraArticles.length > 0) {
                      e.preventDefault();
                      setSelectedSuggestionIndex((prev) => (prev + 1) % matchingExtraArticles.length);
                      return;
                    }
                    if (e.key === 'ArrowUp' && showExtraSuggestions && matchingExtraArticles.length > 0) {
                      e.preventDefault();
                      setSelectedSuggestionIndex((prev) => (prev - 1 + matchingExtraArticles.length) % matchingExtraArticles.length);
                      return;
                    }
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      if (
                        serviceType === 'EXTRAS' &&
                        showExtraSuggestions &&
                        selectedSuggestionIndex >= 0 &&
                        selectedSuggestionIndex < matchingExtraArticles.length
                      ) {
                        const chosen = matchingExtraArticles[selectedSuggestionIndex];
                        setServiceNotes(chosen);
                        setShowExtraSuggestions(false);
                        handleServiceSubmit(undefined, chosen);
                      } else {
                        // En Extras no activar Enter hasta que escriba un artículo o elija uno
                        if (serviceType === 'EXTRAS' && !serviceNotes.trim()) {
                          return;
                        }
                        setShowExtraSuggestions(false);
                        handleServiceSubmit();
                      }
                    }
                  }}
                  placeholder={
                    serviceType === 'CLARO'
                      ? 'Ej: 11 5566-7788'
                      : serviceType === 'SAT'
                      ? 'Ej: Cupón / Factura N°'
                      : 'Ej: Hielo, Flete, Envoltura...'
                  }
                  className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl text-xs text-neutral-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-neutral-900"
                />

                {/* Dropdown predictivo de Artículos Extras Guardados (estilo Marcas en Carga de Artículos) */}
                {serviceType === 'EXTRAS' && showExtraSuggestions && matchingExtraArticles.length > 0 && (
                  <div className="absolute left-0 right-0 mt-1 max-h-40 overflow-y-auto bg-white dark:bg-neutral-800 rounded-xl shadow-xl border border-neutral-200 dark:border-neutral-700 z-50 py-1 text-xs divide-y divide-neutral-100 dark:divide-neutral-700">
                    <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-neutral-400 bg-neutral-50 dark:bg-neutral-900 flex justify-between items-center">
                      <span>Artículos Guardados</span>
                      <span className="text-[9px] text-amber-600 dark:text-amber-400 font-semibold">Extras</span>
                    </div>
                    {matchingExtraArticles.map((b, idx) => (
                      <button
                        key={b}
                        type="button"
                        onMouseDown={(e) => e.preventDefault()}
                        onClick={() => {
                          setServiceNotes(b);
                          setShowExtraSuggestions(false);
                          setSelectedSuggestionIndex(-1);
                        }}
                        className={`w-full text-left px-3 py-1.5 flex items-center justify-between text-neutral-800 dark:text-neutral-200 transition-colors cursor-pointer ${
                          selectedSuggestionIndex === idx
                            ? 'bg-amber-100 dark:bg-amber-900/60 font-bold'
                            : 'hover:bg-amber-50 dark:hover:bg-amber-950/40'
                        }`}
                      >
                        <span className="font-semibold">{b}</span>
                        <span className="text-[10px] text-neutral-400">Seleccionar</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowExternalServiceModal(false)}
                  className="flex-1 px-3 py-2.5 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl font-bold text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={serviceType === 'EXTRAS' && !serviceNotes.trim()}
                  className={`flex-1 px-4 py-2.5 text-white rounded-xl font-black uppercase tracking-wider shadow-sm transition-all ${
                    serviceType === 'EXTRAS' && !serviceNotes.trim()
                      ? 'opacity-40 cursor-not-allowed bg-neutral-400 dark:bg-neutral-700 pointer-events-none'
                      : serviceType === 'CLARO'
                      ? 'bg-red-600 hover:bg-red-700 active:scale-95 cursor-pointer'
                      : serviceType === 'SAT'
                      ? 'bg-sky-700 hover:bg-sky-800 active:scale-95 cursor-pointer'
                      : 'bg-amber-600 hover:bg-amber-700 active:scale-95 cursor-pointer'
                  }`}
                >
                  Sumar al Comprobante
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Aviso de artículo inexistente y alta rápida sin salir de Ventas (POS). */}
      {showArticleNotFound && !showQuickAddArticle && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-xs p-3">
          <div className="w-full max-w-md overflow-hidden rounded-2xl border border-neutral-200 bg-white shadow-2xl dark:border-neutral-700 dark:bg-neutral-900">
            <div className="flex items-center gap-3 border-b border-neutral-200 bg-amber-50 p-4 dark:border-neutral-700 dark:bg-amber-950/30">
              <AlertCircle className="h-7 w-7 text-amber-600" />
              <div className="min-w-0 flex-1">
                <h3 className="font-extrabold text-neutral-900 dark:text-white">Artículo no encontrado</h3>
                <p className="mt-1 break-words text-sm text-neutral-600 dark:text-neutral-300">No existe ningún artículo con código o nombre "{notFoundCode}".</p>
              </div>
              <button type="button" aria-label="Cerrar" onClick={() => { setShowArticleNotFound(false); scanDialogOpenRef.current = false; focusBarcodeInput(); }} className="rounded-lg p-1 text-neutral-500 hover:bg-neutral-200 dark:hover:bg-neutral-800"><X className="h-5 w-5" /></button>
            </div>
            <div className="flex flex-col gap-2 p-4 sm:flex-row sm:justify-end">
              <button ref={notFoundCancelButtonRef} type="button" onClick={() => { setShowArticleNotFound(false); scanDialogOpenRef.current = false; focusBarcodeInput(); }} className={`rounded-xl px-4 py-2.5 text-sm font-bold text-white transition-colors ${notFoundButtonIndex === 0 ? 'bg-emerald-600' : 'bg-neutral-900'}`}>Cancelar</button>
              <button ref={notFoundAddButtonRef} type="button" onClick={() => { setQuickArticleForm({ barcode: notFoundCode, name: '', brand: '', category: '', costPrice: '0', salePrice: '0', stock: '0', minStock: '0' }); setShowArticleNotFound(false); setShowQuickAddArticle(true); scanDialogOpenRef.current = true; setTimeout(() => quickArticleNameRef.current?.focus(), 80); }} className={`inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-extrabold text-white transition-colors ${notFoundButtonIndex === 1 ? 'bg-emerald-600' : 'bg-neutral-900'}`}><Plus className="h-4 w-4" />Agregar artículo nuevo</button>
            </div>
          </div>
        </div>
      )}

      <QuickArticleModal
        isOpen={showQuickAddArticle}
        initialBarcode={notFoundCode}
        singleSaveMode
        onClose={() => {
          setShowQuickAddArticle(false);
          setShowArticleNotFound(false);
          scanDialogOpenRef.current = false;
          setQuickArticleForm({ barcode: '', name: '', brand: '', category: '', costPrice: '0', salePrice: '0', stock: '0', minStock: '0' });
          setTimeout(() => focusBarcodeInput(), 100);
        }}
      />
    </>
  );
};

export const SalesModule = React.memo(SalesModuleComponent);
