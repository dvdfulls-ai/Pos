import React from 'react';
import { 
  Cpu, 
  Layers, 
  Wifi, 
  WifiOff, 
  Database, 
  ShieldCheck, 
  X, 
  CheckCircle2, 
  ArrowRight,
  Sparkles,
  GitBranch,
  Boxes
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const ArchitectBlueprintModal: React.FC<Props> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-3xl w-full overflow-hidden shadow-2xl border border-neutral-200 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-5 border-b border-neutral-100 flex items-center justify-between bg-neutral-900 text-white">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-neutral-800 rounded-lg text-emerald-400">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base tracking-tight">Dictamen de Arquitectura de Software</h3>
              <p className="text-xs text-neutral-400">Guía de diseño e ingeniería senior para alta disponibilidad comercial</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-full text-neutral-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs text-neutral-700 leading-relaxed">
          {/* Section 1: Modularidad */}
          <div className="p-4 bg-neutral-50 rounded-xl border border-neutral-200 space-y-2">
            <div className="flex items-center gap-2 font-bold text-neutral-900 text-sm">
              <Boxes className="w-4 h-4 text-indigo-600" />
              1. Estructura Modular Desacoplada (Monolito Modular)
            </div>
            <p>
              Para garantizar que <strong>puedas editar, agregar o eliminar un módulo sin romper el resto</strong>, la aplicación está estructurada bajo el patrón de <em>Domain-Driven Modular Architecture</em>:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2">
              <div className="p-2.5 bg-white rounded-lg border border-neutral-200">
                <span className="font-bold text-neutral-900 block mb-1">Módulos Aislados</span>
                <code>/src/modules/*</code> cada carpeta contiene su propia lógica, pantallas y subcomponentes. Si eliminas el módulo de Compras, Ventas o Cuentas Corrientes, el sistema sigue compilando sin fallas.
              </div>
              <div className="p-2.5 bg-white rounded-lg border border-neutral-200">
                <span className="font-bold text-neutral-900 block mb-1">Capa de Datos Agnóstica</span>
                <code>/src/services/storage.ts</code> abstrae dónde se guarda la información (LocalStorage, IndexedDB o Cloud API). Los componentes no tocan bases de datos directamente.
              </div>
              <div className="p-2.5 bg-white rounded-lg border border-neutral-200">
                <span className="font-bold text-neutral-900 block mb-1">Tipado Fuerte</span>
                <code>/src/types/index.ts</code> define contratos e interfaces estrictas para evitar errores de tipeo y desfasajes entre modelos.
              </div>
            </div>
          </div>

          {/* Section 2: Offline-First & Multi-terminal */}
          <div className="p-4 bg-neutral-50 rounded-xl border border-neutral-200 space-y-2">
            <div className="flex items-center gap-2 font-bold text-neutral-900 text-sm">
              <WifiOff className="w-4 h-4 text-emerald-600" />
              2. Estrategia Offline-First & Conexión de Múltiples Terminales
            </div>
            <p>
              En un local comercial físico, <strong>el internet nunca puede ser un punto único de falla</strong>. Si se corta la conexión, la caja no puede detenerse:
            </p>
            <ul className="space-y-1.5 list-disc pl-4 text-neutral-600">
              <li>
                <strong>Persistencia Local Inmediata:</strong> Cada venta, movimiento o ajuste se almacena primero en el almacenamiento local con cero latencia (&lt;10ms), garantizando velocidad al escanear con lectora de código de barras.
              </li>
              <li>
                <strong>Outbox / Cola de Sincronización:</strong> Los eventos ocurridos sin conexión se encolan automáticamente. Al detectar el restablecimiento de red, se transmiten a la nube en segundo plano.
              </li>
              <li>
                <strong>Multi-Terminal en Red Local:</strong> Utiliza el canal de difusión inter-terminales (<code>BroadcastChannel</code> / WebSockets locales), lo que permite que varias cajas y computadoras compartan el inventario y no vendan de más.
              </li>
            </ul>
          </div>

          {/* Section 3: Hardware & Lectora de Código de Barras */}
          <div className="p-4 bg-neutral-50 rounded-xl border border-neutral-200 space-y-2">
            <div className="flex items-center gap-2 font-bold text-neutral-900 text-sm">
              <Cpu className="w-4 h-4 text-amber-600" />
              3. Lectora de Código de Barra & Pasarela de Pagos
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div className="space-y-1">
                <strong className="text-neutral-900">Lectora USB / Láser (Recomendación):</strong>
                <p className="text-neutral-600">
                  Las lectoras estándar operan como dispositivos HID (emulación de teclado). El sistema incluye un capturador inteligente de ráfagas rápidas que detecta el escaneo en milisegundos sin necesidad de hacer clic manual en el campo de texto.
                </p>
              </div>
              <div className="space-y-1">
                <strong className="text-neutral-900">Mercado Pago QR & Transferencias:</strong>
                <p className="text-neutral-600">
                  QR Dinámico interoperable: el cliente escanea y abona directamente desde su celular. Al recibir la notificación (webhook), la venta se valida y se emite el ticket automáticamente.
                </p>
              </div>
            </div>
          </div>

          {/* Section 4: Roles y Seguridad */}
          <div className="p-4 bg-neutral-50 rounded-xl border border-neutral-200 space-y-2">
            <div className="flex items-center gap-2 font-bold text-neutral-900 text-sm">
              <ShieldCheck className="w-4 h-4 text-sky-600" />
              4. Control de Roles (RBAC) & Cierre de Caja Ciego
            </div>
            <p>
              El cierre de caja aplica la mejor práctica contable: <strong>Arqueo ciego</strong>. El cajero cuenta el dinero físico real que tiene en mano y el sistema calcula de forma transparente el sobrante o faltante respecto a las ventas del turno, evitando manipulaciones.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-100 bg-neutral-50 flex items-center justify-between">
          <span className="text-[11px] text-neutral-500 font-mono">
            Arquitectura Validada para POS & ERP Comercial
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-bold uppercase tracking-wider"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
};
