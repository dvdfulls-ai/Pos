import React, { useState, useMemo } from 'react';
import { 
  X, 
  TrendingUp, 
  Percent, 
  Truck, 
  Layers, 
  Package, 
  Tag, 
  CheckSquare, 
  Check, 
  AlertCircle 
} from 'lucide-react';
import { Article } from '../../types';
import { formatThousands, matchesQuery } from '../../utils/text';

export type PriceUpdateScope = 'BATCH_SELECTED' | 'SUPPLIER' | 'CATEGORY' | 'PRODUCT' | 'ALL';
export type TargetPriceType = 'SALE' | 'COST' | 'BOTH';

interface PriceUpdateModalProps {
  isOpen: boolean;
  onClose: () => void;
  articles: Article[];
  suppliers: string[];
  categories: string[];
  subcategories: string[];
  selectedArticleIds: string[];
  initialScope?: PriceUpdateScope;
  initialArticle?: Article | null;
  onApply: (updatedArticles: Article[], reason: string) => void;
}

export const PriceUpdateModal: React.FC<PriceUpdateModalProps> = ({
  isOpen,
  onClose,
  articles,
  suppliers,
  categories,
  subcategories,
  selectedArticleIds,
  initialScope = 'SUPPLIER',
  initialArticle = null,
  onApply,
}) => {
  const [scope, setScope] = useState<PriceUpdateScope>(
    initialArticle ? 'PRODUCT' : selectedArticleIds.length > 0 ? 'BATCH_SELECTED' : initialScope
  );
  const [selectedSupplier, setSelectedSupplier] = useState<string>(
    suppliers.length > 0 ? suppliers[0] : 'TODOS'
  );
  const [selectedCategory, setSelectedCategory] = useState<string>('TODAS');
  const [selectedSubcategory, setSelectedSubcategory] = useState<string>('TODAS');
  const [selectedProductId, setSelectedProductId] = useState<string>(
    initialArticle ? initialArticle.id : articles[0]?.id || ''
  );
  const [productSearch, setProductSearch] = useState<string>(
    initialArticle ? initialArticle.name : ''
  );

  const [targetPrice, setTargetPrice] = useState<TargetPriceType>('SALE');
  const [percentageStr, setPercentageStr] = useState<string>('10');
  const [roundToInteger, setRoundToInteger] = useState<boolean>(true);

  const percentNum = parseFloat(percentageStr) || 0;

  // Filter matching articles based on selected scope
  const matchingArticles = useMemo(() => {
    switch (scope) {
      case 'BATCH_SELECTED':
        return articles.filter(a => selectedArticleIds.includes(a.id));
      case 'SUPPLIER':
        if (!selectedSupplier || selectedSupplier === 'TODOS') {
          return articles.filter(a => Boolean(a.supplier));
        }
        return articles.filter(a => a.supplier === selectedSupplier);
      case 'CATEGORY':
        return articles.filter(a => {
          const matchCat = selectedCategory === 'TODAS' || a.category === selectedCategory;
          const matchSub = selectedSubcategory === 'TODAS' || a.subcategory === selectedSubcategory;
          return matchCat && matchSub;
        });
      case 'PRODUCT':
        return articles.filter(a => a.id === selectedProductId);
      case 'ALL':
        return articles;
      default:
        return [];
    }
  }, [articles, scope, selectedArticleIds, selectedSupplier, selectedCategory, selectedSubcategory, selectedProductId]);

  // Function to calculate updated price
  const calculateNewPrice = (currentPrice: number, percent: number, round: boolean) => {
    if (percent === 0) return currentPrice;
    const computed = currentPrice * (1 + percent / 100);
    return round ? Math.round(computed) : Math.round(computed * 100) / 100;
  };

  // Preview updated articles
  const simulatedUpdates = useMemo(() => {
    return matchingArticles.map(art => {
      let newSalePrice = art.salePrice;
      let newCostPrice = art.costPrice;

      if (targetPrice === 'SALE' || targetPrice === 'BOTH') {
        newSalePrice = calculateNewPrice(art.salePrice, percentNum, roundToInteger);
      }
      if (targetPrice === 'COST' || targetPrice === 'BOTH') {
        newCostPrice = calculateNewPrice(art.costPrice, percentNum, roundToInteger);
      }

      return {
        article: art,
        newSalePrice,
        newCostPrice,
        saleDiff: newSalePrice - art.salePrice,
        costDiff: newCostPrice - art.costPrice,
      };
    });
  }, [matchingArticles, targetPrice, percentNum, roundToInteger]);

  const handleConfirm = () => {
    if (matchingArticles.length === 0 || percentNum === 0) return;

    const updatedArticlesList: Article[] = simulatedUpdates.map(sim => ({
      ...sim.article,
      salePrice: sim.newSalePrice,
      costPrice: sim.newCostPrice,
    }));

    let reasonScope = '';
    if (scope === 'SUPPLIER') reasonScope = `proveedor "${selectedSupplier}"`;
    else if (scope === 'CATEGORY') reasonScope = `categoría "${selectedCategory}"`;
    else if (scope === 'BATCH_SELECTED') reasonScope = `lote (${selectedArticleIds.length} seleccionados)`;
    else if (scope === 'PRODUCT') reasonScope = `producto individual`;
    else reasonScope = 'todo el catálogo';

    const reason = `Aumento de precios (${percentNum > 0 ? '+' : ''}${percentNum}%) por ${reasonScope}`;
    onApply(updatedArticlesList, reason);
    onClose();
  };

  const quickPercentages = [5, 10, 15, 20, 25, 30];

  // Filtered products for dropdown search when scope is PRODUCT
  const searchedProducts = useMemo(() => {
    if (!productSearch.trim()) return articles.slice(0, 10);
    return articles
      .filter(a => matchesQuery(a.name, productSearch) || a.barcode.includes(productSearch))
      .slice(0, 10);
  }, [articles, productSearch]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-start sm:items-center justify-center p-2 sm:p-4 overflow-y-auto overscroll-contain">
      <div className="my-auto bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-neutral-200 overflow-hidden flex flex-col max-h-[calc(100dvh-1rem)] sm:max-h-[calc(100dvh-2rem)] min-h-0">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-100 flex items-center justify-between bg-neutral-50/80">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-100 text-emerald-800">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-neutral-900 leading-tight">
                Aumento / Modificación de Precios (%)
              </h3>
              <p className="text-xs text-neutral-500 mt-0.5">
                Ajuste porcentual de precios por proveedor, subcategoría, producto o lote
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="p-1.5 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-200/60 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
          {/* 1. Selector de Alcance (Criterio) */}
          <div>
            <label className="block text-[11px] font-bold text-neutral-700 uppercase tracking-wider mb-2">
              1. Alcance del Aumento (¿A qué productos se aplica?)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
              <button
                type="button"
                onClick={() => setScope('SUPPLIER')}
                className={`p-2.5 rounded-xl border text-center text-xs font-semibold flex flex-col items-center gap-1 transition-all ${
                  scope === 'SUPPLIER'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-900 shadow-xs'
                    : 'border-neutral-200 bg-white text-neutral-600 hover:bg-neutral-50'
                }`}
              >
                <Truck className="w-4 h-4" />
                <span>Por Proveedor</span>
              </button>

              <button
                type="button"
                onClick={() => setScope('CATEGORY')}
                className={`p-2.5 rounded-xl border text-center text-xs font-semibold flex flex-col items-center gap-1 transition-all ${
                  scope === 'CATEGORY'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-900 shadow-xs'
                    : 'border-neutral-200 bg-white text-neutral-600 hover:bg-neutral-50'
                }`}
              >
                <Layers className="w-4 h-4" />
                <span>Subcategoría</span>
              </button>

              <button
                type="button"
                onClick={() => setScope('BATCH_SELECTED')}
                className={`p-2.5 rounded-xl border text-center text-xs font-semibold flex flex-col items-center gap-1 transition-all ${
                  scope === 'BATCH_SELECTED'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-900 shadow-xs'
                    : 'border-neutral-200 bg-white text-neutral-600 hover:bg-neutral-50'
                }`}
              >
                <CheckSquare className="w-4 h-4" />
                <span>Por Lote ({selectedArticleIds.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setScope('PRODUCT')}
                className={`p-2.5 rounded-xl border text-center text-xs font-semibold flex flex-col items-center gap-1 transition-all ${
                  scope === 'PRODUCT'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-900 shadow-xs'
                    : 'border-neutral-200 bg-white text-neutral-600 hover:bg-neutral-50'
                }`}
              >
                <Package className="w-4 h-4" />
                <span>Por Producto</span>
              </button>

              <button
                type="button"
                onClick={() => setScope('ALL')}
                className={`p-2.5 rounded-xl border text-center text-xs font-semibold flex flex-col items-center gap-1 transition-all ${
                  scope === 'ALL'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-900 shadow-xs'
                    : 'border-neutral-200 bg-white text-neutral-600 hover:bg-neutral-50'
                }`}
              >
                <Tag className="w-4 h-4" />
                <span>Todo Catálogo</span>
              </button>
            </div>
          </div>

          {/* Sub-configuración del Alcance según selección */}
          <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 text-xs">
            {scope === 'SUPPLIER' && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-neutral-700">Seleccionar Proveedor:</span>
                  <span className="text-neutral-500 font-mono text-[11px]">
                    {suppliers.length} proveedores registrados
                  </span>
                </div>
                {suppliers.length > 0 ? (
                  <select
                    value={selectedSupplier}
                    onChange={(e) => setSelectedSupplier(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-neutral-300 rounded-lg text-xs font-medium text-neutral-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="TODOS">-- Todos los artículos con proveedor asignado --</option>
                    {suppliers.map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                ) : (
                  <p className="text-neutral-500 italic">
                    Aún no hay proveedores cargados. Al crear o editar artículos puedes asignarle un proveedor.
                  </p>
                )}
              </div>
            )}

            {scope === 'CATEGORY' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-neutral-700 mb-1">Categoría:</label>
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-neutral-300 rounded-lg text-xs font-medium text-neutral-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="TODAS">-- Todas las categorías --</option>
                    {categories.map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-neutral-700 mb-1">Subcategoría:</label>
                  <select
                    value={selectedSubcategory}
                    onChange={(e) => setSelectedSubcategory(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-neutral-300 rounded-lg text-xs font-medium text-neutral-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="TODAS">-- Todas las subcategorías --</option>
                    {subcategories.map(sc => (
                      <option key={sc} value={sc}>{sc}</option>
                    ))}
                  </select>
                </div>
              </div>
            )}

            {scope === 'BATCH_SELECTED' && (
              <div>
                <p className="font-bold text-neutral-800">
                  {selectedArticleIds.length > 0 
                    ? `Se aplicará a los ${selectedArticleIds.length} artículos seleccionados por lote con las casillas de la tabla.`
                    : 'No hay artículos seleccionados en la tabla. Marca las casillas de verificación de los artículos que desees actualizar por lote.'}
                </p>
              </div>
            )}

            {scope === 'PRODUCT' && (
              <div className="space-y-2">
                <label className="block font-bold text-neutral-700">Buscar Producto a Aumentar:</label>
                <input
                  type="text"
                  placeholder="Escribir nombre o código de barra..."
                  value={productSearch}
                  onChange={(e) => setProductSearch(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-neutral-300 rounded-lg text-xs font-medium text-neutral-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                />
                <div className="max-h-32 overflow-y-auto bg-white border border-neutral-200 rounded-lg divide-y divide-neutral-100">
                  {searchedProducts.map(art => (
                    <button
                      key={art.id}
                      type="button"
                      onClick={() => {
                        setSelectedProductId(art.id);
                        setProductSearch(art.name);
                      }}
                      className={`w-full text-left p-2 hover:bg-neutral-50 flex items-center justify-between transition-colors ${
                        selectedProductId === art.id ? 'bg-emerald-50/80 font-bold' : ''
                      }`}
                    >
                      <span className="text-neutral-800 truncate">{art.name}</span>
                      <span className="font-mono text-neutral-500 shrink-0 ml-2">
                        ${formatThousands(art.salePrice)}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {scope === 'ALL' && (
              <p className="font-bold text-neutral-800">
                Se aplicará el aumento al catálogo completo ({articles.length} artículos).
              </p>
            )}
          </div>

          {/* 2. Precios a Modificar */}
          <div>
            <label className="block text-[11px] font-bold text-neutral-700 uppercase tracking-wider mb-2">
              2. Precios a Modificar
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setTargetPrice('SALE')}
                className={`py-2 px-3 rounded-lg border text-center text-xs font-bold transition-all ${
                  targetPrice === 'SALE'
                    ? 'border-neutral-900 bg-neutral-900 text-white shadow-xs'
                    : 'border-neutral-200 bg-white text-neutral-700 hover:bg-neutral-50'
                }`}
              >
                Solo Precio de Venta
              </button>

              <button
                type="button"
                onClick={() => setTargetPrice('COST')}
                className={`py-2 px-3 rounded-lg border text-center text-xs font-bold transition-all ${
                  targetPrice === 'COST'
                    ? 'border-neutral-900 bg-neutral-900 text-white shadow-xs'
                    : 'border-neutral-200 bg-white text-neutral-700 hover:bg-neutral-50'
                }`}
              >
                Solo Precio de Costo
              </button>

              <button
                type="button"
                onClick={() => setTargetPrice('BOTH')}
                className={`py-2 px-3 rounded-lg border text-center text-xs font-bold transition-all ${
                  targetPrice === 'BOTH'
                    ? 'border-neutral-900 bg-neutral-900 text-white shadow-xs'
                    : 'border-neutral-200 bg-white text-neutral-700 hover:bg-neutral-50'
                }`}
              >
                Ambos (Costo y Venta)
              </button>
            </div>
          </div>

          {/* 3. Porcentaje de Aumento */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-[11px] font-bold text-neutral-700 uppercase tracking-wider">
                3. Porcentaje de Aumento (%)
              </label>
              <div className="flex items-center gap-1">
                {quickPercentages.map(pct => (
                  <button
                    key={pct}
                    type="button"
                    onClick={() => setPercentageStr(pct.toString())}
                    className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold transition-colors ${
                      percentageStr === pct.toString()
                        ? 'bg-emerald-600 text-white'
                        : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                    }`}
                  >
                    +{pct}%
                  </button>
                ))}
              </div>
            </div>

            <div className="relative">
              <span className="absolute left-3.5 top-2 text-neutral-500 font-bold text-lg">%</span>
              <input
                type="number"
                step="0.1"
                value={percentageStr}
                onChange={(e) => setPercentageStr(e.target.value)}
                placeholder="0"
                className="w-full pl-9 pr-4 py-2 border-2 border-neutral-300 rounded-xl text-lg font-mono font-bold text-neutral-900 focus:outline-hidden focus:border-emerald-500 shadow-xs"
              />
            </div>

            <label className="flex items-center gap-2 mt-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={roundToInteger}
                onChange={(e) => setRoundToInteger(e.target.checked)}
                className="rounded border-neutral-300 text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
              />
              <span className="text-xs text-neutral-600 font-medium">
                Redondear precios finales a números enteros (ej. $1.250 sin centavos)
              </span>
            </label>
          </div>

          {/* 4. Simulación y Vista Previa en Vivo */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-bold text-neutral-700 uppercase tracking-wider">
                4. Vista Previa de Cambios
              </span>
              <span className="text-xs font-bold text-emerald-700 font-mono">
                {matchingArticles.length} artículo(s) coincidente(s)
              </span>
            </div>

            {matchingArticles.length > 0 ? (
              <div className="border border-neutral-200 rounded-xl overflow-hidden max-h-48 overflow-y-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-neutral-100 text-neutral-600 font-bold border-b border-neutral-200 sticky top-0">
                    <tr>
                      <th className="px-3 py-2">Artículo</th>
                      <th className="px-3 py-2 text-right">Precio Actual</th>
                      <th className="px-3 py-2 text-right">Nuevo Precio ({percentNum > 0 ? `+${percentNum}%` : `${percentNum}%`})</th>
                      <th className="px-3 py-2 text-right">Diferencia</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100 font-mono">
                    {simulatedUpdates.slice(0, 10).map((sim) => {
                      const curr = targetPrice === 'COST' ? sim.article.costPrice : sim.article.salePrice;
                      const next = targetPrice === 'COST' ? sim.newCostPrice : sim.newSalePrice;
                      const diff = next - curr;
                      return (
                        <tr key={sim.article.id} className="hover:bg-neutral-50">
                          <td className="px-3 py-1.5 font-sans font-medium text-neutral-800 truncate max-w-[180px]">
                            {sim.article.name}
                            {sim.article.supplier && (
                              <span className="block text-[10px] text-neutral-400 font-normal">
                                {sim.article.supplier}
                              </span>
                            )}
                          </td>
                          <td className="px-3 py-1.5 text-right text-neutral-500">
                            ${formatThousands(curr)}
                          </td>
                          <td className="px-3 py-1.5 text-right font-bold text-emerald-700">
                            ${formatThousands(next)}
                          </td>
                          <td className="px-3 py-1.5 text-right text-xs text-emerald-600">
                            {diff >= 0 ? `+$${formatThousands(diff)}` : `-$${formatThousands(Math.abs(diff))}`}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
                {simulatedUpdates.length > 10 && (
                  <div className="p-2 text-center text-[11px] text-neutral-400 bg-neutral-50 border-t border-neutral-100">
                    Mostrando 10 de {simulatedUpdates.length} artículos afectados...
                  </div>
                )}
              </div>
            ) : (
              <div className="p-4 bg-neutral-50 rounded-xl border border-dashed border-neutral-300 text-center text-xs text-neutral-500 flex items-center justify-center gap-2">
                <AlertCircle className="w-4 h-4 text-neutral-400" />
                <span>No hay artículos que coincidan con el alcance seleccionado.</span>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-100 bg-neutral-50/80 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-neutral-300 rounded-xl text-xs font-semibold text-neutral-700 hover:bg-neutral-100 transition-colors"
          >
            Cancelar
          </button>

          <button
            type="button"
            disabled={matchingArticles.length === 0 || percentNum === 0}
            onClick={handleConfirm}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Check className="w-4 h-4" />
            Aplicar Aumento a {matchingArticles.length} Artículo(s)
          </button>
        </div>
      </div>
    </div>
  );
};
