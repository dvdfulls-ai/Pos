import React, { useState, useRef, useEffect, useMemo } from 'react';
import { 
  Package, 
  Plus, 
  Search, 
  Barcode, 
  AlertTriangle, 
  Edit3, 
  Trash2, 
  ArrowUpDown, 
  X, 
  Check, 
  TrendingDown,
  TrendingUp,
  Percent,
  Truck,
  Layers,
  Sparkles,
  ChevronDown,
  FileText,
  FileSpreadsheet,
  Download
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import { Article } from '../../types';
import { StorageService } from '../../services/storage';
import { DialogService } from '../../services/dialog';
import { matchesQuery, normalizeText, formatThousands, parseFormattedNumber, toTitleCase } from '../../utils/text';
import { PriceUpdateModal, PriceUpdateScope } from './PriceUpdateModal';
import { CatalogImportModal } from './CatalogImportModal';
import { exportToExcel, exportToCsv } from '../../utils/exportUtils';

type InventoryModuleProps = {
  stockAdjustmentArticleId?: string | null;
  onStockAdjustmentRequestHandled?: () => void;
};

export const InventoryModule: React.FC<InventoryModuleProps> = ({ stockAdjustmentArticleId = null, onStockAdjustmentRequestHandled }) => {
  const { articles, addArticle, updateArticle, updateArticlesBatch, deleteArticle, adjustStock, accounts } = useApp();
  const { hasPermission } = useAuth();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBrand, setSelectedBrand] = useState('TODAS');
  const [selectedSupplier, setSelectedSupplier] = useState('TODOS');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState('TODAS');
  const [stockFilter, setStockFilter] = useState<'ALL' | 'LOW' | 'OUT'>('ALL');

  // Batch selection for multi-product actions / lotes
  const [selectedArticleIds, setSelectedArticleIds] = useState<string[]>([]);

  // Price update modal state
  const [showPriceUpdateModal, setShowPriceUpdateModal] = useState(false);
  const [priceUpdateScope, setPriceUpdateScope] = useState<PriceUpdateScope>('SUPPLIER');
  const [priceUpdateInitialArticle, setPriceUpdateInitialArticle] = useState<Article | null>(null);

  // Import modal state (CSV / Excel)
  const [importModalMode, setImportModalMode] = useState<'CSV' | 'EXCEL' | null>(null);
  
  // Modal state
  const [showModal, setShowModal] = useState(false);
  const [editingArticle, setEditingArticle] = useState<Article | null>(null);
  const [adjustModalArticle, setAdjustModalArticle] = useState<Article | null>(null);
  const [adjustAmountStr, setAdjustAmountStr] = useState<string>('');
  const adjustAmountInputRef = useRef<HTMLInputElement>(null);
  const adjustModalOpenRef = useRef(false);

  const openQuickStockAdjust = (article: Article) => {
    // Evita que el autoenfoque global del buscador robe el cursor al abrir la ventana.
    adjustModalOpenRef.current = true;
    setAdjustAmountStr('');
    setAdjustModalArticle(article);
  };

  const closeQuickStockAdjust = () => {
    adjustModalOpenRef.current = false;
    setAdjustModalArticle(null);
    setAdjustAmountStr('');
    // Al cerrar, devolver el cursor al buscador de Artículos & Stock.
    window.setTimeout(() => {
      searchInputRef.current?.focus();
      searchInputRef.current?.select();
    }, 50);
  };

  // Mantener el foco en la cantidad mientras la ventana está abierta.
  useEffect(() => {
    if (!adjustModalArticle) return;
    const focusTimer = window.setTimeout(() => {
      adjustAmountInputRef.current?.focus();
      adjustAmountInputRef.current?.select();
    }, 50);
    return () => window.clearTimeout(focusTimer);
  }, [adjustModalArticle]);

  // Form input display strings (formatted for direct typing without arrows)
  const [costPriceStr, setCostPriceStr] = useState('');
  const [salePriceStr, setSalePriceStr] = useState('');
  const [stockStr, setStockStr] = useState('');
  const [minStockStr, setMinStockStr] = useState('');

  // Opciones opcionales de cálculo de precios; desactivadas por defecto para conservar el comportamiento actual.
  const [applyCostVat, setApplyCostVat] = useState(false);
  const [applySaleVat, setApplySaleVat] = useState(false);
  const [applyProfitMargin, setApplyProfitMargin] = useState(false);
  const [costVatPercent, setCostVatPercent] = useState('21');
  const [saleVatPercent, setSaleVatPercent] = useState('21');
  const [profitPercent, setProfitPercent] = useState('30');

  // Continuous quick loading feedback
  const [lastSavedQuickArticle, setLastSavedQuickArticle] = useState<string | null>(null);
  const [savedCountSession, setSavedCountSession] = useState<number>(0);

  // Interactive dropdown states for Category and Brand
  const [showCategoryDropdown, setShowCategoryDropdown] = useState(false);
  const [showBrandSuggestions, setShowBrandSuggestions] = useState(false);
  const [brandSuggestionIndex, setBrandSuggestionIndex] = useState(0);
  const [categorySuggestionIndex, setCategorySuggestionIndex] = useState(0);

  const barcodeInputRef = useRef<HTMLInputElement>(null);
  const nameInputRef = useRef<HTMLInputElement>(null);
  // Detecta ráfagas numéricas de lectores de códigos dentro del nombre del artículo.
  // Solo afecta este campo; el lector sigue funcionando normalmente en Código de Barra.
  const nameKeyTimesRef = useRef<number[]>([]);
  const rejectNameScannerUntilRef = useRef(0);
  const brandInputRef = useRef<HTMLInputElement>(null);
  const categoryInputRef = useRef<HTMLInputElement>(null);
  const subcategoryInputRef = useRef<HTMLInputElement>(null);
  const supplierInputRef = useRef<HTMLInputElement>(null);
  const costPriceInputRef = useRef<HTMLInputElement>(null);
  const salePriceInputRef = useRef<HTMLInputElement>(null);
  const stockInputRef = useRef<HTMLInputElement>(null);
  const minStockInputRef = useRef<HTMLInputElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const categoryContainerRef = useRef<HTMLDivElement>(null);
  const brandContainerRef = useRef<HTMLDivElement>(null);

  // Auto-enfocar el buscador por código / nombre al entrar a la pestaña Artículos & Stock
  useEffect(() => {
    const focusSearchInput = () => {
      setTimeout(() => {
        if (!showModal) {
          searchInputRef.current?.focus();
          searchInputRef.current?.select();
        }
      }, 50);
    };

    focusSearchInput();

    window.addEventListener('focus-inventory-search', focusSearchInput);
    return () => window.removeEventListener('focus-inventory-search', focusSearchInput);
  }, [showModal]);

  // Mantener el cursor en el buscador al terminar acciones dentro de Artículos & Stock.
  // Si una acción abre el modal de edición, el cambio de showModal cancela este enfoque.
  useEffect(() => {
    if (showModal) return;

    let focusTimer: ReturnType<typeof setTimeout> | undefined;
    const refocusSearchAfterAction = (event: MouseEvent) => {
      const target = event.target as HTMLElement | null;
      if (target?.closest('input, textarea, select, [contenteditable="true"]')) return;

      if (adjustModalOpenRef.current) return;
      if (focusTimer) clearTimeout(focusTimer);
      focusTimer = setTimeout(() => {
        if (!showModal && !adjustModalOpenRef.current) {
          searchInputRef.current?.focus();
          searchInputRef.current?.select();
        }
      }, 80);
    };

    document.addEventListener('click', refocusSearchAfterAction);
    return () => {
      document.removeEventListener('click', refocusSearchAfterAction);
      if (focusTimer) clearTimeout(focusTimer);
    };
  }, [showModal]);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (categoryContainerRef.current && !categoryContainerRef.current.contains(e.target as Node)) {
        setShowCategoryDropdown(false);
      }
      if (brandContainerRef.current && !brandContainerRef.current.contains(e.target as Node)) {
        setShowBrandSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (showModal) {
      const timer = setTimeout(() => {
        barcodeInputRef.current?.focus();
        barcodeInputRef.current?.select();
      }, 60);
      return () => clearTimeout(timer);
    }
  }, [showModal]);

  // Form state
  const [formData, setFormData] = useState({
    barcode: '',
    name: '',
    brand: '',
    category: '',
    subcategory: '',
    supplier: '',
    costPrice: 0,
    salePrice: 0,
    stock: 0,
    minStock: 0,
    unit: 'Unidad',
  });

  const enteredCostPreview = parseFormattedNumber(costPriceStr);
  const enteredSalePreview = parseFormattedNumber(salePriceStr);
  const costFinalPreview = Math.round(applyCostVat
    ? enteredCostPreview * (1 + Math.max(0, Number(costVatPercent) || 0) / 100)
    : enteredCostPreview);
  const saleBasePreview = applyProfitMargin
    ? costFinalPreview * (1 + Math.max(0, Number(profitPercent) || 0) / 100)
    : enteredSalePreview;
  const saleFinalPreview = Math.round(applySaleVat
    ? saleBasePreview * (1 + Math.max(0, Number(saleVatPercent) || 0) / 100)
    : saleBasePreview);
  const profitAmountPreview = saleBasePreview - costFinalPreview;
  const profitPercentPreview = costFinalPreview > 0 ? (profitAmountPreview / costFinalPreview) * 100 : 0;

  const canManage = hasPermission('canManageInventory');

  // Brands list (memoized for instant responsiveness with 10.000+ items)
  const brands = useMemo(() => {
    return ['TODAS', ...Array.from(new Set(articles.map(a => a.brand).filter(Boolean)))];
  }, [articles]);

  // Single-pass extraction of suppliers, categories, subcategories and brands
  const { suppliers, existingSubcategories, existingCategories, existingBrands } = useMemo(() => {
    const defaultCategories = [
      'Almacén',
      'Bebidas',
      'Lácteos',
      'Golosinas',
      'Panadería',
      'Limpieza',
      'Perfumería',
      'Fiambres',
      'Congelados',
      'Cigarrillos',
      'Snacks',
      'Frutas y Verduras',
      'Kiosco',
      'Bebidas con Alcohol'
    ];

    const suppSet = new Set<string>();
    accounts.filter(a => a.type === 'SUPPLIER').forEach(a => suppSet.add(a.name));

    const subcatSet = new Set<string>();
    const catSet = new Set<string>(defaultCategories);
    const brandSet = new Set<string>();

    for (let i = 0; i < articles.length; i++) {
      const art = articles[i];
      if (art.supplier) suppSet.add(art.supplier);
      if (art.subcategory) subcatSet.add(art.subcategory);
      if (art.category) catSet.add(art.category);
      if (art.brand) brandSet.add(art.brand);
    }

    return {
      suppliers: Array.from(suppSet).sort((a, b) => a.localeCompare(b)),
      existingSubcategories: Array.from(subcatSet).sort((a, b) => a.localeCompare(b)),
      existingCategories: Array.from(catSet).sort((a, b) => a.localeCompare(b)),
      existingBrands: Array.from(brandSet).sort((a, b) => a.localeCompare(b)),
    };
  }, [accounts, articles]);

  // Matching categories filtered in real-time as user types (capped to top 15 to keep DOM fast)
  const matchingCategories = useMemo(() => {
    const query = formData.category || '';
    if (!query.trim()) return existingCategories.slice(0, 15);
    const norm = normalizeText(query);
    return existingCategories.filter(cat => normalizeText(cat).includes(norm)).slice(0, 15);
  }, [existingCategories, formData.category]);

  // Matching brands for predictive typing (capped to top 10)
  const matchingBrands = useMemo(() => {
    const query = formData.brand || '';
    if (!query.trim()) return existingBrands.slice(0, 10);
    const norm = normalizeText(query);
    return existingBrands.filter(b => normalizeText(b).includes(norm)).slice(0, 10);
  }, [existingBrands, formData.brand]);

  // Build the text-search index only when the article collection changes.
  // Before this optimization, every keystroke normalized name/brand/category/subcategory/supplier
  // again for every article (8,000+ articles can mean tens of thousands of normalizations per keypress).
  // This index is in-memory only and does not alter persisted articles or sync payloads.
  const articleSearchIndex = useMemo(() => articles.map(art => ({
    barcode: String(art.barcode || ''),
    name: normalizeText(art.name || ''),
    brand: normalizeText(art.brand || ''),
    category: normalizeText(art.category || ''),
    subcategory: normalizeText(art.subcategory || ''),
    supplier: normalizeText(art.supplier || ''),
  })), [articles]);

  // High-performance filtering with pre-normalized article text.
  const filteredArticles = useMemo(() => {
    const q = searchTerm.trim();
    const hasSearch = Boolean(q);
    const hasBrand = selectedBrand !== 'TODAS';
    const hasSupplier = selectedSupplier !== 'TODOS';
    const hasCat = selectedCategoryFilter !== 'TODAS';
    const hasStock = stockFilter !== 'ALL';

    // Fast-path: if no filters active, return articles directly (0ms latency!)
    if (!hasSearch && !hasBrand && !hasSupplier && !hasCat && !hasStock) {
      return articles;
    }

    const normQ = hasSearch ? normalizeText(q) : '';

    const matches: Article[] = [];
    for (let i = 0; i < articles.length; i++) {
      const art = articles[i];
      const indexed = articleSearchIndex[i];
      if (hasBrand && art.brand !== selectedBrand) continue;
      if (hasSupplier && art.supplier !== selectedSupplier) continue;
      if (hasCat && art.category !== selectedCategoryFilter) continue;
      if (hasStock) {
        if (stockFilter === 'LOW' && (art.stock > art.minStock || art.stock <= 0)) continue;
        if (stockFilter === 'OUT' && art.stock > 0) continue;
      }
      if (!hasSearch) {
        matches.push(art);
        continue;
      }

      // Barcode check remains literal to preserve existing search behavior.
      if (indexed.barcode.includes(q) || indexed.name.includes(normQ) ||
          indexed.brand.includes(normQ) || indexed.category.includes(normQ) ||
          indexed.subcategory.includes(normQ) || indexed.supplier.includes(normQ)) {
        matches.push(art);
      }
    }
    return matches;
  }, [articles, articleSearchIndex, searchTerm, selectedBrand, selectedSupplier, selectedCategoryFilter, stockFilter]);

  // Fast pagination for 10.000+ items
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 50;

  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, selectedBrand, selectedSupplier, selectedCategoryFilter, stockFilter]);

  const totalPages = Math.max(1, Math.ceil(filteredArticles.length / pageSize));
  const paginatedArticles = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredArticles.slice(start, start + pageSize);
  }, [filteredArticles, currentPage, pageSize]);

  // Batch selection handlers
  const handleToggleSelectAll = () => {
    if (selectedArticleIds.length === filteredArticles.length && filteredArticles.length > 0) {
      setSelectedArticleIds([]);
    } else {
      setSelectedArticleIds(filteredArticles.map(a => a.id));
    }
  };

  const handleToggleSelectArticle = (id: string) => {
    setSelectedArticleIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  // Price update modal openers
  const handleOpenPriceUpdate = () => {
    setPriceUpdateInitialArticle(null);
    setPriceUpdateScope(selectedArticleIds.length > 0 ? 'BATCH_SELECTED' : 'SUPPLIER');
    setShowPriceUpdateModal(true);
  };

  const handleOpenPriceUpdateForBatch = () => {
    setPriceUpdateInitialArticle(null);
    setPriceUpdateScope('BATCH_SELECTED');
    setShowPriceUpdateModal(true);
  };

  const handleOpenPriceUpdateForSingle = (article: Article) => {
    setSearchTerm('');
    setPriceUpdateInitialArticle(article);
    setPriceUpdateScope('PRODUCT');
    setShowPriceUpdateModal(true);
  };

  const handleApplyPriceUpdate = (updatedArticlesList: Article[], reason: string) => {
    updateArticlesBatch(updatedArticlesList, reason);
    setSelectedArticleIds([]);
    DialogService.alert(
      `Se han actualizado con éxito los precios de ${updatedArticlesList.length} artículo(s).`,
      'Precios Actualizados',
      'success'
    );
  };

  const handlePriceChange = (field: 'costPrice' | 'salePrice', rawValue: string) => {
    const formatted = formatThousands(rawValue);
    if (field === 'costPrice') {
      setCostPriceStr(formatted);
      setFormData(prev => ({ ...prev, costPrice: parseFormattedNumber(formatted) }));
    } else {
      setSalePriceStr(formatted);
      setFormData(prev => ({ ...prev, salePrice: parseFormattedNumber(formatted) }));
    }
  };

  const handleStockChange = (field: 'stock' | 'minStock', rawValue: string) => {
    const clean = rawValue.replace(/[^\d]/g, '');
    if (field === 'stock') {
      setStockStr(clean);
      setFormData(prev => ({ ...prev, stock: clean === '' ? 0 : parseInt(clean, 10) }));
    } else {
      setMinStockStr(clean);
      setFormData(prev => ({ ...prev, minStock: clean === '' ? 0 : parseInt(clean, 10) }));
    }
  };

  useEffect(() => {
    if (!stockAdjustmentArticleId) return;
    const article = articles.find(item => item.id === stockAdjustmentArticleId);
    if (article) {
      setAdjustModalArticle(article);
      setAdjustAmountStr('');
    }
    onStockAdjustmentRequestHandled?.();
  }, [stockAdjustmentArticleId, articles, onStockAdjustmentRequestHandled]);

  const handleOpenAdd = () => {
    setSearchTerm('');
    setApplyCostVat(false);
    setApplySaleVat(false);
    setApplyProfitMargin(false);
    setCostVatPercent('21');
    setSaleVatPercent('21');
    setProfitPercent('30');
    setEditingArticle(null);
    setLastSavedQuickArticle(null);
    setSavedCountSession(0);
    setFormData({
      barcode: '', // Totalmente vacío para que el cursor empiece listo para escanear
      name: '',
      brand: '',
      category: '',
      subcategory: '',
      supplier: '',
      costPrice: 0,
      salePrice: 0,
      stock: 0,
      minStock: 0,
      unit: 'Unidad',
    });
    setCostPriceStr('');
    setSalePriceStr('');
    setStockStr('');
    setMinStockStr('');
    setShowCategoryDropdown(false);
    setShowBrandSuggestions(false);
    setShowModal(true);
  };

  // Keyboard shortcut listener for F7 / new_article
  useEffect(() => {
    const handleActionNewArticle = () => {
      handleOpenAdd();
    };
    window.addEventListener('pos-action-new-article', handleActionNewArticle);
    return () => window.removeEventListener('pos-action-new-article', handleActionNewArticle);
  }, []);

  const handleOpenEdit = (article: Article) => {
    setSearchTerm('');
    const savedCalc = article.priceCalc;
    setApplyCostVat(savedCalc?.applyCostVat ?? false);
    setApplySaleVat(savedCalc?.applySaleVat ?? false);
    setApplyProfitMargin(savedCalc?.applyProfitMargin ?? false);
    setCostVatPercent(String(savedCalc?.costVatPercent ?? 21));
    setSaleVatPercent(String(savedCalc?.saleVatPercent ?? 21));
    setProfitPercent(String(savedCalc?.profitPercent ?? 30));
    setEditingArticle(article);
    setLastSavedQuickArticle(null);
    setFormData({
      barcode: article.barcode,
      name: article.name,
      brand: article.brand,
      category: article.category,
      subcategory: article.subcategory || '',
      supplier: article.supplier || '',
      costPrice: article.costPrice,
      salePrice: article.salePrice,
      stock: article.stock,
      minStock: article.minStock,
      unit: article.unit,
    });
    setCostPriceStr(formatThousands(savedCalc?.baseCostPrice ?? article.costPrice));
    setSalePriceStr(formatThousands(savedCalc?.baseSalePrice ?? article.salePrice));
    setStockStr(String(article.stock));
    setMinStockStr(String(article.minStock));
    setShowCategoryDropdown(false);
    setShowBrandSuggestions(false);
    setShowModal(true);
  };

  const executeArticleSave = (): boolean => {
    if (!formData.name.trim() || !formData.barcode.trim()) {
      DialogService.alert('El nombre y el código de barras son campos obligatorios.', 'Campos Requeridos', 'warning');
      return false;
    }

    const enteredCost = parseFormattedNumber(costPriceStr);
    const enteredSale = parseFormattedNumber(salePriceStr);
    const costNum = applyCostVat
      ? enteredCost * (1 + Math.max(0, Number(costVatPercent) || 0) / 100)
      : enteredCost;
    const saleBase = applyProfitMargin
      ? costNum * (1 + Math.max(0, Number(profitPercent) || 0) / 100)
      : enteredSale;
    const saleNum = applySaleVat
      ? saleBase * (1 + Math.max(0, Number(saleVatPercent) || 0) / 100)
      : saleBase;
    const stockNum = stockStr.trim() === '' ? 0 : parseInt(stockStr.replace(/[^\d]/g, ''), 10) || 0;
    const minStockNum = minStockStr.trim() === '' ? 0 : parseInt(minStockStr.replace(/[^\d]/g, ''), 10) || 0;

    const articleData = {
      ...formData,
      name: toTitleCase(formData.name.trim()),
      brand: formData.brand.trim() ? toTitleCase(formData.brand.trim()) : 'Genérica',
      category: formData.category.trim() ? toTitleCase(formData.category.trim()) : 'General',
      subcategory: formData.subcategory?.trim() ? toTitleCase(formData.subcategory.trim()) : undefined,
      supplier: formData.supplier?.trim() ? toTitleCase(formData.supplier.trim()) : undefined,
      costPrice: costNum,
      salePrice: saleNum,
      stock: stockNum,
      minStock: minStockNum,
      priceCalc: {
        baseCostPrice: enteredCost,
        baseSalePrice: enteredSale,
        applyCostVat,
        applySaleVat,
        applyProfitMargin,
        costVatPercent: Math.max(0, Number(costVatPercent) || 0),
        saleVatPercent: Math.max(0, Number(saleVatPercent) || 0),
        profitPercent: Math.max(0, Number(profitPercent) || 0),
      },
    };

    if (editingArticle) {
      updateArticle({
        ...editingArticle,
        ...articleData,
      });
    } else {
      addArticle({
        ...articleData,
      });
      setLastSavedQuickArticle(`${formData.name.trim()} ($${formatThousands(saleNum)})`);
      setSavedCountSession(c => c + 1);
    }
    return true;
  };

  const handleSaveAndContinue = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (editingArticle) {
      if (executeArticleSave()) {
        setShowModal(false);
      }
      return;
    }
    if (executeArticleSave()) {
      setFormData({
        barcode: '',
        name: '',
        brand: '',
        category: '',
        subcategory: '',
        supplier: '',
        costPrice: 0,
        salePrice: 0,
        stock: 0,
        minStock: 0,
        unit: 'Unidad',
      });
      setCostPriceStr('');
      setSalePriceStr('');
      setStockStr('');
      setMinStockStr('');
      setTimeout(() => {
        barcodeInputRef.current?.focus();
        barcodeInputRef.current?.select();
      }, 50);
    }
  };

  const handleSaveAndFinish = () => {
    if (executeArticleSave()) {
      setShowModal(false);
    }
  };

  const handleStockAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustModalArticle) return;
    const parsed = adjustAmountStr === '' || adjustAmountStr === '-' ? 0 : parseInt(adjustAmountStr, 10) || 0;
    if (parsed === 0) {
      closeQuickStockAdjust();
      return;
    }
    adjustStock(adjustModalArticle.id, parsed);
    closeQuickStockAdjust();
  };

  const lowStockCount = useMemo(() => articles.filter(a => a.stock <= a.minStock && a.stock > 0).length, [articles]);
  const outOfStockCount = useMemo(() => articles.filter(a => a.stock <= 0).length, [articles]);
  const genericArticlesCount = useMemo(() => articles.filter(a => a.barcode.startsWith('GEN-')).length, [articles]);

  const handleCleanGenericArticles = async () => {
    const confirmed = await DialogService.confirm(
      `¿Deseas eliminar los ${formatThousands(genericArticlesCount)} artículos que quedaron con código "GEN-..." para volver a importar tu archivo limpio con los códigos de barras reales?`,
      'Limpiar Artículos Genéricos',
      'Sí, Eliminar Artículos Genéricos',
      'Cancelar',
      'warning'
    );
    if (confirmed) {
      const cleaned = articles.filter(a => !a.barcode.startsWith('GEN-'));
      StorageService.saveArticles(cleaned);
      window.location.reload();
    }
  };

  const handleExportArticles = (format: 'EXCEL' | 'CSV') => {
    if (articles.length === 0) {
      DialogService.alert('No hay artículos en el catálogo para exportar.', 'Exportar Catálogo', 'info');
      return;
    }

    const exportData = articles.map(a => ({
      CODIGO: a.barcode,
      DETALLE: a.name,
      MARCA: a.brand || '',
      RUBRO: a.category || '',
      SUBRUBRO: a.subcategory || '',
      PRECIOC: a.costPrice,
      PRECIOVP: a.salePrice,
      STEXISTEN: a.stock,
      STMINIMO: a.minStock,
      PROVEEDOR: a.supplier || '',
    }));

    const dateStr = new Date().toISOString().slice(0, 10);
    const fileName = `catalogo_articulos_${dateStr}`;

    if (format === 'EXCEL') {
      exportToExcel(exportData, fileName, 'Artículos');
    } else {
      exportToCsv(exportData, fileName, ';');
    }

    DialogService.alert(
      `Se exportaron ${exportData.length} artículos en formato ${format === 'EXCEL' ? 'Excel (.xlsx)' : 'CSV (.csv)'} correctamente.`,
      'Exportación Exitosa',
      'success'
    );
  };

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-6 space-y-4 w-full">
      {/* Top Banner / Metrics */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-neutral-200">
        <div>
          <h2 className="text-lg font-bold text-neutral-900 tracking-tight">Catálogo de Artículos & Inventario</h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Gestión centralizada de productos, marcas, códigos de barra y alertas de reposición
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {canManage && (
            <>
              <button
                type="button"
                onClick={() => setImportModalMode('CSV')}
                className="px-3 py-2 bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                title="Importar catálogo desde archivo CSV (.csv)"
              >
                <FileText className="w-4 h-4 text-emerald-300" />
                <span>Importar CSV</span>
              </button>

              <button
                type="button"
                onClick={() => setImportModalMode('EXCEL')}
                className="px-3 py-2 bg-teal-700 hover:bg-teal-800 active:scale-95 text-white rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                title="Importar catálogo desde planilla Excel (.xlsx / .xls)"
              >
                <FileSpreadsheet className="w-4 h-4 text-teal-300" />
                <span>Importar Excel</span>
              </button>

              <button
                type="button"
                onClick={() => handleExportArticles('EXCEL')}
                className="px-3 py-2 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 border border-neutral-300 dark:border-neutral-600 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                title="Exportar catálogo completo a Excel (.xlsx)"
              >
                <Download className="w-4 h-4 text-emerald-600" />
                <span>Exportar Excel</span>
              </button>

              <button
                type="button"
                onClick={handleOpenPriceUpdate}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs"
              >
                <TrendingUp className="w-4 h-4" />
                Aumento de Precios (%)
              </button>
              <button
                type="button"
                onClick={handleOpenAdd}
                className="primary-action-dark-white px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs"
              >
                <Plus className="w-4 h-4" />
                Nuevo Artículo
              </button>
            </>
          )}
        </div>
      </div>

      {/* Notice if generic dummy articles exist from previous import */}
      {genericArticlesCount > 0 && (
        <div className="p-4 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-amber-900 dark:text-amber-200 animate-in fade-in">
          <div className="flex items-start sm:items-center gap-2.5">
            <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5 sm:mt-0" />
            <div>
              <p className="font-extrabold text-sm">
                Se detectaron {formatThousands(genericArticlesCount)} artículos con códigos genéricos (GEN-...)
              </p>
              <p className="text-[11px] text-amber-700 dark:text-amber-400 mt-0.5">
                Ocurrió en la importación previa. Puedes eliminarlos con 1 clic para que tu catálogo quede limpio y volver a importar tu archivo CSV o Excel con los códigos y precios reales.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <button
              type="button"
              onClick={handleCleanGenericArticles}
              className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-xs cursor-pointer transition-all active:scale-95"
            >
              <Trash2 className="w-4 h-4" />
              <span>Limpiar Genéricos ({formatThousands(genericArticlesCount)})</span>
            </button>
            <button
              type="button"
              onClick={() => setImportModalMode('EXCEL')}
              className="px-3.5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-xs cursor-pointer transition-all active:scale-95"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>Reimportar Base de Datos</span>
            </button>
          </div>
        </div>
      )}

      {/* Batch Selection Action Bar (when articles are selected in table) */}
      {selectedArticleIds.length > 0 && (
        <div className="p-3 bg-neutral-900 text-white rounded-xl flex flex-col sm:flex-row items-center justify-between gap-3 shadow-md border border-neutral-800 animate-in fade-in duration-200">
          <div className="flex items-center gap-2.5">
            <span className="inline-flex items-center justify-center min-w-6 h-6 px-1.5 rounded-full bg-emerald-500 text-neutral-950 font-mono font-bold text-xs">
              {selectedArticleIds.length}
            </span>
            <span className="text-xs font-semibold">
              {selectedArticleIds.length === 1 
                ? '1 artículo seleccionado por lote' 
                : `${selectedArticleIds.length} artículos seleccionados por lote`}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleOpenPriceUpdateForBatch}
              className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <Percent className="w-3.5 h-3.5" />
              Aumentar Precios de este Lote (%)
            </button>
            <button
              type="button"
              onClick={() => setSelectedArticleIds([])}
              className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded-lg text-xs font-medium transition-colors"
            >
              Deseleccionar
            </button>
          </div>
        </div>
      )}

      {/* Stock Alerts Quick Chips */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <button
          onClick={() => setStockFilter('ALL')}
          className={`p-3 rounded-xl border text-left transition-all ${
            stockFilter === 'ALL'
              ? 'bg-neutral-900 text-white border-neutral-900'
              : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-50'
          }`}
        >
          <span className="text-[11px] uppercase tracking-wider opacity-70">Total Artículos</span>
          <div className="text-xl font-extrabold font-mono mt-0.5">{articles.length}</div>
        </button>

        <button
          onClick={() => setStockFilter('LOW')}
          className={`p-3 rounded-xl border text-left transition-all ${
            stockFilter === 'LOW'
              ? 'bg-amber-600 text-white border-amber-600'
              : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-50'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] uppercase tracking-wider opacity-70">Stock Bajo / Reposición</span>
            <AlertTriangle className={`w-4 h-4 ${stockFilter === 'LOW' ? 'text-white' : 'text-amber-500'}`} />
          </div>
          <div className="text-xl font-extrabold font-mono mt-0.5">{lowStockCount}</div>
        </button>

        <button
          onClick={() => setStockFilter('OUT')}
          className={`p-3 rounded-xl border text-left transition-all ${
            stockFilter === 'OUT'
              ? 'bg-rose-600 text-white border-rose-600'
              : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-50'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] uppercase tracking-wider opacity-70">Agotados (Sin Stock)</span>
            <TrendingDown className={`w-4 h-4 ${stockFilter === 'OUT' ? 'text-white' : 'text-rose-500'}`} />
          </div>
          <div className="text-xl font-extrabold font-mono mt-0.5">{outOfStockCount}</div>
        </button>
      </div>

      {/* Filter Bar with Supplier & Category filters */}
      <div className="p-3 bg-white border border-neutral-200 rounded-xl flex flex-col lg:flex-row gap-3 items-center justify-between">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-neutral-400" />
          <input
            ref={searchInputRef}
            type="text"
            placeholder="Buscar por código de barra, nombre, marca, subcategoría o proveedor..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                const query = searchTerm.trim();
                const exactBarcode = query ? articles.find(article => article.barcode.trim() === query) : undefined;
                setSearchTerm('');
                if (exactBarcode && canManage) handleOpenEdit(exactBarcode);
              }
            }}
            className="w-full pl-9 pr-4 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-neutral-900"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-neutral-500 whitespace-nowrap">Marca:</span>
            <select
              value={selectedBrand}
              onChange={(e) => setSelectedBrand(e.target.value)}
              className="px-2.5 py-1.5 bg-neutral-50 border border-neutral-200 rounded-lg text-xs font-medium text-neutral-700 focus:outline-hidden focus:ring-2 focus:ring-neutral-900"
            >
              {brands.map(b => (
                <option key={b} value={b}>{b}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-xs text-neutral-500 whitespace-nowrap">Proveedor:</span>
            <select
              value={selectedSupplier}
              onChange={(e) => setSelectedSupplier(e.target.value)}
              className="px-2.5 py-1.5 bg-neutral-50 border border-neutral-200 rounded-lg text-xs font-medium text-neutral-700 focus:outline-hidden focus:ring-2 focus:ring-neutral-900"
            >
              <option value="TODOS">Todos</option>
              {suppliers.map(s => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-xs text-neutral-500 whitespace-nowrap">Categoría:</span>
            <select
              value={selectedCategoryFilter}
              onChange={(e) => setSelectedCategoryFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-neutral-50 border border-neutral-200 rounded-lg text-xs font-medium text-neutral-700 focus:outline-hidden focus:ring-2 focus:ring-neutral-900"
            >
              <option value="TODAS">Todas</option>
              {existingCategories.map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Articles Table */}
      <div className="bg-white border border-neutral-200 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-500 font-semibold uppercase tracking-wider">
              <tr>
                <th className="px-3 py-3 w-10 text-center">
                  <input
                    type="checkbox"
                    checked={paginatedArticles.length > 0 && paginatedArticles.every(a => selectedArticleIds.includes(a.id))}
                    onChange={handleToggleSelectAll}
                    className="rounded border-neutral-300 text-neutral-900 focus:ring-neutral-900 w-4 h-4 cursor-pointer"
                    title="Seleccionar / Deseleccionar los artículos de esta página"
                  />
                </th>
                <th className="px-3 py-3">Código de Barra</th>
                <th className="px-4 py-3">Artículo / Descripción</th>
                <th className="px-3 py-3">Marca</th>
                <th className="px-3 py-3 text-right">P. Costo</th>
                <th className="px-3 py-3 text-right">P. Venta</th>
                <th className="px-3 py-3 text-center">Stock Actual</th>
                <th className="px-3 py-3 text-center">Mínimo</th>
                <th className="px-4 py-3 text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100">
              {paginatedArticles.map((article) => {
                const isOutOfStock = article.stock <= 0;
                const isLowStock = article.stock <= article.minStock && !isOutOfStock;
                const isSelected = selectedArticleIds.includes(article.id);

                return (
                  <tr 
                    key={article.id} 
                    className={`transition-colors ${isSelected ? 'bg-emerald-50/50 hover:bg-emerald-50' : 'hover:bg-neutral-50/80'}`}
                  >
                    <td className="px-3 py-3 text-center">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => handleToggleSelectArticle(article.id)}
                        className="rounded border-neutral-300 text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
                      />
                    </td>
                    <td className="px-3 py-3 font-mono font-medium text-neutral-600">
                      <div className="flex items-center gap-1.5">
                        <Barcode className="w-3.5 h-3.5 text-neutral-400" />
                        {article.barcode}
                      </div>
                    </td>
                    <td className="px-4 py-3 font-semibold text-neutral-900">
                      {article.name}
                      <div className="flex flex-wrap items-center gap-1.5 mt-0.5">
                        <span className="text-[10px] font-normal text-neutral-400">
                          {article.category}{article.subcategory ? ` / ${article.subcategory}` : ''} • {article.unit}
                        </span>
                        {article.supplier && (
                          <span className="inline-flex items-center px-1.5 py-0.2 rounded text-[10px] font-medium bg-neutral-100 text-neutral-600 border border-neutral-200">
                            Prov: {article.supplier}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-3 py-3 text-neutral-600 font-medium">
                      {article.brand}
                    </td>
                    <td className="px-3 py-3 text-right font-mono text-neutral-500">
                      ${formatThousands(article.costPrice)}
                    </td>
                    <td className="px-3 py-3 text-right font-mono font-bold text-neutral-900">
                      ${formatThousands(article.salePrice)}
                    </td>
                    <td className="px-3 py-3 text-center">
                      <span className={`inline-block px-2 py-0.5 rounded font-mono font-bold text-xs ${
                        isOutOfStock
                          ? 'bg-rose-100 text-rose-700'
                          : isLowStock
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-50 text-emerald-700'
                      }`}>
                        {article.stock}
                      </span>
                    </td>
                    <td className="px-3 py-3 text-center font-mono text-neutral-400">
                      {article.minStock}
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1">
                        {canManage && (
                          <button
                            type="button"
                            onClick={() => handleOpenPriceUpdateForSingle(article)}
                            title="Modificar / Aumentar Precio (%)"
                            className="p-1.5 text-emerald-600 hover:text-emerald-800 hover:bg-emerald-50 rounded"
                          >
                            <Percent className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => {
                            setSearchTerm('');
                            openQuickStockAdjust(article);
                          }}
                          title="Ajustar Stock Rápido"
                          className="p-1.5 text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded"
                        >
                          <ArrowUpDown className="w-3.5 h-3.5" />
                        </button>
                        {canManage && (
                          <>
                            <button
                              type="button"
                              onClick={() => handleOpenEdit(article)}
                              title="Editar Artículo"
                              className="p-1.5 text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={async () => {
                                const ok = await DialogService.confirm(
                                  `¿Está seguro de eliminar el artículo "${article.name}"? Esta acción removerá el producto del catálogo.`,
                                  'Eliminar Artículo',
                                  'Sí, eliminar',
                                  'Cancelar',
                                  'error'
                                );
                                if (ok) {
                                  deleteArticle(article.id);
                                }
                              }}
                              title="Eliminar Artículo"
                              className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}

              {filteredArticles.length === 0 && (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-neutral-400">
                    No se encontraron artículos registrados con estos filtros.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE / EDIT ARTICLE MODAL */}
      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-start sm:items-center justify-center p-2 sm:p-4 overflow-y-auto overscroll-contain">
          <div className="my-auto bg-white dark:bg-neutral-900 rounded-2xl max-w-xl w-full overflow-hidden shadow-2xl border border-neutral-200 dark:border-neutral-700 max-h-[calc(100dvh-1rem)] sm:max-h-[calc(100dvh-2rem)] min-h-0 flex flex-col">
            <div className="p-4 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between bg-neutral-900 text-white flex-shrink-0">
              <div className="flex items-center gap-2">
                <Package className="w-5 h-5 text-emerald-400" />
                <div>
                  <h3 className="font-extrabold text-sm sm:text-base tracking-tight">
                    {editingArticle ? 'Editar Artículo' : 'Cargar Artículo al Catálogo'}
                  </h3>
                  <p className="text-[11px] text-neutral-400">
                    Apreta Enter para avanzar al siguiente campo automáticamente
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="p-1 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Continuous session feedback banner */}
            {lastSavedQuickArticle && (
              <div className="px-4 py-2 bg-emerald-50 dark:bg-emerald-950/60 border-b border-emerald-200 dark:border-emerald-800 flex items-center justify-between text-xs text-emerald-900 dark:text-emerald-200 animate-in fade-in">
                <div className="flex items-center gap-2 font-medium">
                  <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 flex-shrink-0" />
                  <span>
                    Guardado: <strong>{lastSavedQuickArticle}</strong>. Listo para escanear el siguiente.
                  </span>
                </div>
                <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded-full bg-emerald-200 dark:bg-emerald-900 text-emerald-950 dark:text-emerald-200">
                  {savedCountSession} guardados
                </span>
              </div>
            )}

            <form onSubmit={handleSaveAndContinue} className="p-4 sm:p-5 overflow-y-auto space-y-3.5 text-xs flex-1">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="col-span-1 sm:col-span-2">
                  <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1 flex items-center justify-between">
                    <span>1. Código de Barra (EAN-13 / Lector)</span>
                    <span className="text-[10px] text-neutral-400 font-normal lowercase">(Enter = siguiente)</span>
                  </label>
                  <div className="relative">
                    <Barcode className="absolute left-3 top-2.5 w-4 h-4 text-neutral-400" />
                    <input
                      ref={barcodeInputRef}
                      type="text"
                      required
                      autoFocus
                      value={formData.barcode}
                      onChange={(e) => setFormData({ ...formData, barcode: e.target.value })}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          nameInputRef.current?.focus();
                          nameInputRef.current?.select();
                        }
                      }}
                      placeholder="Escanear o escribir código de barra..."
                      className="w-full pl-9 pr-3 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl text-xs font-mono font-bold text-neutral-950 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="col-span-1 sm:col-span-2">
                  <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                    2. Nombre / Descripción del Artículo
                  </label>
                  <input
                    ref={nameInputRef}
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => {
                      const input = e.target;
                      const start = input.selectionStart;
                      const end = input.selectionEnd;
                      const val = toTitleCase(input.value);
                      setFormData({ ...formData, name: val });
                      if (start !== null && end !== null) {
                        requestAnimationFrame(() => {
                          input.setSelectionRange(start, end);
                        });
                      }
                    }}
                    onKeyDown={(e) => {
                      const now = Date.now();

                      // Si acabamos de detectar un escaneo, bloquear el resto de esa ráfaga,
                      // incluido el Enter final que normalmente envía el lector.
                      if (now < rejectNameScannerUntilRef.current) {
                        e.preventDefault();
                        if (e.key === 'Enter') rejectNameScannerUntilRef.current = 0;
                        setFormData((prev) => ({ ...prev, name: '' }));
                        if (nameInputRef.current) nameInputRef.current.value = '';
                        return;
                      }

                      if (e.key.length === 1 && /^[0-9]$/.test(e.key)) {
                        const recent = [...nameKeyTimesRef.current, now].filter((time) => now - time <= 180);
                        nameKeyTimesRef.current = recent;
                        // Seis dígitos en 180 ms es una ráfaga típica de un lector, no escritura manual.
                        if (recent.length >= 6 && now - recent[0] <= 180) {
                          e.preventDefault();
                          rejectNameScannerUntilRef.current = now + 700;
                          nameKeyTimesRef.current = [];
                          setFormData((prev) => ({ ...prev, name: '' }));
                          if (nameInputRef.current) nameInputRef.current.value = '';
                          return;
                        }
                      } else if (e.key.length === 1) {
                        nameKeyTimesRef.current = [];
                      }

                      if (e.key === 'Enter') {
                        e.preventDefault();
                        nameKeyTimesRef.current = [];
                        brandInputRef.current?.focus();
                        brandInputRef.current?.select();
                      }
                    }}
                    placeholder="Escribí manualmente el nombre del artículo..."
                    className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl text-xs font-bold text-neutral-950 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                {/* Marca */}
                <div ref={brandContainerRef} className="relative">
                  <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                    3. Marca
                  </label>
                  <div className="relative">
                    <input
                      ref={brandInputRef}
                      type="text"
                      value={formData.brand}
                      onFocus={() => {
                        if (existingBrands.length > 0) {
                          setShowBrandSuggestions(true);
                        }
                      }}
                      onChange={(e) => {
                        const input = e.target;
                        const start = input.selectionStart;
                        const end = input.selectionEnd;
                        const val = toTitleCase(input.value);
                        setFormData({ ...formData, brand: val });
                        setShowBrandSuggestions(true);
                        if (start !== null && end !== null) {
                          requestAnimationFrame(() => {
                            input.setSelectionRange(start, end);
                          });
                        }
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                          if (matchingBrands.length > 0) {
                            e.preventDefault();
                            setShowBrandSuggestions(true);
                            setBrandSuggestionIndex((current) => e.key === 'ArrowDown'
                              ? (current + 1) % matchingBrands.length
                              : (current - 1 + matchingBrands.length) % matchingBrands.length);
                          }
                        } else if (e.key === 'Enter') {
                          e.preventDefault();
                          if (showBrandSuggestions && matchingBrands.length > 0) {
                            const selected = matchingBrands[Math.min(brandSuggestionIndex, matchingBrands.length - 1)];
                            setFormData((current) => ({ ...current, brand: selected }));
                            setShowBrandSuggestions(false);
                          }
                          categoryInputRef.current?.focus();
                          categoryInputRef.current?.select();
                        }
                      }}
                      placeholder="Ej: Playadito"
                      className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl text-xs font-medium text-neutral-950 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  {showBrandSuggestions && matchingBrands.length > 0 && (
                    <div className="absolute left-0 right-0 mt-1 max-h-40 overflow-y-auto bg-white dark:bg-neutral-800 rounded-lg shadow-xl border border-neutral-200 dark:border-neutral-700 z-50 py-1 text-xs divide-y divide-neutral-50 dark:divide-neutral-700">
                      <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-neutral-400 bg-neutral-50 dark:bg-neutral-900">
                        Marcas Existentes
                      </div>
                      {matchingBrands.map((b) => (
                        <button
                          key={b}
                          type="button"
                          onClick={() => {
                            setFormData({ ...formData, brand: b });
                            setShowBrandSuggestions(false);
                            categoryInputRef.current?.focus();
                          }}
                          className={`w-full text-left px-3 py-1.5 hover:bg-neutral-100 dark:hover:bg-neutral-700 flex items-center justify-between text-neutral-800 dark:text-neutral-200 transition-colors ${brandSuggestionIndex === matchingBrands.indexOf(b) ? 'bg-emerald-100 dark:bg-emerald-900/40' : ''}`}
                        >
                          <span className="font-medium">{b}</span>
                          <span className="text-[10px] text-neutral-400">Seleccionar</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Categoría */}
                <div ref={categoryContainerRef} className="relative">
                  <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                    4. Categoría
                  </label>
                  <div className="relative">
                    <input
                      ref={categoryInputRef}
                      type="text"
                      value={formData.category}
                      onClick={() => setShowCategoryDropdown(true)}
                      onFocus={() => setShowCategoryDropdown(true)}
                      onChange={(e) => {
                        setFormData({ ...formData, category: e.target.value });
                        setShowCategoryDropdown(true);
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                          if (matchingCategories.length > 0) {
                            e.preventDefault();
                            setShowCategoryDropdown(true);
                            setCategorySuggestionIndex((current) => e.key === 'ArrowDown'
                              ? (current + 1) % matchingCategories.length
                              : (current - 1 + matchingCategories.length) % matchingCategories.length);
                          }
                        } else if (e.key === 'Enter') {
                          e.preventDefault();
                          if (showCategoryDropdown && matchingCategories.length > 0) {
                            const selected = matchingCategories[Math.min(categorySuggestionIndex, matchingCategories.length - 1)];
                            setFormData((current) => ({ ...current, category: selected }));
                            setShowCategoryDropdown(false);
                          }
                          subcategoryInputRef.current?.focus();
                          subcategoryInputRef.current?.select();
                        }
                      }}
                      placeholder="Seleccionar o escribir categoría..."
                      className="w-full px-3 pr-8 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl text-xs font-medium text-neutral-950 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                    />
                    <button
                      type="button"
                      tabIndex={-1}
                      onClick={() => setShowCategoryDropdown(!showCategoryDropdown)}
                      className="absolute right-2 top-2.5 text-neutral-400 hover:text-neutral-700 p-0.5"
                    >
                      <ChevronDown className="w-4 h-4" />
                    </button>
                  </div>

                  {showCategoryDropdown && (
                    <div className="absolute left-0 right-0 mt-1 max-h-48 overflow-y-auto bg-white dark:bg-neutral-800 rounded-lg shadow-xl border border-neutral-200 dark:border-neutral-700 z-50 py-1 text-xs divide-y divide-neutral-50 dark:divide-neutral-700">
                      <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-neutral-400 bg-neutral-50 dark:bg-neutral-900 flex items-center justify-between">
                        <span>Categorías ({matchingCategories.length})</span>
                        <span className="text-[9px] font-normal lowercase">Filtrar por letra</span>
                      </div>
                      {matchingCategories.length > 0 ? (
                        matchingCategories.map((cat) => (
                          <button
                            key={cat}
                            type="button"
                            onClick={() => {
                              setFormData({ ...formData, category: cat });
                              setShowCategoryDropdown(false);
                              subcategoryInputRef.current?.focus();
                            }}
                            className={`w-full text-left px-3 py-1.5 hover:bg-neutral-100 dark:hover:bg-neutral-700 flex items-center justify-between transition-colors ${
                              categorySuggestionIndex === matchingCategories.indexOf(cat) ? 'bg-emerald-100 dark:bg-emerald-900/40' : ''
                            } ${
                              formData.category.toLowerCase() === cat.toLowerCase()
                                ? 'bg-neutral-100 dark:bg-neutral-700 font-bold text-neutral-900 dark:text-white'
                                : 'text-neutral-700 dark:text-neutral-300'
                            }`}
                          >
                            <span>{cat}</span>
                            {formData.category.toLowerCase() === cat.toLowerCase() && (
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                            )}
                          </button>
                        ))
                      ) : (
                        <div className="px-3 py-2 text-neutral-500 italic text-[11px]">
                          Escribiendo nueva categoría: "{formData.category}"
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Subcategoría */}
                <div>
                  <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                    5. Subcategoría (Opcional)
                  </label>
                  <input
                    ref={subcategoryInputRef}
                    type="text"
                    list="subcategories-datalist"
                    value={formData.subcategory || ''}
                    onChange={(e) => setFormData({ ...formData, subcategory: e.target.value })}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        supplierInputRef.current?.focus();
                        supplierInputRef.current?.select();
                      }
                    }}
                    placeholder="Ej: Yerbas, Gaseosas, Galletitas..."
                    className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl text-xs text-neutral-950 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  />
                  <datalist id="subcategories-datalist">
                    {existingSubcategories.slice(0, 40).map(sub => (
                      <option key={sub} value={sub} />
                    ))}
                  </datalist>
                </div>

                {/* Proveedor */}
                <div>
                  <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                    6. Proveedor
                  </label>
                  <input
                    ref={supplierInputRef}
                    type="text"
                    list="suppliers-datalist"
                    value={formData.supplier || ''}
                    onChange={(e) => setFormData({ ...formData, supplier: e.target.value })}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        costPriceInputRef.current?.focus();
                        costPriceInputRef.current?.select();
                      }
                    }}
                    placeholder="Seleccionar o escribir proveedor..."
                    className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl text-xs text-neutral-950 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  />
                  <datalist id="suppliers-datalist">
                    {suppliers.slice(0, 40).map(sup => (
                      <option key={sup} value={sup} />
                    ))}
                  </datalist>
                </div>

                {/* Precio de Costo */}
                <div>
                  <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                    7. Precio de Costo ($)
                  </label>
                  <input
                    ref={costPriceInputRef}
                    type="text"
                    inputMode="decimal"
                    value={costPriceStr}
                    onChange={(e) => handlePriceChange('costPrice', e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        salePriceInputRef.current?.focus();
                        salePriceInputRef.current?.select();
                      }
                    }}
                    placeholder="0"
                    className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl text-xs font-mono font-bold text-neutral-950 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                {/* Opciones de IVA y ganancia */}
                <div className="col-span-1 sm:col-span-2 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800/60 p-3 space-y-3">
                  <p className="text-[11px] font-extrabold uppercase tracking-wide text-neutral-700 dark:text-neutral-200">Cálculos opcionales de precios</p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="rounded-lg bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 p-2.5 space-y-2">
                      <label className="flex items-center justify-between gap-2 text-[11px] font-bold text-neutral-700 dark:text-neutral-200">IVA del costo
                        <input type="checkbox" checked={applyCostVat} onChange={(e) => setApplyCostVat(e.target.checked)} className="h-4 w-4 accent-emerald-600" />
                      </label>
                      <div className="flex items-center gap-1.5">
                        <input aria-label="Porcentaje de IVA del costo" type="number" min="0" max="100" step="0.1" disabled={!applyCostVat} value={costVatPercent} onChange={(e) => setCostVatPercent(e.target.value)} className="w-full min-w-0 px-2 py-1.5 border border-neutral-300 dark:border-neutral-600 rounded-md bg-white dark:bg-neutral-800 disabled:opacity-40" />
                        <span className="text-neutral-500">%</span>
                      </div>
                    </div>
                    <div className="rounded-lg bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 p-2.5 space-y-2">
                      <label className="flex items-center justify-between gap-2 text-[11px] font-bold text-neutral-700 dark:text-neutral-200">IVA venta
                        <input type="checkbox" checked={applySaleVat} onChange={(e) => setApplySaleVat(e.target.checked)} className="h-4 w-4 accent-emerald-600" />
                      </label>
                      <div className="flex items-center gap-1.5">
                        <input aria-label="Porcentaje de IVA del precio de venta" type="number" min="0" max="100" step="0.1" disabled={!applySaleVat} value={saleVatPercent} onChange={(e) => setSaleVatPercent(e.target.value)} className="w-full min-w-0 px-2 py-1.5 border border-neutral-300 dark:border-neutral-600 rounded-md bg-white dark:bg-neutral-800 disabled:opacity-40" />
                        <span className="text-neutral-500">%</span>
                      </div>
                    </div>
                    <div className="rounded-lg bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 p-2.5 space-y-2">
                      <label className="flex items-center justify-between gap-2 text-[11px] font-bold text-neutral-700 dark:text-neutral-200">Ganancia
                        <input type="checkbox" checked={applyProfitMargin} onChange={(e) => setApplyProfitMargin(e.target.checked)} className="h-4 w-4 accent-emerald-600" />
                      </label>
                      <div className="flex items-center gap-1.5">
                        <input aria-label="Porcentaje de ganancia" type="number" min="0" max="1000" step="0.1" disabled={!applyProfitMargin} value={profitPercent} onChange={(e) => setProfitPercent(e.target.value)} className="w-full min-w-0 px-2 py-1.5 border border-neutral-300 dark:border-neutral-600 rounded-md bg-white dark:bg-neutral-800 disabled:opacity-40" />
                        <span className="text-neutral-500">%</span>
                      </div>
                    </div>
                  </div>
                  <p className="text-[10px] text-neutral-500 dark:text-neutral-400">Si se activa IVA del costo, se suma al costo ingresado. La ganancia calcula el precio de venta a partir del costo resultante; el IVA de venta se suma al precio calculado o ingresado. Las opciones empiezan desactivadas.</p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 rounded-lg border border-emerald-200 dark:border-emerald-900 bg-emerald-50/70 dark:bg-emerald-950/30 p-3">
                    <div>
                      <p className="text-[10px] uppercase font-bold text-neutral-600 dark:text-neutral-300">Costo calculado</p>
                      <p className="text-sm font-black text-neutral-900 dark:text-white">${formatThousands(costFinalPreview)}</p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase font-bold text-neutral-600 dark:text-neutral-300">Venta calculada</p>
                      <p className="text-sm font-black text-emerald-700 dark:text-emerald-400">${formatThousands(saleFinalPreview)}</p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase font-bold text-neutral-600 dark:text-neutral-300">Ganancia estimada</p>
                      <p className="text-sm font-black text-neutral-900 dark:text-white">${formatThousands(Math.round(profitAmountPreview))} ({profitPercentPreview.toFixed(1)}%)</p>
                    </div>
                  </div>
                </div>

                {/* Precio de Venta */}
                <div>
                  <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                    8. Precio de Venta ($)
                  </label>
                  <input
                    ref={salePriceInputRef}
                    type="text"
                    inputMode="decimal"
                    required
                    disabled={applyProfitMargin || applySaleVat}
                    value={applyProfitMargin || applySaleVat ? formatThousands(saleFinalPreview) : salePriceStr}
                    onChange={(e) => handlePriceChange('salePrice', e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        stockInputRef.current?.focus();
                        stockInputRef.current?.select();
                      }
                    }}
                    placeholder="0"
                    className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-emerald-500 dark:border-emerald-500 rounded-xl text-xs font-mono font-black text-emerald-700 dark:text-emerald-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed"
                  />
                </div>

                {/* Stock Actual */}
                <div>
                  <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                    9. Stock Actual (Unidades)
                  </label>
                  <input
                    ref={stockInputRef}
                    type="text"
                    inputMode="numeric"
                    value={stockStr}
                    onChange={(e) => handleStockChange('stock', e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        minStockInputRef.current?.focus();
                        minStockInputRef.current?.select();
                      }
                    }}
                    placeholder="0"
                    className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl text-xs font-mono font-bold text-neutral-950 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                {/* Stock Mínimo (Alerta) */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-[11px] font-black text-neutral-900 dark:text-white uppercase">
                      10. Stock Mínimo (Alerta)
                    </label>
                    <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                      Enter ↵ = Guardar y Siguiente
                    </span>
                  </div>
                  <input
                    ref={minStockInputRef}
                    type="text"
                    inputMode="numeric"
                    value={minStockStr}
                    onChange={(e) => handleStockChange('minStock', e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleSaveAndContinue();
                      }
                    }}
                    placeholder="0"
                    className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-amber-400 dark:border-amber-500 rounded-xl text-xs font-mono font-bold text-neutral-950 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 sm:pt-4 border-t border-neutral-200 dark:border-neutral-700 flex flex-col sm:flex-row items-center justify-between gap-2.5">
                <div className="text-[11px] text-neutral-500 dark:text-neutral-400 font-medium text-center sm:text-left">
                  {savedCountSession > 0 ? (
                    <span>Llevas <strong>{savedCountSession}</strong> artículo(s) ingresados en esta sesión</span>
                  ) : (
                    <span>Al apretar Enter en Stock Mínimo se guarda y abre el siguiente</span>
                  )}
                </div>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="px-3.5 py-2 border-2 border-neutral-300 dark:border-neutral-600 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-xl text-neutral-700 dark:text-neutral-300 font-bold transition-colors order-last sm:order-first"
                  >
                    Cancelar
                  </button>

                  <div className="flex flex-col gap-2 w-full sm:w-auto">
                    <button
                      type="button"
                      onClick={() => handleSaveAndContinue()}
                      className="w-full sm:w-auto px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-xl font-black uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer"
                      title="Guarda este artículo y deja la ventana lista para escanear el siguiente"
                    >
                      <Plus className="w-4 h-4" />
                      Guardar y Cargar Siguiente
                    </button>

                    <button
                      type="button"
                      onClick={handleSaveAndFinish}
                      className="w-full sm:w-auto px-4 py-2 bg-neutral-900 hover:bg-neutral-800 active:scale-95 text-white rounded-xl font-black uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer"
                      title="Guarda este artículo y finaliza cerrando la ventana"
                    >
                      <Check className="w-4 h-4 text-emerald-400" />
                      Guardar y Finalizar
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* QUICK ADJUST STOCK MODAL */}
      {adjustModalArticle && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-start sm:items-center justify-center p-2 sm:p-4 overflow-y-auto overscroll-contain">
          <div className="my-auto bg-white rounded-xl max-w-sm w-full overflow-hidden shadow-2xl border border-neutral-200 max-h-[calc(100dvh-1rem)] overflow-y-auto">
            <div className="p-4 border-b border-neutral-100 flex items-center justify-between bg-neutral-50">
              <h3 className="font-bold text-xs text-neutral-900">Ajuste Manual de Stock</h3>
              <button
                type="button"
                onClick={closeQuickStockAdjust}
                className="text-neutral-400 hover:text-neutral-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleStockAdjustment} className="p-4 space-y-3 text-xs">
              <p className="font-semibold text-neutral-800">
                {adjustModalArticle.name}
              </p>
              <div className="text-neutral-500">
                Stock actual: <strong className="font-mono text-neutral-900">{adjustModalArticle.stock}</strong>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                  Cantidad a sumar (+) o restar (-)
                </label>
                <input
                  ref={adjustAmountInputRef}
                  type="text"
                  inputMode="numeric"
                  value={adjustAmountStr}
                  onChange={(e) => {
                    const val = e.target.value.replace(/[^0-9\-]/g, '');
                    if (val.indexOf('-') > 0) return;
                    if ((val.match(/-/g) || []).length > 1) return;
                    setAdjustAmountStr(val);
                  }}
                  placeholder="Ej: 5 para sumar, -2 para restar"
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg font-mono text-xs focus:ring-2 focus:ring-neutral-900"
                  autoFocus
                />
              </div>

              <div className="p-2 bg-neutral-50 rounded border border-neutral-200 flex justify-between">
                <span>Nuevo stock estimado:</span>
                <strong className="font-mono text-neutral-900">
                  {Math.max(0, adjustModalArticle.stock + (adjustAmountStr === '' || adjustAmountStr === '-' ? 0 : parseInt(adjustAmountStr, 10) || 0))}
                </strong>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={closeQuickStockAdjust}
                  className="px-3 py-1.5 border border-neutral-300 rounded text-xs"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-neutral-900 text-white rounded text-xs font-bold"
                >
                  Confirmar Ajuste
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* PRICE UPDATE / AUMENTO DE PRECIOS MODAL */}
      {showPriceUpdateModal && (
        <PriceUpdateModal
          isOpen={showPriceUpdateModal}
          onClose={() => setShowPriceUpdateModal(false)}
          articles={articles}
          suppliers={suppliers}
          categories={existingCategories}
          subcategories={existingSubcategories}
          selectedArticleIds={selectedArticleIds}
          initialScope={priceUpdateScope}
          initialArticle={priceUpdateInitialArticle}
          onApply={handleApplyPriceUpdate}
        />
      )}

      {/* CATALOG IMPORT MODAL (CSV / EXCEL) */}
      {importModalMode !== null && (
        <CatalogImportModal
          isOpen={true}
          mode={importModalMode}
          onClose={() => setImportModalMode(null)}
          onImportComplete={(count) => {
            DialogService.alert(`¡Se importaron ${formatThousands(count)} artículos al catálogo exitosamente!`, 'Importación Completada', 'success');
          }}
        />
      )}
    </div>
  );
};
