import React, { useState, useRef, useMemo } from 'react';
import { 
  X, 
  Upload, 
  FileText, 
  FileSpreadsheet, 
  Check, 
  AlertCircle, 
  CheckCircle2, 
  RefreshCw, 
  ArrowRight,
  Database,
  Layers,
  Sparkles,
  Sliders,
  Trash2
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { Article, CurrentAccount } from '../../types';
import { StorageService } from '../../services/storage';
import { CloudSync } from '../../services/cloudSync';
import { formatThousands } from '../../utils/text';

interface CatalogImportModalProps {
  isOpen: boolean;
  mode: 'CSV' | 'EXCEL' | null;
  onClose: () => void;
  onImportComplete: (count: number) => void;
}

interface ColumnMapping {
  barcode: string;
  name: string;
  brand: string;
  category: string;
  costPrice: string;
  salePrice: string;
  stock: string;
  minStock: string;
  supplier: string;
}

interface ParsedArticleCandidate {
  barcode: string;
  name: string;
  brand: string;
  category: string;
  costPrice: number;
  salePrice: number;
  stock: number;
  stockProvided: boolean;
  minStock: number;
  supplier: string;
  unit: string;
}

// Cleans header names from DBF format:
// "CODIGO,C,13" -> "CODIGO"
// "DETALLE,C,80" -> "DETALLE"
// "PRECIOVP,N,15,4" -> "PRECIOVP"
// "STEXISTEN,N,10,4" -> "STEXISTEN"
export function cleanHeaderKey(raw: string): string {
  if (!raw) return '';
  let s = String(raw).replace(/^\uFEFF/, '').replace(/["']/g, '').trim();
  // Strip DBF field specifications after comma or parenthesis
  s = s.split(/[,(]/)[0].trim();
  return s.toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Z0-9]/g, '');
}

export const CatalogImportModal: React.FC<CatalogImportModalProps> = ({
  isOpen,
  mode,
  onClose,
  onImportComplete,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isParsing, setIsParsing] = useState(false);
  const [parseError, setParseError] = useState<string | null>(null);
  const [detectedColumns, setDetectedColumns] = useState<string[]>([]);
  const [rawRowsData, setRawRowsData] = useState<any[]>([]);
  const [columnMapping, setColumnMapping] = useState<ColumnMapping>({
    barcode: '',
    name: '',
    brand: '',
    category: '',
    costPrice: '',
    salePrice: '',
    stock: '',
    minStock: '',
    supplier: '',
  });
  const [showColumnConfig, setShowColumnConfig] = useState(false);
  const [importStrategy, setImportStrategy] = useState<'REPLACE' | 'MERGE'>('REPLACE');
  const [isImporting, setIsImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);

  // Check if current database has dummy generic articles (GEN-...)
  const currentGenericCount = useMemo(() => {
    try {
      return StorageService.getArticles().filter(a => a.barcode.startsWith('GEN-')).length;
    } catch {
      return 0;
    }
  }, [isOpen]);

  // Flexible number parser for Argentine & DBF decimal formats (e.g. "1500,40", "1500.4000", "$ 1200")
  const parseFlexibleNumber = (val: any): number => {
    if (typeof val === 'number') {
      return isNaN(val) ? 0 : val;
    }
    if (!val) return 0;
    const str = String(val).trim().replace(/[$ \t\r\n]/g, '');
    if (!str) return 0;

    if (str.includes(',') && str.includes('.')) {
      if (str.indexOf('.') < str.indexOf(',')) {
        // e.g. "1.500,50"
        const normalized = str.replace(/\./g, '').replace(',', '.');
        const num = parseFloat(normalized);
        return isNaN(num) ? 0 : num;
      } else {
        // e.g. "1,500.50"
        const normalized = str.replace(/,/g, '');
        const num = parseFloat(normalized);
        return isNaN(num) ? 0 : num;
      }
    } else if (str.includes(',')) {
      const normalized = str.replace(',', '.');
      const num = parseFloat(normalized);
      return isNaN(num) ? 0 : num;
    } else {
      const num = parseFloat(str);
      return isNaN(num) ? 0 : num;
    }
  };

  // Detects the optimal column mapping from raw table keys
  const autoDetectMapping = (keys: string[]): ColumnMapping => {
    const mapping: ColumnMapping = {
      barcode: '',
      name: '',
      brand: '',
      category: '',
      costPrice: '',
      salePrice: '',
      stock: '',
      minStock: '',
      supplier: '',
    };

    for (const rawKey of keys) {
      const norm = cleanHeaderKey(rawKey);

      // Barcode / Código (CODIGO, CODIGO,C,13, BARCODE, COD_BARRA, etc.)
      if (!mapping.barcode && (
        norm.startsWith('CODIGO') || norm.startsWith('BARCODE') || norm.startsWith('CODBARRA') ||
        norm === 'COD' || norm === 'ID' || norm === 'ARTICULO' || norm === 'REFERENCIA' || norm === 'EAN'
      )) {
        mapping.barcode = rawKey;
      }

      // Detalle / Nombre / Descripción (DETALLE, DETALLE,C,80, DESCRIPCION, etc.)
      if (!mapping.name && (
        norm.startsWith('DETALLE') || norm.startsWith('DESCRIP') || norm.startsWith('NOMBRE') ||
        norm.startsWith('PRODUCTO') || norm.startsWith('ARTICULO') || norm === 'DESC' || norm === 'TITULO'
      )) {
        mapping.name = rawKey;
      }

      // Marca (MARCA, MARCA,C,30, BRAND, FABRICANTE)
      if (!mapping.brand && (
        norm.startsWith('MARCA') || norm.startsWith('BRAND') || norm.startsWith('FABRICANTE') || norm.startsWith('LINEA')
      )) {
        mapping.brand = rawKey;
      }

      // Rubro / Categoría (RUBRO, RUBRO,C,20, CATEGORIA, etc.)
      if (!mapping.category && (
        norm.startsWith('RUBRO') || norm.startsWith('CATEGORIA') || norm.startsWith('GRUPO') ||
        norm.startsWith('SECCION') || norm.startsWith('FAMILIA') || norm.startsWith('DEPTO')
      )) {
        mapping.category = rawKey;
      }

      // Stock Existente (STEXISTEN, STEXISTEN,N,10,4, STOCK, EXISTENCIA, CANTIDAD)
      if (!mapping.stock && (
        norm.startsWith('STEXISTEN') || norm.startsWith('STOCK') || norm.startsWith('EXISTEN') ||
        norm.startsWith('CANTIDAD') || norm === 'ACTUAL' || norm === 'UNIDADES' || norm === 'STK'
      )) {
        mapping.stock = rawKey;
      }

      // Stock Mínimo (STMINIMO, STMINIMO,N,10,4, MINIMO, STKMIN)
      if (!mapping.minStock && (
        norm.startsWith('STMINIMO') || norm.startsWith('MINIMO') || norm === 'STKMIN' || norm === 'MIN'
      )) {
        mapping.minStock = rawKey;
      }

      // Precio Costo (PRECIOC, PRECIOC,N,15,4, COSTO, PRECIOCOSTO, COMPRA)
      if (!mapping.costPrice && (
        norm.startsWith('PRECIOC') || norm.startsWith('COSTO') || norm.startsWith('PCOSTO') ||
        norm.startsWith('COMPRA') || norm.startsWith('PRECIOCOMPRA') || norm === 'COST'
      )) {
        mapping.costPrice = rawKey;
      }

      // Precio Venta (PRECIOVP, PRECIOVP,N,15,4, PRECIOVENTA, PVENTA, PVP, PRECIO)
      if (!mapping.salePrice && (
        norm.startsWith('PRECIOVP') || norm.startsWith('PRECIOVENTA') || norm.startsWith('PVENTA') ||
        norm.startsWith('PVP') || norm === 'PRECIO' || norm === 'VENTA' || norm === 'PRICE' || norm === 'PRECIO1'
      )) {
        mapping.salePrice = rawKey;
      }

      // Proveedor (PROVEEDOR, PROVEEDOR,C,20, PROVEE, SUPPLIER)
      if (!mapping.supplier && (
        norm.startsWith('PROVEEDOR') || norm.startsWith('PROVEE') || norm.startsWith('PROV') ||
        norm.startsWith('SUPPLIER') || norm.startsWith('DISTRIBUIDOR')
      )) {
        mapping.supplier = rawKey;
      }
    }

    // Smart fallback if name or barcode weren't strictly named
    if (!mapping.barcode && keys.length > 0) {
      // First column is frequently the code
      mapping.barcode = keys[0];
    }
    if (!mapping.name && keys.length > 1) {
      // Second column is frequently the description/detail
      mapping.name = keys[1];
    }

    return mapping;
  };

  const processLoadedRows = (rows: any[]) => {
    if (!rows || rows.length === 0) {
      throw new Error('El archivo no contiene filas de datos.');
    }

    // Inspect first row to get keys
    const firstRow = rows[0];
    const keys = Object.keys(firstRow).filter(k => k && !k.startsWith('__EMPTY'));
    if (keys.length === 0) {
      // If keys are __EMPTY, check second row
      const allKeys = Object.keys(firstRow);
      setDetectedColumns(allKeys);
      setRawRowsData(rows);
      const initialMap = autoDetectMapping(allKeys);
      setColumnMapping(initialMap);
      return;
    }

    setDetectedColumns(keys);
    setRawRowsData(rows);
    const initialMap = autoDetectMapping(keys);
    setColumnMapping(initialMap);
  };

  // Convert raw rows using current column mapping
  const parsedItems: ParsedArticleCandidate[] = useMemo(() => {
    if (rawRowsData.length === 0) return [];

    const result: ParsedArticleCandidate[] = [];
    const len = rawRowsData.length;

    for (let i = 0; i < len; i++) {
      const row = rawRowsData[i];

      const rawBarcode = columnMapping.barcode ? String(row[columnMapping.barcode] ?? '').trim() : '';
      const rawName = columnMapping.name ? String(row[columnMapping.name] ?? '').trim() : '';

      // Skip completely empty lines
      if (!rawBarcode && !rawName) continue;

      const barcode = rawBarcode || `ART-${(i + 1).toString().padStart(6, '0')}`;
      const name = rawName || `Artículo ${barcode}`;
      const brand = columnMapping.brand ? String(row[columnMapping.brand] ?? '').trim() : 'General';
      const category = columnMapping.category ? String(row[columnMapping.category] ?? '').trim().toUpperCase() : 'ALMACEN';
      const supplier = columnMapping.supplier ? String(row[columnMapping.supplier] ?? '').trim() : 'General';

      const costPrice = columnMapping.costPrice ? parseFlexibleNumber(row[columnMapping.costPrice]) : 0;
      let salePrice = columnMapping.salePrice ? parseFlexibleNumber(row[columnMapping.salePrice]) : 0;

      // If sale price is 0 but cost is available, apply typical 35% margin
      if (salePrice <= 0 && costPrice > 0) {
        salePrice = Math.round(costPrice * 1.35);
      }

      const rawStock = columnMapping.stock ? String(row[columnMapping.stock] ?? '').trim() : '';
      const stockProvided = !!columnMapping.stock && rawStock !== '';
      const stock = stockProvided ? parseFlexibleNumber(rawStock) : 0;
      const minStock = columnMapping.minStock ? parseFlexibleNumber(row[columnMapping.minStock]) : 5;

      result.push({
        barcode,
        name,
        brand: brand || 'General',
        category: category || 'ALMACEN',
        costPrice,
        salePrice,
        stock,
        stockProvided,
        minStock,
        supplier: supplier || 'General',
        unit: 'u',
      });
    }

    return result;
  }, [rawRowsData, columnMapping]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSelectedFile(file);
    setIsParsing(true);
    setParseError(null);
    setRawRowsData([]);

    const reader = new FileReader();

    if (mode === 'EXCEL') {
      reader.onload = (evt) => {
        try {
          const buffer = evt.target?.result as ArrayBuffer;
          const workbook = XLSX.read(buffer, { type: 'array' });
          const sheetName = workbook.SheetNames[0];
          if (!sheetName) throw new Error('El archivo Excel no tiene hojas de datos.');
          const worksheet = workbook.Sheets[sheetName];
          const json = XLSX.utils.sheet_to_json(worksheet, { defval: '' });
          processLoadedRows(json);
        } catch (err: any) {
          setParseError(err.message || 'Error al procesar archivo de Excel.');
        } finally {
          setIsParsing(false);
        }
      };
      reader.onerror = () => {
        setParseError('Error al leer el archivo de Excel.');
        setIsParsing(false);
      };
      reader.readAsArrayBuffer(file);
    } else {
      // CSV: detecta UTF-8 (con o sin BOM) y archivos exportados desde Excel/Windows
      // que suelen venir en Windows-1252. Esto evita convertir ñ, tildes y símbolos en Ã±/Ã©.
      reader.onload = (evt) => {
        try {
          const buffer = evt.target?.result as ArrayBuffer;
          if (!(buffer instanceof ArrayBuffer) || buffer.byteLength === 0) {
            throw new Error('El archivo CSV está vacío.');
          }

          const bytes = new Uint8Array(buffer);
          let text: string;
          try {
            // El modo fatal permite detectar bytes que no forman una secuencia UTF-8 válida.
            text = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
          } catch {
            // Fallback habitual para CSV guardados con la codificación regional de Windows.
            text = new TextDecoder('windows-1252').decode(bytes);
          }
          // Quitar BOM explícitamente si el archivo lo trae.
          text = text.replace(/^\uFEFF/, '');
          if (!text.trim()) {
            throw new Error('El archivo CSV está vacío.');
          }

          // SheetJS detecta delimitadores comunes: punto y coma, coma y tabulación.
          const workbook = XLSX.read(text, { type: 'string' });
          const sheetName = workbook.SheetNames[0];
          if (!sheetName) throw new Error('El archivo CSV no contiene datos válidos.');
          const worksheet = workbook.Sheets[sheetName];
          const json = XLSX.utils.sheet_to_json(worksheet, { defval: '' });
          processLoadedRows(json);
        } catch (err: any) {
          setParseError(err.message || 'Error al procesar archivo CSV.');
        } finally {
          setIsParsing(false);
        }
      };
      reader.onerror = () => {
        setParseError('Error al leer el archivo CSV.');
        setIsParsing(false);
      };
      reader.readAsArrayBuffer(file);
    }
  };

  // Deletes previously created dummy generic articles (GEN-...)
  const handleCleanGenericArticles = () => {
    try {
      const all = StorageService.getArticles();
      const cleaned = all.filter(a => !a.barcode.startsWith('GEN-'));
      StorageService.saveArticles(cleaned);
      alert(`Se eliminaron los artículos genéricos con código GEN-...`);
      onImportComplete(cleaned.length);
    } catch (e: any) {
      alert('Error al limpiar artículos: ' + e.message);
    }
  };

  const handleExecuteImport = () => {
    if (parsedItems.length === 0) return;

    setIsImporting(true);
    setImportProgress(20);

    setTimeout(async () => {
      try {
        const existingArticles = StorageService.getArticles();
        const articleMap = new Map<string, Article>();

        if (importStrategy === 'MERGE') {
          // Keep existing articles, keyed by barcode
          for (const art of existingArticles) {
            // If barcode was a generic from earlier bug, don't keep it
            if (!art.barcode.startsWith('GEN-')) {
              articleMap.set(art.barcode.trim().toUpperCase(), art);
            }
          }
        }

        const now = new Date().toISOString();
        const detectedSuppliers = new Set<string>();

        // Process candidate articles
        for (let idx = 0; idx < parsedItems.length; idx++) {
          const cand = parsedItems[idx];
          const key = cand.barcode.trim().toUpperCase();
          const existing = articleMap.get(key);

          if (cand.supplier && cand.supplier !== 'General') {
            detectedSuppliers.add(cand.supplier);
          }

          if (existing && importStrategy === 'MERGE') {
            articleMap.set(key, {
              ...existing,
              name: cand.name || existing.name,
              brand: cand.brand || existing.brand,
              category: cand.category || existing.category,
              costPrice: cand.costPrice > 0 ? cand.costPrice : existing.costPrice,
              salePrice: cand.salePrice > 0 ? cand.salePrice : existing.salePrice,
              stock: cand.stockProvided ? cand.stock : existing.stock,
              minStock: cand.minStock,
              supplier: cand.supplier || existing.supplier,
              updatedAt: now,
            });
          } else {
            const newId = `art_${Date.now()}_${idx}`;
            articleMap.set(key, {
              id: newId,
              barcode: cand.barcode,
              name: cand.name,
              brand: cand.brand,
              category: cand.category,
              costPrice: cand.costPrice,
              salePrice: cand.salePrice,
              stock: cand.stockProvided ? cand.stock : 0,
              minStock: cand.minStock,
              unit: cand.unit || 'u',
              supplier: cand.supplier,
              updatedAt: now,
            });
          }
        }

        const finalArticles = Array.from(articleMap.values());
        StorageService.saveArticles(finalArticles);

        // En una importación, el stock explícito del archivo es un ajuste absoluto.
        // Para filas sin stock no se envía ajuste y se conserva el stock remoto vigente.
        const finalByBarcode = new Map<string, Article>(
          finalArticles.map(article => [String(article.barcode || '').trim().toUpperCase(), article] as const)
        );
        const stockOverridesById = new Map<string, number>();
        for (const cand of parsedItems) {
          if (!cand.stockProvided || !Number.isFinite(cand.stock)) continue;
          const target = finalByBarcode.get(cand.barcode.trim().toUpperCase());
          if (target) stockOverridesById.set(String(target.id), Math.max(0, cand.stock));
        }
        if (stockOverridesById.size > 0) {
          await CloudSync.publish('ARTICLES_UPDATED', {
            articles: finalArticles,
            stockOverrides: Array.from(stockOverridesById, ([articleId, stock]) => ({ articleId, stock })),
            reason: 'catalog-import',
          });
        }

        // Auto-register suppliers in Accounts
        try {
          const existingAccounts = StorageService.getAccounts();
          const existingSupplierNames = new Set(
            existingAccounts.filter(a => a.type === 'SUPPLIER').map(a => a.name.toLowerCase().trim())
          );

          const newAccounts: CurrentAccount[] = [...existingAccounts];
          detectedSuppliers.forEach(suppName => {
            if (!existingSupplierNames.has(suppName.toLowerCase().trim())) {
              newAccounts.push({
                id: `supp_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
                name: suppName,
                type: 'SUPPLIER',
                documentNumber: '',
                phone: '',
                creditLimit: 0,
                currentBalance: 0,
                updatedAt: now,
              });
              existingSupplierNames.add(suppName.toLowerCase().trim());
            }
          });

          if (newAccounts.length > existingAccounts.length) {
            StorageService.saveAccounts(newAccounts);
          }
        } catch (suppErr) {
          console.warn('Error syncing suppliers:', suppErr);
        }

        setImportProgress(100);
        onImportComplete(finalArticles.length);
        onClose();
      } catch (err: any) {
        setParseError('Error durante el guardado: ' + (err.message || 'Error desconocido'));
        setIsImporting(false);
      }
    }, 100);
  };

  if (!isOpen || !mode) return null;

  const isCsv = mode === 'CSV';

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white dark:bg-neutral-900 rounded-2xl max-w-4xl w-full max-h-[92vh] overflow-hidden shadow-2xl border border-neutral-200 dark:border-neutral-800 flex flex-col animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className={`p-4 text-white flex items-center justify-between ${
          isCsv ? 'bg-emerald-700' : 'bg-teal-700'
        }`}>
          <div className="flex items-center gap-2.5">
            {isCsv ? <FileText className="w-6 h-6" /> : <FileSpreadsheet className="w-6 h-6" />}
            <div>
              <h3 className="font-extrabold text-base tracking-tight flex items-center gap-2">
                <span>Importar Catálogo desde {isCsv ? 'CSV' : 'Excel'}</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-white/20 uppercase">
                  {isCsv ? '.csv' : '.xlsx / .xls'}
                </span>
              </h3>
              <p className="text-xs text-white/80">
                Compatible con bases de datos DBF (FoxPro/dBase), LibreOffice, Excel y proveedores
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-white/80 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4 text-xs text-neutral-800 dark:text-neutral-200 flex-1">
          {/* Notification if previous import generated dummy generic codes */}
          {currentGenericCount > 0 && (
            <div className="p-3.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700 rounded-xl flex items-center justify-between gap-3 text-amber-900 dark:text-amber-200">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0" />
                <span>
                  Hay <strong>{formatThousands(currentGenericCount)}</strong> artículos anteriores con códigos genéricos (GEN-...). Al importar con "Reemplazar Todo" se sustituirán por tus artículos limpios.
                </span>
              </div>
              <button
                type="button"
                onClick={handleCleanGenericArticles}
                className="px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold text-[11px] whitespace-nowrap cursor-pointer flex items-center gap-1.5 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Limpiar Genéricos Ahora</span>
              </button>
            </div>
          )}

          {/* File Upload Drop Area */}
          <div className="border-2 border-dashed border-neutral-300 dark:border-neutral-700 hover:border-emerald-500 rounded-2xl p-6 text-center bg-neutral-50 dark:bg-neutral-800/40 transition-colors">
            <input
              ref={fileInputRef}
              type="file"
              accept={isCsv ? '.csv,.txt' : '.xlsx,.xls'}
              onChange={handleFileChange}
              className="hidden"
            />

            <div className="flex flex-col items-center justify-center space-y-2">
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${
                isCsv ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-600' : 'bg-teal-100 dark:bg-teal-950 text-teal-600'
              }`}>
                {isCsv ? <FileText className="w-7 h-7" /> : <FileSpreadsheet className="w-7 h-7" />}
              </div>

              <div>
                <p className="font-bold text-sm text-neutral-800 dark:text-neutral-100">
                  {selectedFile ? selectedFile.name : `Selecciona tu archivo ${isCsv ? 'CSV (.csv)' : 'Excel (.xlsx)'}`}
                </p>
                <p className="text-neutral-500 text-xs mt-0.5">
                  {selectedFile 
                    ? `${(selectedFile.size / 1024).toFixed(1)} KB listos para importar`
                    : `Arrastra aquí el archivo o haz clic para buscarlo`}
                </p>
              </div>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isParsing || isImporting}
                className="mt-2 px-4 py-2 bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 rounded-xl font-bold uppercase tracking-wider text-xs hover:bg-neutral-800 dark:hover:bg-neutral-100 transition-colors shadow-xs cursor-pointer flex items-center gap-2"
              >
                <Upload className="w-4 h-4" />
                <span>{selectedFile ? 'Cambiar Archivo' : 'Examinar Archivo'}</span>
              </button>
            </div>
          </div>

          {/* Parsing Spinner */}
          {isParsing && (
            <div className="p-4 bg-neutral-100 dark:bg-neutral-800 rounded-xl flex items-center justify-center gap-3 text-neutral-700 dark:text-neutral-300">
              <RefreshCw className="w-5 h-5 animate-spin text-emerald-600" />
              <span className="font-semibold text-xs">Analizando columnas, precios y códigos de tu archivo...</span>
            </div>
          )}

          {/* Parse Error */}
          {parseError && (
            <div className="p-3.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl text-rose-700 dark:text-rose-300 flex items-start gap-2.5">
              <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5 text-rose-600" />
              <div>
                <strong className="block font-bold">No se pudo procesar el archivo</strong>
                <span>{parseError}</span>
              </div>
            </div>
          )}

          {/* Preview and Configuration when parsed */}
          {parsedItems.length > 0 && (
            <div className="space-y-4 animate-in fade-in">
              {/* Stats Card & Strategy */}
              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold flex-shrink-0">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-emerald-950 dark:text-emerald-100 text-sm">
                      {formatThousands(parsedItems.length)} artículos listos para ingresar
                    </h4>
                    <p className="text-[11px] text-emerald-700 dark:text-emerald-400">
                      Códigos reales detectados: <strong>{columnMapping.barcode || 'Ninguno'}</strong> | Nombres: <strong>{columnMapping.name || 'Ninguno'}</strong>
                    </p>
                  </div>
                </div>

                {/* Import Strategy Selector */}
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1.5 bg-white dark:bg-neutral-800 p-1 rounded-xl border border-emerald-300 dark:border-emerald-700">
                    <button
                      type="button"
                      onClick={() => setImportStrategy('REPLACE')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        importStrategy === 'REPLACE'
                          ? 'bg-rose-600 text-white shadow-xs'
                          : 'text-neutral-600 dark:text-neutral-400 hover:text-rose-600'
                      }`}
                      title="Limpia los artículos anteriores y carga este catálogo limpio y ordenado."
                    >
                      Reemplazar Todo (Limpio)
                    </button>
                    <button
                      type="button"
                      onClick={() => setImportStrategy('MERGE')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        importStrategy === 'MERGE'
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900'
                      }`}
                      title="Si el código ya existe actualiza precio y stock. Si no existe, lo agrega nuevo."
                    >
                      Sumar y Actualizar
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => setShowColumnConfig(prev => !prev)}
                    className="px-3 py-1.5 bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 hover:bg-neutral-100 rounded-xl text-xs font-bold text-neutral-700 dark:text-neutral-300 flex items-center gap-1.5 cursor-pointer shadow-2xs"
                  >
                    <Sliders className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{showColumnConfig ? 'Ocultar Columnas' : 'Ajustar Columnas'}</span>
                  </button>
                </div>
              </div>

              {/* Column Mapping Selectors (Auto-detected + Manual Override) */}
              {showColumnConfig && (
                <div className="p-4 bg-neutral-100 dark:bg-neutral-800/80 rounded-xl border border-neutral-200 dark:border-neutral-700 space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between border-b border-neutral-200 dark:border-neutral-700 pb-2">
                    <h5 className="font-extrabold text-xs text-neutral-900 dark:text-white flex items-center gap-2">
                      <Sliders className="w-4 h-4 text-emerald-600" />
                      <span>Asignación de Columnas de tu Archivo:</span>
                    </h5>
                    <span className="text-[11px] text-neutral-500">
                      Revisa que cada campo coincida con la columna correcta de tu base de datos
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                    {/* Código */}
                    <div>
                      <label className="block text-[11px] font-black text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                        Código de Barra / Artículo:
                      </label>
                      <select
                        value={columnMapping.barcode}
                        onChange={(e) => setColumnMapping({ ...columnMapping, barcode: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-lg text-xs font-mono font-bold text-neutral-900 dark:text-white"
                      >
                        <option value="">-- No asignar --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    {/* Detalle / Nombre */}
                    <div>
                      <label className="block text-[11px] font-black text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                        Detalle / Nombre del Producto:
                      </label>
                      <select
                        value={columnMapping.name}
                        onChange={(e) => setColumnMapping({ ...columnMapping, name: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-lg text-xs font-mono font-bold text-neutral-900 dark:text-white"
                      >
                        <option value="">-- No asignar --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    {/* Precio Venta */}
                    <div>
                      <label className="block text-[11px] font-black text-emerald-700 dark:text-emerald-400 uppercase mb-1">
                        Precio de Venta ($):
                      </label>
                      <select
                        value={columnMapping.salePrice}
                        onChange={(e) => setColumnMapping({ ...columnMapping, salePrice: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-neutral-900 border border-emerald-500 rounded-lg text-xs font-mono font-bold text-neutral-900 dark:text-white"
                      >
                        <option value="">-- No asignar --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    {/* Precio Costo */}
                    <div>
                      <label className="block text-[11px] font-black text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                        Precio de Costo ($):
                      </label>
                      <select
                        value={columnMapping.costPrice}
                        onChange={(e) => setColumnMapping({ ...columnMapping, costPrice: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-lg text-xs font-mono font-bold text-neutral-900 dark:text-white"
                      >
                        <option value="">-- No asignar --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    {/* Stock Existente */}
                    <div>
                      <label className="block text-[11px] font-black text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                        Stock Existente (Cantidad):
                      </label>
                      <select
                        value={columnMapping.stock}
                        onChange={(e) => setColumnMapping({ ...columnMapping, stock: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-lg text-xs font-mono font-bold text-neutral-900 dark:text-white"
                      >
                        <option value="">-- No asignar --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    {/* Stock Mínimo */}
                    <div>
                      <label className="block text-[11px] font-black text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                        Stock Mínimo (Alerta):
                      </label>
                      <select
                        value={columnMapping.minStock}
                        onChange={(e) => setColumnMapping({ ...columnMapping, minStock: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-lg text-xs font-mono font-bold text-neutral-900 dark:text-white"
                      >
                        <option value="">-- No asignar --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    {/* Marca */}
                    <div>
                      <label className="block text-[11px] font-black text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                        Marca:
                      </label>
                      <select
                        value={columnMapping.brand}
                        onChange={(e) => setColumnMapping({ ...columnMapping, brand: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-lg text-xs font-mono font-bold text-neutral-900 dark:text-white"
                      >
                        <option value="">-- No asignar --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    {/* Rubro / Categoría */}
                    <div>
                      <label className="block text-[11px] font-black text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                        Rubro / Categoría:
                      </label>
                      <select
                        value={columnMapping.category}
                        onChange={(e) => setColumnMapping({ ...columnMapping, category: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-lg text-xs font-mono font-bold text-neutral-900 dark:text-white"
                      >
                        <option value="">-- No asignar --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    {/* Proveedor */}
                    <div>
                      <label className="block text-[11px] font-black text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                        Proveedor:
                      </label>
                      <select
                        value={columnMapping.supplier}
                        onChange={(e) => setColumnMapping({ ...columnMapping, supplier: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-lg text-xs font-mono font-bold text-neutral-900 dark:text-white"
                      >
                        <option value="">-- No asignar --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* Data Preview Table */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-bold text-xs text-neutral-700 dark:text-neutral-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Vista Previa con Datos Reales (primeras 5 filas):</span>
                  </span>
                  <span className="text-[11px] text-neutral-500">
                    Total a procesar: <strong>{formatThousands(parsedItems.length)}</strong> artículos
                  </span>
                </div>

                <div className="overflow-x-auto rounded-xl border border-neutral-200 dark:border-neutral-800">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 font-bold border-b border-neutral-200 dark:border-neutral-700">
                      <tr>
                        <th className="py-2.5 px-3">Código Real</th>
                        <th className="py-2.5 px-3">Detalle / Nombre</th>
                        <th className="py-2.5 px-3">Marca</th>
                        <th className="py-2.5 px-3">Rubro</th>
                        <th className="py-2.5 px-3 text-right">Costo ($)</th>
                        <th className="py-2.5 px-3 text-right">Precio Venta ($)</th>
                        <th className="py-2.5 px-3 text-right">Stock</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800 font-mono text-[11px]">
                      {parsedItems.slice(0, 5).map((item, idx) => (
                        <tr key={idx} className="hover:bg-neutral-50 dark:hover:bg-neutral-800/50">
                          <td className="py-2 px-3 font-bold text-neutral-900 dark:text-white">
                            <span className="bg-neutral-100 dark:bg-neutral-800 px-1.5 py-0.5 rounded border border-neutral-300 dark:border-neutral-700">
                              {item.barcode}
                            </span>
                          </td>
                          <td className="py-2 px-3 font-sans font-medium text-neutral-800 dark:text-neutral-200 max-w-[220px] truncate" title={item.name}>
                            {item.name}
                          </td>
                          <td className="py-2 px-3 font-sans text-neutral-600 dark:text-neutral-400">{item.brand}</td>
                          <td className="py-2 px-3 font-sans text-neutral-600 dark:text-neutral-400">{item.category}</td>
                          <td className="py-2 px-3 text-right text-neutral-600 dark:text-neutral-400">${formatThousands(item.costPrice)}</td>
                          <td className="py-2 px-3 text-right font-bold text-emerald-600 dark:text-emerald-400 text-xs">${formatThousands(item.salePrice)}</td>
                          <td className="py-2 px-3 text-right font-bold">{formatThousands(item.stock)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-neutral-50 dark:bg-neutral-800/80 border-t border-neutral-200 dark:border-neutral-700/80 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            disabled={isImporting}
            className="px-4 py-2 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl font-bold text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            Cancelar
          </button>

          <button
            type="button"
            onClick={handleExecuteImport}
            disabled={parsedItems.length === 0 || isImporting}
            className={`px-6 py-2.5 text-white rounded-xl font-black uppercase tracking-wider shadow-sm transition-all flex items-center gap-2 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${
              isCsv ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-teal-600 hover:bg-teal-700'
            }`}
          >
            {isImporting ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Importando {formatThousands(parsedItems.length)} artículos...</span>
              </>
            ) : (
              <>
                <Check className="w-4 h-4 stroke-[3]" />
                <span>Confirmar e Importar {parsedItems.length > 0 ? `(${formatThousands(parsedItems.length)})` : ''}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
