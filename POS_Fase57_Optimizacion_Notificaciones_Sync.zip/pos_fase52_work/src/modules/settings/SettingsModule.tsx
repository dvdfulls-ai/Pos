import React, { useState, useEffect, useRef } from 'react';
import { 
  Settings, 
  CreditCard, 
  Store, 
  Cloud, 
  Wifi, 
  WifiOff, 
  ShieldAlert, 
  Save, 
  CheckCircle2, 
  Download, 
  Upload, 
  HardDrive, 
  RefreshCw, 
  Layers, 
  FileText, 
  Check, 
  HelpCircle,
  Server,
  Lock,
  Smartphone,
  Monitor,
  Keyboard,
  Printer,
  RotateCcw,
  Sliders,
  Zap,
  Scissors,
  Usb,
  Radio,
  HelpCircle as HelpIcon,
  Check as CheckIcon
} from 'lucide-react';
import { StorageService, INITIAL_TERMINALS } from '../../services/storage';
import { CloudSync } from '../../services/cloudSync';
import { copyLocalLedgersToIndexedDb, compareLocalLedgersWithIndexedDb, auditIndexedDbLedgerReadiness, exportIndexedDbLedgerBackup, stageLedgerBackupForRestore, verifyStagedLedgerBackup, compareStagedBackupWithCurrentData, diagnosePosLedgerStorage, type LedgerMigrationItem, type LedgerBackupStageResult, type LedgerStageAuditResult, type LedgerStageCompareItem, type LedgerStorageDiagnosticResult } from '../../services/indexedDbLedgerMigration';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import { BusinessInfo, Terminal, KeyboardShortcutConfig, PrinterConfig } from '../../types';
import { PaymentConfigModal } from '../customer/PaymentConfigModal';
import { DialogService } from '../../services/dialog';

export type SettingsSubTab = 'TERMINALS' | 'SHORTCUTS' | 'PRINTER' | 'PAYMENTS' | 'COMMERCE' | 'CLOUD_OFFLINE';

interface SettingsModuleProps {
  initialSubTab?: SettingsSubTab;
}

const POPULAR_KEYS = [
  'F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 'F9', 'F10', 'F11', 'F12',
  'Escape', 'Enter', 'Space', '+', '-', 'Delete',
  'A', 'B', 'C', 'D', 'E', 'P', 'T', 'V', '1', '2', '3', '4', '5'
];

export const SettingsModule: React.FC<SettingsModuleProps> = ({ initialSubTab = 'TERMINALS' }) => {
  const { currentUser, hasPermission } = useAuth();
  const { terminals, saveTerminalsList, currentTerminalId, setCurrentTerminalId } = useApp();

  // Allow configuring workstation options (terminals, keyboard, printer) freely
  const canAccess = true;

  const [activeSubTab, setActiveSubTab] = useState<SettingsSubTab>(initialSubTab);

  useEffect(() => {
    if (initialSubTab) {
      setActiveSubTab(initialSubTab);
    }
  }, [initialSubTab]);

  // Key tester state
  const [testPressedKey, setTestPressedKey] = useState<string | null>(null);
  const [testMatchedAction, setTestMatchedAction] = useState<string | null>(null);

  // Printer assistant state
  const [detectingPrinter, setDetectingPrinter] = useState(false);
  const [detectedPrinterMessage, setDetectedPrinterMessage] = useState<string | null>(null);

  // Commerce form state
  const [businessInfo, setBusinessInfo] = useState<BusinessInfo>(StorageService.getBusinessInfo());
  const [saveCommerceSuccess, setSaveCommerceSuccess] = useState(false);

  // Terminals editable state
  const [terminalsList, setTerminalsList] = useState<Terminal[]>(terminals);
  const [saveTerminalsSuccess, setSaveTerminalsSuccess] = useState(false);

  useEffect(() => {
    setTerminalsList(terminals);
  }, [terminals]);

  const handleSaveTerminals = () => {
    saveTerminalsList(terminalsList);
    setSaveTerminalsSuccess(true);
    setTimeout(() => setSaveTerminalsSuccess(false), 2500);
  };

  const handleResetTerminals = () => {
    const defaultsById = new Map(INITIAL_TERMINALS.map(term => [term.id, term]));
    const resetList = terminalsList.map(term => {
      const original = defaultsById.get(term.id);
      return original ? { ...term, name: original.name, location: original.location } : term;
    });
    setTerminalsList(resetList);
    saveTerminalsList(resetList);
    setSaveTerminalsSuccess(true);
    setTimeout(() => setSaveTerminalsSuccess(false), 2500);
  };

  // Keyboard Shortcuts state
  const [shortcutsList, setShortcutsList] = useState<KeyboardShortcutConfig[]>(() => StorageService.getKeyboardShortcuts());
  const [listeningShortcutId, setListeningShortcutId] = useState<string | null>(null);
  const [saveShortcutsSuccess, setSaveShortcutsSuccess] = useState(false);

  useEffect(() => {
    if (!listeningShortcutId) return;

    const handleKeyCapture = (e: KeyboardEvent) => {
      e.preventDefault();
      e.stopPropagation();
      let keyName = e.key;
      if (keyName === ' ') keyName = 'Space';

      setShortcutsList(prev => prev.map(s => s.id === listeningShortcutId ? { ...s, key: keyName } : s));
      setListeningShortcutId(null);
    };

    window.addEventListener('keydown', handleKeyCapture, { capture: true });
    return () => window.removeEventListener('keydown', handleKeyCapture, { capture: true });
  }, [listeningShortcutId]);

  const handleSaveShortcuts = () => {
    StorageService.saveKeyboardShortcuts(shortcutsList);
    setSaveShortcutsSuccess(true);
    setTimeout(() => setSaveShortcutsSuccess(false), 2500);
  };

  const handleResetShortcuts = () => {
    const defaults = StorageService.resetKeyboardShortcuts();
    setShortcutsList(defaults);
    setSaveShortcutsSuccess(true);
    setTimeout(() => setSaveShortcutsSuccess(false), 2500);
  };

  // Printer configuration state
  const [printerConfig, setPrinterConfig] = useState<PrinterConfig>(() => StorageService.getPrinterConfig());
  const [savePrinterSuccess, setSavePrinterSuccess] = useState(false);

  useEffect(() => {
    const handleBusinessInfo = (event: Event) => {
      const detail = (event as CustomEvent<BusinessInfo>).detail;
      setBusinessInfo(detail || StorageService.getBusinessInfo());
    };
    const handlePrinterConfig = (event: Event) => {
      const detail = (event as CustomEvent<PrinterConfig>).detail;
      setPrinterConfig(detail || StorageService.getPrinterConfig());
    };
    const handleShortcuts = (event: Event) => {
      const detail = (event as CustomEvent<KeyboardShortcutConfig[]>).detail;
      if (Array.isArray(detail)) setShortcutsList(detail);
    };
    window.addEventListener('pos_business_info_changed', handleBusinessInfo);
    window.addEventListener('pos_printer_config_updated', handlePrinterConfig);
    window.addEventListener('pos_keyboard_shortcuts_updated', handleShortcuts);
    return () => {
      window.removeEventListener('pos_business_info_changed', handleBusinessInfo);
      window.removeEventListener('pos_printer_config_updated', handlePrinterConfig);
      window.removeEventListener('pos_keyboard_shortcuts_updated', handleShortcuts);
    };
  }, []);

  const handleSavePrinter = () => {
    StorageService.savePrinterConfig(printerConfig);
    setSavePrinterSuccess(true);
    setTimeout(() => setSavePrinterSuccess(false), 2500);
  };

  const handleTestPrint = () => {
    window.print();
  };

  const handleDetectPrinter = () => {
    setDetectingPrinter(true);
    setDetectedPrinterMessage(null);
    setTimeout(() => {
      setDetectingPrinter(false);
      setDetectedPrinterMessage(`¡Ticketera detectada y comunicada! La impresora está lista para emitir tickets térmicos en formato ${printerConfig.paperWidth}.`);
      setTimeout(() => setDetectedPrinterMessage(null), 5000);
    }, 800);
  };

  // Cloud & Offline diagnostic state
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [storageStats, setStorageStats] = useState({
    articlesCount: 0,
    salesCount: 0,
    accountsCount: 0,
    usedKb: '0',
  });
  const [backupMessage, setBackupMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [ledgerMigrationBusy, setLedgerMigrationBusy] = useState(false);
  const [ledgerMigrationResults, setLedgerMigrationResults] = useState<LedgerMigrationItem[] | null>(null);
  const [ledgerMigrationError, setLedgerMigrationError] = useState<string | null>(null);
  const [ledgerCompareBusy, setLedgerCompareBusy] = useState(false);
  const [ledgerCompareResults, setLedgerCompareResults] = useState<LedgerMigrationItem[] | null>(null);
  const [ledgerCompareError, setLedgerCompareError] = useState<string | null>(null);
  const [ledgerAuditBusy, setLedgerAuditBusy] = useState(false);
  const [ledgerAuditResults, setLedgerAuditResults] = useState<LedgerMigrationItem[] | null>(null);
  const [ledgerAuditError, setLedgerAuditError] = useState<string | null>(null);
  const [ledgerExportBusy, setLedgerExportBusy] = useState(false);
  const [ledgerExportError, setLedgerExportError] = useState<string | null>(null);
  const [ledgerStageBusy, setLedgerStageBusy] = useState(false);
  const [ledgerStageError, setLedgerStageError] = useState<string | null>(null);
  const [ledgerStageResult, setLedgerStageResult] = useState<LedgerBackupStageResult | null>(null);
  const ledgerStageFileRef = useRef<HTMLInputElement>(null);
  const [ledgerStageCompareBusy, setLedgerStageCompareBusy] = useState(false);
  const [ledgerStageCompareError, setLedgerStageCompareError] = useState<string | null>(null);
  const [ledgerStageCompareResults, setLedgerStageCompareResults] = useState<LedgerStageCompareItem[] | null>(null);
  const [ledgerStageAuditBusy, setLedgerStageAuditBusy] = useState(false);
  const [ledgerStageAuditError, setLedgerStageAuditError] = useState<string | null>(null);
  const [ledgerStageAuditResult, setLedgerStageAuditResult] = useState<LedgerStageAuditResult | null>(null);
  const [ledgerStorageDiagnosticBusy, setLedgerStorageDiagnosticBusy] = useState(false);
  const [ledgerStorageDiagnosticError, setLedgerStorageDiagnosticError] = useState<string | null>(null);
  const [ledgerStorageDiagnosticResult, setLedgerStorageDiagnosticResult] = useState<LedgerStorageDiagnosticResult | null>(null);
  const [factoryResetBusy, setFactoryResetBusy] = useState(false);
  const [factoryResetError, setFactoryResetError] = useState<string | null>(null);

  const handleFactoryReset = async () => {
    if (factoryResetBusy) return;
    setFactoryResetError(null);
    if (!hasPermission('canManageSettings')) {
      setFactoryResetError('Tu usuario no tiene permiso para restaurar el sistema.');
      return;
    }
    const terminal = String(currentTerminalId || '').toUpperCase();
    if (terminal !== 'TERM-01' && terminal !== '1') {
      setFactoryResetError('Por seguridad, iniciá la restauración desde la Terminal 01 (Caja Principal).');
      return;
    }
    if (!navigator.onLine) {
      setFactoryResetError('Conectá esta terminal a Internet para restaurar también el servidor y las demás cajas.');
      return;
    }
    const confirmed = window.confirm('ATENCIÓN: se borrarán las ventas, compras, cuentas corrientes, caja, historial, artículos personalizados, usuarios y configuraciones actuales en TODAS las terminales vinculadas. Se restaurarán los datos de demostración. Esta acción no se puede deshacer. ¿Continuar?');
    if (!confirmed) return;
    const phrase = window.prompt('Para confirmar, escribí exactamente: RESTAURAR DEMO');
    if (phrase !== 'RESTAURAR DEMO') {
      setFactoryResetError('La frase no coincide. No se modificó ningún dato.');
      return;
    }
    setFactoryResetBusy(true);
    try {
      const demoArticles = StorageService.getFactoryDemoArticles();
      const result = await CloudSync.resetAllTerminalsToDemo(demoArticles, phrase);
      if (!result.success) {
        setFactoryResetError(result.error || 'No se pudo completar la restauración.');
        return;
      }
      StorageService.resetToDemo(demoArticles);
      const channel = localStorage.getItem('pos_cloud_sync_channel') || localStorage.getItem('pos_sync_channel') || '';
      if (channel && Number.isFinite(result.seq)) {
        localStorage.setItem(`pos_vps_sync_cursor_v1_${channel}`, String(result.seq || 0));
      }
      window.alert('Restauración enviada correctamente. Las demás terminales volverán a la demostración al recibir el evento. Esta terminal se reiniciará ahora.');
      window.setTimeout(() => window.location.reload(), 250);
    } catch (error) {
      setFactoryResetError(error instanceof Error ? error.message : String(error));
    } finally {
      setFactoryResetBusy(false);
    }
  };

  const handleVerifyLedgerCopies = async () => {
    if (ledgerMigrationBusy) return;
    setLedgerMigrationBusy(true);
    setLedgerMigrationError(null);
    try {
      const results = await copyLocalLedgersToIndexedDb();
      setLedgerMigrationResults(results);
    } catch (error) {
      setLedgerMigrationError(error instanceof Error ? error.message : String(error));
    } finally {
      setLedgerMigrationBusy(false);
    }
  };

  const handleCompareLedgerCopies = async () => {
    if (ledgerCompareBusy) return;
    setLedgerCompareBusy(true);
    setLedgerCompareError(null);
    try {
      setLedgerCompareResults(await compareLocalLedgersWithIndexedDb());
    } catch (error) {
      setLedgerCompareError(error instanceof Error ? error.message : String(error));
    } finally {
      setLedgerCompareBusy(false);
    }
  };

  const handleAuditLedgerReadiness = async () => {
    if (ledgerAuditBusy) return;
    setLedgerAuditBusy(true);
    setLedgerAuditError(null);
    try {
      setLedgerAuditResults(await auditIndexedDbLedgerReadiness());
    } catch (error) {
      setLedgerAuditError(error instanceof Error ? error.message : String(error));
    } finally {
      setLedgerAuditBusy(false);
    }
  };

  const handleExportLedgerBackup = async () => {
    if (ledgerExportBusy) return;
    setLedgerExportBusy(true);
    setLedgerExportError(null);
    try {
      const backup = await exportIndexedDbLedgerBackup();
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `pos-indexeddb-respaldo-${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (error) {
      setLedgerExportError(error instanceof Error ? error.message : String(error));
    } finally {
      setLedgerExportBusy(false);
    }
  };

  const handleVerifyStagedLedgerBackup = async () => {
    if (ledgerStageAuditBusy) return;
    setLedgerStageAuditBusy(true);
    setLedgerStageAuditError(null);
    try {
      setLedgerStageAuditResult(await verifyStagedLedgerBackup());
    } catch (error) {
      setLedgerStageAuditError(error instanceof Error ? error.message : String(error));
      setLedgerStageAuditResult(null);
    } finally {
      setLedgerStageAuditBusy(false);
    }
  };

  const handleDiagnoseLedgerStorage = async () => {
    if (ledgerStorageDiagnosticBusy) return;
    setLedgerStorageDiagnosticBusy(true);
    setLedgerStorageDiagnosticError(null);
    try { setLedgerStorageDiagnosticResult(await diagnosePosLedgerStorage()); }
    catch (error) { setLedgerStorageDiagnosticError(error instanceof Error ? error.message : String(error)); setLedgerStorageDiagnosticResult(null); }
    finally { setLedgerStorageDiagnosticBusy(false); }
  };

  const handleExportStorageDiagnostic = () => {
    if (!ledgerStorageDiagnosticResult) return;
    const report = {
      phase: 24,
      purpose: 'Comparar el almacenamiento local entre terminales; informe de métricas, sin contenido de ventas.',
      terminal: localStorage.getItem('pos_current_terminal_v1') || 'no-identificada',
      channel: localStorage.getItem('pos_cloud_sync_channel') || localStorage.getItem('pos_sync_channel') || 'no-identificado',
      diagnostic: ledgerStorageDiagnosticResult,
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `pos-fase24-diagnostico-${String(report.terminal).replace(/[^a-zA-Z0-9_-]/g, '_')}-${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  const handleCompareStagedBackup = async () => {
    if (ledgerStageCompareBusy) return;
    setLedgerStageCompareBusy(true);
    setLedgerStageCompareError(null);
    try { setLedgerStageCompareResults(await compareStagedBackupWithCurrentData()); }
    catch (error) { setLedgerStageCompareError(error instanceof Error ? error.message : String(error)); setLedgerStageCompareResults(null); }
    finally { setLedgerStageCompareBusy(false); }
  };

  const handleStageLedgerBackup = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setLedgerStageBusy(true);
    setLedgerStageError(null);
    setLedgerStageResult(null);
    try {
      const text = await file.text();
      setLedgerStageResult(await stageLedgerBackupForRestore(text));
    } catch (error) {
      setLedgerStageError(error instanceof Error ? error.message : String(error));
    } finally {
      setLedgerStageBusy(false);
      event.target.value = '';
    }
  };

  const fileInputRef = useRef<HTMLInputElement>(null);

  const loadDiagnostics = () => {
    const articles = StorageService.getArticles();
    const sales = StorageService.getSales();
    const accounts = StorageService.getAccounts();

    let totalBytes = 0;
    for (let key in localStorage) {
      if (localStorage.hasOwnProperty(key)) {
        totalBytes += (localStorage[key].length + key.length) * 2;
      }
    }

    setStorageStats({
      articlesCount: articles.length,
      salesCount: sales.length,
      accountsCount: accounts.length,
      usedKb: (totalBytes / 1024).toFixed(1),
    });
  };

  useEffect(() => {
    loadDiagnostics();
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleSaveCommerce = (e: React.FormEvent) => {
    e.preventDefault();
    StorageService.saveBusinessInfo(businessInfo);
    setSaveCommerceSuccess(true);
    setTimeout(() => {
      setSaveCommerceSuccess(false);
    }, 2500);
  };

  const handleExportBackup = () => {
    try {
      const backupData = StorageService.exportFullBackup();
      const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const dateStr = new Date().toISOString().slice(0, 10);
      a.href = url;
      a.download = `respaldo_pos_completo_${dateStr}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setBackupMessage({ type: 'success', text: 'Copia de seguridad descargada correctamente.' });
      setTimeout(() => setBackupMessage(null), 3000);
    } catch (err: any) {
      setBackupMessage({ type: 'error', text: 'Error al exportar respaldo: ' + err.message });
      setTimeout(() => setBackupMessage(null), 4000);
    }
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        const confirmRestore = await DialogService.confirm(
          '¿Estás seguro de restaurar este archivo de respaldo? Esta acción actualizará los artículos, datos de cobro y configuración de esta terminal.',
          'Restaurar Respaldo de Datos',
          'Sí, restaurar datos',
          'Cancelar',
          'warning'
        );
        if (!confirmRestore) return;

        const result = await StorageService.restoreFullBackup(json);
        if (result.success) {
          setBackupMessage({ type: 'success', text: result.message });
          setBusinessInfo(StorageService.getBusinessInfo());
          loadDiagnostics();
          // Recargar aplica de forma consistente el tema y actualiza AuthContext con los usuarios restaurados.
          window.setTimeout(() => window.location.reload(), 700);
        } else {
          setBackupMessage({ type: 'error', text: result.message });
        }
      } catch (err: any) {
        setBackupMessage({ type: 'error', text: 'El archivo seleccionado no es un JSON válido.' });
      } finally {
        if (fileInputRef.current) fileInputRef.current.value = '';
        setTimeout(() => setBackupMessage(null), 4000);
      }
    };
    reader.readAsText(file);
  };

  // Access denied screen
  if (!canAccess) {
    return (
      <div id="settings-restricted" className="p-8 max-w-xl mx-auto my-12 bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-2xl shadow-xs text-center">
        <div className="w-14 h-14 bg-red-100 dark:bg-red-950/50 rounded-2xl flex items-center justify-center mx-auto mb-4 text-red-600 dark:text-red-400">
          <Lock className="w-7 h-7" />
        </div>
        <h2 className="text-xl font-black text-neutral-950 dark:text-white mb-2">
          Acceso Restringido
        </h2>
        <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-6 leading-relaxed">
          No tienes permisos para acceder al módulo de <strong>Configuración y Datos de Cobro</strong>. 
          Esta área contiene información sensible sobre pasarelas de pago (Mercado Pago, cuentas bancarias, billeteras) y parámetros globales del sistema.
        </p>
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 text-xs font-semibold">
          <ShieldAlert className="w-4 h-4 text-amber-500" />
          Solicita el permiso "Configuración general y Datos de Cobro" al Dueño o Administrador.
        </div>
      </div>
    );
  }

  return (
    <div id="settings-module-container" className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-2xl p-5 shadow-xs flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-neutral-900 dark:bg-neutral-800 text-white rounded-xl shadow-xs">
            <Settings className="w-6 h-6 text-emerald-400" />
          </div>
          <div>
            <h1 className="text-xl font-black tracking-tight text-neutral-950 dark:text-white flex items-center gap-2">
              Configuración del Sistema
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                Control Total
              </span>
            </h1>
            <p className="text-xs text-neutral-600 dark:text-neutral-400">
              Datos de cobro, pasarelas de pago, identidad comercial y arquitectura de red (Nube & Offline)
            </p>
          </div>
        </div>

        {/* Subtabs Selector */}
        <div className="flex flex-wrap items-center bg-neutral-100 dark:bg-neutral-800 p-1 rounded-xl border border-neutral-200 dark:border-neutral-700 gap-1">
          <button
            id="tab-btn-terminals"
            type="button"
            onClick={() => setActiveSubTab('TERMINALS')}
            className={`px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
              activeSubTab === 'TERMINALS'
                ? 'bg-white dark:bg-neutral-900 text-neutral-950 dark:text-white shadow-xs ring-1 ring-neutral-300 dark:ring-neutral-700'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            <Monitor className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            <span>Terminales / Cajas (Editar Textos)</span>
          </button>

          <button
            id="tab-btn-shortcuts"
            type="button"
            onClick={() => setActiveSubTab('SHORTCUTS')}
            className={`px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
              activeSubTab === 'SHORTCUTS'
                ? 'bg-white dark:bg-neutral-900 text-neutral-950 dark:text-white shadow-xs ring-1 ring-neutral-300 dark:ring-neutral-700'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            <Keyboard className="w-4 h-4 text-amber-500 dark:text-amber-400" />
            <span>Atajos de Teclado</span>
          </button>

          <button
            id="tab-btn-printer"
            type="button"
            onClick={() => setActiveSubTab('PRINTER')}
            className={`px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
              activeSubTab === 'PRINTER'
                ? 'bg-white dark:bg-neutral-900 text-neutral-950 dark:text-white shadow-xs ring-1 ring-neutral-300 dark:ring-neutral-700'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            <Printer className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>Instalar Ticketera / Impresora</span>
          </button>

          <button
            id="tab-btn-payments"
            type="button"
            onClick={() => setActiveSubTab('PAYMENTS')}
            className={`px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
              activeSubTab === 'PAYMENTS'
                ? 'bg-white dark:bg-neutral-900 text-neutral-950 dark:text-white shadow-xs ring-1 ring-neutral-300 dark:ring-neutral-700'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            <CreditCard className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>Datos de Cobro (QR MP)</span>
          </button>

          <button
            id="tab-btn-commerce"
            type="button"
            onClick={() => setActiveSubTab('COMMERCE')}
            className={`px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
              activeSubTab === 'COMMERCE'
                ? 'bg-white dark:bg-neutral-900 text-neutral-950 dark:text-white shadow-xs ring-1 ring-neutral-300 dark:ring-neutral-700'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            <Store className="w-4 h-4 text-sky-600 dark:text-sky-400" />
            <span>Comercio & Datos</span>
          </button>

          <button
            id="tab-btn-cloud"
            type="button"
            onClick={() => setActiveSubTab('CLOUD_OFFLINE')}
            className={`px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
              activeSubTab === 'CLOUD_OFFLINE'
                ? 'bg-white dark:bg-neutral-900 text-neutral-950 dark:text-white shadow-xs ring-1 ring-neutral-300 dark:ring-neutral-700'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            <Cloud className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            <span>Nube & Offline</span>
          </button>
        </div>
      </div>

      {/* Subtab 1: Datos de Cobro (Payment Config Embedded) */}
      {activeSubTab === 'PAYMENTS' && (
        <div id="settings-payments-view" className="animate-in fade-in duration-200">
          <PaymentConfigModal embedded={true} />
        </div>
      )}

      {/* Subtab 2: Terminales & Cajas (Editar Nombres y Textos) */}
      {activeSubTab === 'TERMINALS' && (
        <div id="settings-terminals-view" className="space-y-6 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-2xl p-6 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6 pb-4 border-b border-neutral-200 dark:border-neutral-800">
              <div>
                <h3 className="text-base font-black text-neutral-950 dark:text-white flex items-center gap-2">
                  <Monitor className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                  Editar Nombres y Textos de las Terminales / Cajas
                </h3>
                <p className="text-xs text-neutral-500 dark:text-neutral-400">
                  Personaliza los nombres identificatorios y ubicaciones de las terminales registradas en este POS. Las terminales nuevas se incorporan al vincularlas con su código del panel.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => { void CloudSync.pairTerminalFromPanel(); }}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
                >
                  <Radio className="w-3.5 h-3.5" />
                  Vincular terminal del panel
                </button>
                <button
                  type="button"
                  onClick={handleResetTerminals}
                  className="px-3 py-1.5 border border-neutral-300 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Nombres Originales
                </button>
              </div>
            </div>

            <div className="space-y-4">
              {terminalsList.map((term, index) => {
                const isActive = term.id === currentTerminalId;
                return (
                  <div
                    key={term.id}
                    className={`p-4 rounded-2xl border transition-all ${
                      isActive
                        ? 'border-indigo-500/60 bg-indigo-50/40 dark:bg-indigo-950/20 dark:border-indigo-700'
                        : 'border-neutral-200 dark:border-neutral-700/80 bg-neutral-50/50 dark:bg-neutral-800/40'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded-md font-mono text-[11px] font-black bg-neutral-200 dark:bg-neutral-700 text-neutral-800 dark:text-neutral-200">
                          {term.id}
                        </span>
                        <span className="text-xs font-bold text-neutral-700 dark:text-neutral-300">
                          Caja #{index + 1}
                        </span>
                        {isActive && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                            Terminal Activa en este dispositivo
                          </span>
                        )}
                      </div>

                      {!isActive && (
                        <button
                          type="button"
                          onClick={() => {
                            setCurrentTerminalId(term.id);
                          }}
                          className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
                        >
                          Usar esta terminal en este equipo
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                          Nombre visible de la Terminal *
                        </label>
                        <input
                          type="text"
                          required
                          value={term.name}
                          onChange={(e) => {
                            const val = e.target.value;
                            setTerminalsList(prev => prev.map(t => t.id === term.id ? { ...t, name: val } : t));
                          }}
                          className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-xs font-bold text-neutral-950 dark:text-white focus:ring-2 focus:ring-indigo-600 focus:outline-hidden"
                          placeholder="Ej: Terminal 01 - Caja Principal"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                          Ubicación / Sector / Detalle
                        </label>
                        <input
                          type="text"
                          value={term.location}
                          onChange={(e) => {
                            const val = e.target.value;
                            setTerminalsList(prev => prev.map(t => t.id === term.id ? { ...t, location: val } : t));
                          }}
                          className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-xs font-medium text-neutral-950 dark:text-white focus:ring-2 focus:ring-indigo-600 focus:outline-hidden"
                          placeholder="Ej: Mostrador Entrada / Pasillo Central / Móvil"
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-6 pt-4 border-t border-neutral-200 dark:border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-3">
              {saveTerminalsSuccess ? (
                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5 animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4" />
                  ¡Nombres de terminales guardados y actualizados en todo el sistema!
                </span>
              ) : (
                <span className="text-[11px] text-neutral-500">
                  Los cambios se reflejan inmediatamente en el selector superior
                </span>
              )}

              <button
                type="button"
                onClick={handleSaveTerminals}
                className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 dark:bg-indigo-600 dark:hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition-colors"
              >
                <Save className="w-4 h-4 text-indigo-400 dark:text-white" />
                Guardar Nombres de Terminales
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Subtab 3: Atajos de Teclado */}
      {activeSubTab === 'SHORTCUTS' && (
        <div id="settings-shortcuts-view" className="space-y-6 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-2xl p-6 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6 pb-4 border-b border-neutral-200 dark:border-neutral-800">
              <div>
                <h3 className="text-base font-black text-neutral-950 dark:text-white flex items-center gap-2">
                  <Keyboard className="w-5 h-5 text-amber-500" />
                  Configuración de Atajos Rápidos de Teclado
                </h3>
                <p className="text-xs text-neutral-500 dark:text-neutral-400">
                  Asigna teclas rápidas (F1 a F12, Escape, Enter, etc.) para acelerar la facturación y operar el sistema sin usar el mouse.
                </p>
              </div>

              <button
                type="button"
                onClick={handleResetShortcuts}
                className="px-3 py-1.5 border border-neutral-300 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Restaurar Predeterminados
              </button>
            </div>

            {/* Interactive Keyboard Test Area */}
            <div className="mb-6 p-4 rounded-xl bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-xs font-black text-amber-950 dark:text-amber-300 flex items-center gap-1.5">
                  <Zap className="w-4 h-4 text-amber-600" />
                  Probador de Teclado en Vivo
                </span>
                <p className="text-[11px] text-amber-800 dark:text-amber-400">
                  Haz clic en el recuadro y presiona cualquier tecla física de tu teclado para verificar qué acción dispara de inmediato:
                </p>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Presiona una tecla aquí..."
                  readOnly
                  value={testPressedKey ? `Tecla: [${testPressedKey}]` : ''}
                  onKeyDown={(e) => {
                    e.preventDefault();
                    let k = e.key;
                    if (k === ' ') k = 'Space';
                    setTestPressedKey(k);
                    const match = shortcutsList.find(s => s.key.toLowerCase() === k.toLowerCase());
                    setTestMatchedAction(match ? match.label : 'Sin acción asignada');
                  }}
                  className="px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-amber-400 dark:border-amber-600 rounded-xl text-xs font-mono font-black text-neutral-900 dark:text-white placeholder:text-neutral-400 focus:outline-hidden focus:ring-2 focus:ring-amber-500 w-48 text-center"
                />
                {testMatchedAction && (
                  <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-amber-200 dark:bg-amber-900 text-amber-950 dark:text-amber-200 border border-amber-300 dark:border-amber-700 animate-in fade-in">
                    ➔ {testMatchedAction}
                  </span>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {shortcutsList.map((shortcut) => {
                const isListening = listeningShortcutId === shortcut.id;
                return (
                  <div
                    key={shortcut.id}
                    className="p-4 rounded-xl border border-neutral-200 dark:border-neutral-700/80 bg-neutral-50/50 dark:bg-neutral-800/40 flex flex-col justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-black text-neutral-900 dark:text-white">
                          {shortcut.label}
                        </span>
                        <span className="text-[10px] uppercase tracking-wider font-bold px-1.5 py-0.5 rounded-md bg-neutral-200 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300">
                          {shortcut.category}
                        </span>
                      </div>
                      <p className="text-[11px] text-neutral-500 dark:text-neutral-400 leading-relaxed">
                        {shortcut.description}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-neutral-200/70 dark:border-neutral-700/70 gap-2">
                      <span className="text-[10px] font-bold text-neutral-500">Tecla Asignada:</span>
                      <div className="flex items-center gap-1.5">
                        {/* Interactive Key Capture Button */}
                        <button
                          type="button"
                          onClick={() => {
                            setListeningShortcutId(shortcut.id);
                          }}
                          className={`px-3 py-1.5 rounded-lg font-mono text-xs font-black border transition-all text-center shadow-xs ${
                            isListening
                              ? 'bg-amber-500 text-white border-amber-600 ring-2 ring-amber-300 animate-pulse'
                              : 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white border-neutral-300 dark:border-neutral-600 hover:border-neutral-400'
                          }`}
                          title="Haz clic para presionar y asignar una tecla en tu teclado"
                        >
                          {isListening ? 'Presiona tecla...' : shortcut.key}
                        </button>

                        {/* Direct dropdown selector */}
                        <select
                          value={shortcut.key}
                          onChange={(e) => {
                            const newKey = e.target.value;
                            setShortcutsList(prev => prev.map(s => s.id === shortcut.id ? { ...s, key: newKey } : s));
                          }}
                          className="px-2 py-1.5 rounded-lg font-mono text-xs font-bold bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-600 text-neutral-700 dark:text-neutral-200"
                          title="O elige directamente una tecla de la lista"
                        >
                          {!POPULAR_KEYS.includes(shortcut.key) && (
                            <option value={shortcut.key}>{shortcut.key}</option>
                          )}
                          {POPULAR_KEYS.map((k) => (
                            <option key={k} value={k}>{k}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-6 pt-4 border-t border-neutral-200 dark:border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-3">
              {saveShortcutsSuccess ? (
                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5 animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4" />
                  ¡Atajos de teclado guardados y activos!
                </span>
              ) : (
                <span className="text-[11px] text-neutral-500">
                  Puedes presionar los atajos en cualquier momento durante la operación
                </span>
              )}

              <button
                type="button"
                onClick={handleSaveShortcuts}
                className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 dark:bg-amber-600 dark:hover:bg-amber-500 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition-colors"
              >
                <Save className="w-4 h-4 text-amber-400 dark:text-white" />
                Guardar Atajos de Teclado
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Subtab 3: Ticketera / Impresora */}
      {activeSubTab === 'PRINTER' && (
        <div id="settings-printer-view" className="space-y-6 animate-in fade-in duration-200">
          {/* Asistente de Instalación y Conexión Rápida */}
          <div className="bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-2xl p-6 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-3 border-b border-neutral-200 dark:border-neutral-800">
              <div>
                <h3 className="text-base font-black text-neutral-950 dark:text-white flex items-center gap-2">
                  <Printer className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                  Asistente para Instalar y Conectar Ticketera / Impresora Térmica
                </h3>
                <p className="text-xs text-neutral-500 dark:text-neutral-400">
                  Sigue estos 4 pasos para conectar cualquier impresora térmica (Epson, Xprinter, Hasar, POS-58, POS-80, Bixolon, Citizen, etc.).
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleDetectPrinter}
                  disabled={detectingPrinter}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition-colors"
                >
                  <Usb className="w-4 h-4" />
                  {detectingPrinter ? 'Detectando...' : 'Detectar y Vincular Impresora'}
                </button>
              </div>
            </div>

            {detectedPrinterMessage && (
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 rounded-xl text-xs font-bold text-emerald-800 dark:text-emerald-300 flex items-center gap-2 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                <span>{detectedPrinterMessage}</span>
              </div>
            )}

            {/* 4 Steps Guide */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-1">
              <div className="p-3.5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50/60 dark:bg-neutral-800/40 space-y-1">
                <div className="flex items-center gap-2 font-black text-xs text-neutral-900 dark:text-white">
                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px]">1</span>
                  <span>Conexión Física</span>
                </div>
                <p className="text-[11px] text-neutral-500 dark:text-neutral-400 leading-relaxed">
                  Conecta el cable USB, Ethernet o empareja por Bluetooth la ticketera a esta computadora o tablet.
                </p>
              </div>

              <div className="p-3.5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50/60 dark:bg-neutral-800/40 space-y-1">
                <div className="flex items-center gap-2 font-black text-xs text-neutral-900 dark:text-white">
                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px]">2</span>
                  <span>Driver del Fabricante</span>
                </div>
                <p className="text-[11px] text-neutral-500 dark:text-neutral-400 leading-relaxed">
                  Instala el driver POS (ej: POS-80, POS-58, Epson TM o Xprinter) en Windows/Mac/Linux.
                </p>
              </div>

              <div className="p-3.5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50/60 dark:bg-neutral-800/40 space-y-1">
                <div className="flex items-center gap-2 font-black text-xs text-neutral-900 dark:text-white">
                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px]">3</span>
                  <span>Ajustes de Papel</span>
                </div>
                <p className="text-[11px] text-neutral-500 dark:text-neutral-400 leading-relaxed">
                  Configura el papel en <strong>80mm o 58mm</strong> y los márgenes en <strong>"Ninguno" (0mm)</strong> en las preferencias.
                </p>
              </div>

              <div className="p-3.5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50/60 dark:bg-neutral-800/40 space-y-1">
                <div className="flex items-center gap-2 font-black text-xs text-neutral-900 dark:text-white">
                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px]">4</span>
                  <span>Prueba de Emisión</span>
                </div>
                <p className="text-[11px] text-neutral-500 dark:text-neutral-400 leading-relaxed">
                  Presiona el botón "Imprimir Ticket de Prueba" abajo para verificar corte y legibilidad.
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-2xl p-6 shadow-xs space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-neutral-200 dark:border-neutral-800">
                  <div>
                    <h3 className="text-base font-black text-neutral-950 dark:text-white flex items-center gap-2">
                      <Printer className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                      Parámetros de la Ticketera Térmica
                    </h3>
                    <p className="text-xs text-neutral-500 dark:text-neutral-400">
                      Personaliza el formato del papel, corte automático, apertura de cajón y textos impresos.
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Módulo de Impresión Listo
                    </span>
                  </div>
                </div>

                {/* Toggle Habilitar */}
                <div className="flex items-center justify-between p-3.5 rounded-xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700">
                  <div>
                    <p className="text-xs font-black text-neutral-900 dark:text-white">
                      Habilitar Impresión de Tickets
                    </p>
                    <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
                      Permite emitir tickets de comprobante de venta e imprimirlos
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={printerConfig.enabled}
                      onChange={(e) => setPrinterConfig({ ...printerConfig, enabled: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-neutral-300 peer-focus:outline-hidden rounded-full peer dark:bg-neutral-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-neutral-600 peer-checked:bg-emerald-600"></div>
                  </label>
                </div>

                {/* Nombre y Tipo */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                      Nombre o Modelo de la Ticketera
                    </label>
                    <input
                      type="text"
                      value={printerConfig.printerName}
                      onChange={(e) => setPrinterConfig({ ...printerConfig, printerName: e.target.value })}
                      className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-xs font-bold text-neutral-950 dark:text-white focus:ring-2 focus:ring-emerald-600 focus:outline-hidden"
                      placeholder="Ej: EPSON TM-T20II / Xprinter XP-80 / Genérica"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                      Tipo de Conexión
                    </label>
                    <select
                      value={printerConfig.printerType}
                      onChange={(e) => setPrinterConfig({ ...printerConfig, printerType: e.target.value as any })}
                      className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-xs font-bold text-neutral-950 dark:text-white focus:ring-2 focus:ring-emerald-600 focus:outline-hidden"
                    >
                      <option value="SYSTEM">Impresora del Sistema (Windows / Mac / Linux) - Recomendado</option>
                      <option value="THERMAL_USB">Térmica USB / ESC-POS Directo</option>
                      <option value="THERMAL_NETWORK">Impresora de Red Local (IP / Ethernet)</option>
                      <option value="BLUETOOTH">Impresora Portátil Bluetooth</option>
                    </select>
                  </div>
                </div>

                {/* Ancho de Papel */}
                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-2">
                    Formato y Ancho del Papel Térmico
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setPrinterConfig({ ...printerConfig, paperWidth: '80mm' })}
                      className={`p-3.5 rounded-xl border text-left flex items-start justify-between transition-all ${
                        printerConfig.paperWidth === '80mm'
                          ? 'border-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/20 text-neutral-950 dark:text-white ring-1 ring-emerald-500'
                          : 'border-neutral-200 dark:border-neutral-700 hover:bg-neutral-50 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300'
                      }`}
                    >
                      <div>
                        <p className="text-xs font-black">Papel Térmico 80 mm (Estándar)</p>
                        <p className="text-[11px] text-neutral-500 mt-0.5">
                          Formato clásico de supermercados y comercios. 48 a 64 caracteres por renglón.
                        </p>
                      </div>
                      {printerConfig.paperWidth === '80mm' && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => setPrinterConfig({ ...printerConfig, paperWidth: '58mm' })}
                      className={`p-3.5 rounded-xl border text-left flex items-start justify-between transition-all ${
                        printerConfig.paperWidth === '58mm'
                          ? 'border-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/20 text-neutral-950 dark:text-white ring-1 ring-emerald-500'
                          : 'border-neutral-200 dark:border-neutral-700 hover:bg-neutral-50 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300'
                      }`}
                    >
                      <div>
                        <p className="text-xs font-black">Papel Térmico 58 mm (Mini)</p>
                        <p className="text-[11px] text-neutral-500 mt-0.5">
                          Ticketeras compactas y portátiles. 32 a 40 caracteres por renglón.
                        </p>
                      </div>
                      {printerConfig.paperWidth === '58mm' && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Textos Personalizados de Encabezado y Pie */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1 border-t border-neutral-200 dark:border-neutral-800">
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                      Encabezado Personalizado en Ticket
                    </label>
                    <input
                      type="text"
                      value={printerConfig.headerText || ''}
                      onChange={(e) => setPrinterConfig({ ...printerConfig, headerText: e.target.value })}
                      className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-xs font-bold text-neutral-950 dark:text-white focus:ring-2 focus:ring-emerald-600 focus:outline-hidden"
                      placeholder="Ej: ¡Bienvenidos a nuestro local!"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                      Mensaje de Despedida al Pie del Ticket
                    </label>
                    <input
                      type="text"
                      value={printerConfig.footerText || ''}
                      onChange={(e) => setPrinterConfig({ ...printerConfig, footerText: e.target.value })}
                      className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-xs font-bold text-neutral-950 dark:text-white focus:ring-2 focus:ring-emerald-600 focus:outline-hidden"
                      placeholder="Ej: ¡Muchas gracias por su compra! Conserve su ticket."
                    />
                  </div>
                </div>

                {/* Opciones automáticas */}
                <div className="space-y-3 pt-2">
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={printerConfig.autoPrintOnSale}
                      onChange={(e) => setPrinterConfig({ ...printerConfig, autoPrintOnSale: e.target.checked })}
                      className="w-4 h-4 rounded text-emerald-600 border-neutral-300 focus:ring-emerald-500"
                    />
                    <div>
                      <span className="text-xs font-bold text-neutral-900 dark:text-white">
                        Imprimir ticket automáticamente al confirmar cada venta
                      </span>
                      <p className="text-[11px] text-neutral-500">
                        Dispara el proceso de impresión inmediatamente tras registrar el cobro
                      </p>
                    </div>
                  </label>

                  {/* Modo de Impresión: Diálogo vs Directo / Silencioso */}
                  <div className="p-3.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50/70 dark:bg-neutral-800/40 space-y-2">
                    <div>
                      <span className="text-xs font-black text-neutral-900 dark:text-white flex items-center gap-1.5">
                        <Zap className="w-3.5 h-3.5 text-emerald-600" />
                        Ventana de Diálogo de Impresión de Windows
                      </span>
                      <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
                        Configura si deseas ver la ventana de vista previa de Windows o imprimir directo a la ticketera
                      </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setPrinterConfig({ ...printerConfig, silentPrinting: false })}
                        className={`p-2.5 rounded-lg border text-left transition-all ${
                          !printerConfig.silentPrinting
                            ? 'border-emerald-600 bg-white dark:bg-neutral-800 text-neutral-950 dark:text-white ring-1 ring-emerald-500 shadow-xs'
                            : 'border-neutral-200 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800/60 text-neutral-600 dark:text-neutral-400'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold">Abrir Ventana de Diálogo</span>
                          {!printerConfig.silentPrinting && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
                        </div>
                        <p className="text-[10px] text-neutral-500 mt-0.5">
                          Muestra la vista previa de Windows/Chrome antes de imprimir
                        </p>
                      </button>

                      <button
                        type="button"
                        onClick={() => setPrinterConfig({ ...printerConfig, silentPrinting: true })}
                        className={`p-2.5 rounded-lg border text-left transition-all ${
                          printerConfig.silentPrinting
                            ? 'border-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/20 text-neutral-950 dark:text-white ring-1 ring-emerald-500 shadow-xs'
                            : 'border-neutral-200 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800/60 text-neutral-600 dark:text-neutral-400'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-emerald-700 dark:text-emerald-300">Impresión Rápida Directa (Sin ventana)</span>
                          {printerConfig.silentPrinting && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
                        </div>
                        <p className="text-[10px] text-neutral-500 mt-0.5">
                          Envía a imprimir directamente sin tocar la ventana de Windows
                        </p>
                      </button>
                    </div>

                    {printerConfig.silentPrinting && (
                      <div className="p-3 bg-white dark:bg-neutral-900 border border-emerald-300 dark:border-emerald-800 rounded-lg text-[11px] text-neutral-700 dark:text-neutral-300 space-y-1.5 animate-in fade-in">
                        <p className="font-bold text-emerald-800 dark:text-emerald-400">
                          📌 ¿Cómo hacer que Chrome no muestre nunca más la ventana emergente al imprimir?
                        </p>
                        <p className="leading-relaxed">
                          Por seguridad, los navegadores muestran la ventana previa a menos que se inicie en modo POS de impresión silenciosa. Para que tu <strong>3nStar RPT-004</strong> imprima en 1 segundo sin tocar nada:
                        </p>
                        <ol className="list-decimal pl-4 space-y-1 text-neutral-600 dark:text-neutral-400">
                          <li>Cierra Google Chrome.</li>
                          <li>Haz clic derecho en el ícono de <strong>Google Chrome</strong> en tu escritorio ➔ <strong>Propiedades</strong>.</li>
                          <li>En la pestaña <em>Acceso directo</em>, en el campo <strong>Destino</strong>, al final de la ruta agrega un espacio y: <strong className="font-mono text-neutral-900 dark:text-white bg-neutral-100 dark:bg-neutral-800 px-1.5 py-0.5 rounded border border-neutral-300 dark:border-neutral-700">--kiosk-printing</strong></li>
                          <li>Haz clic en <strong>Aceptar</strong> y abre el sistema. A partir de ahora, cada vez que cobres o toques Imprimir, saldrá directamente por la impresora térmica sin abrir ventanas.</li>
                        </ol>
                      </div>
                    )}
                  </div>

                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={printerConfig.openCashDrawer}
                      onChange={(e) => setPrinterConfig({ ...printerConfig, openCashDrawer: e.target.checked })}
                      className="w-4 h-4 rounded text-emerald-600 border-neutral-300 focus:ring-emerald-500"
                    />
                    <div>
                      <span className="text-xs font-bold text-neutral-900 dark:text-white">
                        Apertura automática de cajón portamonedas (RJ11)
                      </span>
                      <p className="text-[11px] text-neutral-500">
                        Envía señal de pulso eléctrico al cajón de dinero conectado a la ticketera
                      </p>
                    </div>
                  </label>

                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={printerConfig.cutPaper}
                      onChange={(e) => setPrinterConfig({ ...printerConfig, cutPaper: e.target.checked })}
                      className="w-4 h-4 rounded text-emerald-600 border-neutral-300 focus:ring-emerald-500"
                    />
                    <div>
                      <span className="text-xs font-bold text-neutral-900 dark:text-white">
                        Corte automático de papel al finalizar el ticket
                      </span>
                      <p className="text-[11px] text-neutral-500">
                        Activa la guillotina de corte en impresoras con soporte de corte parcial o total
                      </p>
                    </div>
                  </label>

                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={printerConfig.printBarcode}
                      onChange={(e) => setPrinterConfig({ ...printerConfig, printBarcode: e.target.checked })}
                      className="w-4 h-4 rounded text-emerald-600 border-neutral-300 focus:ring-emerald-500"
                    />
                    <div>
                      <span className="text-xs font-bold text-neutral-900 dark:text-white">
                        Imprimir código de barras del comprobante al pie
                      </span>
                      <p className="text-[11px] text-neutral-500">
                        Permite escanear el ticket posteriormente para devoluciones o consultas rápidas
                      </p>
                    </div>
                  </label>

                  <div className="pt-2 flex items-center gap-4">
                    <span className="text-xs font-bold text-neutral-700 dark:text-neutral-300">
                      Número de copias por venta:
                    </span>
                    <div className="flex items-center gap-2">
                      {[1, 2].map((num) => (
                        <button
                          key={num}
                          type="button"
                          onClick={() => setPrinterConfig({ ...printerConfig, copies: num })}
                          className={`px-3 py-1 rounded-lg text-xs font-bold border transition-colors ${
                            printerConfig.copies === num
                              ? 'bg-emerald-600 text-white border-emerald-700'
                              : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border-neutral-300 dark:border-neutral-700'
                          }`}
                        >
                          {num} {num === 1 ? 'Copia (Cliente)' : 'Copias (Cliente + Control)'}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Botones de acción */}
                <div className="pt-4 border-t border-neutral-200 dark:border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleTestPrint}
                      className="px-4 py-2.5 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors border border-neutral-300 dark:border-neutral-700"
                    >
                      <Printer className="w-4 h-4 text-emerald-600" />
                      Imprimir Ticket de Prueba Térmico
                    </button>
                  </div>

                  <div className="flex items-center gap-3">
                    {savePrinterSuccess && (
                      <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5 animate-in fade-in">
                        <CheckCircle2 className="w-4 h-4" />
                        ¡Configuración de ticketera guardada!
                      </span>
                    )}
                    <button
                      type="button"
                      onClick={handleSavePrinter}
                      className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 dark:bg-emerald-600 dark:hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition-colors"
                    >
                      <Save className="w-4 h-4 text-emerald-400 dark:text-white" />
                      Guardar Configuración
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Columna derecha: Vista previa en vivo del ticket térmico */}
            <div className="bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-2xl p-6 shadow-xs flex flex-col">
              <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400 mb-3 flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-neutral-700 dark:text-neutral-300" />
                Vista Previa Ticket Térmico ({printerConfig.paperWidth})
              </h3>

              <div className={`bg-neutral-50 dark:bg-neutral-950 p-4 rounded-xl border border-neutral-200 dark:border-neutral-800 font-mono text-xs text-neutral-900 dark:text-neutral-100 shadow-inner flex-1 flex flex-col justify-between ${
                printerConfig.paperWidth === '58mm' ? 'max-w-[240px] mx-auto text-[10px]' : ''
              }`}>
                <div>
                  <div className="text-center pb-2.5 border-b border-dashed border-neutral-400 dark:border-neutral-700">
                    <p className="font-black text-sm uppercase">{businessInfo.name || 'MI COMERCIO'}</p>
                    <p className="text-[10px] text-neutral-500">CUIT: {businessInfo.cuit || '30-12345678-9'}</p>
                    <p className="text-[10px] text-neutral-500">{businessInfo.address || 'Av. Comercial 123'}</p>
                    <p className="text-[10px] text-neutral-500">TEL: {businessInfo.phone || '-'}</p>
                    {(printerConfig.headerText || businessInfo.ticketHeader) && (
                      <p className="text-[10px] italic mt-1 text-neutral-600 dark:text-neutral-400">"{printerConfig.headerText || businessInfo.ticketHeader}"</p>
                    )}
                  </div>

                  <div className="py-2 border-b border-dashed border-neutral-400 dark:border-neutral-700 text-[10px] text-neutral-500 flex justify-between">
                    <span>FECHA: {new Date().toLocaleDateString('es-AR')}</span>
                    <span>TICKET: B-0001-000124</span>
                  </div>

                  <div className="py-2 text-[11px] border-b border-dashed border-neutral-400 dark:border-neutral-700 space-y-1">
                    <div className="flex justify-between">
                      <span>1x Leche Entera 1L</span>
                      <span>$1.650</span>
                    </div>
                    <div className="flex justify-between">
                      <span>2x Café en Granos 500g</span>
                      <span>$13.000</span>
                    </div>
                    <div className="flex justify-between">
                      <span>1x Galletitas Chocolinas</span>
                      <span>$2.100</span>
                    </div>
                  </div>

                  <div className="py-2 flex justify-between font-black text-sm border-b border-dashed border-neutral-400 dark:border-neutral-700">
                    <span>TOTAL:</span>
                    <span>$16.750,00</span>
                  </div>
                </div>

                <div className="pt-3 text-center space-y-2 border-t border-dashed border-neutral-400 dark:border-neutral-700 mt-4">
                  <p className="text-[10px] text-neutral-600 dark:text-neutral-400">{printerConfig.footerText || businessInfo.ticketFooter || '¡Gracias por su compra!'}</p>
                  {printerConfig.printBarcode && (
                    <div className="py-1">
                      <div className="inline-block bg-neutral-900 dark:bg-white text-white dark:text-black font-mono text-[9px] px-3 py-1 tracking-widest rounded">
                        ||| | | |||| | ||| | |||
                      </div>
                    </div>
                  )}
                  <p className="text-[9px] text-neutral-400">Terminal: {currentTerminalId} • IVA Responsable Inscripto</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Subtab 5: Comercio & Datos */}
      {activeSubTab === 'COMMERCE' && (
        <div id="settings-commerce-view" className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in fade-in duration-200">
          <div className="lg:col-span-2 bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-2xl p-6 shadow-xs">
            <h3 className="text-base font-black text-neutral-950 dark:text-white mb-1 flex items-center gap-2">
              <Store className="w-5 h-5 text-sky-600 dark:text-sky-400" />
              Identidad Comercial y Datos de Emisión
            </h3>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mb-5">
              Estos datos aparecerán impresos en el encabezado y pie de los tickets de venta y facturación.
            </p>

            <form onSubmit={handleSaveCommerce} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                    Nombre de Fantasía del Negocio *
                  </label>
                  <input
                    type="text"
                    required
                    value={businessInfo.name}
                    onChange={(e) => setBusinessInfo({ ...businessInfo, name: e.target.value })}
                    className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-xs font-bold text-neutral-950 dark:text-white focus:ring-2 focus:ring-sky-600 focus:outline-hidden"
                    placeholder="Ej: SUPERMERCADO CENTRAL"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                    CUIT / Razón Social *
                  </label>
                  <input
                    type="text"
                    required
                    value={businessInfo.cuit}
                    onChange={(e) => setBusinessInfo({ ...businessInfo, cuit: e.target.value })}
                    className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-xs font-bold text-neutral-950 dark:text-white focus:ring-2 focus:ring-sky-600 focus:outline-hidden"
                    placeholder="Ej: 30-71985421-3"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                    Dirección del Local
                  </label>
                  <input
                    type="text"
                    value={businessInfo.address}
                    onChange={(e) => setBusinessInfo({ ...businessInfo, address: e.target.value })}
                    className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-xs font-medium text-neutral-950 dark:text-white focus:ring-2 focus:ring-sky-600 focus:outline-hidden"
                    placeholder="Ej: Av. Corrientes 1420, CABA"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                    Teléfono / WhatsApp de Contacto
                  </label>
                  <input
                    type="text"
                    value={businessInfo.phone}
                    onChange={(e) => setBusinessInfo({ ...businessInfo, phone: e.target.value })}
                    className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-xs font-medium text-neutral-950 dark:text-white focus:ring-2 focus:ring-sky-600 focus:outline-hidden"
                    placeholder="Ej: +54 9 11 5566-7788"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  Mensaje de Encabezado de Ticket
                </label>
                <input
                  type="text"
                  value={businessInfo.ticketHeader || ''}
                  onChange={(e) => setBusinessInfo({ ...businessInfo, ticketHeader: e.target.value })}
                  className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-xs font-medium text-neutral-950 dark:text-white focus:ring-2 focus:ring-sky-600 focus:outline-hidden"
                  placeholder="Ej: ¡Bienvenidos a nuestro comercio!"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  Mensaje de Pie de Ticket
                </label>
                <input
                  type="text"
                  value={businessInfo.ticketFooter || ''}
                  onChange={(e) => setBusinessInfo({ ...businessInfo, ticketFooter: e.target.value })}
                  className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-xs font-medium text-neutral-950 dark:text-white focus:ring-2 focus:ring-sky-600 focus:outline-hidden"
                  placeholder="Ej: ¡Gracias por su compra! Conserve este ticket como comprobante."
                />
              </div>

              <div className="pt-3 border-t border-neutral-200 dark:border-neutral-800 flex items-center justify-between">
                {saveCommerceSuccess ? (
                  <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5 animate-in fade-in">
                    <CheckCircle2 className="w-4 h-4" />
                    ¡Datos comerciales guardados exitosamente!
                  </span>
                ) : (
                  <span className="text-[11px] text-neutral-500">
                    Cambios reflejados inmediatamente en todas las impresiones
                  </span>
                )}
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 dark:bg-sky-600 dark:hover:bg-sky-500 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition-colors"
                >
                  <Save className="w-4 h-4 text-sky-400 dark:text-white" />
                  Guardar Datos Comerciales
                </button>
              </div>
            </form>
          </div>

          {/* Ticket Live Preview */}
          <div className="bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-2xl p-6 shadow-xs flex flex-col">
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400 mb-3 flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-neutral-700 dark:text-neutral-300" />
              Vista Previa del Ticket Térmico (80mm)
            </h3>

            <div className="bg-neutral-100 dark:bg-neutral-950 p-4 rounded-xl border border-neutral-200 dark:border-neutral-800 font-mono text-xs text-neutral-800 dark:text-neutral-200 shadow-inner flex-1 flex flex-col justify-between">
              <div>
                <div className="text-center pb-3 border-b border-dashed border-neutral-400 dark:border-neutral-700">
                  <p className="font-black text-sm uppercase">{businessInfo.name || 'NOMBRE DEL NEGOCIO'}</p>
                  <p className="text-[10px] text-neutral-500">CUIT: {businessInfo.cuit || '30-00000000-0'}</p>
                  <p className="text-[10px] text-neutral-500">{businessInfo.address || 'DIRECCIÓN COMERCIAL'}</p>
                  <p className="text-[10px] text-neutral-500">TEL: {businessInfo.phone || '-'}</p>
                  {businessInfo.ticketHeader && (
                    <p className="text-[10px] italic mt-1 text-neutral-600 dark:text-neutral-400">"{businessInfo.ticketHeader}"</p>
                  )}
                </div>

                <div className="py-2.5 text-[11px] border-b border-dashed border-neutral-400 dark:border-neutral-700 space-y-1">
                  <div className="flex justify-between">
                    <span>1x Leche Entera 1L</span>
                    <span>$1.450,00</span>
                  </div>
                  <div className="flex justify-between">
                    <span>2x Pan de Molde 500g</span>
                    <span>$3.600,00</span>
                  </div>
                </div>

                <div className="py-2 flex justify-between font-black text-sm border-b border-dashed border-neutral-400 dark:border-neutral-700">
                  <span>TOTAL:</span>
                  <span>$5.050,00</span>
                </div>
              </div>

              <div className="pt-3 text-center text-[10px] text-neutral-500 border-t border-dashed border-neutral-400 dark:border-neutral-700 mt-4">
                <p>{businessInfo.ticketFooter || '¡Gracias por su compra!'}</p>
                <p className="text-[9px] mt-1 text-neutral-400">Terminal: {currentTerminalId} • IVA Responsable Inscripto</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Subtab 3: Nube, Hosting & Modo Offline */}
      {activeSubTab === 'CLOUD_OFFLINE' && (
        <div id="settings-cloud-view" className="space-y-6 animate-in fade-in duration-200">
          {/* Main Answer Banner to the User's Question */}
          <div className="bg-gradient-to-r from-emerald-950 via-neutral-900 to-neutral-950 text-white rounded-2xl p-6 border border-emerald-800/40 shadow-md">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-emerald-500/20 border border-emerald-500/30 rounded-xl text-emerald-400 flex-shrink-0 mt-0.5">
                <Server className="w-6 h-6" />
              </div>
              <div className="space-y-3">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 text-[11px] font-bold border border-emerald-500/30">
                  <Check className="w-3.5 h-3.5" /> Arquitectura Híbrida: Nube + Offline Total por Terminal
                </div>
                <h2 className="text-lg font-black text-white">
                  ¿Puedo subir la aplicación a un hosting y que siga funcionando si se corta internet?
                </h2>
                <p className="text-xs text-neutral-300 leading-relaxed max-w-4xl">
                  <strong>¡SÍ, TOTALMENTE!</strong> Este sistema POS fue diseñado con tecnología <strong>PWA (Progressive Web App) con enfoque Offline-First</strong>.
                  Al alojarlo en cualquier hosting web con HTTPS (como Vercel, Netlify, Cloud Run, Firebase Hosting o tu propio servidor VPS):
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                  <div className="bg-neutral-800/80 p-3.5 rounded-xl border border-neutral-700/60 text-xs">
                    <p className="font-bold text-emerald-400 flex items-center gap-1.5 mb-1">
                      <Cloud className="w-4 h-4" /> En la Nube (Con Internet)
                    </p>
                    <p className="text-neutral-300 text-[11px] leading-relaxed">
                      Accedes desde cualquier sucursal, tablet o PC con la URL. Las terminales sincronizan precios, inventario y ventas globales en tiempo real.
                    </p>
                  </div>
                  <div className="bg-neutral-800/80 p-3.5 rounded-xl border border-neutral-700/60 text-xs">
                    <p className="font-bold text-amber-400 flex items-center gap-1.5 mb-1">
                      <WifiOff className="w-4 h-4" /> Sin Internet (Corte de Red)
                    </p>
                    <p className="text-neutral-300 text-[11px] leading-relaxed">
                      Cada terminal guarda los artículos, clientes y caja en su almacenamiento local (SSD/Disco del navegador). <strong>Cobra, emite tickets y lee código de barras sin detenerse</strong>. Al volver internet, se sincroniza automáticamente.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Diagnostic Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-2xl p-4 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-neutral-500 uppercase tracking-wider">Estado de Conexión</span>
                {isOnline ? (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                    <Wifi className="w-3 h-3" /> ONLINE
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-800">
                    <WifiOff className="w-3 h-3" /> OFFLINE
                  </span>
                )}
              </div>
              <p className="text-sm font-black text-neutral-900 dark:text-white">
                {isOnline ? 'Terminal Conectada a la Red' : 'Terminal en Modo Local Autónomo'}
              </p>
              <p className="text-[11px] text-neutral-500 mt-1">
                La terminal no depende de la nube para facturar ni cobrar.
              </p>
            </div>

            <div className="bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-2xl p-4 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-neutral-500 uppercase tracking-wider">Base de Datos Local</span>
                <HardDrive className="w-4 h-4 text-neutral-400" />
              </div>
              <p className="text-sm font-black text-neutral-900 dark:text-white">
                {storageStats.articlesCount} Artículos • {storageStats.salesCount} Ventas
              </p>
              <p className="text-[11px] text-neutral-500 mt-1">
                Espacio utilizado en este dispositivo: <strong className="text-neutral-800 dark:text-neutral-200">{storageStats.usedKb} KB</strong>
              </p>
            </div>

            <div className="bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-2xl p-4 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-neutral-500 uppercase tracking-wider">Terminal Asignada</span>
                <Smartphone className="w-4 h-4 text-neutral-400" />
              </div>
              <p className="text-sm font-black text-neutral-900 dark:text-white">
                {currentTerminalId}
              </p>
              <p className="text-[11px] text-neutral-500 mt-1">
                Identificador único de arqueo de caja para este equipo.
              </p>
            </div>
          </div>

          {/* Backup & Data Synchronization Actions */}
          <div className="bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-2xl p-6 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-neutral-200 dark:border-neutral-800 pb-4">
              <div>
                <h3 className="text-base font-black text-neutral-950 dark:text-white flex items-center gap-2">
                  <HardDrive className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                  Copias de Seguridad y Traspaso de Datos
                </h3>
                <p className="text-xs text-neutral-500 dark:text-neutral-400">
                  Exporta toda la información (artículos, precios, clientes, ventas, datos de cobro) o restaura en otra terminal.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleExportBackup}
                  className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 dark:bg-emerald-600 dark:hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs"
                >
                  <Download className="w-4 h-4" />
                  Descargar Respaldo Total (.json)
                </button>

                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImportBackup}
                  accept=".json"
                  className="hidden"
                />

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2 border border-neutral-300 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-800 dark:text-neutral-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
                >
                  <Upload className="w-4 h-4 text-sky-600" />
                  Restaurar Respaldo
                </button>
              </div>
            </div>

            {backupMessage && (
              <div className={`p-3 rounded-xl text-xs font-bold flex items-center gap-2 animate-in fade-in ${
                backupMessage.type === 'success'
                  ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-900 dark:text-emerald-200 border border-emerald-300 dark:border-emerald-800'
                  : 'bg-red-100 dark:bg-red-950/60 text-red-900 dark:text-red-200 border border-red-300 dark:border-red-800'
              }`}>
                {backupMessage.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <ShieldAlert className="w-4 h-4" />}
                {backupMessage.text}
              </div>
            )}

            <div className="rounded-xl border border-sky-200 dark:border-sky-900 bg-sky-50 dark:bg-sky-950/30 p-4 space-y-3 min-w-0">
              <div className="min-w-0">
                <h4 className="font-black text-sm text-sky-950 dark:text-sky-100">Preparación segura para IndexedDB</h4>
                <p className="text-xs text-sky-900/80 dark:text-sky-200/80 mt-1">Copia y verifica catálogo, cuentas, historiales y colas offline en una base local secundaria. No cambia el almacenamiento que usa el POS ni borra el original.</p>
              </div>
              <div className="flex flex-wrap items-center gap-2 min-w-0 [&>button]:max-w-full [&>button]:whitespace-normal">
                <button type="button" disabled={ledgerMigrationBusy} onClick={handleVerifyLedgerCopies} className="shrink-0 px-4 py-2 bg-sky-700 hover:bg-sky-800 disabled:opacity-60 text-white rounded-xl text-xs font-bold">
                  {ledgerMigrationBusy ? 'Copiando y verificando…' : 'Copiar y verificar datos'}
                </button>
                <button type="button" disabled={ledgerCompareBusy} onClick={handleCompareLedgerCopies} className="shrink-0 px-4 py-2 border border-sky-700 text-sky-800 dark:text-sky-200 hover:bg-sky-100 dark:hover:bg-sky-900/40 disabled:opacity-60 rounded-xl text-xs font-bold">
                  {ledgerCompareBusy ? 'Comparando…' : 'Comparar con datos actuales'}
                </button>
                <button type="button" disabled={ledgerAuditBusy} onClick={handleAuditLedgerReadiness} className="shrink-0 px-4 py-2 border border-violet-700 text-violet-800 dark:text-violet-200 hover:bg-violet-100 dark:hover:bg-violet-900/40 disabled:opacity-60 rounded-xl text-xs font-bold">
                  {ledgerAuditBusy ? 'Auditando…' : 'Auditar preparación para migrar'}
                </button>
                <button type="button" disabled={ledgerExportBusy} onClick={handleExportLedgerBackup} className="shrink-0 px-4 py-2 border border-emerald-700 text-emerald-800 dark:text-emerald-200 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 disabled:opacity-60 rounded-xl text-xs font-bold">
                  {ledgerExportBusy ? 'Preparando respaldo…' : 'Descargar respaldo de IndexedDB'}
                </button>
                <input ref={ledgerStageFileRef} type="file" accept="application/json,.json" onChange={handleStageLedgerBackup} className="hidden" />
                <button type="button" disabled={ledgerStageBusy} onClick={() => ledgerStageFileRef.current?.click()} className="shrink-0 px-4 py-2 border border-amber-700 text-amber-800 dark:text-amber-200 hover:bg-amber-100 dark:hover:bg-amber-900/40 disabled:opacity-60 rounded-xl text-xs font-bold">
                  {ledgerStageBusy ? 'Validando respaldo…' : 'Probar restauración (sin aplicar)'}
                </button>
                <button type="button" disabled={ledgerStageCompareBusy} onClick={handleCompareStagedBackup} className="shrink-0 px-4 py-2 border border-fuchsia-700 text-fuchsia-800 dark:text-fuchsia-200 hover:bg-fuchsia-100 dark:hover:bg-fuchsia-900/40 disabled:opacity-60 rounded-xl text-xs font-bold">
                  {ledgerStageCompareBusy ? 'Comparando ensayo…' : 'Comparar ensayo con datos actuales'}
                </button>
                <button type="button" disabled={ledgerStorageDiagnosticBusy} onClick={handleDiagnoseLedgerStorage} className="shrink-0 px-4 py-2 border border-teal-700 text-teal-800 dark:text-teal-200 hover:bg-teal-100 dark:hover:bg-teal-900/40 disabled:opacity-60 rounded-xl text-xs font-bold">
                  {ledgerStorageDiagnosticBusy ? 'Midiendo almacenamiento…' : 'Diagnosticar tamaño y tiempos'}
                </button>
                <button type="button" disabled={!ledgerStorageDiagnosticResult} onClick={handleExportStorageDiagnostic} className="shrink-0 px-4 py-2 border border-cyan-700 text-cyan-800 dark:text-cyan-200 hover:bg-cyan-100 dark:hover:bg-cyan-900/40 disabled:opacity-50 rounded-xl text-xs font-bold">
                  Descargar informe Fase 24
                </button>
                <button type="button" disabled={ledgerStageAuditBusy} onClick={handleVerifyStagedLedgerBackup} className="shrink-0 px-4 py-2 border border-indigo-700 text-indigo-800 dark:text-indigo-200 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 disabled:opacity-60 rounded-xl text-xs font-bold">
                  {ledgerStageAuditBusy ? 'Verificando ensayo…' : 'Verificar respaldo en ensayo'}
                </button>
              </div>
              {ledgerStageError && <p role="alert" className="text-xs font-bold text-red-700 dark:text-red-300">No se pudo validar el respaldo: {ledgerStageError}. Los datos activos no se modificaron.</p>}
              {ledgerStorageDiagnosticError && <p role="alert" className="text-xs font-bold text-red-700 dark:text-red-300">No se pudo completar el diagnóstico: {ledgerStorageDiagnosticError}. No se modificaron datos.</p>}
              {ledgerStorageDiagnosticResult && <div className="rounded-lg border border-teal-200 dark:border-teal-900 p-3 space-y-3">
                <p className="text-xs font-bold text-neutral-800 dark:text-neutral-100">Diagnóstico de almacenamiento del POS (solo lectura)</p>
                <p className="text-xs text-neutral-700 dark:text-neutral-300">{ledgerStorageDiagnosticResult.message}</p>
                <p className="text-[11px] text-neutral-600 dark:text-neutral-400">Fase 24: descargá este informe en cada terminal para comparar tamaño local, cantidad de registros y estado de la cola. El archivo contiene métricas y nombres de claves, no el contenido de las ventas. No sincroniza ni modifica datos.</p>
                <p className="text-xs text-neutral-700 dark:text-neutral-300">Claves analizadas: {ledgerStorageDiagnosticResult.keyCount} · Contenido aproximado: {(ledgerStorageDiagnosticResult.totalApproxBytes / 1024 / 1024).toFixed(2)} MB · Tiempo total: {ledgerStorageDiagnosticResult.durationMs.toFixed(1)} ms · {new Date(ledgerStorageDiagnosticResult.measuredAt).toLocaleString()}</p>
                {ledgerStorageDiagnosticResult.browserStorageEstimate && <p className="text-xs text-neutral-600 dark:text-neutral-400">Estimación de almacenamiento del navegador (todas las aplicaciones/orígenes que contabilice el navegador): uso {ledgerStorageDiagnosticResult.browserStorageEstimate.usageBytes !== undefined ? `${(ledgerStorageDiagnosticResult.browserStorageEstimate.usageBytes / 1024 / 1024).toFixed(2)} MB` : 'no disponible'} · cuota {ledgerStorageDiagnosticResult.browserStorageEstimate.quotaBytes !== undefined ? `${(ledgerStorageDiagnosticResult.browserStorageEstimate.quotaBytes / 1024 / 1024).toFixed(2)} MB` : 'no disponible'}</p>}
                <div className="max-h-80 overflow-auto space-y-2">
                  {ledgerStorageDiagnosticResult.items.map((item) => <div key={`storage-diagnostic-${item.key}`} className="rounded-md border border-neutral-200 dark:border-neutral-700 p-2 space-y-1">
                    <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-1"><span className="font-mono break-all text-xs text-neutral-800 dark:text-neutral-200">{item.key}</span><span className={`text-xs font-bold ${item.status === 'ok' ? 'text-emerald-700 dark:text-emerald-300' : item.status === 'missing' ? 'text-neutral-600 dark:text-neutral-300' : 'text-red-700 dark:text-red-300'}`}>{item.status}</span></div>
                    <p className="text-[11px] text-neutral-600 dark:text-neutral-400">Grupo: {item.group} · Tamaño aprox.: {(item.approxBytes / 1024).toFixed(1)} KB · Lectura: {item.readMs !== undefined ? `${item.readMs.toFixed(2)} ms` : '—'} · JSON: {item.parseMs !== undefined ? `${item.parseMs.toFixed(2)} ms` : '—'}{item.records !== undefined ? ` · Registros: ${item.records}` : ''}{item.queueEntries !== undefined ? ` · Entradas en cola: ${item.queueEntries}` : ''}</p>
                    <p className="text-[11px] text-neutral-500 dark:text-neutral-400">{item.message}</p>
                  </div>)}
                </div>
                <p className="text-[11px] text-neutral-600 dark:text-neutral-400">Los tamaños por clave son estimaciones basadas en caracteres UTF-16, no una medición exacta de disco. Los tiempos incluyen la lectura de localStorage y el análisis JSON de cada clave; no se escribieron ni borraron datos.</p>
              </div>}
              {ledgerStageCompareError && <p role="alert" className="text-xs font-bold text-red-700 dark:text-red-300">No se pudo comparar el ensayo: {ledgerStageCompareError}. No se modificaron datos.</p>}
              {ledgerStageCompareResults && <div className="rounded-lg border border-fuchsia-200 dark:border-fuchsia-900 p-3 space-y-2">
                <p className="text-xs font-bold text-neutral-800 dark:text-neutral-100">Comparación del respaldo de ensayo con el POS actual (solo lectura)</p>
                {ledgerStageCompareResults.map((item) => <div key={`stage-compare-${item.key}`} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1 text-xs">
                  <span className="font-mono break-all text-neutral-800 dark:text-neutral-200">{item.key}</span>
                  <span className={item.status === 'same' ? 'font-bold text-emerald-700 dark:text-emerald-300' : 'font-bold text-amber-700 dark:text-amber-300'}>{item.status}</span>
                  <span className="text-neutral-500 dark:text-neutral-400">{item.message}</span>
                </div>)}
                <p className="text-[11px] text-neutral-600 dark:text-neutral-400">“different” no significa pérdida de datos: el respaldo puede ser de una fecha anterior. Esta comparación no restaura, sobrescribe ni borra información.</p>
              </div>}
              {ledgerStageAuditError && <p role="alert" className="text-xs font-bold text-red-700 dark:text-red-300">No se pudo verificar el área de ensayo: {ledgerStageAuditError}. Los datos activos no se modificaron.</p>}
              {ledgerStageAuditResult && <div className={`rounded-lg border p-3 space-y-1 ${ledgerStageAuditResult.errors.length === 0 ? 'border-emerald-300 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/20' : 'border-amber-300 dark:border-amber-900 bg-amber-50 dark:bg-amber-950/20'}`}>
                <p className="text-xs font-bold text-neutral-900 dark:text-neutral-100">Verificación persistente del área de ensayo</p>
                <p className="text-xs text-neutral-800 dark:text-neutral-200">{ledgerStageAuditResult.message}</p>
                <p className="text-xs text-neutral-700 dark:text-neutral-300">Claves leídas: {ledgerStageAuditResult.count} · Tamaño aproximado de contenidos: {Math.round(ledgerStageAuditResult.bytes / 1024)} KB · {new Date(ledgerStageAuditResult.checkedAt).toLocaleString()}</p>
                {ledgerStageAuditResult.errors.map((error, index) => <p key={`${index}-${error}`} className="text-xs font-bold text-amber-800 dark:text-amber-200">{error}</p>)}
              </div>}
              {ledgerStageResult && <div className="rounded-lg border border-amber-300 dark:border-amber-900 bg-amber-50 dark:bg-amber-950/20 p-3 space-y-1">
                <p className="text-xs font-bold text-amber-900 dark:text-amber-100">Ensayo de restauración completado sin aplicar cambios</p>
                <p className="text-xs text-amber-900/90 dark:text-amber-200">{ledgerStageResult.message}</p>
                <p className="text-xs text-amber-900/90 dark:text-amber-200">Claves verificadas: {ledgerStageResult.count} · Tamaño del archivo: {Math.round(ledgerStageResult.bytes / 1024)} KB · {new Date(ledgerStageResult.importedAt).toLocaleString()}</p>
                <div className="max-h-28 overflow-auto text-[11px] font-mono text-amber-900 dark:text-amber-200">{ledgerStageResult.keys.map((key) => <div key={key}>{key}</div>)}</div>
              </div>}
              {ledgerMigrationError && <p role="alert" className="text-xs font-bold text-red-700 dark:text-red-300">No se pudo completar la copia: {ledgerMigrationError}. Los datos originales se conservaron.</p>}
              {ledgerCompareError && <p role="alert" className="text-xs font-bold text-red-700 dark:text-red-300">No se pudo comparar la copia: {ledgerCompareError}. No se modificó ningún dato.</p>}
              {ledgerExportError && <p role="alert" className="text-xs font-bold text-red-700 dark:text-red-300">No se pudo descargar el respaldo: {ledgerExportError}. No se modificó ningún dato.</p>}
              {ledgerAuditError && <p role="alert" className="text-xs font-bold text-red-700 dark:text-red-300">No se pudo auditar la preparación: {ledgerAuditError}. No se modificó ningún dato.</p>}
              {ledgerAuditResults && <div className="space-y-2 rounded-lg border border-violet-200 dark:border-violet-900 p-3">
                <p className="text-xs font-bold text-neutral-800 dark:text-neutral-100">Auditoría de preparación para migrar (solo lectura):</p>
                {ledgerAuditResults.map((item) => <div key={`audit-${item.key}`} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1 text-xs">
                  <span className="font-mono break-all text-neutral-800 dark:text-neutral-200">{item.key}</span>
                  <span className={item.status === 'verified' ? 'font-bold text-emerald-700 dark:text-emerald-300' : item.status === 'stale' ? 'font-bold text-amber-700 dark:text-amber-300' : item.status === 'missing' ? 'font-bold text-neutral-600 dark:text-neutral-300' : 'font-bold text-red-700 dark:text-red-300'}>{item.status}{item.records !== undefined ? ` · ${item.records} registros` : ''}{item.bytes !== undefined ? ` · ${Math.round(item.bytes / 1024)} KB` : ''}</span>
                  {item.message && <span className="text-neutral-500 dark:text-neutral-400">{item.message}</span>}
                </div>)}
                <p className="text-[11px] text-neutral-600 dark:text-neutral-400">Antes de migrar, todas las claves requeridas deben revisarse. “missing”, “stale” o “error” requieren análisis; la auditoría no borra ni corrige datos.</p>
              </div>}
              {ledgerCompareResults && <div className="space-y-2 rounded-lg border border-sky-200 dark:border-sky-900 p-3">
                <p className="text-xs font-bold text-neutral-800 dark:text-neutral-100">Comparación de la copia con los datos actuales (solo lectura):</p>
                {ledgerCompareResults.map((item) => <div key={`compare-${item.key}`} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1 text-xs">
                  <span className="font-mono break-all text-neutral-800 dark:text-neutral-200">{item.key}</span>
                  <span className={item.status === 'verified' ? 'font-bold text-emerald-700 dark:text-emerald-300' : item.status === 'stale' ? 'font-bold text-amber-700 dark:text-amber-300' : item.status === 'missing' ? 'font-bold text-neutral-600 dark:text-neutral-300' : 'font-bold text-red-700 dark:text-red-300'}>{item.status}{item.records !== undefined ? ` · ${item.records} registros` : ''}</span>
                  {item.message && <span className="text-neutral-500 dark:text-neutral-400">{item.message}</span>}
                </div>)}
                <p className="text-[11px] text-neutral-600 dark:text-neutral-400">Si aparece “stale”, la copia no coincide con el origen actual. Esta comparación no sobrescribe ni borra nada.</p>
              </div>}
              {ledgerMigrationResults && <div className="space-y-2">
                <p className="text-xs font-bold text-neutral-800 dark:text-neutral-100">Resultado por conjunto de datos:</p>
                <div className="max-h-64 overflow-auto rounded-lg border border-sky-200 dark:border-sky-900">
                  {ledgerMigrationResults.map((item) => <div key={item.key} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1 px-3 py-2 border-b last:border-b-0 border-sky-100 dark:border-sky-900 text-xs">
                    <span className="font-mono break-all text-neutral-800 dark:text-neutral-200">{item.key}</span>
                    <span className={item.status === 'verified' ? 'font-bold text-emerald-700 dark:text-emerald-300' : item.status === 'missing' ? 'font-bold text-amber-700 dark:text-amber-300' : 'font-bold text-red-700 dark:text-red-300'}>{item.status}{item.records !== undefined ? ` · ${item.records} registros` : ''}{item.bytes !== undefined ? ` · ${Math.round(item.bytes / 1024)} KB` : ''}</span>
                    {item.message && <span className="text-neutral-500 dark:text-neutral-400">{item.message}</span>}
                  </div>)}
                </div>
                <p className="text-[11px] text-neutral-600 dark:text-neutral-400">Esta es solo una copia de prueba. No habilita aún el uso de IndexedDB para ventas ni sincronización. Repetí la prueba en cada terminal por separado.</p>
              </div>}
            </div>

            {/* Destructive action: coordinated reset of every terminal on this sync channel. */}
            <section className="rounded-2xl border-2 border-red-300 dark:border-red-900 bg-red-50 dark:bg-red-950/20 p-5 space-y-3">
              <div className="flex items-start gap-3">
                <div className="rounded-xl bg-red-100 dark:bg-red-950 p-3 text-red-700 dark:text-red-300"><RotateCcw className="w-6 h-6" /></div>
                <div className="flex-1 min-w-0 space-y-1">
                  <h3 className="font-black text-red-900 dark:text-red-200">Restaurar de fábrica — todas las terminales</h3>
                  <p className="text-xs leading-relaxed text-red-900/90 dark:text-red-200/90">Borra los datos comerciales y configuraciones personalizadas de este canal compartido y devuelve las terminales vinculadas a los datos de demostración. Requiere Internet y debe iniciarse desde TERM-01. Se conservan la vinculación y los tokens para que las cajas sigan sincronizadas.</p>
                  <p className="text-xs font-bold text-red-900 dark:text-red-200">Se eliminarán ventas, compras, cuentas corrientes, caja, historial, artículos agregados y usuarios personalizados. No se puede deshacer.</p>
                </div>
              </div>
              <button type="button" disabled={factoryResetBusy || !isOnline || !hasPermission('canManageSettings')} onClick={handleFactoryReset} className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-xl bg-red-700 hover:bg-red-800 disabled:opacity-50 text-white px-5 py-3 text-sm font-black shadow-sm">
                <RotateCcw className={`w-4 h-4 ${factoryResetBusy ? 'animate-spin' : ''}`} />
                {factoryResetBusy ? 'Restaurando todas las terminales…' : 'Restaurar de fábrica en todas las terminales'}
              </button>
              {!isOnline && <p className="text-xs font-bold text-amber-800 dark:text-amber-300">Necesitás conexión a Internet para realizar la restauración coordinada.</p>}
              {factoryResetError && <p role="alert" className="text-xs font-bold text-red-800 dark:text-red-300">{factoryResetError}</p>}
            </section>

            {/* Hosting guide instructions */}
            <div className="bg-neutral-50 dark:bg-neutral-800/50 p-4 rounded-xl border border-neutral-200 dark:border-neutral-700 text-xs space-y-2">
              <h4 className="font-bold text-neutral-900 dark:text-white flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4 text-sky-600" />
                Pasos recomendados para desplegar en tu hosting:
              </h4>
              <ol className="list-decimal list-inside space-y-1.5 text-neutral-600 dark:text-neutral-300 leading-relaxed">
                <li>
                  <strong>Compilación de producción:</strong> Ejecuta <code className="bg-neutral-200 dark:bg-neutral-700 px-1.5 py-0.5 rounded font-mono text-[11px]">npm run build</code> para generar la carpeta de archivos estáticos optimizados (<code className="bg-neutral-200 dark:bg-neutral-700 px-1.5 py-0.5 rounded font-mono text-[11px]">dist/</code>).
                </li>
                <li>
                  <strong>Subida al servidor:</strong> Puedes subir el contenido a plataformas modernas como Vercel, Netlify, Cloud Run, Firebase Hosting o tu propio hosting cPanel/Apache/Nginx.
                </li>
                <li>
                  <strong>Certificado SSL (HTTPS):</strong> Asegúrate de que el hosting tenga HTTPS activo (gratuito con Let's Encrypt o Cloudflare). HTTPS es un requisito obligatorio del navegador para permitir el funcionamiento del lector de código de barras por cámara y el modo Offline con Service Workers.
                </li>
                <li>
                  <strong>Instalación en la terminal:</strong> En cada PC o tablet del negocio, abre la URL en Google Chrome o Edge y haz clic en <em>"Instalar aplicación"</em> (ícono de pantalla con flecha en la barra de direcciones) para ejecutarla como un programa de escritorio nativo.
                </li>
              </ol>
            </div>
          </div>
        </div>
      )}

      {/* Ticket de Prueba para Impresión Real */}
      <div id="test-ticket-print-area" className="hidden print:block print:w-full">
        <div className={`thermal-ticket-container ${printerConfig.paperWidth === '58mm' ? 'thermal-ticket-58mm' : ''}`}>
          <div style={{ textAlign: 'center', borderBottom: '1px dashed #000', paddingBottom: '6px' }}>
            <h2 style={{ fontSize: '14px', fontWeight: '900', margin: '0', textTransform: 'uppercase' }}>
              {businessInfo.name || 'COMERCIO CENTRAL'}
            </h2>
            <p style={{ margin: '2px 0', fontSize: '10px' }}>CUIT: {businessInfo.cuit || '30-00000000-0'}</p>
            <p style={{ margin: '2px 0', fontSize: '10px' }}>{businessInfo.address || 'Dirección Comercial'}</p>
            <p style={{ margin: '2px 0', fontSize: '10px' }}>TEL: {businessInfo.phone || '-'}</p>
            {(printerConfig.headerText || businessInfo.ticketHeader) && (
              <p style={{ margin: '4px 0', fontStyle: 'italic', fontSize: '10px' }}>"{printerConfig.headerText || businessInfo.ticketHeader}"</p>
            )}
          </div>

          <div style={{ padding: '6px 0', borderBottom: '1px dashed #000', fontSize: '10px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>COMPROBANTE PRUEBA</span>
              <span>{new Date().toLocaleDateString('es-AR')} {new Date().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>TERMINAL: {currentTerminalId}</span>
              <span>IMPRESORA: OK</span>
            </div>
          </div>

          <div style={{ padding: '6px 0', borderBottom: '1px dashed #000' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>1x Prueba de Ticket Térmico</span>
              <span>$100,00</span>
            </div>
          </div>

          <div style={{ padding: '6px 0', borderBottom: '1px dashed #000', fontWeight: 'bold', fontSize: '13px', display: 'flex', justifyContent: 'space-between' }}>
            <span>TOTAL:</span>
            <span>$100,00</span>
          </div>

          <div style={{ textAlign: 'center', paddingTop: '8px', fontSize: '10px' }}>
            <p style={{ margin: '2px 0' }}>{printerConfig.footerText || businessInfo.ticketFooter || '¡Gracias por su compra!'}</p>
            {printerConfig.printBarcode && (
              <div style={{ margin: '6px 0', fontFamily: 'monospace', letterSpacing: '4px' }}>
                ||| | | |||| | ||| | |||
              </div>
            )}
            <p style={{ margin: '4px 0', fontSize: '9px', textTransform: 'uppercase' }}>*** TICKET DE PRUEBA DE IMPRESORA ***</p>
          </div>
        </div>
      </div>
    </div>
  );
};
