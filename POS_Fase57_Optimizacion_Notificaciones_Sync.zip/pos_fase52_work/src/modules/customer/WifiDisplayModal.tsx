import React, { useState, useEffect } from 'react';
import { 
  X, 
  Wifi, 
  Copy, 
  Check, 
  ExternalLink, 
  Smartphone, 
  Tablet, 
  ShieldCheck,
  QrCode,
  Monitor
} from 'lucide-react';
import { CloudSync } from '../../services/cloudSync';
import { StorageService } from '../../services/storage';
import { getHostPeerId } from '../../services/peerSync';

interface WifiDisplayModalProps {
  isOpen: boolean;
  onClose: () => void;
  terminalId?: string;
}

export const WifiDisplayModal: React.FC<WifiDisplayModalProps> = ({
  isOpen,
  onClose,
  terminalId,
}) => {
  const [copied, setCopied] = useState(false);
  const [networkIps, setNetworkIps] = useState<string[]>([]);
  const [selectedIp, setSelectedIp] = useState<string>('');
  const [customIpInput, setCustomIpInput] = useState<string>('');
  const [terminalsList, setTerminalsList] = useState(() => StorageService.getTerminals());
  const [selectedTerminal, setSelectedTerminal] = useState<string>(() => {
    return terminalId || StorageService.getCurrentTerminalId() || 'TERM-01';
  });

  useEffect(() => {
    if (!isOpen) return;
    setTerminalsList(StorageService.getTerminals());
    const currentActive = terminalId || StorageService.getCurrentTerminalId() || 'TERM-01';
    setSelectedTerminal(currentActive);
  }, [isOpen, terminalId]);

  useEffect(() => {
    if (!isOpen) return;
    const isLocalhost = typeof window !== 'undefined' && 
      (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1');

    if (isLocalhost) {
      fetch('/api/wifi-info')
        .then(res => res.json())
        .then(data => {
          if (Array.isArray(data.ips)) {
            const validIps = data.ips.filter((ip: string) => 
              typeof ip === 'string' && 
              !ip.startsWith('169.254.') && 
              !ip.startsWith('127.')
            );
            if (validIps.length > 0) {
              setNetworkIps(validIps);
              setSelectedIp(validIps[0]);
              setCustomIpInput(validIps[0]);
            }
          }
        })
        .catch(() => {});
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const isLocalhost = typeof window !== 'undefined' && 
    (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1');

  const portPart = typeof window !== 'undefined' && window.location.port ? `:${window.location.port}` : '';
  const effectiveHost = (isLocalhost && (customIpInput || selectedIp)) 
    ? `${customIpInput || selectedIp}${portPart}` 
    : (typeof window !== 'undefined' ? window.location.host : '');

  const protocol = typeof window !== 'undefined' ? window.location.protocol : 'http:';
  const pathname = typeof window !== 'undefined' ? window.location.pathname : '/';

  const channelParam = encodeURIComponent(CloudSync.getChannelId());
  const termParam = encodeURIComponent(selectedTerminal);
  const hostPeerId = getHostPeerId(selectedTerminal);
  const displayUrl = `${protocol}//${effectiveHost}${pathname}?customer_display=true&terminal=${termParam}&peer=${encodeURIComponent(hostPeerId)}&channel=${channelParam}`;

  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=260x260&margin=10&data=${encodeURIComponent(displayUrl)}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(displayUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
      <div className="bg-white dark:bg-neutral-900 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-neutral-200 dark:border-neutral-700 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 bg-neutral-900 text-white flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-neutral-800 rounded-lg text-emerald-400">
              <Wifi className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base tracking-tight">Conectar 2da Pantalla por Wi-Fi</h3>
              <p className="text-xs text-neutral-400">
                Usa una tablet, celular u otra pantalla conectada al Wi-Fi del local
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1 rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs">
          {/* Terminal Selection */}
          <div className="p-3 bg-neutral-100 dark:bg-neutral-800/80 rounded-xl border border-neutral-200 dark:border-neutral-700 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-900/60 flex items-center justify-center text-indigo-600 dark:text-indigo-400 flex-shrink-0">
                <Monitor className="w-4 h-4" />
              </div>
              <div className="truncate">
                <span className="text-[11px] font-bold text-neutral-900 dark:text-neutral-100 block">
                  Terminal de Caja a Sincronizar:
                </span>
                <span className="text-[10px] text-neutral-500 dark:text-neutral-400">
                  El celular recibirá en vivo los precios de esta terminal
                </span>
              </div>
            </div>
            <select
              value={selectedTerminal}
              onChange={(e) => setSelectedTerminal(e.target.value)}
              className="text-xs font-bold bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-600 text-neutral-900 dark:text-white rounded-lg px-2.5 py-1.5 shadow-xs focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            >
              {terminalsList.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name} ({t.id})
                </option>
              ))}
            </select>
          </div>

          <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl text-emerald-900 dark:text-emerald-200 text-xs leading-relaxed flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-900/60 flex items-center justify-center text-emerald-600 dark:text-emerald-300 flex-shrink-0">
              <Tablet className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold">Sincronización Inalámbrica Activa:</span> Cualquier dispositivo en tu red Wi-Fi que abra este enlace mostrará los productos y totales en vivo mientras cobras.
            </div>
          </div>

          {/* QR Code Center Box */}
          <div className="flex flex-col items-center justify-center p-4 bg-neutral-50 dark:bg-neutral-800/60 rounded-2xl border border-neutral-200 dark:border-neutral-700 text-center space-y-3">
            <span className="text-[11px] font-bold text-neutral-600 dark:text-neutral-300 uppercase tracking-wide flex items-center gap-1.5">
              <QrCode className="w-3.5 h-3.5 text-emerald-600" />
              Escanea este código con tu Tablet o Celular
            </span>

            <div className="p-3 bg-white rounded-xl shadow-xs border border-neutral-200 inline-block">
              <img
                src={qrCodeUrl}
                alt="QR Conexión Wi-Fi Segunda Pantalla"
                className="w-48 h-48 object-contain"
              />
            </div>

            <p className="text-[11px] text-neutral-500 dark:text-neutral-400 max-w-xs">
              Apunta la cámara de tu tablet o celular al código para abrir la pantalla de cliente al instante.
            </p>
          </div>

          {/* Direct URL input */}
          {isLocalhost && (
            <div className="p-3 bg-neutral-100 dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-neutral-700 dark:text-neutral-300">
                  IP Wi-Fi de esta PC en la red local:
                </span>
                {networkIps.length > 1 && (
                  <select
                    value={selectedIp}
                    onChange={(e) => {
                      setSelectedIp(e.target.value);
                      setCustomIpInput(e.target.value);
                    }}
                    className="text-[11px] bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-600 rounded px-1.5 py-0.5"
                  >
                    {networkIps.map(ip => <option key={ip} value={ip}>{ip}</option>)}
                  </select>
                )}
              </div>
              <div className="flex gap-2 items-center">
                <input
                  type="text"
                  value={customIpInput}
                  onChange={(e) => setCustomIpInput(e.target.value.trim())}
                  placeholder="Ej: 192.168.1.50"
                  className="flex-1 px-2.5 py-1.5 text-xs bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-600 rounded-lg font-mono font-bold text-neutral-900 dark:text-white"
                />
                <span className="text-xs text-neutral-500 font-mono font-bold">{portPart || ':3000'}</span>
              </div>
              <p className="text-[10px] text-neutral-500 dark:text-neutral-400">
                La tablet o celular se conectará directamente a esta IP a través de la red Wi-Fi del local.
              </p>
            </div>
          )}

          <div>
            <label className="block text-[11px] font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wide mb-1">
              Enlace directo para el navegador de la Tablet:
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                readOnly
                value={displayUrl}
                className="flex-1 px-3 py-2 bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl font-mono text-xs font-bold text-neutral-900 dark:text-white"
              />
              <button
                type="button"
                onClick={handleCopy}
                className="px-3 py-2 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl font-bold flex items-center gap-1.5 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? '¡Copiado!' : 'Copiar'}
              </button>
            </div>
          </div>

          {/* Quick Steps */}
          <div className="space-y-1.5 pt-1">
            <h4 className="font-bold text-neutral-900 dark:text-neutral-100 uppercase text-[11px]">
              Instrucciones paso a paso:
            </h4>
            <ol className="list-decimal pl-4 space-y-1 text-neutral-600 dark:text-neutral-300 text-[11px]">
              <li>Asegúrate de que la tablet o teléfono esté conectado al <strong>mismo Wi-Fi</strong> que este computador.</li>
              <li>Escanea el código QR o ingresa la URL en Chrome / Safari.</li>
              <li>Coloca la tablet en el mostrador apuntando hacia el cliente (¡puedes ponerla en pantalla completa F11!).</li>
              <li>¡Listo! Cada artículo escaneado y método de pago se sincroniza automáticamente.</li>
            </ol>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-200 dark:border-neutral-800 flex items-center justify-between">
          <div className="text-[11px] text-neutral-500 dark:text-neutral-400 flex items-center gap-1">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            Conexión local segura en red
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => window.open(displayUrl, '_blank')}
              className="px-3.5 py-2 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 rounded-xl font-bold flex items-center gap-1.5 transition-colors"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              Probar en nueva pestaña
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl font-bold transition-colors"
            >
              Listo
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
