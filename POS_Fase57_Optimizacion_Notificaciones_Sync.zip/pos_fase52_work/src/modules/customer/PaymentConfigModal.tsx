import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  X, 
  Save, 
  Building2, 
  QrCode, 
  CreditCard, 
  Check, 
  Copy, 
  ShieldCheck,
  Wallet,
  Upload,
  Image as ImageIcon,
  Trash2,
  AlertCircle,
  Plus,
  Edit3,
  Camera,
  CheckCircle2,
  ExternalLink,
  Sparkles,
  Eye,
  EyeOff,
  Radio,
  RefreshCw,
  Zap
} from 'lucide-react';
import { StorageService } from '../../services/storage';
import { PaymentConfig, VirtualWallet } from '../../types';
import { MercadoPagoService } from '../../services/mercadoPagoService';
import { generateArgentinaInteroperableQr } from '../../utils/emvco';
import { decodeQrFromImage } from '../../utils/qrScanner';
import jsQR from 'jsqr';
import { DialogService } from '../../services/dialog';

interface PaymentConfigModalProps {
  isOpen?: boolean;
  onClose?: () => void;
  onSaved?: (newConfig: PaymentConfig) => void;
  embedded?: boolean;
}

const WALLET_PRESETS = [
  { name: 'Ualá', color: 'bg-red-600', placeholderAlias: 'TU.NEGOCIO.UALA' },
  { name: 'Personal Pay', color: 'bg-sky-600', placeholderAlias: 'TU.NEGOCIO.PAY' },
  { name: 'MODO', color: 'bg-emerald-600', placeholderAlias: 'TU.NEGOCIO.MODO' },
  { name: 'Naranja X', color: 'bg-amber-600', placeholderAlias: 'TU.NEGOCIO.NX' },
  { name: 'Brubank', color: 'bg-violet-600', placeholderAlias: 'TU.NEGOCIO.BRU' },
  { name: 'Belo', color: 'bg-purple-600', placeholderAlias: 'TU.NEGOCIO.BELO' },
  { name: 'Lemon Cash', color: 'bg-lime-600', placeholderAlias: 'TU.NEGOCIO.LEM' },
  { name: 'Astropay', color: 'bg-orange-600', placeholderAlias: 'TU.NEGOCIO.ASTRO' },
];

export const PaymentConfigModal: React.FC<PaymentConfigModalProps> = ({
  isOpen = false,
  onClose = () => {},
  onSaved,
  embedded = false,
}) => {
  const [config, setConfig] = useState<PaymentConfig>(StorageService.getPaymentConfig());
  const [activeTab, setActiveTab] = useState<'MP' | 'POSNET' | 'BANK'>('MP');
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Posnet Test State
  const [testingPosnet, setTestingPosnet] = useState(false);
  const [posnetTestResult, setPosnetTestResult] = useState<string | null>(null);

  // Multiple Wallets State (retrocompatibilidad)
  const [wallets, setWallets] = useState<VirtualWallet[]>([]);
  const [isEditingWallet, setIsEditingWallet] = useState(false);
  const [walletForm, setWalletForm] = useState<Partial<VirtualWallet>>({
    name: 'Ualá',
    alias: '',
    cvu: '',
    holder: '',
    color: 'bg-red-600',
  });

  // Mercado Pago Real-Time API Connection State
  const [isVerifyingMp, setIsVerifyingMp] = useState(false);
  const [mpVerifyResult, setMpVerifyResult] = useState<{ success: boolean; message: string; details?: any } | null>(null);
  const [showAccessToken, setShowAccessToken] = useState(false);
  const [availablePosList, setAvailablePosList] = useState<Array<{ id: number | string; name: string; externalId?: string; storeId?: number | string; qrImage?: string; qrData?: string }>>([]);

  // Camera Scanner for MP Placard
  const [isScanningCamera, setIsScanningCamera] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animFrameRef = useRef<number | null>(null);

  // File upload refs
  const mpFileRef = useRef<HTMLInputElement>(null);
  const walletFileRef = useRef<HTMLInputElement>(null);

  const stopCamera = useCallback(() => {
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    setIsScanningCamera(false);
  }, []);

  useEffect(() => {
    if (isOpen || embedded) {
      const currentConfig = StorageService.getPaymentConfig();
      setConfig(currentConfig);
      setWallets(currentConfig.wallets || []);
      setSavedSuccess(false);
      setIsEditingWallet(false);
    } else {
      stopCamera();
    }
  }, [isOpen, embedded, stopCamera]);

  // Clean up camera on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, [stopCamera]);

  const handleVerifyMpConnection = async () => {
    if (!config.mpAccessToken) {
      DialogService.alert('Por favor pega tu Access Token de Mercado Pago (empieza con APP_USR-...)', 'Access Token Requerido', 'warning');
      return;
    }
    setIsVerifyingMp(true);
    setMpVerifyResult(null);

    const result = await MercadoPagoService.verifyCredentials(
      config.mpAccessToken,
      config.mpUserId,
      config.mpPosId
    );

    setIsVerifyingMp(false);
    if (result.success && result.user) {
      if (result.posList && result.posList.length > 0) {
        setAvailablePosList(result.posList);
      }

      const typedPosId = (config.mpPosId || '').trim();
      let matchingPos = undefined;

      // 1. Priorizar búsqueda exacta por el ID o nombre que ingresó el usuario
      if (typedPosId && result.posList && result.posList.length > 0) {
        matchingPos = result.posList.find(p => 
          String(p.id) === typedPosId || 
          String(p.externalId) === typedPosId ||
          (p.name && p.name.trim().toLowerCase() === typedPosId.toLowerCase())
        );
      }

      // 2. Si no se especificó ID o no hubo coincidencia directa, buscar por nombre de caja
      if (!matchingPos && config.mpPosName && result.posList) {
        const targetName = config.mpPosName.trim().toLowerCase();
        matchingPos = result.posList.find(p => p.name && p.name.trim().toLowerCase() === targetName);
      }

      // Mercado Pago in-store requiere el external_id de la caja para transmitir órdenes
      const resolvedPosId = matchingPos 
        ? String(matchingPos.externalId || matchingPos.id)
        : (typedPosId || (result.posList?.[0] ? String(result.posList[0].externalId || result.posList[0].id) : 'default'));

      const resolvedPosName = matchingPos?.name || (typedPosId ? (matchingPos?.name || `Caja ${typedPosId}`) : (result.posList?.[0]?.name || config.mpPosName || 'Caja Principal'));
      const resolvedHolder = result.user.nickname || `${result.user.firstName || ''} ${result.user.lastName || ''}`.trim() || config.mpHolder;

      // Actualizar diccionario de QRs por caja (mpPosQrs)
      const posQrsMap: Record<string, { qrImage?: string; qrData?: string; qrText?: string; posName?: string }> = {
        ...(config.mpPosQrs || {})
      };

      if (result.posList && result.posList.length > 0) {
        for (const p of result.posList) {
          const key = String(p.id);
          const extKey = p.externalId ? String(p.externalId) : null;
          const existing = posQrsMap[key] || (extKey ? posQrsMap[extKey] : undefined);
          const entry = {
            posName: p.name,
            qrImage: existing?.qrImage || p.qrImage || '',
            qrData: p.qrData || existing?.qrData || '',
            qrText: p.qrData || existing?.qrText || '',
          };
          posQrsMap[key] = entry;
          if (extKey) posQrsMap[extKey] = entry;
        }
      }

      // Si la caja anterior era diferente y tenía una foto, asegurarse de guardarla bajo la caja anterior
      if (config.mpPosId && config.mpQrImage && !posQrsMap[config.mpPosId]?.qrImage) {
        posQrsMap[config.mpPosId] = {
          posName: config.mpPosName || 'Caja Anterior',
          qrImage: config.mpQrImage,
          qrData: config.mpQrData,
          qrText: config.mpQrText
        };
      }

      // Para la caja seleccionada actualmente:
      const existingForThisCaja = posQrsMap[resolvedPosId] || (matchingPos ? posQrsMap[String(matchingPos.id)] : undefined);
      const isSwitchingCaja = config.mpPosId && resolvedPosId !== config.mpPosId;
      const resolvedQrImage = existingForThisCaja?.qrImage || matchingPos?.qrImage || (isSwitchingCaja ? '' : config.mpQrImage);
      const resolvedQrData = existingForThisCaja?.qrData || matchingPos?.qrData || (isSwitchingCaja ? '' : config.mpQrData);

      const updated: PaymentConfig = {
        ...config,
        mpConnected: true,
        mpAutoSync: true,
        mpUserId: String(result.user.id),
        mpHolder: resolvedHolder,
        mpPosId: resolvedPosId,
        mpPosName: resolvedPosName,
        mpStoreId: matchingPos?.storeId || config.mpStoreId,
        mpQrImage: resolvedQrImage,
        mpQrData: resolvedQrData,
        mpQrText: resolvedQrData || config.mpQrText,
        mpPosQrs: posQrsMap,
      };

      setConfig(updated);
      StorageService.savePaymentConfig(updated);
      setMpVerifyResult({
        success: true,
        message: `¡Conexión Exitosa con Mercado Pago! Usuario: ${result.user.nickname || result.user.email}. Caja vinculada: ${resolvedPosName} (ID: ${resolvedPosId}).`,
      });
      DialogService.alert(
        `¡Conexión Exitosa con Mercado Pago!\n\n• Titular: ${resolvedHolder}\n• Caja vinculada: ${resolvedPosName} (ID: ${resolvedPosId})\n• Sincronización automática activada.`,
        'Mercado Pago Conectado',
        'success'
      );
    } else {
      setMpVerifyResult({
        success: false,
        message: result.error || 'No se pudo conectar con Mercado Pago. Verifica tu Access Token.',
      });
      DialogService.alert(result.error || 'Error al conectar con Mercado Pago. Verifica las credenciales.', 'Error de Conexión', 'error');
    }
  };

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const startCameraScanner = async () => {
    setCameraError(null);
    setIsScanningCamera(true);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        await videoRef.current.play();
        requestScanFrame();
      }
    } catch (err: any) {
      console.error('Error al acceder a la cámara:', err);
      setCameraError('No se pudo acceder a la cámara. Revisa los permisos de tu navegador o sube una imagen del QR.');
      setIsScanningCamera(false);
    }
  };

  const requestScanFrame = () => {
    if (!videoRef.current || videoRef.current.readyState !== videoRef.current.HAVE_ENOUGH_DATA) {
      animFrameRef.current = requestAnimationFrame(requestScanFrame);
      return;
    }

    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const code = jsQR(imageData.data, imageData.width, imageData.height, {
        inversionAttempts: 'attemptBoth',
      });

      if (code && code.data) {
        // Successfully detected QR from physical stand
        setConfig(prev => ({
          ...prev,
          mpQrText: code.data,
        }));
        stopCamera();
        DialogService.alert(`¡Código QR de Mercado Pago detectado con éxito!\n\nPayload: ${code.data.slice(0, 60)}...`, 'QR Detectado', 'success');
        return;
      }
    }

    animFrameRef.current = requestAnimationFrame(requestScanFrame);
  };

  // Upload MP QR image and decode it
  const handleMpImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      DialogService.alert('La imagen no debe superar los 5 MB.', 'Archivo Demasiado Pesado', 'warning');
      return;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = reader.result as string;
      const decoded = await decodeQrFromImage(dataUrl);

      const curKey = config.mpPosId || 'default';
      const updatedPosQrs = { ...(config.mpPosQrs || {}) };
      const keysToUpdate = Array.from(new Set([curKey, 'TERM-01', 'TERM-02', 'TERM-03', '1', '2', '3', 'default']));
      keysToUpdate.forEach(k => {
        updatedPosQrs[k] = {
          posName: updatedPosQrs[k]?.posName || config.mpPosName || 'Caja Actual',
          qrImage: dataUrl,
          qrData: decoded || updatedPosQrs[k]?.qrData || config.mpQrData || '',
          qrText: decoded || updatedPosQrs[k]?.qrText || config.mpQrText || '',
        };
      });

      const updatedConfig: PaymentConfig = {
        ...config,
        mpQrImage: dataUrl,
        mpQrData: decoded || config.mpQrData || '',
        mpQrText: decoded || config.mpQrText || '',
        mpPosQrs: updatedPosQrs,
      };

      setConfig(updatedConfig);
      StorageService.savePaymentConfig(updatedConfig);
      if (onSaved) onSaved(updatedConfig);
      setSavedSuccess(true);

      if (decoded) {
        DialogService.alert('¡Código QR de Mercado Pago leído y guardado correctamente!\nYa está activo para cobrar en ventas y segunda pantalla.', 'QR Guardado', 'success');
      } else {
        DialogService.alert('¡Imagen de cartel guardada con éxito!\nYa está activa para cobrar en ventas y se mostrará en pantalla.', 'Imagen Guardada', 'success');
      }
    };
    reader.readAsDataURL(file);
  };

  // Generate official interoperable Transferencias 3.0 QR for Mercado Pago
  const handleGenerateInteroperableMpQr = () => {
    const aliasToUse = config.mpAlias?.trim() || 'MANUELSILVA2003.MP';
    const holderToUse = config.mpHolder?.trim() || 'MERCADO PAGO COMERCIO';
    const cvuToUse = config.mpCvu?.trim() || '0000003100084920194820';

    const generated = generateArgentinaInteroperableQr({
      merchantName: holderToUse,
      cvuOrCbu: cvuToUse,
      alias: aliasToUse,
    });

    const curPosId = config.mpPosId || 'default';
    const updatedPosQrs = { ...(config.mpPosQrs || {}) };
    const keysToUpdate = Array.from(new Set([curPosId, 'TERM-01', 'TERM-02', 'TERM-03', '1', '2', '3', 'default']));
    keysToUpdate.forEach(k => {
      updatedPosQrs[k] = {
        posName: updatedPosQrs[k]?.posName || config.mpPosName || 'Caja Actual',
        qrImage: '',
        qrData: generated,
        qrText: generated,
      };
    });

    const updatedConfig: PaymentConfig = {
      ...config,
      mpAlias: aliasToUse,
      mpHolder: holderToUse,
      mpCvu: cvuToUse,
      mpQrText: generated,
      mpQrData: generated,
      mpQrImage: '', // clear custom image to use the standard EMVCo code
      mpPosQrs: updatedPosQrs,
    };

    setConfig(updatedConfig);
    StorageService.savePaymentConfig(updatedConfig);
    if (onSaved) onSaved(updatedConfig);
    setSavedSuccess(true);
    DialogService.alert('¡Código QR EMVCo Transferencias 3.0 generado y guardado!\nEste formato es 100% interoperable con cualquier billetera virtual y ya está activo para cobrar.', 'QR Generado y Guardado', 'success');
  };

  // Virtual Wallets CRUD
  const handleStartAddWallet = (preset?: { name: string; color: string; placeholderAlias: string }) => {
    setWalletForm({
      id: `wal_${Date.now()}`,
      name: preset?.name || '',
      alias: preset?.placeholderAlias ? '' : '',
      cvu: '',
      holder: config.mpHolder || '',
      color: preset?.color || 'bg-neutral-800',
    });
    setIsEditingWallet(true);
  };

  const handleStartEditWallet = (wallet: VirtualWallet) => {
    setWalletForm({ ...wallet });
    setIsEditingWallet(true);
  };

  const handleDeleteWallet = async (walletId: string) => {
    const ok = await DialogService.confirm(
      '¿Desea eliminar esta billetera virtual de sus opciones de cobro?',
      'Eliminar Billetera',
      'Sí, eliminar',
      'Cancelar',
      'error'
    );
    if (ok) {
      const updated = wallets.filter(w => w.id !== walletId);
      setWallets(updated);
    }
  };

  const handleSaveWalletForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!walletForm.name?.trim()) {
      DialogService.alert('Por favor indique el nombre de la billetera virtual.', 'Nombre Requerido', 'warning');
      return;
    }

    const newWallet: VirtualWallet = {
      id: walletForm.id || `wal_${Date.now()}`,
      name: walletForm.name.trim(),
      alias: (walletForm.alias || '').trim().toUpperCase(),
      cvu: (walletForm.cvu || '').trim().replace(/\D/g, ''),
      holder: (walletForm.holder || '').trim(),
      color: walletForm.color || 'bg-neutral-800',
      qrImage: walletForm.qrImage,
      qrText: walletForm.qrText,
    };

    const exists = wallets.some(w => w.id === newWallet.id);
    let updated: VirtualWallet[];
    if (exists) {
      updated = wallets.map(w => w.id === newWallet.id ? newWallet : w);
    } else {
      updated = [...wallets, newWallet];
    }

    setWallets(updated);
    setIsEditingWallet(false);
  };

  const handleWalletQrImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = reader.result as string;
      const decoded = await decodeQrFromImage(dataUrl);
      setWalletForm(prev => ({
        ...prev,
        qrImage: dataUrl,
        qrText: decoded || prev.qrText,
      }));
    };
    reader.readAsDataURL(file);
  };

  const handleTestPosnet = () => {
    setTestingPosnet(true);
    setPosnetTestResult(null);
    setTimeout(() => {
      setTestingPosnet(false);
      setPosnetTestResult(`Terminal ${config.posnetBrand || 'Posnet'} (${config.posnetTerminalId || 'POS-01'}) conectada y respondiendo correctamente en ${config.posnetMode === 'AUTOMATIC' ? 'Modo Automático' : 'Modo Manual'}.`);
    }, 900);
  };

  // Final Modal Save
  const handleSaveAll = (e: React.FormEvent) => {
    e.preventDefault();

    const updatedConfig: PaymentConfig = {
      ...config,
      posnetMode: config.posnetMode || 'MANUAL',
      posnetBrand: config.posnetBrand || 'Payway / Posnet',
      posnetTerminalId: config.posnetTerminalId || 'POS-01',
      posnetIntegratedType: config.posnetIntegratedType || 'INTEGRATED_SIMULATOR',
      posnetAutoPrintCoupon: config.posnetAutoPrintCoupon ?? true,
      wallets: wallets,
    };

    StorageService.savePaymentConfig(updatedConfig);
    setConfig(updatedConfig);
    setSavedSuccess(true);
    if (onSaved) onSaved(updatedConfig);

    if (embedded) {
      setTimeout(() => {
        setSavedSuccess(false);
      }, 3000);
    } else {
      setTimeout(() => {
        setSavedSuccess(false);
        if (onClose) onClose();
      }, 900);
    }
  };

  if (!isOpen && !embedded) return null;

  const modalBody = (
    <div className={`bg-white dark:bg-neutral-900 text-neutral-950 dark:text-neutral-100 rounded-2xl w-full overflow-hidden border border-neutral-300 dark:border-neutral-700 flex flex-col ${embedded ? 'shadow-xs' : 'max-w-2xl max-h-[92vh] shadow-2xl'}`}>
      {/* Modal Header */}
      <div className="p-4 bg-neutral-900 text-white flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-neutral-800 rounded-lg text-emerald-400">
            <CreditCard className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-base tracking-tight text-white">Datos de Cobro & Pasarela de Pagos</h3>
            <p className="text-xs text-neutral-300">
              Mercado Pago QR oficial interoperable, Billeteras Virtuales Múltiples y CBU Bancario
            </p>
          </div>
        </div>
        {!embedded && onClose && (
          <button
            type="button"
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1 rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

        {/* Tab Selector */}
        <div className="flex border-b border-neutral-200 dark:border-neutral-800 bg-neutral-100 dark:bg-neutral-950 p-2 gap-1.5 flex-shrink-0">
          <button
            type="button"
            onClick={() => { setActiveTab('MP'); stopCamera(); }}
            className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'MP'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'bg-white dark:bg-neutral-800 text-neutral-900 dark:text-neutral-200 hover:bg-neutral-200 dark:hover:bg-neutral-700 border border-neutral-300 dark:border-neutral-700'
            }`}
          >
            <QrCode className="w-4 h-4" />
            <span className="truncate">Mercado Pago QR</span>
          </button>

          <button
            type="button"
            onClick={() => { setActiveTab('POSNET'); stopCamera(); }}
            className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'POSNET'
                ? 'bg-violet-700 text-white shadow-xs'
                : 'bg-white dark:bg-neutral-800 text-neutral-900 dark:text-neutral-200 hover:bg-neutral-200 dark:hover:bg-neutral-700 border border-neutral-300 dark:border-neutral-700'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span className="truncate">Tarjeta / Posnet</span>
          </button>

          <button
            type="button"
            onClick={() => { setActiveTab('BANK'); stopCamera(); }}
            className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'BANK'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'bg-white dark:bg-neutral-800 text-neutral-900 dark:text-neutral-200 hover:bg-neutral-200 dark:hover:bg-neutral-700 border border-neutral-300 dark:border-neutral-700'
            }`}
          >
            <Building2 className="w-4 h-4" />
            <span className="truncate">Banco (CBU)</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs flex-1 text-neutral-950 dark:text-neutral-100">
          {savedSuccess && (
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 rounded-xl text-emerald-800 dark:text-emerald-300 font-semibold flex items-center gap-2 animate-in zoom-in-95">
              <Check className="w-4 h-4 text-emerald-600 flex-shrink-0" />
              ¡Datos guardados con éxito! Se sincronizarán en el POS y la Segunda Pantalla.
            </div>
          )}

          {/* TAB 1: MERCADO PAGO QR */}
          {activeTab === 'MP' && (
            <div className="space-y-4 animate-in fade-in">
              {/* REAL-TIME POS INTEGRATION CARD */}
              <div className="p-4 bg-gradient-to-br from-sky-50 to-blue-50/50 dark:from-sky-950/40 dark:to-neutral-900 border-2 border-sky-400 dark:border-sky-600 rounded-2xl shadow-xs space-y-3.5">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 bg-sky-600 text-white rounded-lg">
                      <Zap className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-bold text-xs text-sky-950 dark:text-sky-200">
                        Integración Oficial Mercado Pago Point of Sale (POS)
                      </h4>
                      <p className="text-[10px] text-sky-800 dark:text-sky-300">
                        Transmisión de montos en vivo y confirmación automática de pagos
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {config.mpConnected ? (
                      <span className="px-2.5 py-1 bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 text-[11px] font-bold rounded-full flex items-center gap-1.5 border border-emerald-400">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                        Conectado: {config.mpPosName || 'Caja POS'}
                      </span>
                    ) : (
                      <span className="px-2.5 py-1 bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 text-[11px] font-bold rounded-full flex items-center gap-1.5 border border-amber-300">
                        <span className="w-2 h-2 rounded-full bg-amber-500" />
                        Sin Vincular
                      </span>
                    )}
                  </div>
                </div>

                {/* Form fields for MP connection */}
                <div className="space-y-3 pt-1">
                  {/* Access Token */}
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <label className="font-bold text-neutral-900 dark:text-neutral-100 text-[11px] uppercase tracking-wide flex items-center gap-1">
                        <span>Access Token de Producción</span>
                        <span className="text-rose-500 font-bold">*</span>
                      </label>
                      <span className="text-[10px] text-neutral-500 dark:text-neutral-400">
                        Comienza con <strong className="font-mono text-neutral-700 dark:text-neutral-300">APP_USR-...</strong>
                      </span>
                    </div>

                    <div className="relative flex items-center">
                      <input
                        type={showAccessToken ? 'text' : 'password'}
                        value={config.mpAccessToken || ''}
                        onChange={(e) => setConfig({ ...config, mpAccessToken: e.target.value.trim() })}
                        placeholder="APP_USR-4629986348459991-..."
                        className="w-full pl-3 pr-24 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-700 rounded-xl font-mono text-xs font-bold text-neutral-900 dark:text-white focus:border-sky-500 focus:outline-hidden"
                      />
                      <div className="absolute right-1.5 flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => setShowAccessToken(!showAccessToken)}
                          className="p-1 text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200 rounded"
                          title={showAccessToken ? 'Ocultar token' : 'Mostrar token'}
                        >
                          {showAccessToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                        <button
                          type="button"
                          onClick={async () => {
                            try {
                              const text = await navigator.clipboard.readText();
                              if (text) setConfig({ ...config, mpAccessToken: text.trim() });
                            } catch (e) {
                              DialogService.alert('Pega el token manualmente con Ctrl+V en el campo.', 'Pegar Token', 'info');
                            }
                          }}
                          className="px-2 py-1 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-700 dark:hover:bg-neutral-600 rounded text-[10px] font-bold text-neutral-800 dark:text-neutral-200"
                        >
                          Pegar
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* User ID and POS ID Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold text-neutral-900 dark:text-neutral-100 text-[11px] uppercase tracking-wide mb-1">
                        User ID (Collector ID)
                      </label>
                      <input
                        type="text"
                        value={config.mpUserId || ''}
                        onChange={(e) => setConfig({ ...config, mpUserId: e.target.value.trim() })}
                        placeholder="49052653"
                        className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-700 rounded-xl font-mono text-xs font-bold text-neutral-900 dark:text-white focus:border-sky-500 focus:outline-hidden"
                      />
                      <span className="text-[10px] text-neutral-500 mt-0.5 block">
                        Visible en tu panel de Mercado Pago Developers.
                      </span>
                    </div>

                    <div>
                      <label className="block font-bold text-neutral-900 dark:text-neutral-100 text-[11px] uppercase tracking-wide mb-1">
                        ID o Código de Caja (POS ID)
                      </label>
                      <input
                        type="text"
                        value={config.mpPosId || ''}
                        onChange={(e) => setConfig({ ...config, mpPosId: e.target.value.trim() })}
                        placeholder="1364877 o QR #01"
                        className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-700 rounded-xl font-mono text-xs font-bold text-neutral-900 dark:text-white focus:border-sky-500 focus:outline-hidden"
                      />
                      <span className="text-[10px] text-neutral-500 mt-0.5 block">
                        ID numérico o nombre asignado a la caja en MP.
                      </span>
                    </div>
                  </div>

                  {availablePosList.length > 0 && (
                    <div className="p-2.5 bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 rounded-xl space-y-1.5">
                      <div className="text-[11px] font-bold text-sky-900 dark:text-sky-300">
                        Cajas detectadas en tu cuenta de Mercado Pago (haz clic para seleccionar):
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {availablePosList.map((pos) => {
                          const isSelected = String(config.mpPosId) === String(pos.externalId || pos.id) || String(config.mpPosId) === String(pos.id);
                          return (
                            <button
                              key={pos.id}
                              type="button"
                              onClick={() => {
                                const posIdStr = String(pos.externalId || pos.id);
                                const posIdNum = String(pos.id);
                                setConfig(prev => {
                                  const saved = prev.mpPosQrs?.[posIdStr] || prev.mpPosQrs?.[posIdNum];
                                  return {
                                    ...prev,
                                    mpPosId: posIdStr,
                                    mpPosName: pos.name,
                                    mpStoreId: pos.storeId || prev.mpStoreId,
                                    mpQrImage: saved?.qrImage || pos.qrImage || '',
                                    mpQrData: saved?.qrData || pos.qrData || '',
                                    mpQrText: saved?.qrText || pos.qrData || prev.mpQrText,
                                  };
                                });
                              }}
                              className={`px-2.5 py-1 rounded-lg text-xs flex items-center gap-1.5 transition-all ${
                                isSelected
                                  ? 'bg-sky-600 text-white shadow-xs font-bold'
                                  : 'bg-white dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-sky-100 dark:hover:bg-neutral-700 border border-neutral-300 dark:border-neutral-700'
                              }`}
                            >
                              <span>{pos.name || `Caja ${pos.id}`}</span>
                              <span className="text-[10px] opacity-75 font-mono">(ID: {pos.externalId || pos.id})</span>
                              {isSelected && <Check className="w-3 h-3 text-white" />}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Connect Button and AutoSync Toggle */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-sky-200 dark:border-neutral-800">
                    <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-neutral-800 dark:text-neutral-200">
                      <input
                        type="checkbox"
                        checked={config.mpAutoSync !== false}
                        onChange={(e) => setConfig({ ...config, mpAutoSync: e.target.checked })}
                        className="w-4 h-4 rounded text-sky-600 focus:ring-sky-500"
                      />
                      <span>Transmitir monto automáticamente al QR al iniciar venta</span>
                    </label>

                    <button
                      type="button"
                      disabled={isVerifyingMp}
                      onClick={handleVerifyMpConnection}
                      className="px-4 py-2 bg-sky-600 hover:bg-sky-700 disabled:opacity-50 text-white rounded-xl font-bold flex items-center gap-2 shadow-xs transition-colors"
                    >
                      {isVerifyingMp ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>Verificando con MP...</span>
                        </>
                      ) : (
                        <>
                          <Radio className="w-4 h-4" />
                          <span>{config.mpConnected ? 'Re-verificar Conexión' : 'Conectar Caja con Mercado Pago'}</span>
                        </>
                      )}
                    </button>
                  </div>

                  {mpVerifyResult && (
                    <div className={`p-3 rounded-xl text-xs font-medium ${
                      mpVerifyResult.success 
                        ? 'bg-emerald-100 text-emerald-900 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-400' 
                        : 'bg-rose-100 text-rose-900 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-400'
                    }`}>
                      {mpVerifyResult.message}
                    </div>
                  )}
                </div>
              </div>

              {/* Important Error Explanation Banner */}
              <div className="p-3.5 bg-amber-50 dark:bg-amber-950/30 border border-amber-300 dark:border-amber-800 rounded-xl text-neutral-900 dark:text-amber-100 text-[11px] leading-relaxed space-y-1.5">
                <div className="flex items-center gap-2 font-bold text-amber-900 dark:text-amber-300 text-xs">
                  <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0" />
                  ¿Por qué la app de Mercado Pago decía "No es un código QR de pago"?
                </div>
                <p>
                  El escáner de la app de Mercado Pago <strong>rechaza enlaces web convencionales</strong> (como los links <code>link.mercadopago.com.ar/...</code>) porque espera un código de <strong>Cartel de Cobro Oficial</strong> o el formato <strong>Transferencias 3.0 EMVCo</strong> del BCRA.
                </p>
                <div className="flex flex-wrap gap-2 pt-1">
                  <button
                    type="button"
                    onClick={handleGenerateInteroperableMpQr}
                    className="px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-lg font-bold flex items-center gap-1.5 shadow-xs transition-colors"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                    Generar QR Interoperable Oficial (EMVCo)
                  </button>

                  <button
                    type="button"
                    onClick={() => mpFileRef.current?.click()}
                    className="px-3 py-1.5 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 text-neutral-900 dark:text-white rounded-lg font-bold flex items-center gap-1.5 transition-colors"
                  >
                    <Upload className="w-3.5 h-3.5 text-sky-600" />
                    Subir Foto / Imagen de mi QR MP
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      if (isScanningCamera) stopCamera();
                      else startCameraScanner();
                    }}
                    className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-colors ${
                      isScanningCamera 
                        ? 'bg-rose-600 text-white' 
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                    }`}
                  >
                    <Camera className="w-3.5 h-3.5" />
                    {isScanningCamera ? 'Detener Cámara' : 'Escanear Cartel Físico con Cámara'}
                  </button>
                </div>
              </div>

              {/* Live Camera Scanner View */}
              {isScanningCamera && (
                <div className="p-4 bg-neutral-950 rounded-2xl border-2 border-emerald-500 text-center space-y-2 animate-in zoom-in-95">
                  <div className="text-white font-bold text-xs flex items-center justify-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                    Apunta la cámara a tu cartel impreso de Mercado Pago
                  </div>
                  <div className="relative max-w-sm mx-auto rounded-xl overflow-hidden border border-neutral-800 bg-black aspect-video flex items-center justify-center">
                    <video ref={videoRef} className="w-full h-full object-cover" />
                    <div className="absolute inset-8 border-2 border-emerald-400/80 rounded-xl pointer-events-none" />
                  </div>
                  <p className="text-[10px] text-neutral-400">
                    Al enfocar el código, se detectará automáticamente sin necesidad de presionar ningún botón.
                  </p>
                  <button
                    type="button"
                    onClick={stopCamera}
                    className="px-3 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded text-[11px] font-semibold"
                  >
                    Cancelar escaneo
                  </button>
                </div>
              )}

              {cameraError && (
                <div className="p-3 bg-rose-50 dark:bg-rose-950/30 border border-rose-300 dark:border-rose-800 rounded-xl text-rose-800 dark:text-rose-300 text-xs">
                  {cameraError}
                </div>
              )}

              {/* Hidden file input */}
              <input
                ref={mpFileRef}
                type="file"
                accept="image/*"
                onChange={handleMpImageUpload}
                className="hidden"
              />

              {/* QR Preview & Data Fields */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2 space-y-3">
                  <div>
                    <label className="block font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wide mb-1">
                      Alias de Mercado Pago
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        required
                        value={config.mpAlias}
                        onChange={(e) => setConfig({ ...config, mpAlias: e.target.value.toUpperCase() })}
                        placeholder="MANUELSILVA2003.MP"
                        className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl font-mono text-sm font-bold text-neutral-900 dark:text-white uppercase focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                      />
                      <button
                        type="button"
                        onClick={() => handleCopy(config.mpAlias, 'mpAlias')}
                        className="absolute right-2 top-2 px-2 py-1 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-700 dark:hover:bg-neutral-600 rounded text-[10px] font-bold text-neutral-800 dark:text-neutral-200 flex items-center gap-1"
                      >
                        {copiedKey === 'mpAlias' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                        Copiar
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wide mb-1">
                      Nombre del Titular de la Cuenta MP
                    </label>
                    <input
                      type="text"
                      required
                      value={config.mpHolder}
                      onChange={(e) => setConfig({ ...config, mpHolder: e.target.value })}
                      placeholder="Manuel Silva / Comercio Central"
                      className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-xs font-bold text-neutral-900 dark:text-white focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wide mb-1">
                      CVU de Mercado Pago (22 dígitos)
                    </label>
                    <input
                      type="text"
                      maxLength={22}
                      value={config.mpCvu}
                      onChange={(e) => setConfig({ ...config, mpCvu: e.target.value.replace(/\D/g, '') })}
                      placeholder="0000003100084920194820"
                      className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl font-mono text-xs font-bold text-neutral-900 dark:text-white focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wide mb-1">
                      Contenido / Código del QR (EMVCo o URL de POS)
                    </label>
                    <input
                      type="text"
                      value={config.mpQrText || ''}
                      onChange={(e) => setConfig({ ...config, mpQrText: e.target.value })}
                      placeholder="00020101021243650016com.mercadolibre... o https://mpago.la/pos/..."
                      className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-xs font-mono font-bold text-neutral-900 dark:text-white focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                    />
                    <span className="text-[10px] text-neutral-500 dark:text-neutral-400 mt-0.5 block">
                      Se genera automáticamente con el botón "Generar QR Interoperable Oficial" o al subir una foto del cartel.
                    </span>
                  </div>
                </div>

                {/* QR Preview Side Card */}
                <div className="p-3 bg-neutral-50 dark:bg-neutral-800/70 rounded-2xl border border-neutral-200 dark:border-neutral-700 flex flex-col items-center justify-center text-center space-y-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
                    Vista Previa del QR
                  </span>
                  <div className="p-2.5 bg-white rounded-xl shadow-xs border border-neutral-300 inline-block">
                    {config.mpQrImage ? (
                      <img
                        src={config.mpQrImage}
                        alt="QR Oficial Mercado Pago"
                        className="w-36 h-36 object-contain rounded"
                      />
                    ) : (
                      <img
                        src={`https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(
                          config.mpQrData || config.mpQrText || generateArgentinaInteroperableQr({
                            merchantName: config.mpHolder || 'MERCADO PAGO',
                            cvuOrCbu: config.mpCvu || '0000003100084920194820',
                            alias: config.mpAlias || 'MANUELSILVA2003.MP'
                          })
                        )}`}
                        alt="QR Oficial Mercado Pago"
                        className="w-36 h-36 rounded"
                      />
                    )}
                  </div>
                  <div className="text-[10px] text-neutral-600 dark:text-neutral-300 font-bold">
                    {config.mpQrImage ? 'Foto de cartel cargada para esta caja' : `QR Oficial (${config.mpPosName || 'Caja Principal'})`}
                  </div>
                  {config.mpQrImage && (
                    <button
                      type="button"
                      onClick={() => {
                        const curPosId = config.mpPosId || 'default';
                        const updatedPosQrs = { ...(config.mpPosQrs || {}) };
                        const keysToUpdate = Array.from(new Set([curPosId, 'TERM-01', 'TERM-02', 'TERM-03', '1', '2', '3', 'default']));
                        keysToUpdate.forEach(k => {
                          if (updatedPosQrs[k]) {
                            updatedPosQrs[k] = {
                              ...updatedPosQrs[k],
                              qrImage: ''
                            };
                          }
                        });
                        const updatedConfig: PaymentConfig = {
                          ...config,
                          mpQrImage: '',
                          mpPosQrs: updatedPosQrs
                        };
                        setConfig(updatedConfig);
                        StorageService.savePaymentConfig(updatedConfig);
                        if (onSaved) onSaved(updatedConfig);
                      }}
                      className="text-[10px] text-rose-600 hover:underline flex items-center gap-1 font-bold"
                    >
                      <Trash2 className="w-3 h-3" />
                      Quitar foto y usar QR oficial de esta caja
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: TARJETA / POSNET */}
          {activeTab === 'POSNET' && (
            <div className="space-y-4 animate-in fade-in">
              <div className="p-3 bg-violet-50 dark:bg-violet-950/30 border border-violet-200 dark:border-violet-800 rounded-xl text-neutral-900 dark:text-violet-100 text-[11px] leading-relaxed flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <div className="font-bold flex items-center gap-1.5 text-xs text-violet-950 dark:text-violet-200">
                    <CreditCard className="w-4 h-4 text-violet-700 dark:text-violet-400" />
                    Configuración de Cobro con Tarjeta / Posnet
                  </div>
                  <p className="text-neutral-600 dark:text-neutral-300">
                    Permite cobrar con tarjetas físicas de Débito, Crédito o Prepaga en el punto de venta. Puedes elegir cómo operar entre <strong>Modo Manual</strong> y <strong>Modo Automático</strong>.
                  </p>
                </div>
              </div>

              {/* SELECTOR DE LOS 2 MODOS DE USO */}
              <div className="space-y-2">
                <label className="block text-xs font-black text-neutral-900 dark:text-white uppercase tracking-wider">
                  Modo Predeterminado para Cobros con Tarjeta / Posnet:
                </label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {/* Modo Manual */}
                  <div
                    onClick={() => setConfig({ ...config, posnetMode: 'MANUAL' })}
                    className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                      (config.posnetMode || 'MANUAL') === 'MANUAL'
                        ? 'border-violet-600 bg-violet-50/60 dark:bg-violet-950/40 shadow-xs'
                        : 'border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 hover:border-neutral-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className={`p-2 rounded-lg ${
                          (config.posnetMode || 'MANUAL') === 'MANUAL'
                            ? 'bg-violet-600 text-white'
                            : 'bg-neutral-200 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300'
                        }`}>
                          <CreditCard className="w-4 h-4" />
                        </div>
                        <h4 className="font-bold text-sm text-neutral-900 dark:text-white">Modo Manual</h4>
                      </div>
                      <span className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                        (config.posnetMode || 'MANUAL') === 'MANUAL'
                          ? 'border-violet-600 bg-violet-600'
                          : 'border-neutral-400'
                      }`}>
                        {(config.posnetMode || 'MANUAL') === 'MANUAL' && (
                          <div className="w-1.5 h-1.5 rounded-full bg-white" />
                        )}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-600 dark:text-neutral-300">
                      <strong>Recomendado para Posnet tradicional de cualquier empresa.</strong> El cliente pasa la tarjeta física en la terminal del mostrador (Payway, Posnet, First Data, Clover, etc.) y el cajero registra en pantalla Débito/Crédito, cuotas y opcionalmente número de cupón para el arqueo de caja.
                    </p>
                    <div className="mt-2.5 flex items-center gap-1.5 text-[10px] font-bold text-violet-700 dark:text-violet-300">
                      <Check className="w-3.5 h-3.5" /> Compatible con cualquier aparato sin necesidad de cables
                    </div>
                  </div>

                  {/* Modo Automático */}
                  <div
                    onClick={() => setConfig({ ...config, posnetMode: 'AUTOMATIC' })}
                    className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                      config.posnetMode === 'AUTOMATIC'
                        ? 'border-violet-600 bg-violet-50/60 dark:bg-violet-950/40 shadow-xs'
                        : 'border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 hover:border-neutral-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className={`p-2 rounded-lg ${
                          config.posnetMode === 'AUTOMATIC'
                            ? 'bg-violet-600 text-white'
                            : 'bg-neutral-200 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300'
                        }`}>
                          <Zap className="w-4 h-4" />
                        </div>
                        <h4 className="font-bold text-sm text-neutral-900 dark:text-white">Modo Automático</h4>
                      </div>
                      <span className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                        config.posnetMode === 'AUTOMATIC'
                          ? 'border-violet-600 bg-violet-600'
                          : 'border-neutral-400'
                      }`}>
                        {config.posnetMode === 'AUTOMATIC' && (
                          <div className="w-1.5 h-1.5 rounded-full bg-white" />
                        )}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-600 dark:text-neutral-300">
                      <strong>Para lectores integrados o terminales Point.</strong> El sistema envía la orden y el monto directamente al dispositivo Posnet, muestra en vivo el estado "Esperando tarjeta..." y confirma el cobro automáticamente con comprobante digital.
                    </p>
                    <div className="mt-2.5 flex items-center gap-1.5 text-[10px] font-bold text-violet-700 dark:text-violet-300">
                      <Zap className="w-3.5 h-3.5" /> Envío de monto y autorización automática en pantalla
                    </div>
                  </div>
                </div>
              </div>

              {/* DATOS DE LA TERMINAL POSNET */}
              <div className="p-4 bg-neutral-50 dark:bg-neutral-900 rounded-xl border border-neutral-300 dark:border-neutral-700 space-y-3.5">
                <h4 className="font-bold text-xs uppercase tracking-wide text-neutral-900 dark:text-white flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-violet-600" />
                  Identificación de la Terminal Posnet del Local
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wide mb-1">
                      Empresa / Marca de la Terminal
                    </label>
                    <select
                      value={config.posnetBrand || 'Payway / Posnet'}
                      onChange={(e) => setConfig({ ...config, posnetBrand: e.target.value })}
                      className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-xs font-bold text-neutral-900 dark:text-white focus:ring-2 focus:ring-violet-600 focus:outline-hidden"
                    >
                      <option value="Payway / Posnet">Payway / Posnet (Fiserv / Prisma)</option>
                      <option value="Mercado Pago Point">Mercado Pago Point (Bluetooth / Smart)</option>
                      <option value="Clover">Clover (Fiserv)</option>
                      <option value="Getnet">Getnet (Santander)</option>
                      <option value="Ualá Bis">Ualá Bis</option>
                      <option value="Genérico">Terminal Posnet Genérica</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wide mb-1">
                      N° de Terminal / Identificador de Caja
                    </label>
                    <input
                      type="text"
                      value={config.posnetTerminalId || 'POS-01'}
                      onChange={(e) => setConfig({ ...config, posnetTerminalId: e.target.value })}
                      placeholder="Ej: POS-01 o N° de Serie"
                      className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-xs font-bold text-neutral-900 dark:text-white focus:ring-2 focus:ring-violet-600 focus:outline-hidden"
                    />
                  </div>
                </div>

                {/* Sub-opción si está en Automático */}
                {config.posnetMode === 'AUTOMATIC' && (
                  <div className="p-3 bg-white dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700 space-y-2">
                    <label className="block font-bold text-neutral-900 dark:text-white uppercase tracking-wide text-[11px]">
                      Tipo de Conexión Automática:
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setConfig({ ...config, posnetIntegratedType: 'INTEGRATED_SIMULATOR' })}
                        className={`p-2.5 rounded-lg border text-left text-xs font-bold transition-all ${
                          (config.posnetIntegratedType || 'INTEGRATED_SIMULATOR') === 'INTEGRATED_SIMULATOR'
                            ? 'border-violet-600 bg-violet-50 dark:bg-violet-950/60 text-violet-950 dark:text-violet-200'
                            : 'border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-900 text-neutral-700 dark:text-neutral-300'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 mb-0.5">
                          <Radio className="w-3.5 h-3.5 text-violet-600" />
                          <span>Lector Integrado / Digital</span>
                        </div>
                        <div className="text-[10px] font-normal text-neutral-500">
                          Lectura automática de Chip, Contactless y Banda con autorización instantánea
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => setConfig({ ...config, posnetIntegratedType: 'POINT_MP' })}
                        className={`p-2.5 rounded-lg border text-left text-xs font-bold transition-all ${
                          config.posnetIntegratedType === 'POINT_MP'
                            ? 'border-violet-600 bg-violet-50 dark:bg-violet-950/60 text-violet-950 dark:text-violet-200'
                            : 'border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-900 text-neutral-700 dark:text-neutral-300'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 mb-0.5">
                          <Zap className="w-3.5 h-3.5 text-sky-500" />
                          <span>Mercado Pago Point</span>
                        </div>
                        <div className="text-[10px] font-normal text-neutral-500">
                          {config.mpAccessToken ? 'Conexión activa con Access Token de MP' : 'Requiere Access Token en pestaña Mercado Pago'}
                        </div>
                      </button>
                    </div>
                  </div>
                )}

                {/* Comprobantes */}
                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="posnetAutoPrint"
                    checked={config.posnetAutoPrintCoupon ?? true}
                    onChange={(e) => setConfig({ ...config, posnetAutoPrintCoupon: e.target.checked })}
                    className="w-4 h-4 text-violet-600 rounded border-neutral-300 focus:ring-violet-500"
                  />
                  <label htmlFor="posnetAutoPrint" className="text-xs text-neutral-700 dark:text-neutral-300 cursor-pointer">
                    Imprimir datos de cupón y lote en el ticket / comprobante de venta
                  </label>
                </div>
              </div>

              {/* TEST DE CONEXIÓN CON TERMINAL */}
              <div className="p-3 bg-white dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="font-bold text-xs text-neutral-900 dark:text-white flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Estado de la Terminal Posnet
                  </div>
                  <div className="text-[11px] text-neutral-500 mt-0.5">
                    {posnetTestResult || `Configurada como: ${config.posnetBrand || 'Payway / Posnet'} (${config.posnetMode || 'MANUAL'})`}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleTestPosnet}
                  disabled={testingPosnet}
                  className="px-3 py-1.5 bg-neutral-900 dark:bg-white text-white dark:text-neutral-950 hover:bg-neutral-800 dark:hover:bg-neutral-100 rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors flex-shrink-0"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${testingPosnet ? 'animate-spin' : ''}`} />
                  {testingPosnet ? 'Verificando terminal...' : 'Probar Terminal'}
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: CUENTAS BANCARIAS */}
          {activeTab === 'BANK' && (
            <div className="space-y-3.5 animate-in fade-in">
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 rounded-xl text-neutral-900 dark:text-emerald-100 text-[11px] leading-relaxed">
                <strong>Transferencias Bancarias:</strong> Al cobrar por <strong>Transferencia Bancaria</strong> en el POS, la segunda pantalla y el comprobante mostrarán estos datos para que el cliente transfiera de inmediato desde su Homebanking.
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wide mb-1">
                    Nombre del Banco / Entidad
                  </label>
                  <input
                    type="text"
                    required
                    value={config.bankName}
                    onChange={(e) => setConfig({ ...config, bankName: e.target.value })}
                    placeholder="Ej: Santander, Galicia, Banco Nación"
                    className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-xs font-bold text-neutral-900 dark:text-white focus:ring-2 focus:ring-emerald-600 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wide mb-1">
                    CUIT / CUIL del Titular
                  </label>
                  <input
                    type="text"
                    value={config.bankCuit}
                    onChange={(e) => setConfig({ ...config, bankCuit: e.target.value })}
                    placeholder="30-71458999-9"
                    className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-xs font-mono font-bold text-neutral-900 dark:text-white focus:ring-2 focus:ring-emerald-600 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wide mb-1">
                  Alias Bancario
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={config.bankAlias}
                    onChange={(e) => setConfig({ ...config, bankAlias: e.target.value.toUpperCase() })}
                    placeholder="Ej: COMERCIO.CENTRAL.PAGO"
                    className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl font-mono text-sm font-bold text-neutral-900 dark:text-white uppercase focus:ring-2 focus:ring-emerald-600 focus:outline-hidden"
                  />
                  <button
                    type="button"
                    onClick={() => handleCopy(config.bankAlias, 'bankAlias')}
                    className="absolute right-2 top-2 px-2 py-1 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-700 dark:hover:bg-neutral-600 rounded text-[10px] font-bold text-neutral-800 dark:text-neutral-200 flex items-center gap-1"
                  >
                    {copiedKey === 'bankAlias' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    Copiar
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wide mb-1">
                  CBU (22 dígitos)
                </label>
                <div className="relative">
                  <input
                    type="text"
                    maxLength={22}
                    required
                    value={config.bankCbu}
                    onChange={(e) => setConfig({ ...config, bankCbu: e.target.value.replace(/\D/g, '') })}
                    placeholder="0720123488000012345678"
                    className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl font-mono text-xs font-bold text-neutral-900 dark:text-white focus:ring-2 focus:ring-emerald-600 focus:outline-hidden"
                  />
                  <button
                    type="button"
                    onClick={() => handleCopy(config.bankCbu, 'bankCbu')}
                    className="absolute right-2 top-2 px-2 py-1 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-700 dark:hover:bg-neutral-600 rounded text-[10px] font-bold text-neutral-800 dark:text-neutral-200 flex items-center gap-1"
                  >
                    {copiedKey === 'bankCbu' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    Copiar
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wide mb-1">
                  Titular de la Cuenta Bancaria
                </label>
                <input
                  type="text"
                  required
                  value={config.bankHolder}
                  onChange={(e) => setConfig({ ...config, bankHolder: e.target.value })}
                  placeholder="Ej: Empresa Comercial S.A."
                  className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-xs font-bold text-neutral-900 dark:text-white focus:ring-2 focus:ring-emerald-600 focus:outline-hidden"
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-neutral-50 dark:bg-neutral-950 border-t border-neutral-200 dark:border-neutral-800 flex items-center justify-between flex-shrink-0">
          <div className="text-[11px] text-neutral-500 dark:text-neutral-400 flex items-center gap-1">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            Configuración guardada en tu sistema local
          </div>
          <div className="flex gap-2">
            {!embedded && onClose && (
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-neutral-200 hover:bg-neutral-300 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 rounded-xl font-bold transition-colors text-xs"
              >
                Cerrar
              </button>
            )}
            <button
              type="button"
              onClick={handleSaveAll}
              className="px-5 py-2 bg-neutral-900 hover:bg-neutral-800 dark:bg-emerald-600 dark:hover:bg-emerald-500 text-white rounded-xl font-bold flex items-center gap-1.5 transition-colors shadow-xs text-xs"
            >
              <Save className="w-4 h-4 text-emerald-400 dark:text-white" />
              Guardar Cambios
            </button>
          </div>
        </div>
      </div>
  );

  if (embedded) {
    return modalBody;
  }

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
      {modalBody}
    </div>
  );
};
