import React, { useState, useEffect } from 'react';
import { 
  ShoppingBag, 
  Banknote, 
  QrCode, 
  CreditCard, 
  CheckCircle2, 
  ArrowRight,
  Clock,
  Sparkles,
  Maximize2,
  Minimize2,
  Tv,
  Check,
  Wallet,
  Wifi,
  RefreshCw
} from 'lucide-react';
import { StorageService, OFFICIAL_MP_QRS } from '../../services/storage';
import { CloudSync } from '../../services/cloudSync';
import { PeerSync } from '../../services/peerSync';
import { CustomerDisplayState, PaymentConfig, VirtualWallet } from '../../types';
import { generateArgentinaInteroperableQr } from '../../utils/emvco';
import { formatThousands } from '../../utils/text';
import { WifiDisplayModal } from './WifiDisplayModal';

interface CustomerDisplayViewProps {
  standalone?: boolean;
  onClose?: () => void;
}

const normalizeTerminalId = (raw?: string | null): string => {
  if (!raw) return 'TERM-01';
  let cleaned = raw.trim().toUpperCase();
  if (cleaned.startsWith('TERMINAL')) {
    cleaned = cleaned.replace('TERMINAL', '').trim();
  }
  if (/^\d+$/.test(cleaned)) {
    cleaned = `TERM-${cleaned.padStart(2, '0')}`;
  } else if (/^TERM-\d+$/.test(cleaned)) {
    const num = cleaned.replace('TERM-', '');
    cleaned = `TERM-${num.padStart(2, '0')}`;
  }
  return cleaned || 'TERM-01';
};

export const CustomerDisplayView: React.FC<CustomerDisplayViewProps> = ({
  standalone = false,
  onClose
}) => {
  const [activeTerminalId, setActiveTerminalId] = useState<string>(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const urlTerm = params.get('terminal') || params.get('terminalId') || params.get('term');
      if (urlTerm) return normalizeTerminalId(urlTerm);
    } catch {}
    return normalizeTerminalId(StorageService.getCurrentTerminalId());
  });

  const [availableTerminals, setAvailableTerminals] = useState(() => StorageService.getTerminals());

  const [displayState, setDisplayState] = useState<CustomerDisplayState>(() => {
    try {
      return StorageService.getCustomerDisplayState(activeTerminalId) || {
        status: 'WELCOME',
        items: [],
        subtotal: 0,
        discount: 0,
        total: 0,
        paymentMethod: null,
        terminalId: activeTerminalId,
        timestamp: 0,
      };
    } catch {
      return {
        status: 'WELCOME',
        items: [],
        subtotal: 0,
        discount: 0,
        total: 0,
        paymentMethod: null,
        terminalId: activeTerminalId,
        timestamp: 0,
      };
    }
  });
  const [paymentConfig, setPaymentConfig] = useState<PaymentConfig>(() => {
    try {
      return StorageService.getPaymentConfig();
    } catch {
      return {} as PaymentConfig;
    }
  });
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showWifiModal, setShowWifiModal] = useState(false);
  const [activeWalletId, setActiveWalletId] = useState<string>('');

  // Sync state in real time
  useEffect(() => {
    // Check if channel was passed via URL query parameter (from QR code or Wi-Fi link)
    try {
      const params = new URLSearchParams(window.location.search);
      const urlChannel = params.get('channel') || params.get('sync_channel');
      if (urlChannel && urlChannel.trim()) {
        CloudSync.setChannelId(urlChannel.trim());
      }
    } catch {}

    const urlParams = new URLSearchParams(window.location.search);
    const displayChannel = (urlParams.get('channel') || urlParams.get('sync_channel') || CloudSync.getChannelId()).trim();

    const applyIncomingData = (data: any) => {
      if (!data) return;
      const targetState = data.state || (data.status ? data : null);
      if (!targetState || !targetState.status) return;

      const incomingTerm = (targetState.terminalId || data.terminalId || '').trim();
      if (incomingTerm && normalizeTerminalId(incomingTerm) !== normalizeTerminalId(activeTerminalId)) {
        return;
      }

      setDisplayState(prev => {
        const nextStatus = targetState.status || 'WELCOME';
        const nextTotal = typeof targetState.total === 'number' ? targetState.total : 0;
        const nextSubtotal = typeof targetState.subtotal === 'number' ? targetState.subtotal : 0;
        const nextDiscount = typeof targetState.discount === 'number' ? targetState.discount : 0;
        const nextPaymentMethod = targetState.paymentMethod || null;
        const nextItems = Array.isArray(targetState.items) ? targetState.items : [];

        // Check if anything meaningful changed to avoid re-rendering identically
        if (
          prev.status === nextStatus &&
          prev.total === nextTotal &&
          prev.subtotal === nextSubtotal &&
          prev.discount === nextDiscount &&
          prev.paymentMethod === nextPaymentMethod &&
          prev.items.length === nextItems.length &&
          prev.cashReceived === targetState.cashReceived &&
          prev.cashChange === targetState.cashChange &&
          prev.receiptNumber === targetState.receiptNumber &&
          prev.activeWalletId === targetState.activeWalletId &&
          prev.posnetStatus === targetState.posnetStatus &&
          prev.posnetMode === targetState.posnetMode &&
          (prev.transfersReceived?.length || 0) === (targetState.transfersReceived?.length || 0) &&
          (prev.transfersTotalReceived || 0) === (targetState.transfersTotalReceived || 0)
        ) {
          if (nextItems.length === 0) return prev;
          let itemsIdentical = true;
          for (let i = 0; i < nextItems.length; i++) {
            if (
              prev.items[i]?.name !== nextItems[i].name ||
              prev.items[i]?.quantity !== nextItems[i].quantity ||
              prev.items[i]?.unitPrice !== nextItems[i].unitPrice ||
              prev.items[i]?.total !== nextItems[i].total
            ) {
              itemsIdentical = false;
              break;
            }
          }
          if (itemsIdentical) return prev;
        }

        return {
          status: nextStatus,
          items: nextItems,
          subtotal: nextSubtotal,
          discount: nextDiscount,
          total: nextTotal,
          paymentMethod: nextPaymentMethod,
          cashReceived: targetState.cashReceived,
          cashChange: targetState.cashChange,
          receiptNumber: targetState.receiptNumber,
          terminalId: targetState.terminalId,
          timestamp: typeof targetState.timestamp === 'number' ? targetState.timestamp : Date.now(),
          selectedWallet: targetState.selectedWallet,
          activeWalletId: targetState.activeWalletId,
          posnetMode: targetState.posnetMode,
          posnetStatus: targetState.posnetStatus,
          posnetCardType: targetState.posnetCardType,
          posnetCardBrand: targetState.posnetCardBrand,
          transfersReceived: targetState.transfersReceived,
          transfersTotalReceived: targetState.transfersTotalReceived,
          paymentConfig: targetConfig || targetState.paymentConfig,
          qrImageUrl: targetState.qrImageUrl,
          qrData: targetState.qrData,
        };
      });

      const targetConfig = data.paymentConfig || targetState?.paymentConfig;
      if (targetConfig && typeof targetConfig === 'object') {
        setPaymentConfig(prev => ({ ...prev, ...targetConfig }));
      }
    };

    // QR/Wi-Fi displays run in a different browser and do not share the cashier's
    // localStorage token or BroadcastChannel. This endpoint exposes only the latest
    // read-only customer-display state for this terminal.
    let displayPollInFlight = false;
    const fetchQrDisplayState = async () => {
      if (displayPollInFlight || !displayChannel || !navigator.onLine) return;
      displayPollInFlight = true;
      try {
        const url = `/api/sync.php?action=display-state&channelId=${encodeURIComponent(displayChannel)}&terminal=${encodeURIComponent(activeTerminalId)}&_t=${Date.now()}`;
        const response = await fetch(url, { cache: 'no-store', headers: { 'Cache-Control': 'no-cache' } });
        if (response.ok) {
          const result = await response.json();
          if (result?.success && result.state) applyIncomingData({ state: result.state, paymentConfig: result.state.paymentConfig });
        }
      } catch {}
      finally { displayPollInFlight = false; }
    };
    void fetchQrDisplayState();
    const qrDisplayPollInterval = window.setInterval(fetchQrDisplayState, 1200);

    const handleStorageEvent = (e: StorageEvent) => {
      if (e.key === 'pos_customer_display_state_v1' && e.newValue) {
        try {
          applyIncomingData(JSON.parse(e.newValue));
        } catch {}
      } else if (e.key === 'pos_payment_config_v1' && e.newValue) {
        try {
          setPaymentConfig(JSON.parse(e.newValue));
        } catch {}
      }
    };

    const handleCustomEvent = (e: any) => {
      if (e.detail) {
        applyIncomingData(e.detail);
      }
    };

    window.addEventListener('storage', handleStorageEvent);
    window.addEventListener('pos_customer_display_event', handleCustomEvent);

    // Subscribe to internal StorageService sync
    const unsubscribeSync = StorageService.subscribeToSync((event) => {
      if (event.type === 'CUSTOMER_DISPLAY_SYNC') {
        const next = event.payload || StorageService.getCustomerDisplayState(activeTerminalId);
        const term = (next?.terminalId || '').toUpperCase();
        if (!term || normalizeTerminalId(term) === normalizeTerminalId(activeTerminalId)) {
          applyIncomingData(next);
        }
      } else if (event.type === 'PAYMENT_CONFIG_UPDATED') {
        setPaymentConfig(StorageService.getPaymentConfig());
      }
    });

    // Multi-tab BroadcastChannel support (matching channel 'pos_system_sync')
    let channel: BroadcastChannel | null = null;
    let legacyChannel: BroadcastChannel | null = null;
    try {
      channel = new BroadcastChannel('pos_system_sync');
      channel.onmessage = (e) => {
        if (e.data?.type === 'CUSTOMER_DISPLAY_SYNC' && e.data.payload) {
          const term = (e.data.payload.terminalId || '').toUpperCase();
          if (!term || normalizeTerminalId(term) === normalizeTerminalId(activeTerminalId)) {
            applyIncomingData(e.data.payload);
          }
        } else if (e.data?.type === 'PAYMENT_CONFIG_UPDATED') {
          setPaymentConfig(StorageService.getPaymentConfig());
        }
      };
    } catch {}

    try {
      legacyChannel = new BroadcastChannel('pos_sync_channel');
      legacyChannel.onmessage = (e) => {
        if (e.data?.type === 'CUSTOMER_DISPLAY_SYNC' && e.data.payload) {
          const term = (e.data.payload.terminalId || '').toUpperCase();
          if (!term || normalizeTerminalId(term) === normalizeTerminalId(activeTerminalId)) {
            applyIncomingData(e.data.payload);
          }
        }
      };
    } catch {}

    // 1. Multi-terminal Real-time Cloud / WebSocket sync (works across Wi-Fi & cellular networks)
    const unsubscribeCloud = CloudSync.subscribe((msg: any) => {
      if (msg.type === 'CUSTOMER_DISPLAY_SYNC' && msg.payload) {
        const term = (msg.payload.terminalId || msg.senderTerminalId || '').toUpperCase();
        if (!term || normalizeTerminalId(term) === normalizeTerminalId(activeTerminalId)) {
          applyIncomingData(msg.payload);
        }
      }
    });

    // 1. WebRTC Direct Peer-to-Peer sync (connects Cashier PC to Phone/Tablet with 0ms latency)
    try {
      PeerSync.connectToHost(activeTerminalId, (incomingData) => {
        applyIncomingData(incomingData);
      });
    } catch {}

    // 2. Instant 0ms Server-Sent Events (SSE) stream over Wi-Fi (for local dev server)
    const isLocalDevHost = typeof window !== 'undefined' && 
      (window.location.hostname === 'localhost' || 
       window.location.hostname === '127.0.0.1' || 
       window.location.port === '3000' ||
       /^192\.168\./.test(window.location.hostname) ||
       /^10\./.test(window.location.hostname));

    let isCustomerDisplayApiSupported: boolean | null = isLocalDevHost ? null : false;
    let eventSource: EventSource | null = null;
    let sseTimeout: any = null;
    let isSseConnected = false;

    const connectSse = () => {
      if (isCustomerDisplayApiSupported === false) return;
      try {
        const sseUrl = `/api/customer-display/stream?terminal=${encodeURIComponent(activeTerminalId)}&_t=${Date.now()}`;
        eventSource = new EventSource(sseUrl);
        eventSource.onopen = () => {
          isSseConnected = true;
          isCustomerDisplayApiSupported = true;
        };
        eventSource.onmessage = (e) => {
          if (!e.data || e.data.startsWith(':')) return;
          try {
            const parsed = JSON.parse(e.data);
            applyIncomingData(parsed);
          } catch {}
        };
        eventSource.onerror = () => {
          isSseConnected = false;
          try { eventSource?.close(); } catch {}
          if (isCustomerDisplayApiSupported !== false) {
            sseTimeout = setTimeout(connectSse, 4000);
          }
        };
      } catch {}
    };

    if (isCustomerDisplayApiSupported !== false) {
      connectSse();
    }

    // 3. Active cache-busting fetch & polling fallback for Wi-Fi tablets and external screens
    let isFetching = false;
    const fetchFromServer = () => {
      if (isFetching || isCustomerDisplayApiSupported === false) return;
      isFetching = true;
      fetch(`/api/customer-display?terminal=${encodeURIComponent(activeTerminalId)}&_t=${Date.now()}`, {
        cache: 'no-store',
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
        },
      })
        .then(res => {
          if (res.status === 404) {
            isCustomerDisplayApiSupported = false;
            try { eventSource?.close(); } catch {}
            if (sseTimeout) clearTimeout(sseTimeout);
            return null;
          }
          if (!res.ok) return null;
          isCustomerDisplayApiSupported = true;
          return res.json();
        })
        .then(serverData => {
          if (serverData) applyIncomingData(serverData);
        })
        .catch(() => {})
        .finally(() => {
          isFetching = false;
        });
    };

    // Initial immediate fetch only if supported
    if (isCustomerDisplayApiSupported !== false) {
      fetchFromServer();
    }

    // Adaptive polling: continuous fallback every 500ms
    const interval = isCustomerDisplayApiSupported !== false ? setInterval(fetchFromServer, 500) : null;

    // Clock interval
    const clockInterval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => {
      PeerSync.disconnectClient();
      window.removeEventListener('storage', handleStorageEvent);
      window.removeEventListener('pos_customer_display_event', handleCustomEvent);
      unsubscribeSync();
      unsubscribeCloud();
      if (interval) clearInterval(interval);
      clearInterval(qrDisplayPollInterval);
      clearInterval(clockInterval);
      if (sseTimeout) clearTimeout(sseTimeout);
      channel?.close();
      legacyChannel?.close();
      try { eventSource?.close(); } catch {}
    };
  }, [activeTerminalId]);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const items = Array.isArray(displayState?.items) ? displayState.items : [];
  const subtotal = typeof displayState?.subtotal === 'number' ? displayState.subtotal : 0;
  const discount = typeof displayState?.discount === 'number' ? displayState.discount : 0;
  const total = typeof displayState?.total === 'number' ? displayState.total : 0;
  const paymentMethod = displayState?.paymentMethod || null;
  const cashReceived = displayState?.cashReceived;
  const cashChange = displayState?.cashChange;
  const status = displayState?.status || 'WELCOME';
  const receiptNumber = displayState?.receiptNumber;

  const effectivePaymentConfig = displayState?.paymentConfig || paymentConfig;

  const getMpQrUrl = () => {
    // 1. Exact active QR image or cartel photo transmitted from main cashier terminal
    if (displayState?.qrImageUrl) {
      return displayState.qrImageUrl;
    }
    if (displayState?.qrData) {
      return `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(displayState.qrData)}`;
    }

    const cfg = effectivePaymentConfig;
    const normTerm = activeTerminalId.toUpperCase().trim();
    const curPosId = cfg.mpPosId || 'default';
    const specificQr = cfg.mpPosQrs?.[normTerm] 
      || cfg.mpPosQrs?.[normTerm.replace('TERM-', '')]
      || cfg.mpPosQrs?.[curPosId]
      || (cfg.mpPosQrs && Object.values(cfg.mpPosQrs)[0]);

    if (specificQr?.qrImage) return specificQr.qrImage;
    if (cfg.mpQrImage) return cfg.mpQrImage;
    if (specificQr?.qrData) {
      return `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(specificQr.qrData)}`;
    }
    if (cfg.mpQrData) {
      return `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(cfg.mpQrData)}`;
    }

    let qrData = cfg.mpQrText || '';
    if (!qrData) {
      try {
        qrData = generateArgentinaInteroperableQr({
          merchantName: cfg.mpHolder || 'MERCADO PAGO',
          cvuOrCbu: cfg.mpCvu || '0000003100084920194820',
          alias: cfg.mpAlias || 'MANUELSILVA2003.MP',
          amount: total > 0 ? total : undefined,
        });
      } catch {
        qrData = cfg.mpAlias || 'MANUELSILVA2003.MP';
      }
    }
    return `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(qrData)}`;
  };

  return (
    <div className={`w-full h-full min-h-screen bg-neutral-950 text-white flex flex-col font-['Plus_Jakarta_Sans',sans-serif] select-none overflow-y-auto lg:overflow-hidden ${standalone ? 'p-3 sm:p-5 md:p-6' : 'p-2 sm:p-4 md:p-5'}`}>
      {/* TOP STATUS BAR (Pantalla de Cliente) */}
      <header className="flex items-center justify-between pb-3 sm:pb-4 border-b border-neutral-800 flex-shrink-0">
        <div className="flex items-center gap-2.5 sm:gap-3">
          <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-xl bg-neutral-100 text-neutral-950 flex items-center justify-center font-black text-base sm:text-lg shadow-md shrink-0">
            POS
          </div>
          <div>
            <h1 className="text-base sm:text-lg md:text-xl font-black tracking-tight text-white flex items-center gap-2 flex-wrap">
              COMERCIO CENTRAL
              <span className="text-[10px] sm:text-xs font-bold px-2.5 py-0.5 rounded-full bg-neutral-800 text-neutral-300 font-mono">
                Pantalla para el Cliente
              </span>
            </h1>
            <p className="text-xs sm:text-sm text-neutral-400">
              Terminal: {activeTerminalId} • ¡Bienvenido!
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          {/* Terminal Switcher */}
          <div className="flex items-center gap-1.5 bg-neutral-900 border border-neutral-800 rounded-xl px-2.5 py-1 text-xs">
            <span className="text-[10px] text-neutral-400 uppercase font-bold hidden sm:inline">Terminal:</span>
            <select
              value={activeTerminalId}
              onChange={(e) => {
                const newTerm = e.target.value;
                setActiveTerminalId(newTerm);
                try {
                  const u = new URL(window.location.href);
                  u.searchParams.set('terminal', newTerm);
                  window.history.replaceState({}, '', u.toString());
                } catch {}
              }}
              className="bg-transparent text-emerald-400 font-bold focus:outline-hidden text-xs cursor-pointer"
            >
              {availableTerminals.map((t) => (
                <option key={t.id} value={t.id} className="bg-neutral-900 text-white">
                  {t.name}
                </option>
              ))}
            </select>
          </div>

          <button
            type="button"
            onClick={() => setShowWifiModal(true)}
            className="px-2.5 py-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-emerald-400 border border-neutral-800 transition-colors flex items-center gap-1.5 text-xs font-bold cursor-pointer"
            title="Conectar por Wi-Fi desde celular o tablet"
          >
            <Wifi className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Wi-Fi</span>
          </button>

          <div className="flex items-center gap-2 bg-neutral-900 px-3 py-1.5 rounded-xl border border-neutral-800 text-xs sm:text-sm font-mono text-neutral-300">
            <Clock className="w-3.5 h-3.5 text-neutral-400" />
            <span>{currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
          </div>

          <button
            type="button"
            onClick={toggleFullscreen}
            className="p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-800 transition-colors cursor-pointer"
            title="Pantalla Completa"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs sm:text-sm text-neutral-300 font-medium cursor-pointer"
            >
              Cerrar Vista
            </button>
          )}
        </div>
      </header>

      {/* COMPLETED SALE BANNER OVERLAY */}
      {status === 'COMPLETED' ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center p-6 sm:p-10 space-y-6 animate-in zoom-in-95">
          <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-emerald-500/20 border-2 border-emerald-500 text-emerald-400 flex items-center justify-center shadow-2xl">
            <CheckCircle2 className="w-14 h-14 sm:w-16 sm:h-16" />
          </div>
          <div className="space-y-2">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight">
              ¡Muchas Gracias por su Compra!
            </h2>
            <p className="text-xl sm:text-2xl text-emerald-400 font-extrabold">
              Pago procesado exitosamente
            </p>
            {receiptNumber && (
              <p className="text-base sm:text-lg font-mono text-neutral-400">
                Ticket / Comprobante #{receiptNumber}
              </p>
            )}
          </div>
          <div className="p-5 sm:p-6 bg-neutral-900 rounded-2xl border border-neutral-800 max-w-md w-full space-y-3 text-base">
            <div className="flex justify-between items-center text-neutral-400">
              <span className="font-medium">Total abonado:</span>
              <span className="text-2xl sm:text-3xl font-black font-mono text-white">${formatThousands(total)}</span>
            </div>
            {paymentMethod && (
              <div className="flex justify-between items-center text-neutral-400">
                <span className="font-medium">Forma de pago:</span>
                <span className="font-extrabold text-neutral-200 uppercase">
                  {(paymentMethod === 'TARJETA_POSNET' || paymentMethod === 'BILLETERA_VIRTUAL') ? 'TARJETA / POSNET' : paymentMethod}
                </span>
              </div>
            )}
            {cashChange !== undefined && cashChange > 0 && (
              <div className="flex justify-between items-center text-emerald-400 pt-2 border-t border-neutral-800 font-bold">
                <span className="text-lg">Su Vuelto:</span>
                <span className="text-2xl sm:text-3xl font-black font-mono">${formatThousands(cashChange)}</span>
              </div>
            )}
          </div>
          <p className="text-sm text-neutral-400">
            Retire su ticket impreso en el mostrador. ¡Que tenga un excelente día!
          </p>
        </div>
      ) : (
        /* ACTIVE SALE / REAL-TIME 2-COLUMN DISPLAY */
        <div className="flex-1 grid grid-cols-12 gap-2 sm:gap-4 pt-3 sm:pt-4 min-h-0 overflow-hidden">
          {/* LEFT COLUMN: LIST OF PURCHASED ITEMS */}
          <div className="col-span-6 xl:col-span-7 flex flex-col bg-neutral-900 rounded-2xl border border-neutral-800 overflow-hidden min-h-0">
            <div className="p-4 sm:p-5 bg-neutral-850 border-b border-neutral-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <ShoppingBag className="w-6 h-6 sm:w-7 sm:h-7 text-neutral-300" />
                <h3 className="text-lg sm:text-xl md:text-2xl font-black text-white tracking-wide">
                  Detalle de su Compra
                </h3>
              </div>
              <span className="text-sm sm:text-base md:text-lg font-mono font-bold px-3.5 py-1 bg-neutral-800 text-neutral-200 rounded-xl">
                {items.reduce((acc, i) => acc + i.quantity, 0)} artículos
              </span>
            </div>

            {/* Items list scroll */}
            <div className="flex-1 overflow-y-auto p-3 sm:p-5 divide-y divide-neutral-800/80">
              {items.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-8 text-neutral-500">
                  <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-neutral-800/50 flex items-center justify-center mb-3">
                    <Sparkles className="w-8 h-8 sm:w-10 sm:h-10 text-neutral-400" />
                  </div>
                  <h4 className="text-xl sm:text-2xl font-black text-neutral-200">Bienvenido</h4>
                  <p className="text-sm sm:text-base mt-1 text-neutral-400 max-w-sm">
                    Tus artículos aparecerán aquí en tiempo real a medida que sean escaneados en caja.
                  </p>
                </div>
              ) : (
                items.map((item, index) => (
                  <div key={index} className="py-3.5 sm:py-5 flex items-center justify-between gap-4">
                    <div className="min-w-0 flex-1">
                      <h4 className="text-lg sm:text-xl md:text-2xl font-bold sm:font-black text-neutral-100 leading-snug">
                        {item.name}
                      </h4>
                      <div className="text-sm sm:text-base md:text-lg text-neutral-300 flex items-center gap-3 mt-1 font-mono">
                        <span className="px-2.5 py-0.5 rounded-lg bg-neutral-800 text-emerald-400 font-black text-sm sm:text-base md:text-lg">
                          {item.quantity} un.
                        </span>
                        <span className="text-neutral-400">x ${formatThousands(item.unitPrice)} c/u</span>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="text-xl sm:text-2xl md:text-3xl font-black font-mono text-white">
                        ${formatThousands(item.total)}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Bottom Subtotal & Items count */}
            {items.length > 0 && (
              <div className="p-4 sm:p-5 bg-neutral-950/90 border-t border-neutral-800 flex items-center justify-between text-base sm:text-lg text-neutral-300">
                <span className="font-bold">Subtotal ({items.length} productos):</span>
                <span className="font-mono text-xl sm:text-2xl md:text-3xl font-black text-white">
                  ${formatThousands(subtotal)}
                </span>
              </div>
            )}
          </div>

          {/* RIGHT COLUMN: PAYMENT FOCUS & TOTAL A PAGAR */}
          <div className="col-span-6 xl:col-span-5 flex flex-col gap-2 sm:gap-4 min-h-0 overflow-y-auto">
            {/* TOTAL HERO BOX */}
            <div className="p-5 sm:p-6 md:p-7 bg-gradient-to-b from-neutral-900 to-neutral-850 rounded-2xl border-2 border-neutral-800 shadow-xl text-center space-y-1">
              <span className="text-xs sm:text-sm md:text-base font-black uppercase tracking-widest text-neutral-400">
                Total a Pagar
              </span>
              <div className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black font-mono text-white tracking-tight">
                ${formatThousands(total)}
              </div>
              {discount > 0 && (
                <div className="text-sm sm:text-base text-rose-400 font-extrabold pt-1">
                  Descuento especial aplicado: -${formatThousands(discount)}
                </div>
              )}
            </div>

            {/* DYNAMIC PAYMENT METHOD CARDS */}
            {paymentMethod === 'EFECTIVO' && (
              <div className="flex-1 bg-neutral-900 rounded-2xl border-2 border-emerald-500/40 p-5 sm:p-7 flex flex-col justify-center text-center space-y-5 animate-in fade-in shadow-xl">
                <div className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto text-xs sm:text-sm md:text-base font-extrabold uppercase tracking-wider">
                  <Banknote className="w-5 h-5" />
                  Pago en Efectivo
                </div>

                <div className="space-y-1">
                  <span className="text-xs sm:text-sm text-neutral-400 font-extrabold uppercase tracking-wider">Monto Total a Cobrar</span>
                  <div className="text-5xl sm:text-6xl md:text-7xl font-black font-mono text-white">
                    ${formatThousands(total)}
                  </div>
                </div>

                {cashReceived !== undefined && cashReceived > 0 ? (
                  <div className="p-4 sm:p-5 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-3 text-left">
                    <div className="flex justify-between items-center text-base sm:text-lg text-neutral-300">
                      <span className="font-bold">Monto Abonado:</span>
                      <span className="font-mono text-xl sm:text-2xl font-black text-white">${formatThousands(cashReceived)}</span>
                    </div>
                    <div className="flex justify-between items-center text-lg sm:text-xl pt-3 border-t border-neutral-800">
                      <span className="font-black text-emerald-400 uppercase text-sm sm:text-base">Su Vuelto:</span>
                      <span className="text-3xl sm:text-4xl md:text-5xl font-black font-mono text-emerald-400">
                        ${formatThousands(cashChange || 0)}
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="text-sm sm:text-base text-neutral-300 bg-neutral-950/70 p-4 rounded-xl border border-neutral-800 font-medium">
                    Aguarde mientras el cajero ingresa el monto recibido en caja...
                  </div>
                )}
              </div>
            )}

            {paymentMethod === 'MERCADO_PAGO_QR' && (
              <div className="flex-1 bg-neutral-900 rounded-2xl border-2 border-sky-500/40 p-5 sm:p-7 flex flex-col items-center justify-center text-center space-y-4 animate-in fade-in shadow-xl">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-sky-500/20 text-sky-400 text-xs sm:text-sm md:text-base font-extrabold uppercase tracking-wider">
                  <QrCode className="w-5 h-5" />
                  Mercado Pago QR (Interoperable BCRA)
                </div>

                {effectivePaymentConfig.mpConnected && (
                  <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/20 text-emerald-400 text-xs sm:text-sm font-bold">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                    Caja en Vivo: {effectivePaymentConfig.mpPosName || 'QR #01'} • Importe automático
                  </div>
                )}

                <div className="text-base sm:text-lg md:text-xl text-neutral-200 max-w-md font-medium">
                  Abra la App de <strong>Mercado Pago</strong> o cualquier billetera y escanee el código:
                </div>

                {/* QR CODE CARD */}
                <div className="p-4 sm:p-5 bg-white rounded-2xl shadow-2xl inline-block border-2 border-sky-300">
                  <div className="w-52 h-52 sm:w-64 sm:h-64 md:w-72 md:h-72 lg:w-80 lg:h-80 bg-white rounded-xl flex flex-col items-center justify-center relative overflow-hidden p-1">
                    <img 
                      src={getMpQrUrl()} 
                      alt="Código QR Oficial de Mercado Pago"
                      className="w-full h-full object-contain"
                      loading="eager"
                    />
                  </div>
                </div>

                <div className="bg-neutral-950 px-5 py-2.5 rounded-xl border border-neutral-800 text-center">
                  <span className="text-xs sm:text-sm uppercase font-bold text-neutral-400 block">Total a escanear:</span>
                  <span className="text-2xl sm:text-3xl font-black font-mono text-white">${formatThousands(total)}</span>
                </div>
              </div>
            )}

            {(paymentMethod === 'TARJETA_POSNET' || paymentMethod === 'BILLETERA_VIRTUAL') && (() => {
              const isAuto = displayState?.posnetMode === 'AUTOMATIC';
              const status = displayState?.posnetStatus || 'WAITING_CARD';

              return (
                <div className="flex-1 bg-neutral-900 rounded-2xl border-2 border-violet-500/40 p-5 sm:p-7 flex flex-col justify-between text-center space-y-4 animate-in fade-in shadow-xl">
                  <div className="space-y-1">
                    <div className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-full bg-violet-500/20 text-violet-400 mx-auto text-xs sm:text-sm md:text-base font-extrabold uppercase tracking-wider">
                      <CreditCard className="w-5 h-5" />
                      Pago con Tarjeta / Posnet
                    </div>
                  </div>

                  <div className="flex-1 flex flex-col items-center justify-center space-y-4 py-4 sm:py-6">
                    {status === 'APPROVED' ? (
                      <div className="space-y-3 animate-in zoom-in-95">
                        <div className="w-18 h-18 sm:w-22 sm:h-22 rounded-full bg-emerald-500 text-black flex items-center justify-center mx-auto shadow-2xl">
                          <Check className="w-10 h-10 sm:w-12 sm:h-12 stroke-[3]" />
                        </div>
                        <h4 className="text-2xl sm:text-3xl md:text-4xl font-black text-emerald-400">¡Pago Aprobado!</h4>
                        <p className="text-sm sm:text-base text-neutral-300">
                          Operación completada con éxito. Aguarde su comprobante.
                        </p>
                      </div>
                    ) : status === 'PROCESSING' ? (
                      <div className="space-y-3 animate-in fade-in">
                        <RefreshCw className="w-14 h-14 sm:w-16 sm:h-16 text-violet-400 animate-spin mx-auto" />
                        <h4 className="text-xl sm:text-2xl md:text-3xl font-black text-white">Procesando pago...</h4>
                        <p className="text-sm sm:text-base text-neutral-300">
                          Validando operación con la red de tarjetas
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-4 animate-in fade-in">
                        <div className="relative w-18 h-18 sm:w-20 sm:h-20 mx-auto">
                          <div className="absolute inset-0 rounded-full bg-violet-500/30 animate-ping" />
                          <div className="relative w-18 h-18 sm:w-20 sm:h-20 rounded-full bg-violet-600 text-white flex items-center justify-center shadow-xl">
                            <CreditCard className="w-9 h-9 sm:w-10 sm:h-10" />
                          </div>
                        </div>
                        <div>
                          <h4 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-black text-white">
                            {isAuto ? 'Acerque o Inserte su Tarjeta' : 'Pase su Tarjeta por el Posnet'}
                          </h4>
                          <p className="text-sm sm:text-base md:text-lg text-neutral-300 mt-2 font-medium">
                            Aceptamos Débito, Crédito y Prepaga (Contactless, Chip o Banda)
                          </p>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="bg-neutral-950 p-4 sm:p-5 rounded-2xl border border-neutral-800 flex justify-between items-center">
                    <span className="text-sm sm:text-base md:text-lg text-neutral-300 font-bold">Total a pagar:</span>
                    <span className="text-2xl sm:text-3xl md:text-4xl font-black font-mono text-white">${formatThousands(total)}</span>
                  </div>
                </div>
              );
            })()}

            {paymentMethod === 'TRANSFERENCIA' && (() => {
              const transfers = displayState?.transfersReceived || [];
              const totalRec = displayState?.transfersTotalReceived || 0;
              const remaining = Math.max(0, total - totalRec);
              const isCovered = totalRec >= total && total > 0;

              return (
                <div className="flex-1 bg-neutral-900 rounded-2xl border-2 border-emerald-500/40 p-4 sm:p-6 md:p-7 flex flex-col justify-center text-center space-y-4 animate-in fade-in shadow-xl">
                  <div className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto text-xs sm:text-sm md:text-base font-extrabold uppercase tracking-wider">
                    <CreditCard className="w-5 h-5" />
                    Transferencia Bancaria
                  </div>

                  {isCovered ? (
                    <div className="p-6 bg-emerald-950/80 border-2 border-emerald-500 rounded-2xl space-y-3 animate-pulse">
                      <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                        <CheckCircle2 className="w-8 h-8 text-emerald-400" />
                      </div>
                      <h4 className="text-xl sm:text-2xl md:text-3xl font-black text-emerald-300">
                        ¡PAGO TOTAL RECIBIDO!
                      </h4>
                      <p className="text-base sm:text-lg text-emerald-200">
                        Total acreditado: <span className="font-mono font-black text-white">${formatThousands(totalRec)}</span>
                      </p>
                      <p className="text-sm text-neutral-300">
                        Aguarde mientras el cajero emite su ticket.
                      </p>
                    </div>
                  ) : (
                    <>
                      <div className="text-sm sm:text-base text-neutral-300 font-medium">
                        Realice la transferencia desde su Homebanking o billetera:
                      </div>

                      {/* Bank Card Info - TEXTOS GRANDES Y CLAROS PARA LOS CLIENTES */}
                      <div className="bg-neutral-950 p-4 sm:p-6 rounded-2xl border-2 border-emerald-500/30 space-y-3.5 sm:space-y-4 text-left shadow-xl">
                        <div>
                          <span className="text-xs sm:text-sm text-neutral-400 uppercase font-black tracking-wider block mb-1">
                            Alias para Transferir
                          </span>
                          <div className="font-mono text-xl sm:text-2xl md:text-3xl lg:text-4xl font-black text-emerald-400 bg-neutral-900/90 p-3 sm:p-4 rounded-xl border-2 border-emerald-500/40 shadow-inner select-all break-all tracking-wide">
                            {paymentConfig.bankAlias || 'COMERCIO.CENTRAL.PAGO'}
                          </div>
                        </div>

                        <div>
                          <span className="text-xs sm:text-sm text-neutral-400 uppercase font-black tracking-wider block mb-1">
                            CBU / CVU (22 Dígitos)
                          </span>
                          <div className="font-mono text-sm sm:text-base md:text-lg lg:text-xl font-bold text-white bg-neutral-900/90 p-3 sm:p-3.5 rounded-xl border border-neutral-700 select-all tracking-wider break-all">
                            {paymentConfig.bankCbu || '0720123488000012345678'}
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 pt-2 border-t border-neutral-800">
                          <div className="bg-neutral-900/70 p-2.5 sm:p-3 rounded-xl border border-neutral-800/80">
                            <span className="text-neutral-400 text-xs sm:text-sm font-bold uppercase block">Banco:</span>
                            <div className="text-white text-base sm:text-lg md:text-xl font-extrabold mt-0.5">{paymentConfig.bankName || 'Banco Santander / Galicia'}</div>
                          </div>
                          <div className="bg-neutral-900/70 p-2.5 sm:p-3 rounded-xl border border-neutral-800/80">
                            <span className="text-neutral-400 text-xs sm:text-sm font-bold uppercase block">Titular de la Cuenta:</span>
                            <div className="text-white text-base sm:text-lg md:text-xl font-extrabold mt-0.5">{paymentConfig.bankHolder || 'Empresa Comercial S.A.'}</div>
                          </div>
                        </div>

                        {paymentConfig.bankCuit && (
                          <div className="bg-neutral-900/70 p-2.5 sm:p-3 rounded-xl border border-neutral-800/80 flex items-center justify-between flex-wrap gap-2">
                            <span className="text-neutral-400 text-xs sm:text-sm font-bold uppercase">CUIT:</span>
                            <span className="font-mono text-base sm:text-lg md:text-xl font-extrabold text-white">{paymentConfig.bankCuit}</span>
                          </div>
                        )}
                      </div>
                    </>
                  )}

                  {/* Estado en vivo de transferencias detectadas */}
                  {transfers.length > 0 && !isCovered && (
                    <div className="bg-neutral-950 p-4 sm:p-5 rounded-2xl border-2 border-amber-500/50 text-left space-y-3 shadow-lg">
                      <div className="flex justify-between items-center text-sm sm:text-base">
                        <span className="font-black text-amber-400 flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping" />
                          Pago Parcial Acreditado
                        </span>
                        <span className="font-mono font-black text-emerald-400 text-lg sm:text-xl">
                          +${formatThousands(totalRec)}
                        </span>
                      </div>

                      <div className="space-y-1.5">
                        {transfers.map((tr, idx) => (
                          <div key={idx} className="flex justify-between items-center text-xs sm:text-sm bg-neutral-900/90 px-3 py-2 rounded-xl text-neutral-200 border border-neutral-800 font-medium">
                            <span>✓ {tr.payerName} ({tr.platform})</span>
                            <span className="font-mono font-bold text-emerald-400 text-sm sm:text-base">${formatThousands(tr.amount)}</span>
                          </div>
                        ))}
                      </div>

                      <div className="flex justify-between items-baseline pt-2 border-t border-neutral-800">
                        <span className="text-amber-300 font-extrabold uppercase tracking-wider text-xs sm:text-sm">
                          Resta Transferir:
                        </span>
                        <span className="text-2xl sm:text-3xl md:text-4xl font-black font-mono text-amber-400">
                          ${formatThousands(remaining)}
                        </span>
                      </div>
                    </div>
                  )}

                  {!isCovered && transfers.length === 0 && (
                    <div className="bg-neutral-950 p-4 sm:p-5 rounded-2xl border-2 border-emerald-500/50 flex flex-col sm:flex-row justify-between items-center gap-2 shadow-lg">
                      <span className="text-sm sm:text-base md:text-lg font-extrabold text-neutral-300 uppercase tracking-wide">
                        Total a transferir:
                      </span>
                      <span className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-black font-mono text-emerald-400">
                        ${formatThousands(total)}
                      </span>
                    </div>
                  )}
                </div>
              );
            })()}

            {paymentMethod === 'CUENTA_CORRIENTE' && (
              /* CRITICAL REQUIREMENT: Do NOT show the client's name on the customer display */
              <div className="flex-1 bg-neutral-900 rounded-2xl border-2 border-amber-500/40 p-5 sm:p-7 flex flex-col justify-center text-center space-y-5 animate-in fade-in shadow-xl">
                <div className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-full bg-amber-500/20 text-amber-400 mx-auto text-xs sm:text-sm md:text-base font-extrabold uppercase tracking-wider">
                  <Check className="w-5 h-5" />
                  Cargo a Cuenta Corriente
                </div>

                <div className="p-6 sm:p-8 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-4">
                  <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto shadow-md">
                    <CheckCircle2 className="w-8 h-8 sm:w-9 sm:h-9" />
                  </div>
                  <h4 className="text-xl sm:text-2xl md:text-3xl font-black text-white">
                    Venta Registrada en Cuenta Corriente
                  </h4>
                  <p className="text-sm sm:text-base text-neutral-300 max-w-md mx-auto font-medium">
                    El importe de la venta se ha cargado de manera privada en su saldo deudor comercial.
                  </p>
                  <div className="pt-3 border-t border-neutral-800">
                    <span className="text-xs sm:text-sm text-neutral-400 uppercase font-extrabold">Monto del Comprobante:</span>
                    <div className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black font-mono text-amber-400 mt-1">
                      ${formatThousands(total)}
                    </div>
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-neutral-400">
                  Por razones de seguridad y privacidad, los datos del titular no se exhiben en pantalla.
                </p>
              </div>
            )}

            {!paymentMethod && (
              <div className="flex-1 bg-neutral-900/60 rounded-2xl border-2 border-dashed border-neutral-800 p-8 flex flex-col items-center justify-center text-center space-y-3">
                <div className="w-14 h-14 rounded-2xl bg-neutral-800 text-neutral-400 flex items-center justify-center">
                  <Tv className="w-7 h-7" />
                </div>
                <h4 className="text-base sm:text-lg md:text-xl font-black text-neutral-200">
                  Seleccione su Forma de Pago
                </h4>
                <p className="text-sm sm:text-base text-neutral-400 max-w-sm">
                  Indique en caja cómo desea abonar: Efectivo, Mercado Pago QR, Transferencia Bancaria o Cuenta Corriente.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Wi-Fi Pairing Modal */}
      <WifiDisplayModal
        isOpen={showWifiModal}
        onClose={() => setShowWifiModal(false)}
        terminalId={activeTerminalId}
      />
    </div>
  );
};
