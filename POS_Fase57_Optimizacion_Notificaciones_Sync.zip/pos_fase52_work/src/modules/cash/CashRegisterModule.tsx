import React, { useState } from 'react';
import { 
  DollarSign, 
  Lock, 
  Unlock, 
  ArrowUpRight, 
  ArrowDownRight, 
  Printer, 
  AlertCircle, 
  CheckCircle2, 
  QrCode, 
  CreditCard, 
  Banknote,
  Receipt,
  X,
  History,
  Smartphone,
  FileText,
  FileSpreadsheet,
  Download,
  Upload,
  Trash2
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import { CashShift, PaymentMethod } from '../../types';
import { formatThousands, parseFormattedNumber } from '../../utils/text';
import { CashImportModal } from './CashImportModal';
import { exportToExcel, exportToCsv } from '../../utils/exportUtils';
import { DialogService } from '../../services/dialog';

export const CashRegisterModule: React.FC = () => {
  const { 
    currentShift, 
    cashShifts, 
    openCashShift, 
    closeCashShift, 
    addCashExpenseOrIncome,
    externalServiceSales,
    addExternalServiceSale,
    deleteExternalServiceSale,
    currentTerminalId,
    reloadAllFromStorage
  } = useApp();

  const { hasPermission, currentUser } = useAuth();

  // Modals
  const [showOpenModal, setShowOpenModal] = useState(false);
  const [showCloseModal, setShowCloseModal] = useState(false);
  const [showMovementModal, setShowMovementModal] = useState(false);
  const [showReportModal, setShowReportModal] = useState<CashShift | null>(null);
  const [showExternalServiceModal, setShowExternalServiceModal] = useState(false);
  const [importModalMode, setImportModalMode] = useState<'CSV' | 'EXCEL' | null>(null);

  // Form inputs
  const [initialCashInput, setInitialCashInput] = useState<string>('15,000');
  const [declaredCashInput, setDeclaredCashInput] = useState<string>('');
  const [closureNotes, setClosureNotes] = useState<string>('');

  // Cash movement input
  const [movementType, setMovementType] = useState<'INCOME' | 'EXPENSE'>('EXPENSE');
  const [movementAmount, setMovementAmount] = useState<string>('');
  const [movementConcept, setMovementConcept] = useState<string>('');

  // External Services (Claro & SAT) input
  const [serviceType, setServiceType] = useState<'CLARO' | 'SAT'>('CLARO');
  const [serviceAmount, setServiceAmount] = useState<string>('');
  const [serviceNotes, setServiceNotes] = useState<string>('');

  const canClose = hasPermission('canCloseCashRegister');

  // External services calculations for the active shift
  const currentShiftExternalSales = externalServiceSales.filter(s => 
    currentShift ? (s.shiftId === currentShift.id || (s.shiftNumber === currentShift.shiftNumber && s.terminalId === currentTerminalId)) : false
  );

  const claroSales = currentShiftExternalSales.filter(s => s.service === 'CLARO');
  const satSales = currentShiftExternalSales.filter(s => s.service === 'SAT');

  const totalClaroShift = claroSales.reduce((acc, curr) => acc + curr.amount, 0);
  const totalSatShift = satSales.reduce((acc, curr) => acc + curr.amount, 0);
  const totalExternalShift = totalClaroShift + totalSatShift;

  const handleOpenServiceModal = (type: 'CLARO' | 'SAT') => {
    setServiceType(type);
    setServiceAmount('');
    setServiceNotes('');
    setShowExternalServiceModal(true);
  };

  const handleServiceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFormattedNumber(serviceAmount);
    if (amount <= 0) return;

    addExternalServiceSale(serviceType, amount, serviceNotes);
    setShowExternalServiceModal(false);
    setServiceAmount('');
    setServiceNotes('');
  };

  const handleOpenSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFormattedNumber(initialCashInput);
    openCashShift(amount);
    setShowOpenModal(false);
  };

  const handleCloseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentShift) return;
    const declared = parseFormattedNumber(declaredCashInput);
    const { shift } = closeCashShift(declared, closureNotes);
    setShowCloseModal(false);
    setShowReportModal(shift);
    setDeclaredCashInput('');
    setClosureNotes('');
  };

  const handleMovementSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFormattedNumber(movementAmount);
    if (amount <= 0 || !movementConcept.trim()) return;

    addCashExpenseOrIncome(movementType, amount, movementConcept.trim(), 'EFECTIVO');
    setShowMovementModal(false);
    setMovementAmount('');
    setMovementConcept('');
  };

  const handleExportCash = (format: 'EXCEL' | 'CSV') => {
    if (cashShifts.length === 0) {
      DialogService.alert('No hay turnos registrados en el historial para exportar.', 'Exportar Caja', 'info');
      return;
    }

    const exportData = cashShifts.map((shift) => {
      const openDate = new Date(shift.openedAt);
      const closeDate = shift.closedAt ? new Date(shift.closedAt) : null;
      const dateFormatted = !isNaN(openDate.getTime()) ? openDate.toISOString().slice(0, 10) : '';
      const timeFormatted = closeDate && !isNaN(closeDate.getTime())
        ? closeDate.toTimeString().slice(0, 8)
        : (!isNaN(openDate.getTime()) ? openDate.toTimeString().slice(0, 8) : '12:00:00');

      return {
        FECHA: dateFormatted,
        HORA: timeFormatted,
        TURNO: shift.shiftNumber,
        USUARIO: shift.closedByUserName || shift.openedByUserName,
        INICIAL: shift.initialCash,
        EFECTIVO: shift.totalCashSales,
        MERCADOPAG: shift.totalMpSales,
        QR: 0,
        TRANSFEREN: shift.totalTransferSales,
        TARJETA: shift.totalCardSales,
        INGRESOS: shift.totalCashIncomes,
        EGRESOS: shift.totalCashExpenses,
        ESPERADO: shift.expectedCashInRegister,
        ARQUEO: shift.declaredCashInRegister ?? shift.expectedCashInRegister,
        DIFERENCIA: shift.cashDifference ?? 0,
        CONCEPTO: shift.notes || 'Cierre de turno',
        ESTADO: shift.status === 'OPEN' ? 'ABIERTO' : 'CERRADO',
      };
    });

    const dateStr = new Date().toISOString().slice(0, 10);
    const fileName = `caja_turnos_cierres_${dateStr}`;

    if (format === 'EXCEL') {
      exportToExcel(exportData, fileName, 'Cierres de Caja');
    } else {
      exportToCsv(exportData, fileName, ';');
    }

    DialogService.alert(
      `Se exportaron ${exportData.length} turnos de caja en formato ${format === 'EXCEL' ? 'Excel (.xlsx)' : 'CSV (.csv)'} con las columnas de tu base de datos exitosamente.`,
      'Exportación Exitosa',
      'success'
    );
  };

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-6 space-y-4 w-full">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-neutral-900 p-4 rounded-xl border border-neutral-200 dark:border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-neutral-900 dark:text-white tracking-tight">Control & Cierre de Caja</h2>
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider ${
              currentShift 
                ? 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300' 
                : 'bg-rose-100 dark:bg-rose-950/80 text-rose-800 dark:text-rose-300'
            }`}>
              {currentShift ? `Turno Abierto (${currentShift.shiftNumber})` : 'Caja Cerrada'}
            </span>
          </div>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
            Arqueo ciego, desglose por formas de pago y balance del turno en la terminal activa
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Base de Datos CSV / Excel */}
          <button
            type="button"
            onClick={() => setImportModalMode('CSV')}
            className="px-3 py-2 bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
            title="Importar base de datos de caja en formato CSV (.csv)"
          >
            <FileText className="w-4 h-4 text-emerald-300" />
            <span>Importar CSV</span>
          </button>

          <button
            type="button"
            onClick={() => setImportModalMode('EXCEL')}
            className="px-3 py-2 bg-teal-700 hover:bg-teal-800 active:scale-95 text-white rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
            title="Importar base de datos de caja en formato Excel (.xlsx / .xls)"
          >
            <FileSpreadsheet className="w-4 h-4 text-teal-300" />
            <span>Importar Excel</span>
          </button>

          <button
            type="button"
            onClick={() => handleExportCash('EXCEL')}
            className="px-3 py-2 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 border border-neutral-300 dark:border-neutral-600 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
            title="Exportar cierres de caja a Excel (.xlsx)"
          >
            <Download className="w-4 h-4 text-emerald-600" />
            <span>Exportar Excel</span>
          </button>

          {currentShift ? (
            <>
              <button
                type="button"
                onClick={() => setShowMovementModal(true)}
                className="px-3.5 py-2 border border-neutral-300 dark:border-neutral-700 hover:bg-neutral-50 dark:hover:bg-neutral-800 text-neutral-800 dark:text-neutral-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <DollarSign className="w-4 h-4 text-neutral-500 dark:text-neutral-400" />
                Ingreso / Retiro de Efectivo
              </button>
              {canClose && (
                <button
                  type="button"
                  onClick={() => {
                    setDeclaredCashInput(formatThousands(currentShift.expectedCashInRegister));
                    setShowCloseModal(true);
                  }}
                  className="primary-action-dark-white px-4 py-2 bg-neutral-900 hover:bg-neutral-800 dark:bg-emerald-600 dark:hover:bg-emerald-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs"
                >
                  <Lock className="w-4 h-4 text-amber-400" />
                  Cierre de Turno (Arqueo)
                </button>
              )}
            </>
          ) : (
            <button
              type="button"
              onClick={() => setShowOpenModal(true)}
              className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 dark:bg-emerald-600 dark:hover:bg-emerald-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <Unlock className="w-4 h-4 text-emerald-400" />
              Abrir Turno de Caja
            </button>
          )}
        </div>
      </div>

      {/* ACTIVE SHIFT SUMMARY */}
      {currentShift ? (
        <div className="space-y-4">
          {/* Main Key Figures */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            {/* Expected Cash in drawer */}
            <div className="p-4 bg-neutral-900 dark:bg-neutral-950 text-white rounded-xl shadow-xs border border-transparent dark:border-neutral-800">
              <span className="text-[11px] uppercase tracking-wider text-neutral-400 font-semibold">
                Efectivo Esperado en Cajón
              </span>
              <div className="text-2xl font-black font-mono mt-1 text-emerald-400">
                ${formatThousands(currentShift.expectedCashInRegister)}
              </div>
              <div className="text-[10px] text-neutral-400 mt-1">
                Fondo inicial (${formatThousands(currentShift.initialCash)}) + Ventas Efectivo - Retiros
              </div>
            </div>

            {/* Total Sales in shift */}
            <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl">
              <span className="text-[11px] uppercase tracking-wider text-neutral-500 dark:text-neutral-400 font-semibold">
                Total Ventas del Turno
              </span>
              <div className="text-2xl font-black font-mono mt-1 text-neutral-900 dark:text-white">
                ${formatThousands(currentShift.totalSales)}
              </div>
              <div className="text-[10px] text-neutral-500 dark:text-neutral-400 mt-1">
                Todos los medios de pago consolidados
              </div>
            </div>

            {/* Incomes & Outflows */}
            <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl">
              <span className="text-[11px] uppercase tracking-wider text-neutral-500 dark:text-neutral-400 font-semibold">
                Ingresos / Retiros Efectivo
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-sm font-bold font-mono text-emerald-600 dark:text-emerald-400">
                  +${formatThousands(currentShift.totalCashIncomes)}
                </span>
                <span className="text-sm font-bold font-mono text-rose-600 dark:text-rose-400">
                  -${formatThousands(currentShift.totalCashExpenses)}
                </span>
              </div>
              <div className="text-[10px] text-neutral-500 dark:text-neutral-400 mt-1">
                Cobranzas cta cte y gastos menores
              </div>
            </div>

            {/* Shift info */}
            <div className="p-4 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl text-xs space-y-1">
              <div className="text-[11px] uppercase tracking-wider text-neutral-500 dark:text-neutral-400 font-semibold">
                Detalles del Turno
              </div>
              <div className="text-neutral-700 dark:text-neutral-300"><strong>Cajero:</strong> {currentShift.openedByUserName}</div>
              <div className="text-neutral-700 dark:text-neutral-300"><strong>Terminal:</strong> {currentShift.terminalId}</div>
              <div className="text-neutral-500 dark:text-neutral-400 text-[10px]">
                Abierto: {new Date(currentShift.openedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          </div>

          {/* Breakdown by Payment Method */}
          <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-3">
              Desglose de Ventas por Medio de Pago
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
              <div className="p-3 bg-neutral-50 dark:bg-neutral-800/60 rounded-lg border border-neutral-200 dark:border-neutral-700 flex items-center gap-3">
                <div className="p-2 bg-emerald-100 dark:bg-emerald-950/80 rounded-lg text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/60 shadow-2xs">
                  <Banknote className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-semibold text-neutral-500 dark:text-neutral-400 uppercase">Efectivo</span>
                  <div className="text-sm font-extrabold font-mono text-neutral-900 dark:text-white">
                    ${formatThousands(currentShift.totalCashSales)}
                  </div>
                </div>
              </div>

              <div className="p-3 bg-sky-50/60 dark:bg-sky-950/40 rounded-lg border border-sky-200 dark:border-sky-800/80 flex items-center gap-3">
                <div className="p-2 bg-sky-100 dark:bg-sky-900/60 rounded-lg text-sky-700 dark:text-sky-300">
                  <QrCode className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-semibold text-sky-700 dark:text-sky-300 uppercase">Mercado Pago QR</span>
                  <div className="text-sm font-extrabold font-mono text-sky-950 dark:text-sky-100">
                    ${formatThousands(currentShift.totalMpSales)}
                  </div>
                </div>
              </div>

              <div className="p-3 bg-violet-50/60 dark:bg-violet-950/40 rounded-lg border border-violet-200 dark:border-violet-800/80 flex items-center gap-3">
                <div className="p-2 bg-violet-100 dark:bg-violet-900/60 rounded-lg text-violet-700 dark:text-violet-300">
                  <CreditCard className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-semibold text-violet-700 dark:text-violet-300 uppercase">Tarjeta / Posnet</span>
                  <div className="text-sm font-extrabold font-mono text-violet-950 dark:text-violet-100">
                    ${formatThousands(currentShift.totalCardSales || 0)}
                  </div>
                </div>
              </div>

              <div className="p-3 bg-emerald-50/60 dark:bg-emerald-950/40 rounded-lg border border-emerald-200 dark:border-emerald-800/80 flex items-center gap-3">
                <div className="p-2 bg-emerald-100 dark:bg-emerald-900/60 rounded-lg text-emerald-700 dark:text-emerald-300">
                  <CreditCard className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-semibold text-emerald-700 dark:text-emerald-300 uppercase">Transferencias</span>
                  <div className="text-sm font-extrabold font-mono text-emerald-950 dark:text-emerald-100">
                    ${formatThousands(currentShift.totalTransferSales)}
                  </div>
                </div>
              </div>

              <div className="p-3 bg-amber-50/60 dark:bg-amber-950/40 rounded-lg border border-amber-200 dark:border-amber-800/80 flex items-center gap-3">
                <div className="p-2 bg-amber-100 dark:bg-amber-900/60 rounded-lg text-amber-700 dark:text-amber-300">
                  <DollarSign className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-semibold text-amber-700 dark:text-amber-300 uppercase">Cuenta Corriente</span>
                  <div className="text-sm font-extrabold font-mono text-amber-950 dark:text-amber-100">
                    ${formatThousands(currentShift.totalCurrentAccountSales)}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* SERVICIOS EXTERNOS (CLARO & SAT) DEL TURNO */}
          <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl p-4 space-y-3 shadow-2xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-100 dark:border-neutral-800 pb-3">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-800 dark:text-neutral-200 flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-red-600" />
                  Control de Servicios Externos del Turno (Claro & SAT)
                </h3>
                <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
                  Registro de ventas externas cargadas por el cajero para el balance y arqueo al momento de cerrar
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleOpenServiceModal('CLARO')}
                  className="px-3 py-1.5 bg-red-600 hover:bg-red-700 active:scale-95 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-all"
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  + Cargar Claro
                </button>
                <button
                  type="button"
                  onClick={() => handleOpenServiceModal('SAT')}
                  className="px-3 py-1.5 bg-sky-700 hover:bg-sky-800 active:scale-95 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-all"
                >
                  <FileText className="w-3.5 h-3.5" />
                  + Cargar SAT
                </button>
              </div>
            </div>

            {/* Total cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3 bg-red-50/60 dark:bg-red-950/30 rounded-lg border border-red-200 dark:border-red-900/50 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-red-700 dark:text-red-400 uppercase tracking-wider">
                    Total Claro
                  </span>
                  <div className="text-lg font-black font-mono text-red-900 dark:text-red-200">
                    ${formatThousands(totalClaroShift)}
                  </div>
                  <span className="text-[10px] text-neutral-500">{claroSales.length} carga(s)</span>
                </div>
                <div className="p-2 bg-red-100 dark:bg-red-900/50 rounded-lg text-red-600 dark:text-red-300">
                  <Smartphone className="w-5 h-5" />
                </div>
              </div>

              <div className="p-3 bg-sky-50/60 dark:bg-sky-950/30 rounded-lg border border-sky-200 dark:border-sky-900/50 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-sky-700 dark:text-sky-400 uppercase tracking-wider">
                    Total SAT
                  </span>
                  <div className="text-lg font-black font-mono text-sky-900 dark:text-sky-200">
                    ${formatThousands(totalSatShift)}
                  </div>
                  <span className="text-[10px] text-neutral-500">{satSales.length} carga(s)</span>
                </div>
                <div className="p-2 bg-sky-100 dark:bg-sky-900/50 rounded-lg text-sky-700 dark:text-sky-300">
                  <FileText className="w-5 h-5" />
                </div>
              </div>

              <div className="p-3 bg-neutral-900 text-white rounded-lg flex items-center justify-between shadow-xs">
                <div>
                  <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
                    Total Servicios Externos
                  </span>
                  <div className="text-lg font-black font-mono text-emerald-400">
                    ${formatThousands(totalExternalShift)}
                  </div>
                  <span className="text-[10px] text-neutral-400">Claro + SAT consolidado</span>
                </div>
                <div className="p-2 bg-neutral-800 rounded-lg text-emerald-400">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
              </div>
            </div>

            {/* List of registered entries for this shift */}
            {currentShiftExternalSales.length > 0 ? (
              <div className="overflow-x-auto border border-neutral-100 dark:border-neutral-800 rounded-lg">
                <table className="w-full text-left text-xs">
                  <thead className="bg-neutral-50 dark:bg-neutral-800/50 text-neutral-500 text-[10px] font-bold uppercase">
                    <tr>
                      <th className="px-3 py-2">Fecha y Hora</th>
                      <th className="px-3 py-2">Servicio</th>
                      <th className="px-3 py-2">Cajero de Turno</th>
                      <th className="px-3 py-2">Detalle / Obs</th>
                      <th className="px-3 py-2 text-right">Monto</th>
                      <th className="px-3 py-2 text-center w-12">Acción</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
                    {currentShiftExternalSales.map((sale) => (
                      <tr key={sale.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-800/30">
                        <td className="px-3 py-2 text-neutral-600 dark:text-neutral-400 font-mono text-[11px]">
                          {new Date(sale.timestamp).toLocaleDateString()} {new Date(sale.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} hs
                        </td>
                        <td className="px-3 py-2">
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black ${
                            sale.service === 'CLARO'
                              ? 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                              : 'bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300'
                          }`}>
                            {sale.service === 'CLARO' ? <Smartphone className="w-3 h-3" /> : <FileText className="w-3 h-3" />}
                            {sale.serviceName}
                          </span>
                        </td>
                        <td className="px-3 py-2 font-medium text-neutral-800 dark:text-neutral-200">
                          {sale.userName}
                        </td>
                        <td className="px-3 py-2 text-neutral-500 dark:text-neutral-400 italic">
                          {sale.notes || '-'}
                        </td>
                        <td className="px-3 py-2 text-right font-mono font-bold text-neutral-900 dark:text-white">
                          ${formatThousands(sale.amount)}
                        </td>
                        <td className="px-3 py-2 text-center">
                          <button
                            type="button"
                            onClick={() => {
                              if (confirm(`¿Eliminar registro de $${formatThousands(sale.amount)} de ${sale.serviceName}?`)) {
                                deleteExternalServiceSale(sale.id);
                              }
                            }}
                            className="p-1 text-neutral-400 hover:text-rose-600 rounded transition-colors"
                            title="Eliminar registro"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-3 text-center bg-neutral-50/50 dark:bg-neutral-800/20 rounded-lg text-neutral-400 text-xs italic">
                Aún no se han cargado ventas externas de Claro ni SAT en este turno.
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="p-12 text-center bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200 dark:border-neutral-800 space-y-3">
          <Lock className="w-12 h-12 mx-auto text-neutral-400 dark:text-neutral-500" />
          <h3 className="text-base font-bold text-neutral-800 dark:text-white">No hay turno de caja abierto en esta terminal</h3>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 max-w-sm mx-auto">
            Para registrar ventas y movimientos de dinero, debe abrir formalmente la caja ingresando el fondo de cambio inicial.
          </p>
          <button
            type="button"
            onClick={() => setShowOpenModal(true)}
            className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 dark:bg-emerald-600 dark:hover:bg-emerald-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider inline-flex items-center gap-2 shadow-xs transition-colors"
          >
            <Unlock className="w-4 h-4 text-emerald-400 dark:text-white" />
            Abrir Turno de Caja Ahora
          </button>
        </div>
      )}

      {/* PREVIOUS CASH SHIFTS HISTORY */}
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl overflow-hidden shadow-xs">
        <div className="p-4 border-b border-neutral-100 dark:border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-neutral-500 dark:text-neutral-400" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-200">
              Historial de Turnos y Cierres de Caja
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handleExportCash('EXCEL')}
              className="px-2.5 py-1.5 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-200 rounded-lg text-xs font-bold flex items-center gap-1 transition-colors"
              title="Descargar historial en Excel"
            >
              <Download className="w-3.5 h-3.5 text-emerald-600" />
              <span>Excel</span>
            </button>
            <button
              type="button"
              onClick={() => handleExportCash('CSV')}
              className="px-2.5 py-1.5 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-200 rounded-lg text-xs font-bold flex items-center gap-1 transition-colors"
              title="Descargar historial en CSV"
            >
              <Download className="w-3.5 h-3.5 text-teal-600" />
              <span>CSV</span>
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-50 dark:bg-neutral-800/80 border-b border-neutral-200 dark:border-neutral-700 text-neutral-500 dark:text-neutral-300 uppercase tracking-wider text-[11px]">
              <tr>
                <th className="px-4 py-3">Turno</th>
                <th className="px-4 py-3">Apertura</th>
                <th className="px-4 py-3">Cierre</th>
                <th className="px-4 py-3 text-right">Fondo Inicial</th>
                <th className="px-4 py-3 text-right">Ventas Totales</th>
                <th className="px-4 py-3 text-right">Efectivo Esperado</th>
                <th className="px-4 py-3 text-right">Efectivo Declarado</th>
                <th className="px-4 py-3 text-right">Diferencia</th>
                <th className="px-4 py-3 text-center">Reporte</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
              {cashShifts.map((shift) => {
                const isDiffNegative = (shift.cashDifference || 0) < 0;
                const isDiffZero = (shift.cashDifference || 0) === 0;

                return (
                  <tr key={shift.id} className="hover:bg-neutral-50/80 dark:hover:bg-neutral-800/50 transition-colors">
                    <td className="px-4 py-3 font-mono font-bold text-neutral-900 dark:text-white">
                      {shift.shiftNumber}
                      <span className={`ml-2 px-1.5 py-0.2 rounded text-[9px] uppercase ${
                        shift.status === 'OPEN' 
                          ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 font-bold' 
                          : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300'
                      }`}>
                        {shift.status === 'OPEN' ? 'En curso' : 'Cerrado'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-neutral-600 dark:text-neutral-300">
                      {new Date(shift.openedAt).toLocaleDateString()} {new Date(shift.openedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      <span className="block text-[10px] text-neutral-400 dark:text-neutral-500">Por: {shift.openedByUserName}</span>
                    </td>
                    <td className="px-4 py-3 text-neutral-600 dark:text-neutral-300">
                      {shift.closedAt ? (
                        <>
                          {new Date(shift.closedAt).toLocaleDateString()} {new Date(shift.closedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          <span className="block text-[10px] text-neutral-400 dark:text-neutral-500">Por: {shift.closedByUserName || '-'}</span>
                        </>
                      ) : (
                        <span className="text-emerald-600 dark:text-emerald-400 font-semibold">-</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right font-mono text-neutral-500 dark:text-neutral-400">
                      ${formatThousands(shift.initialCash)}
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-bold text-neutral-900 dark:text-white">
                      ${formatThousands(shift.totalSales)}
                    </td>
                    <td className="px-4 py-3 text-right font-mono text-neutral-600 dark:text-neutral-300">
                      ${formatThousands(shift.expectedCashInRegister)}
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-semibold text-neutral-800 dark:text-neutral-200">
                      {shift.declaredCashInRegister !== undefined ? `$${formatThousands(shift.declaredCashInRegister)}` : '-'}
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-bold">
                      {shift.cashDifference !== undefined ? (
                        <span className={isDiffZero ? 'text-emerald-600 dark:text-emerald-400' : isDiffNegative ? 'text-rose-600 dark:text-rose-400' : 'text-amber-600 dark:text-amber-400'}>
                          {shift.cashDifference > 0 ? `+$${formatThousands(shift.cashDifference)}` : `$${formatThousands(shift.cashDifference)}`}
                        </span>
                      ) : '-'}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <button
                        type="button"
                        onClick={() => setShowReportModal(shift)}
                        className="p-1.5 text-neutral-500 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded transition-colors"
                        title="Ver Reporte de Arqueo y Cierre"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* OPEN SHIFT MODAL */}
      {showOpenModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-neutral-900 rounded-xl max-w-sm w-full overflow-hidden shadow-2xl border border-neutral-200 dark:border-neutral-700 animate-in fade-in zoom-in-95">
            <div className="p-4 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between bg-neutral-50 dark:bg-neutral-800/80">
              <h3 className="font-bold text-sm text-neutral-900 dark:text-white">Apertura de Turno de Caja</h3>
              <button
                type="button"
                onClick={() => setShowOpenModal(false)}
                className="text-neutral-400 hover:text-neutral-700 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleOpenSubmit} className="p-5 space-y-3 text-xs">
              <p className="text-neutral-600 dark:text-neutral-300">
                Ingrese el dinero en efectivo que queda como <strong>fondo de cambio inicial</strong> en el cajón de la terminal.
              </p>
              <div>
                <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                  Fondo Inicial ($)
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  required
                  value={initialCashInput}
                  onChange={(e) => setInitialCashInput(formatThousands(e.target.value))}
                  className="w-full px-3 py-2 border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-white rounded-lg text-base font-mono font-bold focus:ring-2 focus:ring-neutral-900 dark:focus:ring-emerald-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-neutral-100 dark:border-neutral-800">
                <button
                  type="button"
                  onClick={() => setShowOpenModal(false)}
                  className="px-3 py-1.5 border border-neutral-300 dark:border-neutral-700 rounded text-neutral-700 dark:text-neutral-300 hover:bg-neutral-50 dark:hover:bg-neutral-800 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-neutral-900 hover:bg-neutral-800 dark:bg-emerald-600 dark:hover:bg-emerald-700 text-white rounded font-bold uppercase tracking-wider transition-colors"
                >
                  Confirmar Apertura
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CLOSE SHIFT / ARQUEO MODAL */}
      {showCloseModal && currentShift && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-neutral-900 rounded-xl max-w-md w-full overflow-hidden shadow-2xl border border-neutral-200 dark:border-neutral-700 animate-in fade-in zoom-in-95">
            <div className="p-4 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between bg-neutral-50 dark:bg-neutral-800/80">
              <h3 className="font-bold text-sm text-neutral-900 dark:text-white">Arqueo & Cierre de Caja ({currentShift.shiftNumber})</h3>
              <button
                type="button"
                onClick={() => setShowCloseModal(false)}
                className="text-neutral-400 hover:text-neutral-700 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCloseSubmit} className="p-5 space-y-4 text-xs">
              <div className="p-3 bg-neutral-50 dark:bg-neutral-800/60 rounded-xl border border-neutral-200 dark:border-neutral-700 space-y-1 text-neutral-800 dark:text-neutral-200">
                <div className="flex justify-between">
                  <span>Efectivo según sistema:</span>
                  <strong className="font-mono text-sm text-neutral-900 dark:text-white">${formatThousands(currentShift.expectedCashInRegister)}</strong>
                </div>
                <div className="flex justify-between text-neutral-500 dark:text-neutral-400 text-[11px]">
                  <span>Ventas en efectivo:</span>
                  <span className="font-mono">${formatThousands(currentShift.totalCashSales)}</span>
                </div>
                <div className="flex justify-between text-neutral-500 dark:text-neutral-400 text-[11px]">
                  <span>Fondo inicial:</span>
                  <span className="font-mono">${formatThousands(currentShift.initialCash)}</span>
                </div>
                {totalExternalShift > 0 && (
                  <div className="pt-1.5 mt-1.5 border-t border-neutral-200 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 text-[11px] space-y-0.5">
                    <div className="flex justify-between font-bold text-neutral-900 dark:text-white">
                      <span>Ventas Externas (Control):</span>
                      <span className="font-mono text-emerald-600 dark:text-emerald-400">${formatThousands(totalExternalShift)}</span>
                    </div>
                    <div className="flex justify-between text-[10px] text-neutral-500 dark:text-neutral-400 font-mono">
                      <span>• Claro: ${formatThousands(totalClaroShift)}</span>
                      <span>• SAT: ${formatThousands(totalSatShift)}</span>
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                  Efectivo Real en Cajón (Arqueo Físico)
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  required
                  value={declaredCashInput}
                  onChange={(e) => setDeclaredCashInput(formatThousands(e.target.value))}
                  placeholder="0"
                  className="w-full px-3 py-2 border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-white rounded-lg text-lg font-mono font-bold focus:ring-2 focus:ring-neutral-900 dark:focus:ring-emerald-500"
                />
              </div>

              {/* Real-time difference calculation */}
              {declaredCashInput !== '' && (
                <div className="p-3 rounded-lg border border-neutral-200 dark:border-neutral-700 flex justify-between items-center bg-white dark:bg-neutral-800/90 text-neutral-800 dark:text-neutral-200">
                  <span>Diferencia de Caja:</span>
                  {(() => {
                    const decl = parseFormattedNumber(declaredCashInput);
                    const diff = decl - currentShift.expectedCashInRegister;
                    return (
                      <span className={`font-mono font-bold text-sm ${
                        diff === 0 ? 'text-emerald-600 dark:text-emerald-400' : diff < 0 ? 'text-rose-600 dark:text-rose-400' : 'text-amber-600 dark:text-amber-400'
                      }`}>
                        {diff === 0 ? 'Exacto ($0)' : diff > 0 ? `Sobrante: +$${formatThousands(diff)}` : `Faltante: -$${formatThousands(Math.abs(diff))}`}
                      </span>
                    );
                  })()}
                </div>
              )}

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                  Observaciones / Motivo de diferencia
                </label>
                <input
                  type="text"
                  value={closureNotes}
                  onChange={(e) => setClosureNotes(e.target.value)}
                  placeholder="Ej: Cierre normal sin novedades"
                  className="w-full px-3 py-2 border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-white rounded-lg text-xs"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-neutral-100 dark:border-neutral-800">
                <button
                  type="button"
                  onClick={() => setShowCloseModal(false)}
                  className="px-3 py-1.5 border border-neutral-300 dark:border-neutral-700 rounded text-neutral-700 dark:text-neutral-300 hover:bg-neutral-50 dark:hover:bg-neutral-800 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-neutral-900 hover:bg-neutral-800 dark:bg-emerald-600 dark:hover:bg-emerald-700 text-white rounded-lg font-bold uppercase tracking-wider shadow-xs transition-colors"
                >
                  Confirmar Cierre Formal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CASH INFLOW/OUTFLOW MODAL */}
      {showMovementModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-neutral-900 rounded-xl max-w-sm w-full overflow-hidden shadow-2xl border border-neutral-200 dark:border-neutral-700 animate-in fade-in zoom-in-95">
            <div className="p-4 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between bg-neutral-50 dark:bg-neutral-800/80">
              <h3 className="font-bold text-sm text-neutral-900 dark:text-white">Movimiento Manual de Efectivo</h3>
              <button
                type="button"
                onClick={() => setShowMovementModal(false)}
                className="text-neutral-400 hover:text-neutral-700 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleMovementSubmit} className="p-5 space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setMovementType('EXPENSE')}
                  className={`p-2 rounded-lg border text-center font-bold transition-colors ${
                    movementType === 'EXPENSE'
                      ? 'bg-rose-600 text-white border-rose-600'
                      : 'bg-white dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-neutral-700 hover:bg-neutral-50 dark:hover:bg-neutral-700'
                  }`}
                >
                  Retiro / Gasto (-)
                </button>
                <button
                  type="button"
                  onClick={() => setMovementType('INCOME')}
                  className={`p-2 rounded-lg border text-center font-bold transition-colors ${
                    movementType === 'INCOME'
                      ? 'bg-emerald-600 text-white border-emerald-600'
                      : 'bg-white dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-neutral-700 hover:bg-neutral-50 dark:hover:bg-neutral-700'
                  }`}
                >
                  Ingreso Extra (+)
                </button>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                  Monto ($)
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  required
                  value={movementAmount}
                  onChange={(e) => setMovementAmount(formatThousands(e.target.value))}
                  placeholder="0"
                  className="w-full px-3 py-2 border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-white rounded-lg text-sm font-mono font-bold focus:ring-2 focus:ring-neutral-900 dark:focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                  Concepto / Motivo
                </label>
                <input
                  type="text"
                  required
                  value={movementConcept}
                  onChange={(e) => setMovementConcept(e.target.value)}
                  placeholder="Ej: Pago de flete, retiro del dueño, cambio adicional"
                  className="w-full px-3 py-2 border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-white rounded-lg text-xs"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-neutral-100 dark:border-neutral-800">
                <button
                  type="button"
                  onClick={() => setShowMovementModal(false)}
                  className="px-3 py-1.5 border border-neutral-300 dark:border-neutral-700 rounded text-neutral-700 dark:text-neutral-300 hover:bg-neutral-50 dark:hover:bg-neutral-800 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-neutral-900 hover:bg-neutral-800 dark:bg-emerald-600 dark:hover:bg-emerald-700 text-white rounded font-bold uppercase tracking-wider transition-colors"
                >
                  Registrar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PRINTABLE CLOSURE REPORT MODAL */}
      {showReportModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="ticket-modal-card bg-white dark:bg-neutral-900 rounded-xl max-w-md w-full overflow-hidden shadow-2xl border border-neutral-200 dark:border-neutral-700 animate-in fade-in zoom-in-95">
            <div className="p-4 bg-neutral-900 text-white flex items-center justify-between border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Printer className="w-4 h-4 text-emerald-400" />
                <h3 className="font-bold text-xs uppercase tracking-wider text-white">Reporte de Arqueo y Cierre</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowReportModal(null)}
                className="text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="cash-closure-report-container p-6 font-mono text-xs bg-white dark:bg-neutral-900 space-y-3 text-neutral-800 dark:text-white border-b border-neutral-200 dark:border-neutral-700">
              <div className="text-center border-b border-dashed border-neutral-300 dark:border-neutral-700 pb-2">
                <h4 className="font-bold text-sm tracking-widest text-neutral-900 dark:text-white">REPORTE Z - CIERRE DE CAJA</h4>
                <p className="text-[10px] text-neutral-500 dark:text-neutral-300">Terminal: {showReportModal.terminalId} | {showReportModal.shiftNumber}</p>
                <p className="text-[10px] text-neutral-500 dark:text-neutral-300">Apertura: {new Date(showReportModal.openedAt).toLocaleString()}</p>
                {showReportModal.closedAt && (
                  <p className="text-[10px] text-neutral-500 dark:text-neutral-300">Cierre: {new Date(showReportModal.closedAt).toLocaleString()}</p>
                )}
                <p className="text-[10px] text-neutral-500 dark:text-neutral-300">Responsable: {showReportModal.closedByUserName || showReportModal.openedByUserName}</p>
              </div>

              <div className="space-y-1 py-1 border-b border-dashed border-neutral-300 dark:border-neutral-700 text-neutral-800 dark:text-white">
                <div className="flex justify-between">
                  <span>Fondo Inicial:</span>
                  <span>${formatThousands(showReportModal.initialCash)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Ventas Efectivo:</span>
                  <span>${formatThousands(showReportModal.totalCashSales)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Ventas Mercado Pago QR:</span>
                  <span>${formatThousands(showReportModal.totalMpSales)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Ventas Tarjeta / Posnet:</span>
                  <span>${formatThousands(showReportModal.totalCardSales || 0)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Ventas Transferencias:</span>
                  <span>${formatThousands(showReportModal.totalTransferSales)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Ventas Cta. Corriente:</span>
                  <span>${formatThousands(showReportModal.totalCurrentAccountSales)}</span>
                </div>
                <div className="flex justify-between font-bold pt-1 border-t border-neutral-200 dark:border-neutral-700 text-neutral-900 dark:text-white">
                  <span>TOTAL VENTAS FACTURADAS:</span>
                  <span>${formatThousands(showReportModal.totalSales)}</span>
                </div>
              </div>

              {/* SERVICIOS EXTERNOS (CONTROL CLARO & SAT) */}
              {(() => {
                const shiftExt = externalServiceSales.filter(s => 
                  s.shiftId === showReportModal.id || (s.shiftNumber === showReportModal.shiftNumber && s.terminalId === showReportModal.terminalId)
                );
                if (shiftExt.length === 0) return null;
                const cTotal = shiftExt.filter(s => s.service === 'CLARO').reduce((acc, curr) => acc + curr.amount, 0);
                const sTotal = shiftExt.filter(s => s.service === 'SAT').reduce((acc, curr) => acc + curr.amount, 0);
                return (
                  <div className="space-y-1 py-1 border-b border-dashed border-neutral-300 dark:border-neutral-700 text-neutral-800 dark:text-white">
                    <div className="font-bold text-[10px] text-neutral-900 dark:text-white pb-0.5">
                      VENTAS EXTERNAS (CONTROL):
                    </div>
                    {cTotal > 0 && (
                      <div className="flex justify-between">
                        <span>Servicio Claro:</span>
                        <span>${formatThousands(cTotal)}</span>
                      </div>
                    )}
                    {sTotal > 0 && (
                      <div className="flex justify-between">
                        <span>Servicio SAT:</span>
                        <span>${formatThousands(sTotal)}</span>
                      </div>
                    )}
                    <div className="flex justify-between font-bold pt-0.5 border-t border-neutral-200 dark:border-neutral-700 text-neutral-900 dark:text-white">
                      <span>TOTAL SERV. EXTERNOS:</span>
                      <span>${formatThousands(cTotal + sTotal)}</span>
                    </div>
                  </div>
                );
              })()}

              <div className="space-y-1 py-1 border-b border-dashed border-neutral-300 dark:border-neutral-700 text-neutral-800 dark:text-white">
                <div className="flex justify-between">
                  <span>Ingresos Extras:</span>
                  <span>+${formatThousands(showReportModal.totalCashIncomes)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Retiros / Gastos:</span>
                  <span>-${formatThousands(showReportModal.totalCashExpenses)}</span>
                </div>
                <div className="flex justify-between font-bold text-neutral-900 dark:text-white pt-1">
                  <span>EFECTIVO ESPERADO:</span>
                  <span>${formatThousands(showReportModal.expectedCashInRegister)}</span>
                </div>
                <div className="flex justify-between font-bold text-neutral-900 dark:text-white">
                  <span>EFECTIVO DECLARADO:</span>
                  <span>${formatThousands(showReportModal.declaredCashInRegister || 0)}</span>
                </div>
                <div className="flex justify-between font-extrabold text-sm pt-1">
                  <span className="text-neutral-900 dark:text-white">DIFERENCIA:</span>
                  <span className={(showReportModal.cashDifference || 0) < 0 ? 'text-rose-600 dark:text-rose-400 font-bold' : 'text-emerald-700 dark:text-emerald-400 font-bold'}>
                    {(showReportModal.cashDifference || 0) > 0 ? `+$${formatThousands(showReportModal.cashDifference || 0)}` : `$${formatThousands(showReportModal.cashDifference || 0)}`}
                  </span>
                </div>
              </div>

              {showReportModal.notes && (
                <div className="text-[10px] text-neutral-500 dark:text-neutral-300 italic">
                  Obs: {showReportModal.notes}
                </div>
              )}
            </div>

            <div className="ticket-modal-footer p-3 bg-white dark:bg-neutral-900 flex justify-end gap-2 border-t border-neutral-200 dark:border-neutral-700">
              <button
                type="button"
                onClick={() => window.print()}
                className="px-3 py-1.5 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-800 dark:text-white border border-neutral-300 dark:border-neutral-600 rounded text-xs font-semibold flex items-center gap-1 transition-colors"
              >
                <Printer className="w-3.5 h-3.5" />
                Imprimir Comprobante
              </button>
              <button
                type="button"
                onClick={() => setShowReportModal(null)}
                className="px-4 py-1.5 bg-neutral-900 hover:bg-neutral-800 dark:bg-neutral-700 dark:hover:bg-neutral-600 text-white rounded text-xs font-bold transition-colors"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* REGISTRAR VENTA EXTERNA MODAL (CLARO / SAT) */}
      {showExternalServiceModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-neutral-900 rounded-xl max-w-sm w-full overflow-hidden shadow-2xl border border-neutral-200 dark:border-neutral-700 animate-in fade-in zoom-in-95">
            <div className={`p-4 border-b text-white flex items-center justify-between ${
              serviceType === 'CLARO' ? 'bg-red-600' : 'bg-sky-700'
            }`}>
              <div className="flex items-center gap-2">
                {serviceType === 'CLARO' ? <Smartphone className="w-5 h-5" /> : <FileText className="w-5 h-5" />}
                <div>
                  <h3 className="font-bold text-sm">Registrar Venta Externa</h3>
                  <p className="text-[10px] text-white/80 font-medium">Servicio: {serviceType === 'CLARO' ? 'Claro' : 'SAT'}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowExternalServiceModal(false)}
                className="text-white/80 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleServiceSubmit} className="p-5 space-y-3.5 text-xs">
              {/* Service selector tabs */}
              <div className="grid grid-cols-2 gap-2 p-1 bg-neutral-100 dark:bg-neutral-800 rounded-lg">
                <button
                  type="button"
                  onClick={() => setServiceType('CLARO')}
                  className={`py-1.5 px-3 rounded-md font-bold text-xs flex items-center justify-center gap-1.5 transition-all ${
                    serviceType === 'CLARO'
                      ? 'bg-red-600 text-white shadow-xs'
                      : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  Claro
                </button>
                <button
                  type="button"
                  onClick={() => setServiceType('SAT')}
                  className={`py-1.5 px-3 rounded-md font-bold text-xs flex items-center justify-center gap-1.5 transition-all ${
                    serviceType === 'SAT'
                      ? 'bg-sky-700 text-white shadow-xs'
                      : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  SAT
                </button>
              </div>

              {/* Automatic Metadata Info Banner */}
              <div className="p-2.5 bg-neutral-50 dark:bg-neutral-800/50 rounded-lg border border-neutral-200 dark:border-neutral-700 space-y-1 text-[11px] text-neutral-600 dark:text-neutral-300">
                <div className="flex justify-between">
                  <span>Fecha y Hora:</span>
                  <strong className="font-mono text-neutral-900 dark:text-white">
                    {new Date().toLocaleDateString()} {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} hs
                  </strong>
                </div>
                <div className="flex justify-between">
                  <span>Cajero de Turno:</span>
                  <strong className="text-neutral-900 dark:text-white">{currentUser.name}</strong>
                </div>
                {currentShift && (
                  <div className="flex justify-between">
                    <span>Turno Activo:</span>
                    <span className="font-mono text-neutral-700 dark:text-neutral-300">{currentShift.shiftNumber} ({currentShift.terminalId})</span>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                  Monto Vendido ($) *
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 font-mono font-bold text-neutral-400 text-base">$</span>
                  <input
                    type="text"
                    inputMode="decimal"
                    autoFocus
                    required
                    value={serviceAmount}
                    onChange={(e) => setServiceAmount(formatThousands(e.target.value))}
                    placeholder="0"
                    className="w-full pl-7 pr-3 py-2.5 border-2 border-neutral-300 dark:border-neutral-700 rounded-lg text-lg font-mono font-black text-neutral-900 dark:text-white bg-white dark:bg-neutral-800 focus:ring-2 focus:ring-neutral-900 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                  Observación / N° Comprobante o Lote (Opcional)
                </label>
                <input
                  type="text"
                  value={serviceNotes}
                  onChange={(e) => setServiceNotes(e.target.value)}
                  placeholder="Ej: Lote cierre, recargas día, cobro recibo..."
                  className="w-full px-3 py-2 border border-neutral-300 dark:border-neutral-700 rounded-lg text-xs bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white focus:ring-2 focus:ring-neutral-900 focus:outline-hidden"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-neutral-100 dark:border-neutral-800">
                <button
                  type="button"
                  onClick={() => setShowExternalServiceModal(false)}
                  className="px-3 py-1.5 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-700 dark:text-neutral-300 font-semibold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className={`px-4 py-2 text-white rounded-lg font-bold uppercase tracking-wider shadow-xs transition-colors ${
                    serviceType === 'CLARO' ? 'bg-red-600 hover:bg-red-700' : 'bg-sky-700 hover:bg-sky-800'
                  }`}
                >
                  Guardar Venta {serviceType === 'CLARO' ? 'Claro' : 'SAT'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CASH IMPORT MODAL (CSV / EXCEL) */}
      {importModalMode !== null && (
        <CashImportModal
          isOpen={true}
          mode={importModalMode}
          onClose={() => setImportModalMode(null)}
          onImportComplete={(shiftsCount, movementsCount) => {
            reloadAllFromStorage();
            DialogService.alert(
              `¡Se importaron ${formatThousands(shiftsCount)} turnos de caja y ${formatThousands(movementsCount)} movimientos de efectivo con éxito!`,
              'Importación Exitosa',
              'success'
            );
          }}
        />
      )}
    </div>
  );
};
