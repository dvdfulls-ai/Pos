import React, { useState, useRef, useMemo } from 'react';
import { 
  X, 
  Upload, 
  FileText, 
  FileSpreadsheet, 
  Check, 
  AlertCircle, 
  CheckCircle2, 
  RefreshCw, 
  Layers, 
  Sliders, 
  DollarSign,
  Calendar,
  Clock,
  User,
  CreditCard,
  QrCode,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { CashShift, CashMovement, PaymentMethod } from '../../types';
import { StorageService } from '../../services/storage';
import { formatThousands } from '../../utils/text';

interface CashImportModalProps {
  isOpen: boolean;
  mode: 'CSV' | 'EXCEL' | null;
  onClose: () => void;
  onImportComplete: (shiftsCount: number, movementsCount: number) => void;
}

interface ColumnMapping {
  date: string;
  time: string;
  shift: string;
  concept: string;
  cash: string;
  mercadoPago: string;
  qr: string;
  transfer: string;
  card: string;
  incomes: string;
  expenses: string;
  initialCash: string;
  declaredCash: string;
  userName: string;
}

interface ParsedCashRow {
  date: string;
  time: string;
  shift: string;
  concept: string;
  cash: number;
  mercadoPago: number;
  qr: number;
  transfer: number;
  card: number;
  incomes: number;
  expenses: number;
  initialCash: number;
  declaredCash: number;
  userName: string;
}

// Cleans header names from DBF format:
// "INGRESOS,N,15,4" -> "INGRESOS"
// "EGRESOS,N,15,4"  -> "EGRESOS"
// "CONCEPTO,C,40"   -> "CONCEPTO"
// "FECHA,D"         -> "FECHA"
// "TURNO,C,20"      -> "TURNO"
// "EFECTIVO"        -> "EFECTIVO"
// "MERCADOPAG,N,15,4" -> "MERCADOPAG"
// "QR,N,15,4"       -> "QR"
// "TRANSFEREN,N,15,4" -> "TRANSFEREN"
export function cleanHeaderKey(raw: string): string {
  if (!raw) return '';
  let s = String(raw).replace(/^\uFEFF/, '').replace(/["']/g, '').trim();
  s = s.split(/[,(]/)[0].trim();
  return s.toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Z0-9]/g, '');
}

// Flexible date parser for DBF (YYYYMMDD, DD/MM/YYYY, Excel serial, ISO)
function parseFlexibleDate(val: any): string {
  if (!val) return new Date().toISOString();
  if (val instanceof Date) return isNaN(val.getTime()) ? new Date().toISOString() : val.toISOString();
  
  if (typeof val === 'number') {
    const excelEpoch = new Date(Date.UTC(1899, 11, 30));
    const date = new Date(excelEpoch.getTime() + val * 86400000);
    return isNaN(date.getTime()) ? new Date().toISOString() : date.toISOString();
  }

  const str = String(val).trim();
  if (!str) return new Date().toISOString();

  // YYYYMMDD (standard DBF Date format)
  if (/^\d{8}$/.test(str)) {
    const year = parseInt(str.slice(0, 4), 10);
    const month = parseInt(str.slice(4, 6), 10) - 1;
    const day = parseInt(str.slice(6, 8), 10);
    const d = new Date(year, month, day, 12, 0, 0);
    return isNaN(d.getTime()) ? new Date().toISOString() : d.toISOString();
  }

  // DD/MM/YYYY or DD-MM-YYYY
  const dmyMatch = str.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})/);
  if (dmyMatch) {
    const day = parseInt(dmyMatch[1], 10);
    const month = parseInt(dmyMatch[2], 10) - 1;
    let year = parseInt(dmyMatch[3], 10);
    if (year < 100) year += 2000;
    const d = new Date(year, month, day, 12, 0, 0);
    return isNaN(d.getTime()) ? new Date().toISOString() : d.toISOString();
  }

  const parsed = Date.parse(str);
  if (!isNaN(parsed)) {
    return new Date(parsed).toISOString();
  }

  return new Date().toISOString();
}

function parseFlexibleTime(val: any): string {
  if (!val) return '12:00:00';
  const str = String(val).trim();
  if (/^\d{1,2}:\d{2}(:\d{2})?$/.test(str)) {
    return str.length === 5 ? `${str}:00` : str;
  }
  return '12:00:00';
}

export const CashImportModal: React.FC<CashImportModalProps> = ({
  isOpen,
  mode,
  onClose,
  onImportComplete,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isParsing, setIsParsing] = useState(false);
  const [parseError, setParseError] = useState<string | null>(null);
  const [detectedColumns, setDetectedColumns] = useState<string[]>([]);
  const [rawRowsData, setRawRowsData] = useState<any[]>([]);
  const [columnMapping, setColumnMapping] = useState<ColumnMapping>({
    date: '',
    time: '',
    shift: '',
    concept: '',
    cash: '',
    mercadoPago: '',
    qr: '',
    transfer: '',
    card: '',
    incomes: '',
    expenses: '',
    initialCash: '',
    declaredCash: '',
    userName: '',
  });
  const [showColumnConfig, setShowColumnConfig] = useState(false);
  const [importStrategy, setImportStrategy] = useState<'REPLACE' | 'MERGE'>('MERGE');
  const [importTarget, setImportTarget] = useState<'BOTH' | 'SHIFTS' | 'MOVEMENTS'>('BOTH');
  const [isImporting, setIsImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);

  // Flexible number parser for Argentine and DBF decimal formats
  const parseFlexibleNumber = (val: any): number => {
    if (typeof val === 'number') {
      return isNaN(val) ? 0 : val;
    }
    if (!val) return 0;
    const str = String(val).trim().replace(/[$ \t\r\n]/g, '');
    if (!str) return 0;

    if (str.includes(',') && str.includes('.')) {
      if (str.indexOf('.') < str.indexOf(',')) {
        // e.g. "1.500,50"
        const normalized = str.replace(/\./g, '').replace(',', '.');
        const num = parseFloat(normalized);
        return isNaN(num) ? 0 : num;
      } else {
        // e.g. "1,500.50"
        const normalized = str.replace(/,/g, '');
        const num = parseFloat(normalized);
        return isNaN(num) ? 0 : num;
      }
    }

    if (str.includes(',')) {
      const normalized = str.replace(',', '.');
      const num = parseFloat(normalized);
      return isNaN(num) ? 0 : num;
    }

    const num = parseFloat(str);
    return isNaN(num) ? 0 : num;
  };

  const autoDetectMapping = (keys: string[]): ColumnMapping => {
    const mapping: ColumnMapping = {
      date: '',
      time: '',
      shift: '',
      concept: '',
      cash: '',
      mercadoPago: '',
      qr: '',
      transfer: '',
      card: '',
      incomes: '',
      expenses: '',
      initialCash: '',
      declaredCash: '',
      userName: '',
    };

    for (const rawKey of keys) {
      const norm = cleanHeaderKey(rawKey);

      // FECHA
      if (!mapping.date && (
        norm.startsWith('FECHA') || norm.startsWith('DATE') || norm.startsWith('FEC') || norm.startsWith('DIA')
      )) {
        mapping.date = rawKey;
      }

      // HORA
      if (!mapping.time && (
        norm.startsWith('HORA') || norm.startsWith('TIME') || norm.startsWith('HOR')
      )) {
        mapping.time = rawKey;
      }

      // TURNO
      if (!mapping.shift && (
        norm.startsWith('TURNO') || norm.startsWith('SHIFT') || norm === 'NROTURNO' || norm.startsWith('NUMTURNO')
      )) {
        mapping.shift = rawKey;
      }

      // CONCEPTO / DETALLE
      if (!mapping.concept && (
        norm.startsWith('CONCEPTO') || norm.startsWith('DETALLE') || norm.startsWith('MOTIVO') ||
        norm.startsWith('OBSERV') || norm.startsWith('NOTA') || norm.startsWith('DESCRIP')
      )) {
        mapping.concept = rawKey;
      }

      // EFECTIVO
      if (!mapping.cash && (
        norm === 'EFECTIVO' || norm.startsWith('EFECT') || norm.startsWith('EFEC') ||
        norm.startsWith('CASH') || norm.startsWith('CONTADO')
      )) {
        mapping.cash = rawKey;
      }

      // MERCADOPAGO
      if (!mapping.mercadoPago && (
        norm.startsWith('MERCADOPAG') || norm.startsWith('MERCADOP') || norm.startsWith('MP') ||
        norm.startsWith('MERCADO')
      )) {
        mapping.mercadoPago = rawKey;
      }

      // QR
      if (!mapping.qr && (
        norm === 'QR' || norm.startsWith('PAGOQR') || norm.startsWith('COBROQR')
      )) {
        mapping.qr = rawKey;
      }

      // TRANSFERENCIA
      if (!mapping.transfer && (
        norm.startsWith('TRANSFEREN') || norm.startsWith('TRANSF') || norm.startsWith('TRANSFER') ||
        norm.startsWith('BANCO') || norm.startsWith('DEPOSITO')
      )) {
        mapping.transfer = rawKey;
      }

      // TARJETA / POSNET
      if (!mapping.card && (
        norm.startsWith('TARJETA') || norm.startsWith('POSNET') || norm.startsWith('DEBITO') ||
        norm.startsWith('CREDITO') || norm.startsWith('CARD')
      )) {
        mapping.card = rawKey;
      }

      // INGRESOS
      if (!mapping.incomes && (
        norm.startsWith('INGRESOS') || norm.startsWith('INGRESO') || norm.startsWith('ENTRADAS') ||
        norm.startsWith('ENTRADA')
      )) {
        mapping.incomes = rawKey;
      }

      // EGRESOS / GASTOS
      if (!mapping.expenses && (
        norm.startsWith('EGRESOS') || norm.startsWith('EGRESO') || norm.startsWith('GASTOS') ||
        norm.startsWith('GASTO') || norm.startsWith('SALIDAS') || norm.startsWith('SALIDA') ||
        norm.startsWith('RETIRO')
      )) {
        mapping.expenses = rawKey;
      }

      // INICIAL / FONDO
      if (!mapping.initialCash && (
        norm.startsWith('INICIAL') || norm.startsWith('FONDO') || norm.startsWith('APERTURA') ||
        norm.startsWith('BASE')
      )) {
        mapping.initialCash = rawKey;
      }

      // ARQUEO / DECLARADO
      if (!mapping.declaredCash && (
        norm.startsWith('ARQUEO') || norm.startsWith('DECLARADO') || norm.startsWith('REAL') ||
        norm.startsWith('CIERRE')
      )) {
        mapping.declaredCash = rawKey;
      }

      // USUARIO / CAJERO
      if (!mapping.userName && (
        norm.startsWith('USUARIO') || norm.startsWith('CAJERO') || norm.startsWith('OPERADOR') ||
        norm.startsWith('USER')
      )) {
        mapping.userName = rawKey;
      }
    }

    return mapping;
  };

  const processLoadedRows = (rows: any[]) => {
    if (!rows || rows.length === 0) {
      throw new Error('El archivo no contiene filas de datos.');
    }

    const firstRow = rows[0];
    const keys = Object.keys(firstRow).filter(k => k && !k.startsWith('__EMPTY'));
    if (keys.length === 0) {
      const allKeys = Object.keys(firstRow);
      setDetectedColumns(allKeys);
      setRawRowsData(rows);
      setColumnMapping(autoDetectMapping(allKeys));
      return;
    }

    setDetectedColumns(keys);
    setRawRowsData(rows);
    setColumnMapping(autoDetectMapping(keys));
  };

  // Convert raw rows using current mapping
  const parsedRows: ParsedCashRow[] = useMemo(() => {
    if (rawRowsData.length === 0) return [];

    const result: ParsedCashRow[] = [];
    const len = rawRowsData.length;

    for (let i = 0; i < len; i++) {
      const row = rawRowsData[i];

      const dateStr = columnMapping.date ? parseFlexibleDate(row[columnMapping.date]) : new Date().toISOString();
      const timeStr = columnMapping.time ? parseFlexibleTime(row[columnMapping.time]) : '12:00:00';
      const shiftStr = columnMapping.shift ? String(row[columnMapping.shift] ?? '').trim() : `TURNO-${i + 1}`;
      const conceptStr = columnMapping.concept ? String(row[columnMapping.concept] ?? '').trim() : 'Cierre de turno importado';

      const cashVal = columnMapping.cash ? parseFlexibleNumber(row[columnMapping.cash]) : 0;
      const mpVal = columnMapping.mercadoPago ? parseFlexibleNumber(row[columnMapping.mercadoPago]) : 0;
      const qrVal = columnMapping.qr ? parseFlexibleNumber(row[columnMapping.qr]) : 0;
      const transferVal = columnMapping.transfer ? parseFlexibleNumber(row[columnMapping.transfer]) : 0;
      const cardVal = columnMapping.card ? parseFlexibleNumber(row[columnMapping.card]) : 0;
      const incomesVal = columnMapping.incomes ? parseFlexibleNumber(row[columnMapping.incomes]) : 0;
      const expensesVal = columnMapping.expenses ? parseFlexibleNumber(row[columnMapping.expenses]) : 0;
      const initialCashVal = columnMapping.initialCash ? parseFlexibleNumber(row[columnMapping.initialCash]) : 0;
      const declaredCashVal = columnMapping.declaredCash ? parseFlexibleNumber(row[columnMapping.declaredCash]) : (cashVal || 0);
      const userStr = columnMapping.userName ? String(row[columnMapping.userName] ?? '').trim() : 'Cajero';

      // Skip row only if completely empty of numbers and concept
      const hasAnyData = cashVal !== 0 || mpVal !== 0 || qrVal !== 0 || transferVal !== 0 ||
        cardVal !== 0 || incomesVal !== 0 || expensesVal !== 0 || initialCashVal !== 0 ||
        Boolean(shiftStr) || Boolean(conceptStr);

      if (!hasAnyData) continue;

      result.push({
        date: dateStr,
        time: timeStr,
        shift: shiftStr || `TURNO-${i + 1}`,
        concept: conceptStr,
        cash: cashVal,
        mercadoPago: mpVal,
        qr: qrVal,
        transfer: transferVal,
        card: cardVal,
        incomes: incomesVal,
        expenses: expensesVal,
        initialCash: initialCashVal,
        declaredCash: declaredCashVal,
        userName: userStr || 'Cajero',
      });
    }

    return result;
  }, [rawRowsData, columnMapping]);

  // Aggregate statistics
  const summaryStats = useMemo(() => {
    let totalCash = 0;
    let totalDigital = 0;
    let totalIncomes = 0;
    let totalExpenses = 0;

    for (const r of parsedRows) {
      totalCash += r.cash;
      totalDigital += (r.mercadoPago + r.qr + r.transfer + r.card);
      totalIncomes += r.incomes;
      totalExpenses += r.expenses;
    }

    return {
      totalRows: parsedRows.length,
      totalCash,
      totalDigital,
      totalIncomes,
      totalExpenses,
      grandTotal: totalCash + totalDigital + totalIncomes - totalExpenses,
    };
  }, [parsedRows]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSelectedFile(file);
    setIsParsing(true);
    setParseError(null);
    setRawRowsData([]);

    const reader = new FileReader();

    if (mode === 'EXCEL') {
      reader.onload = (evt) => {
        try {
          const buffer = evt.target?.result as ArrayBuffer;
          const workbook = XLSX.read(buffer, { type: 'array' });
          const sheetName = workbook.SheetNames[0];
          if (!sheetName) throw new Error('El archivo Excel no contiene hojas de datos.');
          const worksheet = workbook.Sheets[sheetName];
          const json = XLSX.utils.sheet_to_json(worksheet, { defval: '' });
          processLoadedRows(json);
        } catch (err: any) {
          setParseError(err.message || 'Error al procesar archivo de Excel.');
        } finally {
          setIsParsing(false);
        }
      };
      reader.onerror = () => {
        setParseError('Error al leer el archivo de Excel.');
        setIsParsing(false);
      };
      reader.readAsArrayBuffer(file);
    } else {
      // CSV mode: supports comma, semicolon, tab
      reader.onload = (evt) => {
        try {
          const text = evt.target?.result as string;
          if (!text || !text.trim()) {
            throw new Error('El archivo CSV está vacío.');
          }

          const workbook = XLSX.read(text, { type: 'string' });
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          const json = XLSX.utils.sheet_to_json(worksheet, { defval: '' });
          processLoadedRows(json);
        } catch (err: any) {
          setParseError(err.message || 'Error al procesar archivo CSV.');
        } finally {
          setIsParsing(false);
        }
      };
      reader.onerror = () => {
        setParseError('Error al leer el archivo CSV.');
        setIsParsing(false);
      };
      reader.readAsText(file, 'utf-8');
    }
  };

  const handleExecuteImport = () => {
    if (parsedRows.length === 0) return;

    setIsImporting(true);
    setImportProgress(30);

    setTimeout(() => {
      try {
        const existingShifts = StorageService.getCashShifts();
        const existingMovements = StorageService.getCashMovements();
        const currentUser = StorageService.getCurrentUser();
        const currentTerminalId = StorageService.getCurrentTerminalId();

        const newShifts: CashShift[] = importStrategy === 'MERGE' ? [...existingShifts] : [];
        const newMovements: CashMovement[] = importStrategy === 'MERGE' ? [...existingMovements] : [];

        let shiftsCreatedCount = 0;
        let movementsCreatedCount = 0;

        parsedRows.forEach((r, idx) => {
          const timestamp = r.date || new Date().toISOString();
          const totalSales = r.cash + r.mercadoPago + r.qr + r.transfer + r.card;
          const expectedCash = r.initialCash + r.cash + r.incomes - r.expenses;
          const declared = r.declaredCash || r.cash;
          const diff = declared - expectedCash;

          // 1. Create Shift entry if requested
          if (importTarget === 'BOTH' || importTarget === 'SHIFTS') {
            const shiftId = `sh_${idx}_${Date.now()}`;
            
            const newShift: CashShift = {
              id: shiftId,
              shiftNumber: r.shift || `TURNO-${idx + 1}`,
              openedAt: timestamp,
              closedAt: timestamp,
              openedByUserId: currentUser.id,
              openedByUserName: (r.userName || currentUser.name).slice(0, 30),
              closedByUserId: currentUser.id,
              closedByUserName: (r.userName || currentUser.name).slice(0, 30),
              terminalId: currentTerminalId,
              initialCash: r.initialCash,
              totalCashSales: r.cash,
              totalMpSales: r.mercadoPago + r.qr, // MP and QR consolidated
              totalTransferSales: r.transfer,
              totalCardSales: r.card,
              totalCurrentAccountSales: 0,
              totalSales: totalSales,
              totalCashIncomes: r.incomes,
              totalCashExpenses: r.expenses,
              expectedCashInRegister: expectedCash,
              declaredCashInRegister: declared,
              cashDifference: diff,
              notes: (r.concept || 'Turno importado').slice(0, 80),
              status: 'CLOSED',
            };

            newShifts.push(newShift);
            shiftsCreatedCount++;
          }

          // 2. Create Movements entries if requested and non-zero
          if (importTarget === 'BOTH' || importTarget === 'MOVEMENTS') {
            if (r.expenses > 0) {
              newMovements.push({
                id: `me_${idx}_${Date.now()}`,
                type: 'EXPENSE',
                concept: `${r.concept || 'Egreso'} [${r.shift}]`.slice(0, 60),
                amount: r.expenses,
                paymentMethod: 'EFECTIVO',
                userId: currentUser.id,
                userName: (r.userName || currentUser.name).slice(0, 30),
                timestamp: timestamp,
              });
              movementsCreatedCount++;
            }

            if (r.incomes > 0) {
              newMovements.push({
                id: `mi_${idx}_${Date.now()}`,
                type: 'INCOME',
                concept: `${r.concept || 'Ingreso'} [${r.shift}]`.slice(0, 60),
                amount: r.incomes,
                paymentMethod: 'EFECTIVO',
                userId: currentUser.id,
                userName: (r.userName || currentUser.name).slice(0, 30),
                timestamp: timestamp,
              });
              movementsCreatedCount++;
            }
          }
        });

        // Save to storage with quota protection
        try {
          if (importTarget === 'BOTH' || importTarget === 'SHIFTS') {
            StorageService.saveCashShifts(newShifts);
          }
        } catch (shiftErr) {
          console.warn('Non-fatal error saving cash shifts:', shiftErr);
        }

        try {
          if (importTarget === 'BOTH' || importTarget === 'MOVEMENTS') {
            StorageService.saveCashMovements(newMovements);
          }
        } catch (movErr) {
          console.warn('Non-fatal error saving cash movements:', movErr);
        }

        setImportProgress(100);
        onImportComplete(shiftsCreatedCount, movementsCreatedCount);
        onClose();
      } catch (err: any) {
        setParseError('Error durante el guardado: ' + (err.message || 'Error desconocido'));
        setIsImporting(false);
      }
    }, 100);
  };

  if (!isOpen || !mode) return null;

  const isCsv = mode === 'CSV';

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white dark:bg-neutral-900 rounded-2xl max-w-4xl w-full max-h-[92vh] overflow-hidden shadow-2xl border border-neutral-200 dark:border-neutral-800 flex flex-col animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className={`p-4 text-white flex items-center justify-between ${
          isCsv ? 'bg-emerald-800' : 'bg-teal-800'
        }`}>
          <div className="flex items-center gap-2.5">
            {isCsv ? <FileText className="w-6 h-6" /> : <FileSpreadsheet className="w-6 h-6" />}
            <div>
              <h3 className="font-extrabold text-base tracking-tight flex items-center gap-2">
                <span>Importar Caja y Cierres de Turno desde {isCsv ? 'CSV' : 'Excel'}</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-white/20 uppercase">
                  {isCsv ? '.csv' : '.xlsx / .xls'}
                </span>
              </h3>
              <p className="text-xs text-white/80">
                Compatible con DBF (FECHA, TURNO, EFECTIVO, MERCADOPAG, QR, TRANSFEREN, INGRESOS, EGRESOS, CONCEPTO)
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-white/20 text-white/80 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-5">
          {/* File Picker */}
          {!selectedFile ? (
            <div
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-8 sm:p-12 text-center cursor-pointer transition-all ${
                isCsv 
                  ? 'border-emerald-300 dark:border-emerald-800/60 hover:border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/20' 
                  : 'border-teal-300 dark:border-teal-800/60 hover:border-teal-500 bg-teal-50/50 dark:bg-teal-950/20'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept={isCsv ? '.csv,.txt' : '.xlsx,.xls,.xlsm'}
                onChange={handleFileChange}
                className="hidden"
              />
              <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-white dark:bg-neutral-800 shadow-md flex items-center justify-center text-emerald-600">
                <Upload className="w-8 h-8" />
              </div>
              <h4 className="font-bold text-sm text-neutral-800 dark:text-neutral-200">
                Selecciona o arrastra el archivo de Caja ({isCsv ? '.csv' : '.xlsx'})
              </h4>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1 max-w-md mx-auto">
                Detecta automáticamente los encabezados de tu base de datos de caja:
                <br />
                <code className="text-[11px] font-mono font-bold text-emerald-700 dark:text-emerald-400 bg-white/70 dark:bg-neutral-800 px-1.5 py-0.5 rounded mt-1.5 inline-block">
                  FECHA, TURNO, EFECTIVO, MERCADOPAG, QR, TRANSFEREN, INGRESOS, EGRESOS, CONCEPTO
                </code>
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {/* File Info Card */}
              <div className="p-3.5 bg-neutral-50 dark:bg-neutral-800/50 rounded-xl border border-neutral-200 dark:border-neutral-700 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg text-white ${isCsv ? 'bg-emerald-700' : 'bg-teal-700'}`}>
                    {isCsv ? <FileText className="w-5 h-5" /> : <FileSpreadsheet className="w-5 h-5" />}
                  </div>
                  <div>
                    <div className="font-bold text-xs text-neutral-900 dark:text-white flex items-center gap-2">
                      <span>{selectedFile.name}</span>
                      <span className="text-[10px] text-neutral-400">
                        ({(selectedFile.size / 1024).toFixed(1)} KB)
                      </span>
                    </div>
                    <div className="text-[11px] text-neutral-500 dark:text-neutral-400 mt-0.5">
                      {isParsing ? (
                        <span className="flex items-center gap-1 text-emerald-600 font-medium">
                          <RefreshCw className="w-3 h-3 animate-spin" /> Procesando columnas...
                        </span>
                      ) : (
                        <span>
                          {parsedRows.length} fila(s) válida(s) de caja detectadas
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowColumnConfig(!showColumnConfig)}
                    className="px-3 py-1.5 text-xs font-semibold rounded-lg border border-neutral-300 dark:border-neutral-600 hover:bg-white dark:hover:bg-neutral-800 flex items-center gap-1.5 text-neutral-700 dark:text-neutral-200 transition-colors"
                  >
                    <Sliders className="w-3.5 h-3.5" />
                    <span>{showColumnConfig ? 'Ocultar Mapeo' : 'Ajustar Columnas'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedFile(null);
                      setRawRowsData([]);
                      setParseError(null);
                    }}
                    className="px-3 py-1.5 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
                  >
                    Cambiar archivo
                  </button>
                </div>
              </div>

              {/* Parsing Error */}
              {parseError && (
                <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 rounded-xl text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{parseError}</span>
                </div>
              )}

              {/* Column Mapping Adjuster (Accordion) */}
              {showColumnConfig && (
                <div className="p-4 bg-neutral-50 dark:bg-neutral-800/80 rounded-xl border border-neutral-200 dark:border-neutral-700 space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between">
                    <h5 className="font-extrabold text-xs text-neutral-800 dark:text-neutral-200 uppercase tracking-wider flex items-center gap-1.5">
                      <Sliders className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Asignación de Columnas de tu Base de Datos</span>
                    </h5>
                    <span className="text-[10px] text-neutral-400">
                      Detectado automáticamente por nombres y sufijos DBF
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div>
                      <label className="block text-[10px] font-bold text-neutral-500 uppercase mb-1">
                        Fecha (FECHA,D)
                      </label>
                      <select
                        value={columnMapping.date}
                        onChange={(e) => setColumnMapping({ ...columnMapping, date: e.target.value })}
                        className="w-full p-2 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-lg text-xs"
                      >
                        <option value="">-- No mapear --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-neutral-500 uppercase mb-1">
                        Turno (TURNO,C,20)
                      </label>
                      <select
                        value={columnMapping.shift}
                        onChange={(e) => setColumnMapping({ ...columnMapping, shift: e.target.value })}
                        className="w-full p-2 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-lg text-xs"
                      >
                        <option value="">-- No mapear --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-neutral-500 uppercase mb-1">
                        Efectivo (EFECTIVO)
                      </label>
                      <select
                        value={columnMapping.cash}
                        onChange={(e) => setColumnMapping({ ...columnMapping, cash: e.target.value })}
                        className="w-full p-2 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-lg text-xs"
                      >
                        <option value="">-- No mapear --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-neutral-500 uppercase mb-1">
                        Mercado Pago (MERCADOPAG)
                      </label>
                      <select
                        value={columnMapping.mercadoPago}
                        onChange={(e) => setColumnMapping({ ...columnMapping, mercadoPago: e.target.value })}
                        className="w-full p-2 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-lg text-xs"
                      >
                        <option value="">-- No mapear --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-neutral-500 uppercase mb-1">
                        QR (QR,N,15,4)
                      </label>
                      <select
                        value={columnMapping.qr}
                        onChange={(e) => setColumnMapping({ ...columnMapping, qr: e.target.value })}
                        className="w-full p-2 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-lg text-xs"
                      >
                        <option value="">-- No mapear --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-neutral-500 uppercase mb-1">
                        Transferencia (TRANSFEREN)
                      </label>
                      <select
                        value={columnMapping.transfer}
                        onChange={(e) => setColumnMapping({ ...columnMapping, transfer: e.target.value })}
                        className="w-full p-2 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-lg text-xs"
                      >
                        <option value="">-- No mapear --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-neutral-500 uppercase mb-1">
                        Ingresos (INGRESOS,N,15,4)
                      </label>
                      <select
                        value={columnMapping.incomes}
                        onChange={(e) => setColumnMapping({ ...columnMapping, incomes: e.target.value })}
                        className="w-full p-2 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-lg text-xs"
                      >
                        <option value="">-- No mapear --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-neutral-500 uppercase mb-1">
                        Egresos (EGRESOS,N,15,4)
                      </label>
                      <select
                        value={columnMapping.expenses}
                        onChange={(e) => setColumnMapping({ ...columnMapping, expenses: e.target.value })}
                        className="w-full p-2 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-lg text-xs"
                      >
                        <option value="">-- No mapear --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-neutral-500 uppercase mb-1">
                        Concepto (CONCEPTO,C,40)
                      </label>
                      <select
                        value={columnMapping.concept}
                        onChange={(e) => setColumnMapping({ ...columnMapping, concept: e.target.value })}
                        className="w-full p-2 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-lg text-xs"
                      >
                        <option value="">-- No mapear --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-neutral-500 uppercase mb-1">
                        Fondo Inicial (INICIAL)
                      </label>
                      <select
                        value={columnMapping.initialCash}
                        onChange={(e) => setColumnMapping({ ...columnMapping, initialCash: e.target.value })}
                        className="w-full p-2 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-lg text-xs"
                      >
                        <option value="">-- No mapear --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-neutral-500 uppercase mb-1">
                        Arqueo / Real (ARQUEO)
                      </label>
                      <select
                        value={columnMapping.declaredCash}
                        onChange={(e) => setColumnMapping({ ...columnMapping, declaredCash: e.target.value })}
                        className="w-full p-2 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-lg text-xs"
                      >
                        <option value="">-- No mapear --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-neutral-500 uppercase mb-1">
                        Cajero / Usuario (USUARIO)
                      </label>
                      <select
                        value={columnMapping.userName}
                        onChange={(e) => setColumnMapping({ ...columnMapping, userName: e.target.value })}
                        className="w-full p-2 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-lg text-xs"
                      >
                        <option value="">-- No mapear --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* Summary Stats Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-neutral-100 dark:bg-neutral-800 rounded-xl">
                  <span className="text-[10px] font-bold text-neutral-500 uppercase">Filas / Turnos</span>
                  <div className="text-xl font-extrabold font-mono text-neutral-900 dark:text-white mt-0.5">
                    {summaryStats.totalRows}
                  </div>
                </div>

                <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl">
                  <span className="text-[10px] font-bold text-emerald-700 dark:text-emerald-400 uppercase">
                    Total Efectivo
                  </span>
                  <div className="text-xl font-extrabold font-mono text-emerald-800 dark:text-emerald-200 mt-0.5">
                    ${formatThousands(summaryStats.totalCash)}
                  </div>
                </div>

                <div className="p-3 bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 rounded-xl">
                  <span className="text-[10px] font-bold text-sky-700 dark:text-sky-400 uppercase">
                    Digital (MP + QR + Transf)
                  </span>
                  <div className="text-xl font-extrabold font-mono text-sky-800 dark:text-sky-200 mt-0.5">
                    ${formatThousands(summaryStats.totalDigital)}
                  </div>
                </div>

                <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl">
                  <span className="text-[10px] font-bold text-rose-700 dark:text-rose-400 uppercase">
                    Egresos Totales
                  </span>
                  <div className="text-xl font-extrabold font-mono text-rose-800 dark:text-rose-200 mt-0.5">
                    -${formatThousands(summaryStats.totalExpenses)}
                  </div>
                </div>
              </div>

              {/* Live Preview Table */}
              <div className="border border-neutral-200 dark:border-neutral-700 rounded-xl overflow-hidden">
                <div className="p-2.5 bg-neutral-100 dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 flex items-center justify-between text-xs font-bold text-neutral-700 dark:text-neutral-300">
                  <span>Vista Previa (Primeras 5 filas procesadas)</span>
                  <span className="text-[10px] font-normal text-neutral-500">
                    Mostrando cómo se guardará en la base de datos
                  </span>
                </div>
                <div className="overflow-x-auto max-h-56">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-neutral-50 dark:bg-neutral-800/60 text-neutral-500 text-[10px] uppercase font-bold sticky top-0">
                      <tr>
                        <th className="px-3 py-2">Fecha</th>
                        <th className="px-3 py-2">Turno</th>
                        <th className="px-3 py-2 text-right">Efectivo</th>
                        <th className="px-3 py-2 text-right">Mercado Pago</th>
                        <th className="px-3 py-2 text-right">QR</th>
                        <th className="px-3 py-2 text-right">Transferencia</th>
                        <th className="px-3 py-2 text-right">Ingresos</th>
                        <th className="px-3 py-2 text-right">Egresos</th>
                        <th className="px-3 py-2">Concepto</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
                      {parsedRows.slice(0, 5).map((row, idx) => (
                        <tr key={idx} className="hover:bg-neutral-50 dark:hover:bg-neutral-800/30">
                          <td className="px-3 py-2 font-mono text-[11px] text-neutral-700 dark:text-neutral-300 whitespace-nowrap">
                            {new Date(row.date).toLocaleDateString()}
                          </td>
                          <td className="px-3 py-2 font-bold text-neutral-900 dark:text-white">
                            {row.shift}
                          </td>
                          <td className="px-3 py-2 text-right font-mono font-bold text-emerald-600">
                            ${formatThousands(row.cash)}
                          </td>
                          <td className="px-3 py-2 text-right font-mono text-sky-600">
                            ${formatThousands(row.mercadoPago)}
                          </td>
                          <td className="px-3 py-2 text-right font-mono text-indigo-600">
                            ${formatThousands(row.qr)}
                          </td>
                          <td className="px-3 py-2 text-right font-mono text-blue-600">
                            ${formatThousands(row.transfer)}
                          </td>
                          <td className="px-3 py-2 text-right font-mono text-emerald-700">
                            {row.incomes > 0 ? `+$${formatThousands(row.incomes)}` : '-'}
                          </td>
                          <td className="px-3 py-2 text-right font-mono text-rose-600">
                            {row.expenses > 0 ? `-$${formatThousands(row.expenses)}` : '-'}
                          </td>
                          <td className="px-3 py-2 text-neutral-500 italic max-w-xs truncate">
                            {row.concept}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Import Options (Target & Strategy) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="p-3 bg-neutral-50 dark:bg-neutral-800/50 rounded-xl border border-neutral-200 dark:border-neutral-700">
                  <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 mb-1.5 uppercase">
                    ¿Qué datos deseas registrar?
                  </label>
                  <div className="space-y-1.5 text-xs">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="importTarget"
                        value="BOTH"
                        checked={importTarget === 'BOTH'}
                        onChange={() => setImportTarget('BOTH')}
                        className="text-emerald-600 focus:ring-emerald-500"
                      />
                      <span className="font-semibold text-neutral-800 dark:text-neutral-200">
                        Historial de Turnos y Movimientos de Ingreso/Egreso
                      </span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="importTarget"
                        value="SHIFTS"
                        checked={importTarget === 'SHIFTS'}
                        onChange={() => setImportTarget('SHIFTS')}
                        className="text-emerald-600 focus:ring-emerald-500"
                      />
                      <span>Solo Cierres de Turno (Historial de Arqueos)</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="importTarget"
                        value="MOVEMENTS"
                        checked={importTarget === 'MOVEMENTS'}
                        onChange={() => setImportTarget('MOVEMENTS')}
                        className="text-emerald-600 focus:ring-emerald-500"
                      />
                      <span>Solo Movimientos de Efectivo (Gastos y Entradas)</span>
                    </label>
                  </div>
                </div>

                <div className="p-3 bg-neutral-50 dark:bg-neutral-800/50 rounded-xl border border-neutral-200 dark:border-neutral-700">
                  <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 mb-1.5 uppercase">
                    Estrategia de Guardado
                  </label>
                  <div className="space-y-1.5 text-xs">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="strategy"
                        value="MERGE"
                        checked={importStrategy === 'MERGE'}
                        onChange={() => setImportStrategy('MERGE')}
                        className="text-emerald-600 focus:ring-emerald-500"
                      />
                      <span className="font-semibold text-neutral-800 dark:text-neutral-200">
                        Anexar al historial existente (Recomendado)
                      </span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="strategy"
                        value="REPLACE"
                        checked={importStrategy === 'REPLACE'}
                        onChange={() => setImportStrategy('REPLACE')}
                        className="text-rose-600 focus:ring-rose-500"
                      />
                      <span className="text-rose-600 font-semibold">
                        Reemplazar todo el historial previo con este archivo
                      </span>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-neutral-50 dark:bg-neutral-800/80 border-t border-neutral-200 dark:border-neutral-700 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            disabled={isImporting}
            className="px-4 py-2 text-xs font-semibold text-neutral-600 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded-lg transition-colors"
          >
            Cancelar
          </button>

          {selectedFile && parsedRows.length > 0 && (
            <div className="flex items-center gap-3">
              {isImporting && (
                <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600">
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Importando... {importProgress}%</span>
                </div>
              )}
              <button
                type="button"
                onClick={handleExecuteImport}
                disabled={isImporting}
                className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-xs font-extrabold uppercase tracking-wider flex items-center gap-2 shadow-md cursor-pointer transition-all active:scale-95 disabled:opacity-50"
              >
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Confirmar e Importar {parsedRows.length} Registros</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
