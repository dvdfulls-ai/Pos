import React, { useState, useRef, useEffect } from 'react';
import { 
  ShoppingBag, 
  Plus, 
  Search, 
  Trash2, 
  CreditCard, 
  Banknote, 
  UserCheck, 
  FileText,
  Calendar,
  X,
  CheckCircle2,
  Building
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import { Article, PaymentMethod, PurchaseItem } from '../../types';
import { DialogService } from '../../services/dialog';
import { matchesQuery, formatThousands, parseFormattedNumber } from '../../utils/text';

export const PurchasesModule: React.FC = () => {
  const { purchases, articles, registerPurchase, accounts } = useApp();
  const { hasPermission } = useAuth();

  const [showModal, setShowModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Enfocar el buscador al entrar a Compras & Pagos y después de acciones.
  useEffect(() => {
    const focusSearchInput = () => {
      setTimeout(() => {
        if (!showModal) {
          searchInputRef.current?.focus();
          searchInputRef.current?.select();
        }
      }, 50);
    };

    focusSearchInput();

    const refocusSearchAfterAction = (event: MouseEvent) => {
      const target = event.target as HTMLElement | null;
      if (target?.closest('input, textarea, select, [contenteditable="true"]')) return;
      setTimeout(() => {
        if (!showModal) {
          searchInputRef.current?.focus();
          searchInputRef.current?.select();
        }
      }, 80);
    };

    document.addEventListener('click', refocusSearchAfterAction);
    return () => document.removeEventListener('click', refocusSearchAfterAction);
  }, [showModal]);

  // New Purchase Form
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [supplierName, setSupplierName] = useState('');
  const [supplierTaxId, setSupplierTaxId] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('TRANSFERENCIA');
  const [paymentRef, setPaymentRef] = useState('');

  // Item builder inside modal
  const [items, setItems] = useState<PurchaseItem[]>([]);
  const [selectedArticleId, setSelectedArticleId] = useState('');
  const [itemQty, setItemQty] = useState<number>(1);
  const [itemCost, setItemCost] = useState<number>(0);
  const [itemCostStr, setItemCostStr] = useState<string>('0');

  const canPurchase = hasPermission('canMakePurchases');

  const suppliers = accounts.filter(a => a.type === 'SUPPLIER');

  const handleSelectArticle = (artId: string) => {
    setSelectedArticleId(artId);
    const art = articles.find(a => a.id === artId);
    if (art) {
      setItemCost(art.costPrice);
      setItemCostStr(formatThousands(art.costPrice));
    } else {
      setItemCost(0);
      setItemCostStr('0');
    }
  };

  const handleCostChange = (rawValue: string) => {
    const formatted = formatThousands(rawValue);
    setItemCostStr(formatted);
    setItemCost(parseFormattedNumber(formatted));
  };

  const handleAddItem = () => {
    const art = articles.find(a => a.id === selectedArticleId);
    if (!art) {
      DialogService.alert('Seleccione un artículo para agregar a la factura de compra.', 'Artículo Requerido', 'warning');
      return;
    }
    if (itemQty <= 0 || itemCost <= 0) {
      DialogService.alert('Ingrese una cantidad y costo unitario válidos.', 'Valores Inválidos', 'warning');
      return;
    }

    const newItem: PurchaseItem = {
      articleId: art.id,
      name: art.name,
      brand: art.brand,
      quantity: itemQty,
      costPrice: itemCost,
      total: itemQty * itemCost,
    };

    setItems([...items, newItem]);
    setSelectedArticleId('');
    setItemQty(1);
    setItemCost(0);
    setItemCostStr('0');
  };

  const handleRemoveItem = (idx: number) => {
    setItems(items.filter((_, i) => i !== idx));
  };

  const totalPurchase = items.reduce((sum, item) => sum + item.total, 0);

  const handleSubmitPurchase = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supplierName.trim()) {
      DialogService.alert('Por favor, ingrese el nombre del proveedor.', 'Proveedor Requerido', 'warning');
      return;
    }
    if (items.length === 0) {
      DialogService.alert('Debe incluir al menos un artículo en el detalle de la compra.', 'Sin Artículos', 'warning');
      return;
    }

    registerPurchase({
      invoiceNumber: invoiceNumber.trim() || `FC-INT-${Date.now().toString().slice(-6)}`,
      supplierName: supplierName.trim(),
      supplierTaxId: supplierTaxId.trim() || undefined,
      items,
      total: totalPurchase,
      paymentMethod,
      paymentRef: paymentRef.trim() || undefined,
    });

    // Reset and close
    setShowModal(false);
    setInvoiceNumber('');
    setSupplierName('');
    setSupplierTaxId('');
    setItems([]);
    setPaymentRef('');
    setItemCost(0);
    setItemCostStr('0');
  };

  const filteredPurchases = purchases.filter(p => 
    matchesQuery(p.supplierName, searchTerm) ||
    matchesQuery(p.invoiceNumber, searchTerm)
  );

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-6 space-y-4 w-full">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-neutral-200">
        <div>
          <h2 className="text-lg font-bold text-neutral-900 tracking-tight">Compras & Pagos a Proveedores</h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Registro de facturas, recepción de mercadería y actualización automática de stock
          </p>
        </div>

        {canPurchase && (
          <button
            type="button"
            onClick={() => {
              setItems([]);
              setItemCost(0);
              setItemCostStr('0');
              setShowModal(true);
            }}
            className="primary-action-dark-white px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Plus className="w-4 h-4" />
            Registrar Compra
          </button>
        )}
      </div>

      {/* Search & Filter */}
      <div className="p-3 bg-white border border-neutral-200 rounded-xl flex items-center gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-neutral-400" />
          <input
            ref={searchInputRef}
            type="text"
            placeholder="Buscar compra por proveedor o número de factura..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-neutral-900"
          />
        </div>
      </div>

      {/* Purchases List */}
      <div className="bg-white border border-neutral-200 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-500 font-semibold uppercase tracking-wider">
              <tr>
                <th className="px-4 py-3">Fecha & Hora</th>
                <th className="px-4 py-3">N° Factura / Remito</th>
                <th className="px-4 py-3">Proveedor</th>
                <th className="px-4 py-3">Artículos Ingresados</th>
                <th className="px-4 py-3">Medio de Pago</th>
                <th className="px-4 py-3 text-right">Monto Total</th>
                <th className="px-4 py-3">Usuario Responsable</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100">
              {filteredPurchases.map((purchase) => (
                <tr key={purchase.id} className="hover:bg-neutral-50/80 transition-colors">
                  <td className="px-4 py-3 font-mono text-neutral-600 whitespace-nowrap">
                    {new Date(purchase.timestamp).toLocaleDateString()} {new Date(purchase.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </td>
                  <td className="px-4 py-3 font-mono font-semibold text-neutral-900">
                    {purchase.invoiceNumber}
                  </td>
                  <td className="px-4 py-3 font-medium text-neutral-800">
                    {purchase.supplierName}
                    {purchase.supplierTaxId && (
                      <span className="block text-[10px] text-neutral-400 font-mono">
                        CUIT: {purchase.supplierTaxId}
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-neutral-600">
                    <span className="font-semibold text-neutral-900">{purchase.items.length} productos:</span>{' '}
                    {purchase.items.map(i => `${i.quantity}x ${i.name}`).join(', ').slice(0, 45)}...
                  </td>
                  <td className="px-4 py-3">
                    <span className="inline-block px-2 py-0.5 rounded text-[11px] font-semibold bg-neutral-100 text-neutral-800">
                      {purchase.paymentMethod}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right font-mono font-bold text-sm text-neutral-900">
                    ${formatThousands(purchase.total)}
                  </td>
                  <td className="px-4 py-3 text-neutral-500">
                    {purchase.userName}
                  </td>
                </tr>
              ))}

              {filteredPurchases.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-neutral-400">
                    No se encontraron registros de compras a proveedores.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* NEW PURCHASE MODAL */}
      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-2xl w-full overflow-hidden shadow-2xl border border-neutral-200 max-h-[90vh] flex flex-col">
            <div className="p-4 border-b border-neutral-100 flex items-center justify-between bg-neutral-50">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-neutral-800" />
                <h3 className="font-bold text-sm text-neutral-900">Registrar Factura de Compra / Mercadería</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="p-1 text-neutral-400 hover:text-neutral-700 rounded-full"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitPurchase} className="p-5 overflow-y-auto space-y-4 flex-1">
              {/* Supplier & Invoice Data */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3 bg-neutral-50 rounded-xl border border-neutral-200 text-xs">
                <div>
                  <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                    Proveedor
                  </label>
                  <input
                    type="text"
                    required
                    list="suppliers-list"
                    placeholder="Nombre o razón social"
                    value={supplierName}
                    onChange={(e) => setSupplierName(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-neutral-300 rounded-lg text-xs"
                  />
                  <datalist id="suppliers-list">
                    {suppliers.map(s => (
                      <option key={s.id} value={s.name} />
                    ))}
                  </datalist>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                    N° Factura / Remito
                  </label>
                  <input
                    type="text"
                    placeholder="Ej: FC-A-0001-00045"
                    value={invoiceNumber}
                    onChange={(e) => setInvoiceNumber(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-neutral-300 rounded-lg text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                    CUIT / Identificación
                  </label>
                  <input
                    type="text"
                    placeholder="30-..."
                    value={supplierTaxId}
                    onChange={(e) => setSupplierTaxId(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-neutral-300 rounded-lg text-xs font-mono"
                  />
                </div>
              </div>

              {/* Items in this purchase */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-700">
                    Artículos a Incorporar al Stock
                  </h4>
                  <span className="text-[11px] text-neutral-500">
                    El stock se sumará de inmediato al catálogo
                  </span>
                </div>

                {/* Item adder line */}
                <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 grid grid-cols-1 sm:grid-cols-12 gap-2 items-end">
                  <div className="sm:col-span-6">
                    <label className="block text-[10px] uppercase font-bold text-neutral-500 mb-1">Artículo existente</label>
                    <select
                      value={selectedArticleId}
                      onChange={(e) => handleSelectArticle(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-neutral-300 rounded-lg text-xs"
                    >
                      <option value="">-- Seleccione un artículo --</option>
                      {articles.map(a => (
                        <option key={a.id} value={a.id}>
                          {a.name} ({a.brand}) - Costo act: ${formatThousands(a.costPrice)}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-[10px] uppercase font-bold text-neutral-500 mb-1">Cantidad</label>
                    <input
                      type="number"
                      min="1"
                      value={itemQty}
                      onChange={(e) => setItemQty(parseInt(e.target.value, 10) || 1)}
                      className="w-full px-2 py-2 bg-white border border-neutral-300 rounded-lg text-xs font-mono"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-[10px] uppercase font-bold text-neutral-500 mb-1">Costo Unit. ($)</label>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={itemCostStr}
                      onChange={(e) => handleCostChange(e.target.value)}
                      className="w-full px-2 py-2 bg-white border border-neutral-300 rounded-lg text-xs font-mono font-bold"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <button
                      type="button"
                      onClick={handleAddItem}
                      className="w-full py-2 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-bold transition-colors"
                    >
                      + Agregar
                    </button>
                  </div>
                </div>

                {/* Table of added items */}
                <div className="border border-neutral-200 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-500 text-[11px]">
                      <tr>
                        <th className="p-2.5">Producto</th>
                        <th className="p-2.5 text-center">Cant.</th>
                        <th className="p-2.5 text-right">Costo Unit.</th>
                        <th className="p-2.5 text-right">Subtotal</th>
                        <th className="p-2.5 text-center">Acción</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-100">
                      {items.map((it, idx) => (
                        <tr key={idx}>
                          <td className="p-2.5 font-medium text-neutral-800">
                            {it.name} <span className="text-neutral-400">({it.brand})</span>
                          </td>
                          <td className="p-2.5 text-center font-mono font-bold">{it.quantity}</td>
                          <td className="p-2.5 text-right font-mono">${formatThousands(it.costPrice)}</td>
                          <td className="p-2.5 text-right font-mono font-bold">${formatThousands(it.total)}</td>
                          <td className="p-2.5 text-center">
                            <button
                              type="button"
                              onClick={() => handleRemoveItem(idx)}
                              className="text-rose-500 hover:text-rose-700 p-1"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                      {items.length === 0 && (
                        <tr>
                          <td colSpan={5} className="p-4 text-center text-neutral-400 text-xs">
                            No se han agregado productos a esta orden de compra todavía.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Payment Method Selection */}
              <div className="p-4 bg-neutral-50 rounded-xl border border-neutral-200 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold uppercase tracking-wider text-neutral-700">
                    Forma de Pago de la Factura
                  </span>
                  <div className="text-right">
                    <span className="text-xs text-neutral-500">Total a pagar:</span>
                    <span className="text-lg font-black font-mono text-neutral-900 ml-2">
                      ${formatThousands(totalPurchase)}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  {(['TRANSFERENCIA', 'EFECTIVO', 'CUENTA_CORRIENTE'] as PaymentMethod[]).map(pm => (
                    <button
                      key={pm}
                      type="button"
                      onClick={() => setPaymentMethod(pm)}
                      className={`p-2.5 rounded-lg border-2 text-xs font-semibold text-center transition-colors ${
                        paymentMethod === pm
                          ? 'payment-method-active bg-white text-black font-bold border-black dark:bg-white dark:text-black dark:border-white shadow-xs'
                          : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-100 dark:bg-neutral-800 dark:text-neutral-300 dark:border-neutral-700 dark:hover:bg-neutral-700'
                      }`}
                    >
                      {pm === 'EFECTIVO' ? 'Efectivo (Caja)' : pm === 'TRANSFERENCIA' ? 'Transferencia' : 'Cta. Cte. Proveedor'}
                    </button>
                  ))}
                </div>

                {paymentMethod === 'EFECTIVO' && (
                  <p className="text-[11px] text-neutral-500">
                    Nota: Se registrará automáticamente un egreso de caja en el turno actual de la terminal.
                  </p>
                )}
                {paymentMethod === 'TRANSFERENCIA' && (
                  <div>
                    <input
                      type="text"
                      placeholder="N° Comprobante / Referencia de transferencia bancaria"
                      value={paymentRef}
                      onChange={(e) => setPaymentRef(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-neutral-300 rounded-lg text-xs font-mono"
                    />
                  </div>
                )}
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 border border-neutral-300 rounded-lg text-xs font-semibold text-neutral-700"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white !text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors shadow-xs"
                >
                  Confirmar e Ingresar Stock
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
