import React, { useState, useRef, useMemo } from 'react';
import { 
  X, 
  Upload, 
  FileText, 
  FileSpreadsheet, 
  Check, 
  AlertCircle, 
  CheckCircle2, 
  RefreshCw, 
  Layers, 
  Sliders, 
  DollarSign,
  UserCheck,
  Calendar,
  Receipt
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { CurrentAccount, AccountMovement } from '../../types';
import { StorageService } from '../../services/storage';
import { formatThousands } from '../../utils/text';

interface AccountsImportModalProps {
  isOpen: boolean;
  mode: 'CSV' | 'EXCEL' | null;
  accountType?: 'CLIENT' | 'SUPPLIER';
  onClose: () => void;
  onImportComplete: (accountsCount: number, totalBalance: number) => void;
}

interface ColumnMapping {
  date: string;
  name: string;
  invoice: string;
  total: string;
  paid: string;
  balance: string;
}

interface ParsedAccountRow {
  date: string;
  name: string;
  invoice: string;
  total: number;
  paid: number;
  balance: number;
}

// Cleans header names from DBF format:
// "FECHA,D" -> "FECHA"
// "NOMBRE,C,20" -> "NOMBRE"
// "FACTURA,N,10,0" -> "FACTURA"
// "TOTAL,N,15,4" -> "TOTAL"
// "PAGADO,N,15,4" -> "PAGADO"
// "SALDO,N,15,4" -> "SALDO"
export function cleanHeaderKey(raw: string): string {
  if (!raw) return '';
  let s = String(raw).replace(/^\uFEFF/, '').replace(/["']/g, '').trim();
  s = s.split(/[,(]/)[0].trim();
  return s.toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Z0-9]/g, '');
}

// Flexible date parser for DBF (YYYYMMDD, DD/MM/YYYY, Excel serial, ISO)
function parseFlexibleDate(val: any): string {
  if (!val) return new Date().toISOString();
  if (val instanceof Date) return isNaN(val.getTime()) ? new Date().toISOString() : val.toISOString();
  
  // Excel serial number (e.g. 45658)
  if (typeof val === 'number') {
    const excelEpoch = new Date(Date.UTC(1899, 11, 30));
    const date = new Date(excelEpoch.getTime() + val * 86400000);
    return isNaN(date.getTime()) ? new Date().toISOString() : date.toISOString();
  }

  const str = String(val).trim();
  if (!str) return new Date().toISOString();

  // YYYYMMDD (standard DBF Date format)
  if (/^\d{8}$/.test(str)) {
    const year = parseInt(str.slice(0, 4), 10);
    const month = parseInt(str.slice(4, 6), 10) - 1;
    const day = parseInt(str.slice(6, 8), 10);
    const d = new Date(year, month, day, 12, 0, 0);
    return isNaN(d.getTime()) ? new Date().toISOString() : d.toISOString();
  }

  // DD/MM/YYYY or DD-MM-YYYY
  const dmyMatch = str.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})/);
  if (dmyMatch) {
    const day = parseInt(dmyMatch[1], 10);
    const month = parseInt(dmyMatch[2], 10) - 1;
    let year = parseInt(dmyMatch[3], 10);
    if (year < 100) year += 2000;
    const d = new Date(year, month, day, 12, 0, 0);
    return isNaN(d.getTime()) ? new Date().toISOString() : d.toISOString();
  }

  const parsed = Date.parse(str);
  if (!isNaN(parsed)) {
    return new Date(parsed).toISOString();
  }

  return new Date().toISOString();
}

function formatDateDisplay(isoStr: string): string {
  try {
    const d = new Date(isoStr);
    if (isNaN(d.getTime())) return '-';
    return d.toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit', year: 'numeric' });
  } catch {
    return '-';
  }
}

export const AccountsImportModal: React.FC<AccountsImportModalProps> = ({
  isOpen,
  mode,
  accountType = 'CLIENT',
  onClose,
  onImportComplete,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isParsing, setIsParsing] = useState(false);
  const [parseError, setParseError] = useState<string | null>(null);
  const [detectedColumns, setDetectedColumns] = useState<string[]>([]);
  const [rawRowsData, setRawRowsData] = useState<any[]>([]);
  const [columnMapping, setColumnMapping] = useState<ColumnMapping>({
    date: '',
    name: '',
    invoice: '',
    total: '',
    paid: '',
    balance: '',
  });
  const [showColumnConfig, setShowColumnConfig] = useState(false);
  const [targetType, setTargetType] = useState<'CLIENT' | 'SUPPLIER'>(accountType);
  const [importStrategy, setImportStrategy] = useState<'REPLACE' | 'MERGE'>('MERGE');
  const [isImporting, setIsImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);

  // Flexible number parser for Argentine and DBF decimal formats
  const parseFlexibleNumber = (val: any): number => {
    if (typeof val === 'number') {
      return isNaN(val) ? 0 : val;
    }
    if (!val) return 0;
    const str = String(val).trim().replace(/[$ \t\r\n]/g, '');
    if (!str) return 0;

    if (str.includes(',') && str.includes('.')) {
      if (str.indexOf('.') < str.indexOf(',')) {
        // e.g. "1.500,50"
        const normalized = str.replace(/\./g, '').replace(',', '.');
        const num = parseFloat(normalized);
        return isNaN(num) ? 0 : num;
      } else {
        // e.g. "1,500.50"
        const normalized = str.replace(/,/g, '');
        const num = parseFloat(normalized);
        return isNaN(num) ? 0 : num;
      }
    } else if (str.includes(',')) {
      const normalized = str.replace(',', '.');
      const num = parseFloat(normalized);
      return isNaN(num) ? 0 : num;
    } else {
      const num = parseFloat(str);
      return isNaN(num) ? 0 : num;
    }
  };

  // Auto-detect columns matching FECHA,D, NOMBRE,C,20, FACTURA,N,10,0, TOTAL,N,15,4, PAGADO,N,15,4, SALDO,N,15,4
  const autoDetectMapping = (keys: string[]): ColumnMapping => {
    const mapping: ColumnMapping = {
      date: '',
      name: '',
      invoice: '',
      total: '',
      paid: '',
      balance: '',
    };

    for (const rawKey of keys) {
      const norm = cleanHeaderKey(rawKey);

      // Fecha (FECHA, FECHA,D, DATE, DIA, FEC)
      if (!mapping.date && (
        norm.startsWith('FECHA') || norm.startsWith('DATE') || norm.startsWith('FEC') || norm.startsWith('DIA')
      )) {
        mapping.date = rawKey;
      }

      // Nombre (NOMBRE, NOMBRE,C,20, CLIENTE, TITULAR, RAZON, PROVEEDOR)
      if (!mapping.name && (
        norm.startsWith('NOMBRE') || norm.startsWith('CLIENTE') || norm.startsWith('TITULAR') ||
        norm.startsWith('RAZON') || norm === 'NOM' || (targetType === 'SUPPLIER' && norm.startsWith('PROVEEDOR'))
      )) {
        mapping.name = rawKey;
      }

      // Factura / Comprobante (FACTURA, FACTURA,N,10,0, COMPROBANTE, RECIBO, NUMERO, NRO, DOC, TICKET)
      if (!mapping.invoice && (
        norm.startsWith('FACTURA') || norm.startsWith('COMPROBANTE') || norm.startsWith('RECIBO') ||
        norm.startsWith('NUMERO') || norm.startsWith('NRO') || norm.startsWith('DOC') || norm.startsWith('TICKET')
      )) {
        mapping.invoice = rawKey;
      }

      // Total (TOTAL, TOTAL,N,15,4, IMPORTE, MONTO, DEBE, CARGO)
      if (!mapping.total && (
        norm.startsWith('TOTAL') || norm.startsWith('IMPORTE') || norm.startsWith('MONTO') ||
        norm.startsWith('DEBE') || norm.startsWith('CARGO')
      )) {
        mapping.total = rawKey;
      }

      // Pagado (PAGADO, PAGADO,N,15,4, PAGO, ABONADO, ABONO, ENTREGA, HABER)
      if (!mapping.paid && (
        norm.startsWith('PAGADO') || norm.startsWith('PAGO') || norm.startsWith('ABONADO') ||
        norm.startsWith('ABONO') || norm.startsWith('ENTREGA') || norm.startsWith('HABER')
      )) {
        mapping.paid = rawKey;
      }

      // Saldo (SALDO, SALDO,N,15,4, RESTO, DEUDA, PENDIENTE)
      if (!mapping.balance && (
        norm.startsWith('SALDO') || norm.startsWith('RESTO') || norm.startsWith('DEUDA') ||
        norm.startsWith('PENDIENTE')
      )) {
        mapping.balance = rawKey;
      }
    }

    // Fallbacks
    if (!mapping.name && keys.length > 0) {
      // Find candidate text column
      mapping.name = keys[0];
    }
    if (!mapping.balance && mapping.total) {
      mapping.balance = mapping.total;
    }

    return mapping;
  };

  const processLoadedRows = (rows: any[]) => {
    if (!rows || rows.length === 0) {
      throw new Error('El archivo no contiene filas de datos.');
    }

    const firstRow = rows[0];
    const keys = Object.keys(firstRow).filter(k => k && !k.startsWith('__EMPTY'));
    if (keys.length === 0) {
      const allKeys = Object.keys(firstRow);
      setDetectedColumns(allKeys);
      setRawRowsData(rows);
      setColumnMapping(autoDetectMapping(allKeys));
      return;
    }

    setDetectedColumns(keys);
    setRawRowsData(rows);
    setColumnMapping(autoDetectMapping(keys));
  };

  // Convert raw rows using current mapping
  const parsedRows: ParsedAccountRow[] = useMemo(() => {
    if (rawRowsData.length === 0) return [];

    const result: ParsedAccountRow[] = [];
    const len = rawRowsData.length;

    for (let i = 0; i < len; i++) {
      const row = rawRowsData[i];

      const rawName = columnMapping.name ? String(row[columnMapping.name] ?? '').trim() : '';
      if (!rawName) continue;

      const dateStr = columnMapping.date ? parseFlexibleDate(row[columnMapping.date]) : new Date().toISOString();
      const invoice = columnMapping.invoice ? String(row[columnMapping.invoice] ?? '').trim() : '';

      const total = columnMapping.total ? parseFlexibleNumber(row[columnMapping.total]) : 0;
      const paid = columnMapping.paid ? parseFlexibleNumber(row[columnMapping.paid]) : 0;
      
      let balance = 0;
      if (columnMapping.balance && row[columnMapping.balance] !== undefined) {
        balance = parseFlexibleNumber(row[columnMapping.balance]);
      } else if (total > 0 || paid > 0) {
        balance = Math.max(0, total - paid);
      }

      result.push({
        date: dateStr,
        name: rawName,
        invoice,
        total,
        paid,
        balance,
      });
    }

    return result;
  }, [rawRowsData, columnMapping]);

  // Aggregate statistics
  const summaryStats = useMemo(() => {
    const clientsSet = new Set<string>();
    let totalBalanceSum = 0;
    let totalOriginalSum = 0;
    let totalPaidSum = 0;

    for (const r of parsedRows) {
      clientsSet.add(r.name.toLowerCase().trim());
      totalBalanceSum += r.balance;
      totalOriginalSum += r.total;
      totalPaidSum += r.paid;
    }

    return {
      uniqueClientsCount: clientsSet.size,
      totalRows: parsedRows.length,
      totalBalanceSum,
      totalOriginalSum,
      totalPaidSum,
    };
  }, [parsedRows]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSelectedFile(file);
    setIsParsing(true);
    setParseError(null);
    setRawRowsData([]);

    const reader = new FileReader();

    if (mode === 'EXCEL') {
      reader.onload = (evt) => {
        try {
          const buffer = evt.target?.result as ArrayBuffer;
          const workbook = XLSX.read(buffer, { type: 'array' });
          const sheetName = workbook.SheetNames[0];
          if (!sheetName) throw new Error('El archivo Excel no contiene hojas de datos.');
          const worksheet = workbook.Sheets[sheetName];
          const json = XLSX.utils.sheet_to_json(worksheet, { defval: '' });
          processLoadedRows(json);
        } catch (err: any) {
          setParseError(err.message || 'Error al procesar archivo de Excel.');
        } finally {
          setIsParsing(false);
        }
      };
      reader.onerror = () => {
        setParseError('Error al leer el archivo de Excel.');
        setIsParsing(false);
      };
      reader.readAsArrayBuffer(file);
    } else {
      // CSV mode: supports comma, semicolon, tab
      reader.onload = (evt) => {
        try {
          const text = evt.target?.result as string;
          if (!text || !text.trim()) {
            throw new Error('El archivo CSV está vacío.');
          }

          const workbook = XLSX.read(text, { type: 'string' });
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          const json = XLSX.utils.sheet_to_json(worksheet, { defval: '' });
          processLoadedRows(json);
        } catch (err: any) {
          setParseError(err.message || 'Error al procesar archivo CSV.');
        } finally {
          setIsParsing(false);
        }
      };
      reader.onerror = () => {
        setParseError('Error al leer el archivo CSV.');
        setIsParsing(false);
      };
      reader.readAsText(file, 'utf-8');
    }
  };

  const handleExecuteImport = () => {
    if (parsedRows.length === 0) return;

    setIsImporting(true);
    setImportProgress(25);

    setTimeout(() => {
      try {
        const existingAccounts = StorageService.getAccounts();
        const existingMovements = StorageService.getAccountMovements();

        // Map existing accounts of the target type (CLIENT or SUPPLIER)
        const accountMap = new Map<string, CurrentAccount>();

        if (importStrategy === 'MERGE') {
          for (const acc of existingAccounts) {
            accountMap.set(`${acc.type}_${acc.name.toLowerCase().trim()}`, acc);
          }
        } else {
          // In REPLACE mode, keep accounts of the OTHER type, replace accounts of this type
          for (const acc of existingAccounts) {
            if (acc.type !== targetType) {
              accountMap.set(`${acc.type}_${acc.name.toLowerCase().trim()}`, acc);
            }
          }
        }

        const newMovements: AccountMovement[] = importStrategy === 'MERGE' ? [...existingMovements] : [];
        const nowIso = new Date().toISOString();
        const currentUser = StorageService.getCurrentUser();

        // Group rows by client name
        const groupedRows = new Map<string, ParsedAccountRow[]>();
        for (const row of parsedRows) {
          const key = row.name.trim();
          if (!groupedRows.has(key)) {
            groupedRows.set(key, []);
          }
          groupedRows.get(key)!.push(row);
        }

        let totalBalanceImported = 0;

        // Process each unique client/supplier
        groupedRows.forEach((rows, clientName) => {
          const mapKey = `${targetType}_${clientName.toLowerCase().trim()}`;
          const existing = accountMap.get(mapKey);

          // Calculate total balance for this client from rows
          const clientBalanceFromImport = rows.reduce((acc, r) => acc + r.balance, 0);
          totalBalanceImported += clientBalanceFromImport;

          const accountId = existing ? existing.id : `acc_${targetType.toLowerCase()}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;

          const targetAccount: CurrentAccount = {
            id: accountId,
            type: targetType,
            name: clientName,
            documentNumber: existing ? existing.documentNumber : (rows[0]?.invoice || ''),
            phone: existing ? existing.phone : '',
            email: existing?.email,
            creditLimit: existing ? existing.creditLimit : 0,
            currentBalance: existing && importStrategy === 'MERGE' 
              ? existing.currentBalance + clientBalanceFromImport 
              : clientBalanceFromImport,
            updatedAt: nowIso,
          };

          accountMap.set(mapKey, targetAccount);

          // Create individual movements for invoices/balances
          rows.forEach((r, idx) => {
            if (r.balance > 0 || r.total > 0) {
              const invoiceTag = r.invoice ? `Factura Nº ${r.invoice}` : `Saldo inicial`;
              const movementAmount = r.balance > 0 ? r.balance : r.total;

              newMovements.push({
                id: `mov_imp_${Date.now()}_${idx}_${Math.random().toString(36).slice(2, 6)}`,
                accountId,
                accountName: clientName,
                type: 'DEBIT',
                amount: movementAmount,
                concept: `${invoiceTag} (Importación de Base de Datos)`,
                userId: currentUser.id,
                userName: currentUser.name,
                timestamp: r.date || nowIso,
              });
            }
          });
        });

        const finalAccounts = Array.from(accountMap.values());
        StorageService.saveAccounts(finalAccounts);
        StorageService.saveAccountMovements(newMovements);

        setImportProgress(100);
        onImportComplete(groupedRows.size, totalBalanceImported);
        onClose();
      } catch (err: any) {
        setParseError('Error durante el guardado: ' + (err.message || 'Error desconocido'));
        setIsImporting(false);
      }
    }, 100);
  };

  // Safe early return placed AFTER all hooks are evaluated
  if (!isOpen || !mode) return null;

  const isCsv = mode === 'CSV';

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white dark:bg-neutral-900 rounded-2xl max-w-4xl w-full max-h-[92vh] overflow-hidden shadow-2xl border border-neutral-200 dark:border-neutral-800 flex flex-col animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className={`p-4 text-white flex items-center justify-between ${
          isCsv ? 'bg-amber-700' : 'bg-orange-700'
        }`}>
          <div className="flex items-center gap-2.5">
            {isCsv ? <FileText className="w-6 h-6" /> : <FileSpreadsheet className="w-6 h-6" />}
            <div>
              <h3 className="font-extrabold text-base tracking-tight flex items-center gap-2">
                <span>Importar Cuentas Corrientes desde {isCsv ? 'CSV' : 'Excel'}</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-white/20 uppercase">
                  {isCsv ? '.csv' : '.xlsx / .xls'}
                </span>
              </h3>
              <p className="text-xs text-white/80">
                Compatible con DBF (FECHA, NOMBRE, FACTURA, TOTAL, PAGADO, SALDO) y planillas de clientes
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-white/80 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4 text-xs text-neutral-800 dark:text-neutral-200 flex-1">
          {/* Target Type & Strategy Selector */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-neutral-50 dark:bg-neutral-800/50 rounded-xl border border-neutral-200 dark:border-neutral-700">
            <div>
              <label className="block text-[11px] font-black uppercase text-neutral-700 dark:text-neutral-300 mb-1">
                Tipo de Cuenta de Destino:
              </label>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setTargetType('CLIENT')}
                  className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                    targetType === 'CLIENT'
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'bg-white dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border border-neutral-200 dark:border-neutral-700'
                  }`}
                >
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>Clientes (Fiados)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setTargetType('SUPPLIER')}
                  className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                    targetType === 'SUPPLIER'
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'bg-white dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border border-neutral-200 dark:border-neutral-700'
                  }`}
                >
                  <DollarSign className="w-3.5 h-3.5" />
                  <span>Proveedores</span>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase text-neutral-700 dark:text-neutral-300 mb-1">
                Modo de Importación:
              </label>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setImportStrategy('MERGE')}
                  className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    importStrategy === 'MERGE'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-white dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border border-neutral-200 dark:border-neutral-700'
                  }`}
                  title="Suma los saldos y comprobantes a las cuentas existentes"
                >
                  Sumar y Actualizar
                </button>
                <button
                  type="button"
                  onClick={() => setImportStrategy('REPLACE')}
                  className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    importStrategy === 'REPLACE'
                      ? 'bg-rose-600 text-white shadow-xs'
                      : 'bg-white dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border border-neutral-200 dark:border-neutral-700'
                  }`}
                  title="Reemplaza los clientes de cuenta corriente por los del archivo"
                >
                  Reemplazar ({targetType === 'CLIENT' ? 'Clientes' : 'Proveedores'})
                </button>
              </div>
            </div>
          </div>

          {/* File Upload Drop Area */}
          <div className="border-2 border-dashed border-neutral-300 dark:border-neutral-700 hover:border-amber-500 rounded-2xl p-6 text-center bg-neutral-50 dark:bg-neutral-800/40 transition-colors">
            <input
              ref={fileInputRef}
              type="file"
              accept={isCsv ? '.csv,.txt' : '.xlsx,.xls'}
              onChange={handleFileChange}
              className="hidden"
            />

            <div className="flex flex-col items-center justify-center space-y-2">
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${
                isCsv ? 'bg-amber-100 dark:bg-amber-950 text-amber-600' : 'bg-orange-100 dark:bg-orange-950 text-orange-600'
              }`}>
                {isCsv ? <FileText className="w-7 h-7" /> : <FileSpreadsheet className="w-7 h-7" />}
              </div>

              <div>
                <p className="font-bold text-sm text-neutral-800 dark:text-neutral-100">
                  {selectedFile ? selectedFile.name : `Selecciona tu archivo ${isCsv ? 'CSV (.csv)' : 'Excel (.xlsx)'}`}
                </p>
                <p className="text-neutral-500 text-xs mt-0.5">
                  {selectedFile 
                    ? `${(selectedFile.size / 1024).toFixed(1)} KB listos para importar`
                    : `Arrastra aquí el archivo exportado de tu base de datos o haz clic para buscarlo`}
                </p>
              </div>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isParsing || isImporting}
                className="mt-2 px-4 py-2 bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 rounded-xl font-bold uppercase tracking-wider text-xs hover:bg-neutral-800 dark:hover:bg-neutral-100 transition-colors shadow-xs cursor-pointer flex items-center gap-2"
              >
                <Upload className="w-4 h-4" />
                <span>{selectedFile ? 'Cambiar Archivo' : 'Examinar Archivo'}</span>
              </button>
            </div>
          </div>

          {/* Parsing Spinner */}
          {isParsing && (
            <div className="p-4 bg-neutral-100 dark:bg-neutral-800 rounded-xl flex items-center justify-center gap-3 text-neutral-700 dark:text-neutral-300">
              <RefreshCw className="w-5 h-5 animate-spin text-amber-600" />
              <span className="font-semibold text-xs">Analizando fechas, clientes, facturas y saldos...</span>
            </div>
          )}

          {/* Parse Error */}
          {parseError && (
            <div className="p-3.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl text-rose-700 dark:text-rose-300 flex items-start gap-2.5">
              <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5 text-rose-600" />
              <div>
                <strong className="block font-bold">No se pudo procesar el archivo</strong>
                <span>{parseError}</span>
              </div>
            </div>
          )}

          {/* Preview and Configuration when parsed */}
          {parsedRows.length > 0 && (
            <div className="space-y-4 animate-in fade-in">
              {/* Stats Card */}
              <div className="p-4 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center font-bold flex-shrink-0">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-amber-950 dark:text-amber-100 text-sm">
                      {formatThousands(summaryStats.uniqueClientsCount)} titulares detectados ({formatThousands(summaryStats.totalRows)} comprobantes)
                    </h4>
                    <p className="text-[11px] text-amber-800 dark:text-amber-300">
                      Saldo Total a Cobrar: <strong>${formatThousands(summaryStats.totalBalanceSum)}</strong>
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setShowColumnConfig(prev => !prev)}
                  className="px-3.5 py-1.5 bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 hover:bg-neutral-100 rounded-xl text-xs font-bold text-neutral-700 dark:text-neutral-300 flex items-center gap-1.5 cursor-pointer shadow-2xs self-start md:self-auto"
                >
                  <Sliders className="w-3.5 h-3.5 text-amber-600" />
                  <span>{showColumnConfig ? 'Ocultar Columnas' : 'Ajustar Columnas'}</span>
                </button>
              </div>

              {/* Column Mapping Selector */}
              {showColumnConfig && (
                <div className="p-4 bg-neutral-100 dark:bg-neutral-800/80 rounded-xl border border-neutral-200 dark:border-neutral-700 space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between border-b border-neutral-200 dark:border-neutral-700 pb-2">
                    <h5 className="font-extrabold text-xs text-neutral-900 dark:text-white flex items-center gap-2">
                      <Sliders className="w-4 h-4 text-amber-600" />
                      <span>Asignación de Columnas de tu Archivo DBF / Excel:</span>
                    </h5>
                    <span className="text-[11px] text-neutral-500">
                      Revisa que coincidan con FECHA, NOMBRE, FACTURA, TOTAL, PAGADO, SALDO
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                    {/* Fecha */}
                    <div>
                      <label className="block text-[11px] font-black text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                        Fecha (FECHA,D):
                      </label>
                      <select
                        value={columnMapping.date}
                        onChange={(e) => setColumnMapping({ ...columnMapping, date: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-lg text-xs font-mono font-bold text-neutral-900 dark:text-white"
                      >
                        <option value="">-- No asignar --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    {/* Nombre */}
                    <div>
                      <label className="block text-[11px] font-black text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                        Nombre / Titular (NOMBRE,C,20):
                      </label>
                      <select
                        value={columnMapping.name}
                        onChange={(e) => setColumnMapping({ ...columnMapping, name: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-lg text-xs font-mono font-bold text-neutral-900 dark:text-white"
                      >
                        <option value="">-- No asignar --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    {/* Factura */}
                    <div>
                      <label className="block text-[11px] font-black text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                        Factura / Nro (FACTURA,N,10,0):
                      </label>
                      <select
                        value={columnMapping.invoice}
                        onChange={(e) => setColumnMapping({ ...columnMapping, invoice: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-lg text-xs font-mono font-bold text-neutral-900 dark:text-white"
                      >
                        <option value="">-- No asignar --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    {/* Total */}
                    <div>
                      <label className="block text-[11px] font-black text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                        Total Comprobante (TOTAL,N,15,4):
                      </label>
                      <select
                        value={columnMapping.total}
                        onChange={(e) => setColumnMapping({ ...columnMapping, total: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-lg text-xs font-mono font-bold text-neutral-900 dark:text-white"
                      >
                        <option value="">-- No asignar --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    {/* Pagado */}
                    <div>
                      <label className="block text-[11px] font-black text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                        Monto Pagado (PAGADO,N,15,4):
                      </label>
                      <select
                        value={columnMapping.paid}
                        onChange={(e) => setColumnMapping({ ...columnMapping, paid: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-lg text-xs font-mono font-bold text-neutral-900 dark:text-white"
                      >
                        <option value="">-- No asignar --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>

                    {/* Saldo */}
                    <div>
                      <label className="block text-[11px] font-black text-amber-700 dark:text-amber-400 uppercase mb-1">
                        Saldo Pendiente (SALDO,N,15,4):
                      </label>
                      <select
                        value={columnMapping.balance}
                        onChange={(e) => setColumnMapping({ ...columnMapping, balance: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-neutral-900 border border-amber-500 rounded-lg text-xs font-mono font-bold text-neutral-900 dark:text-white"
                      >
                        <option value="">-- No asignar --</option>
                        {detectedColumns.map(col => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* Data Preview Table */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-bold text-xs text-neutral-700 dark:text-neutral-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-amber-600" />
                    <span>Vista Previa de Cuentas Corrientes (primeras 5 filas):</span>
                  </span>
                  <span className="text-[11px] text-neutral-500">
                    Total a procesar: <strong>{formatThousands(parsedRows.length)}</strong> filas
                  </span>
                </div>

                <div className="overflow-x-auto rounded-xl border border-neutral-200 dark:border-neutral-800">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 font-bold border-b border-neutral-200 dark:border-neutral-700">
                      <tr>
                        <th className="py-2.5 px-3">Fecha</th>
                        <th className="py-2.5 px-3">Nombre / Titular</th>
                        <th className="py-2.5 px-3">Factura Nº</th>
                        <th className="py-2.5 px-3 text-right">Total ($)</th>
                        <th className="py-2.5 px-3 text-right">Pagado ($)</th>
                        <th className="py-2.5 px-3 text-right">Saldo Deudor ($)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800 font-mono text-[11px]">
                      {parsedRows.slice(0, 5).map((row, idx) => (
                        <tr key={idx} className="hover:bg-neutral-50 dark:hover:bg-neutral-800/50">
                          <td className="py-2 px-3 text-neutral-600 dark:text-neutral-400">
                            {formatDateDisplay(row.date)}
                          </td>
                          <td className="py-2 px-3 font-sans font-bold text-neutral-900 dark:text-white max-w-[200px] truncate">
                            {row.name}
                          </td>
                          <td className="py-2 px-3 text-neutral-600 dark:text-neutral-400">
                            {row.invoice ? (
                              <span className="px-1.5 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700">
                                {row.invoice}
                              </span>
                            ) : '-'}
                          </td>
                          <td className="py-2 px-3 text-right text-neutral-600 dark:text-neutral-400">
                            ${formatThousands(row.total)}
                          </td>
                          <td className="py-2 px-3 text-right text-emerald-600 dark:text-emerald-400">
                            ${formatThousands(row.paid)}
                          </td>
                          <td className="py-2 px-3 text-right font-black text-amber-600 dark:text-amber-400 text-xs">
                            ${formatThousands(row.balance)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-neutral-50 dark:bg-neutral-800/80 border-t border-neutral-200 dark:border-neutral-700/80 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            disabled={isImporting}
            className="px-4 py-2 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl font-bold text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            Cancelar
          </button>

          <button
            type="button"
            onClick={handleExecuteImport}
            disabled={parsedRows.length === 0 || isImporting}
            className={`px-6 py-2.5 text-white rounded-xl font-black uppercase tracking-wider shadow-sm transition-all flex items-center gap-2 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${
              isCsv ? 'bg-amber-600 hover:bg-amber-700' : 'bg-orange-600 hover:bg-orange-700'
            }`}
          >
            {isImporting ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Importando {formatThousands(summaryStats.uniqueClientsCount)} cuentas...</span>
              </>
            ) : (
              <>
                <Check className="w-4 h-4 stroke-[3]" />
                <span>Confirmar e Importar {parsedRows.length > 0 ? `(${formatThousands(summaryStats.uniqueClientsCount)} cuentas)` : ''}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
