import React, { useState } from 'react';
import { 
  UserCheck, 
  Plus, 
  Search, 
  DollarSign, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Phone, 
  Mail, 
  FileText, 
  X,
  CreditCard,
  Banknote,
  QrCode,
  History,
  Building,
  Eye,
  ShoppingBag,
  Receipt,
  FileSpreadsheet,
  Download
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import { CurrentAccount, PaymentMethod, AccountMovement } from '../../types';
import { DialogService } from '../../services/dialog';
import { matchesQuery, formatThousands, parseFormattedNumber } from '../../utils/text';
import { AccountsImportModal } from './AccountsImportModal';
import { exportToExcel, exportToCsv } from '../../utils/exportUtils';

export const AccountsModule: React.FC = () => {
  const { accounts, accountMovements, addAccount, registerAccountPayment, sales, purchases, reloadAllFromStorage } = useApp();
  const { hasPermission } = useAuth();

  const [activeTab, setActiveTab] = useState<'CLIENT' | 'SUPPLIER'>('CLIENT');
  const [searchTerm, setSearchTerm] = useState('');
  const [importModalMode, setImportModalMode] = useState<'CSV' | 'EXCEL' | null>(null);
  
  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedAccountForPayment, setSelectedAccountForPayment] = useState<CurrentAccount | null>(null);
  const [selectedAccountForHistory, setSelectedAccountForHistory] = useState<CurrentAccount | null>(null);
  const [selectedOperationDetail, setSelectedOperationDetail] = useState<{
    type: 'SALE' | 'PURCHASE' | 'PAYMENT';
    title: string;
    receiptNumber?: string;
    partyName: string;
    timestamp: string;
    userName: string;
    paymentMethod?: string;
    items?: { name: string; quantity: number; unitPrice: number; total: number }[];
    subtotal?: number;
    discount?: number;
    total: number;
    concept?: string;
  } | null>(null);

  // New Account form
  const [name, setName] = useState('');
  const [documentNumber, setDocumentNumber] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [creditLimitStr, setCreditLimitStr] = useState<string>('');

  // Payment form
  const [paymentAmount, setPaymentAmount] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('EFECTIVO');
  const [paymentConcept, setPaymentConcept] = useState('');

  const canManage = hasPermission('canManageAccounts');

  const filteredAccounts = accounts.filter(acc => 
    acc.type === activeTab &&
    (matchesQuery(acc.name, searchTerm) ||
     acc.documentNumber.includes(searchTerm) ||
     acc.phone.includes(searchTerm))
  );

  const totalOwedByClients = accounts
    .filter(a => a.type === 'CLIENT')
    .reduce((sum, a) => sum + a.currentBalance, 0);

  const totalOwedToSuppliers = accounts
    .filter(a => a.type === 'SUPPLIER')
    .reduce((sum, a) => sum + a.currentBalance, 0);

  const handleOpenAddModal = () => {
    setName('');
    setDocumentNumber('');
    setPhone('');
    setEmail('');
    setCreditLimitStr('');
    setShowAddModal(true);
  };

  const handleCreateAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const parsedCreditLimit = creditLimitStr.trim() === '' ? 0 : parseFormattedNumber(creditLimitStr);

    addAccount({
      type: activeTab,
      name: name.trim(),
      documentNumber: documentNumber.trim(),
      phone: phone.trim(),
      email: email.trim() || undefined,
      creditLimit: parsedCreditLimit,
      currentBalance: 0,
    });

    setShowAddModal(false);
    setName('');
    setDocumentNumber('');
    setPhone('');
    setEmail('');
    setCreditLimitStr('');
  };

  const handleRegisterPaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAccountForPayment) return;
    const amount = parseFormattedNumber(paymentAmount);
    if (amount <= 0) {
      DialogService.alert('Ingrese un monto válido a abonar.', 'Monto Inválido', 'warning');
      return;
    }

    registerAccountPayment(
      selectedAccountForPayment.id,
      amount,
      paymentMethod,
      paymentConcept.trim() || `Cobro / Abono a cuenta corriente`
    );

    setSelectedAccountForPayment(null);
    setPaymentAmount('');
    setPaymentConcept('');
  };

  const accountHistoryMovements = selectedAccountForHistory
    ? accountMovements.filter(m => m.accountId === selectedAccountForHistory.id)
    : [];

  const handleViewMovementDetail = (m: AccountMovement, account: CurrentAccount) => {
    // 1. Check if linked to sale
    if (m.referenceId) {
      const sale = sales.find(s => s.id === m.referenceId || s.receiptNumber === m.referenceId);
      if (sale) {
        setSelectedOperationDetail({
          type: 'SALE',
          title: `Detalle de Venta Facturada #${sale.receiptNumber}`,
          receiptNumber: sale.receiptNumber,
          partyName: account.name,
          timestamp: sale.timestamp,
          userName: sale.userName,
          paymentMethod: sale.paymentMethod,
          items: sale.items.map(i => ({
            name: i.name,
            quantity: i.quantity,
            unitPrice: i.unitPrice,
            total: i.total,
          })),
          subtotal: sale.subtotal,
          discount: sale.discount,
          total: sale.total,
        });
        return;
      }

      const purchase = purchases.find(p => p.id === m.referenceId || p.invoiceNumber === m.referenceId);
      if (purchase) {
        setSelectedOperationDetail({
          type: 'PURCHASE',
          title: `Detalle de Factura de Compra #${purchase.invoiceNumber}`,
          receiptNumber: purchase.invoiceNumber,
          partyName: purchase.supplierName || account.name,
          timestamp: purchase.timestamp,
          userName: purchase.userName,
          paymentMethod: purchase.paymentMethod,
          items: purchase.items.map(i => ({
            name: i.name,
            quantity: i.quantity,
            unitPrice: i.costPrice,
            total: i.total,
          })),
          subtotal: purchase.total,
          total: purchase.total,
        });
        return;
      }
    }

    // 2. Fallback search by client/supplier in sales/purchases or direct payment
    const possibleSale = sales.find(s => s.clientId === account.id && Math.abs(s.total - m.amount) < 1);
    if (possibleSale && m.type === 'DEBIT') {
      setSelectedOperationDetail({
        type: 'SALE',
        title: `Detalle de Venta Facturada #${possibleSale.receiptNumber}`,
        receiptNumber: possibleSale.receiptNumber,
        partyName: account.name,
        timestamp: possibleSale.timestamp,
        userName: possibleSale.userName,
        paymentMethod: possibleSale.paymentMethod,
        items: possibleSale.items.map(i => ({
          name: i.name,
          quantity: i.quantity,
          unitPrice: i.unitPrice,
          total: i.total,
        })),
        subtotal: possibleSale.subtotal,
        discount: possibleSale.discount,
        total: possibleSale.total,
      });
      return;
    }

    setSelectedOperationDetail({
      type: 'PAYMENT',
      title: m.type === 'DEBIT' ? 'Operación de Cargo / Compra en Cuenta' : 'Comprobante de Abono / Pago a Cuenta',
      partyName: account.name,
      timestamp: m.timestamp,
      userName: m.userName,
      paymentMethod: m.paymentMethod,
      concept: m.concept,
      total: m.amount,
    });
  };

  const handleExportAccounts = (format: 'EXCEL' | 'CSV') => {
    const list = accounts.filter(a => a.type === activeTab);
    if (list.length === 0) {
      DialogService.alert(`No hay cuentas de ${activeTab === 'CLIENT' ? 'clientes' : 'proveedores'} para exportar.`, 'Exportar Cuentas Corrientes', 'info');
      return;
    }

    const exportData = list.map((acc) => {
      const movs = accountMovements.filter(m => m.accountId === acc.id);
      const totalDebits = movs.filter(m => m.type === 'DEBIT').reduce((s, m) => s + m.amount, 0);
      const totalCredits = movs.filter(m => m.type === 'CREDIT').reduce((s, m) => s + m.amount, 0);
      const lastMov = movs[0];
      const dateFormatted = lastMov ? lastMov.timestamp.slice(0, 10) : acc.updatedAt.slice(0, 10);

      return {
        FECHA: dateFormatted,
        NOMBRE: acc.name,
        FACTURA: acc.documentNumber || '',
        TOTAL: totalDebits || acc.currentBalance,
        PAGADO: totalCredits,
        SALDO: acc.currentBalance,
        TIPO: acc.type === 'CLIENT' ? 'CLIENTE' : 'PROVEEDOR',
        TELEFONO: acc.phone || '',
        EMAIL: acc.email || '',
      };
    });

    const dateStr = new Date().toISOString().slice(0, 10);
    const fileName = `cuentas_corrientes_${activeTab.toLowerCase()}_${dateStr}`;

    if (format === 'EXCEL') {
      exportToExcel(exportData, fileName, activeTab === 'CLIENT' ? 'Clientes' : 'Proveedores');
    } else {
      exportToCsv(exportData, fileName, ';');
    }

    DialogService.alert(
      `Se exportaron ${exportData.length} cuentas de ${activeTab === 'CLIENT' ? 'clientes' : 'proveedores'} en formato ${format === 'EXCEL' ? 'Excel (.xlsx)' : 'CSV (.csv)'} correctamente.`,
      'Exportación Exitosa',
      'success'
    );
  };

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-6 space-y-4 w-full">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-neutral-200">
        <div>
          <h2 className="text-lg font-bold text-neutral-900 tracking-tight">Cuentas Corrientes</h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Control de fiados, créditos a clientes y saldos pendientes con proveedores
          </p>
        </div>

        {canManage && (
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setImportModalMode('CSV')}
              className="px-3 py-2 bg-amber-700 hover:bg-amber-800 active:scale-95 text-white rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
              title="Importar cuentas corrientes desde archivo CSV (.csv)"
            >
              <FileText className="w-4 h-4 text-amber-300" />
              <span>Importar CSV</span>
            </button>

            <button
              type="button"
              onClick={() => setImportModalMode('EXCEL')}
              className="px-3 py-2 bg-orange-700 hover:bg-orange-800 active:scale-95 text-white rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
              title="Importar cuentas corrientes desde planilla Excel (.xlsx / .xls)"
            >
              <FileSpreadsheet className="w-4 h-4 text-orange-300" />
              <span>Importar Excel</span>
            </button>

            <button
              type="button"
              onClick={() => handleExportAccounts('EXCEL')}
              className="px-3 py-2 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 border border-neutral-300 dark:border-neutral-600 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
              title="Exportar cuentas a Excel (.xlsx)"
            >
              <Download className="w-4 h-4 text-emerald-600" />
              <span>Exportar Excel</span>
            </button>

            <button
              type="button"
              onClick={handleOpenAddModal}
              className="primary-action-dark-white px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Nueva Cuenta ({activeTab === 'CLIENT' ? 'Cliente' : 'Proveedor'})</span>
            </button>
          </div>
        )}
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="p-4 bg-white rounded-xl border border-neutral-200 flex items-center justify-between">
          <div>
            <span className="text-[11px] uppercase tracking-wider text-neutral-500 font-semibold">
              Total a Cobrar (Fiados / Clientes)
            </span>
            <div className="text-2xl font-black font-mono text-amber-600 mt-0.5">
              ${formatThousands(totalOwedByClients)}
            </div>
            <p className="text-[11px] text-neutral-400 mt-0.5">Saldos pendientes de cobro</p>
          </div>
          <div className="p-3 bg-amber-50 rounded-xl text-amber-600">
            <ArrowDownLeft className="w-6 h-6" />
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-neutral-200 flex items-center justify-between">
          <div>
            <span className="text-[11px] uppercase tracking-wider text-neutral-500 font-semibold">
              Total a Pagar (Proveedores)
            </span>
            <div className="text-2xl font-black font-mono text-neutral-900 mt-0.5">
              ${formatThousands(totalOwedToSuppliers)}
            </div>
            <p className="text-[11px] text-neutral-400 mt-0.5">Deuda con mayoristas y distribuidores</p>
          </div>
          <div className="p-3 bg-neutral-100 rounded-xl text-neutral-700">
            <Building className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Tabs & Search */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="flex bg-neutral-200 dark:bg-neutral-800 p-1 rounded-xl w-full sm:w-auto border border-neutral-300 dark:border-neutral-700">
          <button
            type="button"
            onClick={() => setActiveTab('CLIENT')}
            className={`flex-1 sm:flex-none px-5 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'CLIENT'
                ? 'bg-white dark:bg-neutral-900 border-2 border-emerald-500 dark:border-emerald-400 shadow-xs ring-2 ring-emerald-500/20'
                : 'text-neutral-700 dark:text-neutral-300 hover:text-neutral-950 dark:hover:text-white border-2 border-transparent'
            }`}
          >
            {activeTab === 'CLIENT' && (
              <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0 animate-pulse" />
            )}
            <span
              className={
                activeTab === 'CLIENT'
                  ? 'text-emerald-600 dark:text-emerald-400 !text-emerald-600 dark:!text-emerald-400 font-extrabold tracking-tight'
                  : ''
              }
            >
              Clientes (A Cobrar)
            </span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('SUPPLIER')}
            className={`flex-1 sm:flex-none px-5 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'SUPPLIER'
                ? 'bg-white dark:bg-neutral-900 border-2 border-emerald-500 dark:border-emerald-400 shadow-xs ring-2 ring-emerald-500/20'
                : 'text-neutral-700 dark:text-neutral-300 hover:text-neutral-950 dark:hover:text-white border-2 border-transparent'
            }`}
          >
            {activeTab === 'SUPPLIER' && (
              <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0 animate-pulse" />
            )}
            <span
              className={
                activeTab === 'SUPPLIER'
                  ? 'text-emerald-600 dark:text-emerald-400 !text-emerald-600 dark:!text-emerald-400 font-extrabold tracking-tight'
                  : ''
              }
            >
              Proveedores (A Pagar)
            </span>
          </button>
        </div>

        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-neutral-400" />
          <input
            type="text"
            placeholder="Buscar por nombre, CUIT/DNI o teléfono..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-white border border-neutral-200 rounded-lg text-xs focus:outline-hidden focus:ring-2 focus:ring-neutral-900"
          />
        </div>
      </div>

      {/* Accounts List */}
      <div className="bg-white border border-neutral-200 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-500 font-semibold uppercase tracking-wider">
              <tr>
                <th className="px-4 py-3">Nombre / Razón Social</th>
                <th className="px-4 py-3">DNI / CUIT</th>
                <th className="px-4 py-3">Contacto</th>
                <th className="px-4 py-3 text-right">Límite Crédito</th>
                <th className="px-4 py-3 text-right">Saldo Actual</th>
                <th className="px-4 py-3 text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100">
              {filteredAccounts.map((account) => {
                const isOverLimit = account.currentBalance > account.creditLimit;

                return (
                  <tr key={account.id} className="hover:bg-neutral-50/80 transition-colors">
                    <td className="px-4 py-3">
                      <div className="font-bold text-neutral-900 text-sm">{account.name}</div>
                      <span className="text-[10px] text-neutral-400">
                        Actualizado: {new Date(account.updatedAt).toLocaleDateString()}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-mono text-neutral-600">
                      {account.documentNumber || '-'}
                    </td>
                    <td className="px-4 py-3 text-neutral-600 space-y-0.5">
                      {account.phone && (
                        <div className="flex items-center gap-1 text-[11px]">
                          <Phone className="w-3 h-3 text-neutral-400" />
                          {account.phone}
                        </div>
                      )}
                      {account.email && (
                        <div className="flex items-center gap-1 text-[11px] text-neutral-400">
                          <Mail className="w-3 h-3" />
                          {account.email}
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right font-mono text-neutral-500">
                      ${formatThousands(account.creditLimit)}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className={`font-mono font-bold text-sm ${
                        account.currentBalance > 0
                          ? 'text-amber-600'
                          : 'text-emerald-700'
                      }`}>
                        ${formatThousands(account.currentBalance)}
                      </div>
                      {isOverLimit && (
                        <span className="text-[9px] text-rose-600 font-bold uppercase tracking-wider block">
                          Superó Límite
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => setSelectedAccountForHistory(account)}
                          className="px-2.5 py-1.5 border border-neutral-300 dark:border-neutral-600 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-lg text-neutral-800 dark:text-neutral-200 font-bold text-xs flex items-center gap-1.5 shadow-2xs transition-colors"
                          title="Ver detalle de compras, pagos y movimientos de esta cuenta"
                        >
                          <Eye className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                          <span>Ver Operaciones</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedAccountForPayment(account);
                            setPaymentAmount(account.currentBalance > 0 ? formatThousands(account.currentBalance) : '');
                          }}
                          className="px-3 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-xs"
                        >
                          <DollarSign className="w-3.5 h-3.5" />
                          {account.type === 'CLIENT' ? 'Cobrar / Abonar' : 'Pagar'}
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}

              {filteredAccounts.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-neutral-400">
                    No hay cuentas registradas en esta categoría.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* REGISTER PAYMENT / ABONO MODAL */}
      {selectedAccountForPayment && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full overflow-hidden shadow-2xl border border-neutral-200">
            <div className="p-4 border-b border-neutral-100 flex items-center justify-between bg-neutral-50">
              <h3 className="font-bold text-sm text-neutral-900">
                Registrar Cobro / Abono a Cuenta
              </h3>
              <button
                type="button"
                onClick={() => setSelectedAccountForPayment(null)}
                className="text-neutral-400 hover:text-neutral-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRegisterPaymentSubmit} className="p-5 space-y-4 text-xs">
              <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200">
                <div className="font-bold text-neutral-900 text-sm">
                  {selectedAccountForPayment.name}
                </div>
                <div className="flex justify-between mt-1 text-neutral-600">
                  <span>Saldo deudor actual:</span>
                  <span className="font-mono font-bold text-amber-600 text-sm">
                    ${formatThousands(selectedAccountForPayment.currentBalance)}
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                  Monto a Abonar
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  required
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(formatThousands(e.target.value))}
                  placeholder="0"
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg font-mono text-base font-bold focus:ring-2 focus:ring-neutral-900"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                  Medio de Pago Recibido
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['EFECTIVO', 'TRANSFERENCIA', 'MERCADO_PAGO_QR'] as PaymentMethod[]).map(m => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setPaymentMethod(m)}
                      className={`p-2 rounded-lg border text-center font-medium transition-colors ${
                        paymentMethod === m
                          ? 'bg-neutral-900 text-white border-neutral-900'
                          : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-50'
                      }`}
                    >
                      {m === 'EFECTIVO' ? 'Efectivo' : m === 'TRANSFERENCIA' ? 'Transf.' : 'Mercado Pago'}
                    </button>
                  ))}
                </div>
                {paymentMethod === 'EFECTIVO' && (
                  <p className="text-[10px] text-emerald-600 mt-1">
                    ✓ Ingresará automáticamente al arqueo de caja del turno actual.
                  </p>
                )}
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                  Concepto / Observaciones
                </label>
                <input
                  type="text"
                  value={paymentConcept}
                  onChange={(e) => setPaymentConcept(e.target.value)}
                  placeholder="Ej: Pago parcial de mercadería, entrega a cuenta"
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setSelectedAccountForPayment(null)}
                  className="px-3 py-2 border border-neutral-300 rounded-lg font-medium text-neutral-700"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-neutral-900 text-white rounded-lg font-bold uppercase tracking-wider"
                >
                  Confirmar Abono
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ACCOUNT HISTORY MODAL */}
      {selectedAccountForHistory && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-2xl w-full overflow-hidden shadow-2xl border border-neutral-200 max-h-[85vh] flex flex-col">
            <div className="p-4 border-b border-neutral-100 flex items-center justify-between bg-neutral-50">
              <div>
                <h3 className="font-bold text-sm text-neutral-900">
                  Extracto de Cuenta: {selectedAccountForHistory.name}
                </h3>
                <span className="text-xs text-neutral-500">
                  Saldo actual: ${formatThousands(selectedAccountForHistory.currentBalance)}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setSelectedAccountForHistory(null)}
                className="text-neutral-400 hover:text-neutral-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto flex-1">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-500 font-semibold uppercase tracking-wider text-[11px]">
                  <tr>
                    <th className="p-2.5">Fecha & Hora</th>
                    <th className="p-2.5">Tipo</th>
                    <th className="p-2.5">Concepto</th>
                    <th className="p-2.5">Medio</th>
                    <th className="p-2.5 text-right">Monto</th>
                    <th className="p-2.5">Cajero</th>
                    <th className="p-2.5 text-center">Ver</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {accountHistoryMovements.map(m => (
                    <tr key={m.id}>
                      <td className="p-2.5 font-mono text-neutral-600 whitespace-nowrap">
                        {new Date(m.timestamp).toLocaleDateString()} {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </td>
                      <td className="p-2.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          m.type === 'DEBIT'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}>
                          {m.type === 'DEBIT' ? 'Cargo / Deuda' : 'Abono / Pago'}
                        </span>
                      </td>
                      <td className="p-2.5 font-medium text-neutral-800">{m.concept}</td>
                      <td className="p-2.5 text-neutral-500">{m.paymentMethod || '-'}</td>
                      <td className={`p-2.5 text-right font-mono font-bold ${
                        m.type === 'DEBIT' ? 'text-amber-600' : 'text-emerald-600'
                      }`}>
                        {m.type === 'DEBIT' ? `+$${formatThousands(m.amount)}` : `-$${formatThousands(m.amount)}`}
                      </td>
                      <td className="p-2.5 text-neutral-500">{m.userName}</td>
                      <td className="p-2.5 text-center">
                        <button
                          type="button"
                          onClick={() => handleViewMovementDetail(m, selectedAccountForHistory)}
                          className="p-1 text-neutral-500 hover:text-indigo-600 hover:bg-neutral-100 rounded-lg transition-colors"
                          title="Ver comprobante / detalle de la operación con el ojito"
                        >
                          <Eye className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                        </button>
                      </td>
                    </tr>
                  ))}

                  {accountHistoryMovements.length === 0 && (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-neutral-400">
                        No hay movimientos registrados para esta cuenta.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="p-3 border-t border-neutral-100 bg-neutral-50 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedAccountForHistory(null)}
                className="px-4 py-1.5 bg-neutral-900 text-white rounded text-xs font-bold"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* OPERATION DETAIL MODAL (OJITO VIEW) */}
      {selectedOperationDetail && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-60 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-neutral-900 rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-neutral-200 dark:border-neutral-700 flex flex-col max-h-[85vh] animate-in fade-in zoom-in-95">
            <div className="p-4 bg-neutral-900 text-white flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-white">{selectedOperationDetail.title}</h3>
                <p className="text-[11px] text-neutral-400">{selectedOperationDetail.partyName}</p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedOperationDetail(null)}
                className="text-neutral-400 hover:text-white p-1 rounded-lg hover:bg-neutral-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2 p-3 bg-neutral-50 dark:bg-neutral-800/60 rounded-xl border border-neutral-200 dark:border-neutral-700 text-[11px]">
                <div>
                  <span className="text-neutral-500 block">Titular</span>
                  <span className="font-bold text-neutral-900 dark:text-white">{selectedOperationDetail.partyName}</span>
                </div>
                <div>
                  <span className="text-neutral-500 block">Fecha y Hora</span>
                  <span className="text-neutral-800 dark:text-neutral-200">{new Date(selectedOperationDetail.timestamp).toLocaleString()}</span>
                </div>
                <div>
                  <span className="text-neutral-500 block">Operador</span>
                  <span className="text-neutral-800 dark:text-neutral-200">{selectedOperationDetail.userName}</span>
                </div>
                <div>
                  <span className="text-neutral-500 block">Medio</span>
                  <span className="text-neutral-800 dark:text-neutral-200">{selectedOperationDetail.paymentMethod || 'Cuenta Corriente'}</span>
                </div>
              </div>

              {selectedOperationDetail.items && selectedOperationDetail.items.length > 0 ? (
                <div>
                  <h4 className="font-bold text-neutral-800 dark:text-neutral-200 mb-1 uppercase text-[10px] tracking-wider">
                    Artículos Asociados ({selectedOperationDetail.items.length})
                  </h4>
                  <div className="border border-neutral-200 dark:border-neutral-700 rounded-xl overflow-hidden">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 font-semibold text-[10px] uppercase">
                        <tr>
                          <th className="p-2">Cant.</th>
                          <th className="p-2">Artículo</th>
                          <th className="p-2 text-right">Precio</th>
                          <th className="p-2 text-right">Total</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-neutral-200 dark:divide-neutral-700">
                        {selectedOperationDetail.items.map((it, idx) => (
                          <tr key={idx} className="hover:bg-neutral-50 dark:hover:bg-neutral-800/40">
                            <td className="p-2 font-mono font-bold text-neutral-900 dark:text-white">{it.quantity}x</td>
                            <td className="p-2 text-neutral-800 dark:text-neutral-200">{it.name}</td>
                            <td className="p-2 text-right font-mono text-neutral-600 dark:text-neutral-400">${formatThousands(it.unitPrice)}</td>
                            <td className="p-2 text-right font-mono font-bold text-neutral-900 dark:text-white">${formatThousands(it.total)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ) : (
                <div className="p-3 bg-neutral-100 dark:bg-neutral-800/60 rounded-xl text-neutral-600 dark:text-neutral-300 text-xs">
                  {selectedOperationDetail.concept || 'Movimiento directo de pago o ajuste de cuenta.'}
                </div>
              )}

              <div className="p-3 bg-neutral-50 dark:bg-neutral-800/50 rounded-xl border border-neutral-200 dark:border-neutral-700 flex justify-between items-center text-sm font-bold text-neutral-900 dark:text-white">
                <span>IMPORTE TOTAL:</span>
                <span className="font-mono text-base font-black text-indigo-600 dark:text-indigo-400">
                  ${formatThousands(selectedOperationDetail.total)}
                </span>
              </div>
            </div>

            <div className="p-3 border-t border-neutral-100 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedOperationDetail(null)}
                className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-xs font-bold"
              >
                Cerrar Detalle
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CREATE NEW ACCOUNT MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full overflow-hidden shadow-2xl border border-neutral-200">
            <div className="p-4 border-b border-neutral-100 flex items-center justify-between bg-neutral-50">
              <h3 className="font-bold text-sm text-neutral-900">
                Crear Cuenta Corriente ({activeTab === 'CLIENT' ? 'Cliente' : 'Proveedor'})
              </h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-neutral-400 hover:text-neutral-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateAccount} className="p-5 space-y-3 text-xs">
              <div>
                <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                  Nombre Completo / Razón Social
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ej: Panadería San Martín"
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                  DNI / CUIT
                </label>
                <input
                  type="text"
                  value={documentNumber}
                  onChange={(e) => setDocumentNumber(e.target.value)}
                  placeholder="Ej: 30-71829481-2"
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                  Teléfono / WhatsApp
                </label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="Ej: +54 9 11 2345-6789"
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                  Email (Opcional)
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="contacto@cliente.com"
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                  Límite de Crédito Autorizado
                </label>
                <input
                  type="text"
                  inputMode="decimal"
                  value={creditLimitStr}
                  onChange={(e) => setCreditLimitStr(formatThousands(e.target.value))}
                  placeholder="0"
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg text-xs font-mono font-bold focus:outline-hidden focus:ring-2 focus:ring-neutral-900"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-2 border border-neutral-300 rounded-lg text-neutral-700 font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-bold uppercase tracking-wider"
                >
                  Crear Cuenta
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ACCOUNTS IMPORT MODAL (CSV / EXCEL) */}
      {importModalMode !== null && (
        <AccountsImportModal
          isOpen={true}
          mode={importModalMode}
          accountType={activeTab}
          onClose={() => setImportModalMode(null)}
          onImportComplete={(count, totalBalance) => {
            reloadAllFromStorage();
            DialogService.alert(
              `¡Se importaron ${formatThousands(count)} cuentas corrientes con un saldo total de $${formatThousands(totalBalance)} exitosamente!`,
              'Importación Exitosa',
              'success'
            );
          }}
        />
      )}
    </div>
  );
};
