import React, { useState } from 'react';
import { 
  Users, 
  UserPlus, 
  ShieldCheck, 
  ShieldAlert, 
  Key, 
  Check, 
  X, 
  UserCheck, 
  Power, 
  Edit3, 
  Lock,
  Sparkles,
  Trash2
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { User, UserRole, UserPermissions } from '../../types';
import { DialogService } from '../../services/dialog';
import { StorageService } from '../../services/storage';

export const UsersModule: React.FC = () => {
  const { 
    currentUser, 
    users, 
    loginAs, 
    createUser, 
    updateUser, 
    toggleUserStatus, 
    deleteUser,
    canManageRole 
  } = useAuth();

  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  // Form state
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('CASHIER');
  const [permissions, setPermissions] = useState<UserPermissions>({
    canMakeSales: true,
    canMakePurchases: false,
    canManageInventory: false,
    canManageAccounts: false,
    canCloseCashRegister: true,
    canViewHistory: false,
    canManageUsers: false,
    canGiveDiscounts: false,
    canManageSettings: false,
  });

  // Password verification modal for switching user
  const [challengeUser, setChallengeUser] = useState<User | null>(null);
  const [challengePasswordInput, setChallengePasswordInput] = useState('');
  const [challengeError, setChallengeError] = useState('');

  const isSuperAdmin = currentUser.role === 'SUPER_ADMIN';
  const isOwner = currentUser.role === 'OWNER';
  const canCreateAnyUser = isSuperAdmin || isOwner;

  const handleOpenCreate = () => {
    setName('');
    setUsername('');
    setPassword('');
    setRole('CASHIER');
    setPermissions({
      canMakeSales: true,
      canMakePurchases: false,
      canManageInventory: false,
      canManageAccounts: true,
      canCloseCashRegister: true,
      canViewHistory: false,
      canManageUsers: false,
      canGiveDiscounts: false,
      canManageSettings: false,
    });
    setEditingUser(null);
    setShowCreateModal(true);
  };

  const handleOpenEdit = (user: User) => {
    setEditingUser(user);
    setName(user.name);
    setUsername(user.username || '');
    setPassword(user.password || '');
    setRole(user.role);
    setPermissions({
      ...user.permissions,
      canManageSettings: Boolean(user.permissions.canManageSettings),
    });
    setShowCreateModal(true);
  };

  const handleTogglePermission = (key: keyof UserPermissions) => {
    setPermissions(prev => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !username.trim() || !password.trim()) {
      DialogService.alert('Por favor complete todos los campos requeridos: Nombre, Usuario y Contraseña.', 'Campos Incompletos', 'warning');
      return;
    }

    const cleanUsername = username.trim().toLowerCase().replace(/\s+/g, '');

    // Check if username already exists for another user
    const existing = users.find(u => u.username?.toLowerCase() === cleanUsername && u.id !== editingUser?.id);
    if (existing) {
      DialogService.alert(`El nombre de usuario "${cleanUsername}" ya está en uso. Por favor elija otro nombre de usuario.`, 'Usuario Duplicado', 'warning');
      return;
    }

    if (editingUser) {
      const res = updateUser({
        ...editingUser,
        name: name.trim(),
        username: cleanUsername,
        password: password.trim(),
        role,
        permissions,
      });
      if (!res.success) {
        DialogService.alert(res.message || 'Error al actualizar usuario', 'Error', 'error');
        return;
      }
    } else {
      const res = createUser({
        name: name.trim(),
        username: cleanUsername,
        password: password.trim(),
        role,
        active: true,
        permissions,
        avatarColor: role === 'SUPER_ADMIN' ? 'bg-indigo-600' : role === 'OWNER' ? 'bg-emerald-600' : role === 'ADMIN' ? 'bg-amber-600' : 'bg-sky-600',
      });
      if (!res.success) {
        DialogService.alert(res.message || 'Error al crear usuario', 'Error', 'error');
        return;
      }
    }

    setShowCreateModal(false);
  };

  const handleStartLoginChallenge = (user: User) => {
    setChallengeUser(user);
    setChallengePasswordInput('');
    setChallengeError('');
  };

  const handleConfirmLoginChallenge = (e: React.FormEvent) => {
    e.preventDefault();
    if (!challengeUser) return;

    if (challengeUser.password !== challengePasswordInput) {
      setChallengeError('Contraseña incorrecta. Verifique la clave e intente nuevamente.');
      return;
    }

    const res = loginAs(challengeUser);
    if (res && !res.success) {
      setChallengeError(res.message || 'Error al iniciar sesión');
      return;
    }

    setChallengeUser(null);
  };

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-6 space-y-4 w-full">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-neutral-200">
        <div>
          <h2 className="text-lg font-bold text-neutral-900 tracking-tight">Gestión de Usuarios & Permisos</h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Jerarquía de acceso: Super Administrador, Dueños, Administradores y Cajeros con permisos granulares
          </p>
        </div>

        {canCreateAnyUser && (
          <button
            type="button"
            onClick={handleOpenCreate}
            className="primary-action-dark-white px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <UserPlus className="w-4 h-4" />
            Crear Usuario
          </button>
        )}
      </div>

      {/* Role Hierarchy Explanation Box */}
      <div className="p-4 bg-neutral-900 text-white rounded-xl grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
        <div className="space-y-1">
          <div className="font-bold flex items-center gap-1 text-indigo-300">
            <ShieldCheck className="w-3.5 h-3.5" />
            Super Administrador
          </div>
          <p className="text-[11px] text-neutral-400">
            Control total del sistema comercial, base de datos, activación/desactivación de cualquier cuenta y auditorías globales.
          </p>
        </div>

        <div className="space-y-1">
          <div className="font-bold flex items-center gap-1 text-emerald-300">
            <ShieldCheck className="w-3.5 h-3.5" />
            Dueño / Propietario
          </div>
          <p className="text-[11px] text-neutral-400">
            Crea y administra administradores y cajeros, define permisos comerciales y tiene acceso a métricas y balances.
          </p>
        </div>

        <div className="space-y-1">
          <div className="font-bold flex items-center gap-1 text-amber-300">
            <Key className="w-3.5 h-3.5" />
            Administrador
          </div>
          <p className="text-[11px] text-neutral-400">
            Encargado de compras, altas de stock, cuentas corrientes y supervisión de turnos de caja en la sucursal.
          </p>
        </div>

        <div className="space-y-1">
          <div className="font-bold flex items-center gap-1 text-sky-300">
            <UserCheck className="w-3.5 h-3.5" />
            Cajero / Vendedor
          </div>
          <p className="text-[11px] text-neutral-400">
            Operación rápida del punto de venta con lectora de código de barra, cobro en efectivo, MP y cierre de su propio turno.
          </p>
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-white border border-neutral-200 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-500 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="px-4 py-3">Usuario</th>
                <th className="px-4 py-3">Rol</th>
                {isSuperAdmin && <th className="px-4 py-3">Contraseña / PIN</th>}
                <th className="px-4 py-3">Estado</th>
                <th className="px-4 py-3">Permisos Habilitados</th>
                <th className="px-4 py-3 text-center">Simular Login</th>
                <th className="px-4 py-3 text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100">
              {users.map((user) => {
                const isCurrent = user.id === currentUser.id;
                const canManageThisUser = canManageRole(user.role);

                return (
                  <tr key={user.id} className={`hover:bg-neutral-50/80 transition-colors ${!user.active ? 'opacity-60 bg-neutral-50/40' : ''}`}>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-full text-white flex items-center justify-center font-bold text-xs ${user.avatarColor || 'bg-neutral-700'}`}>
                          {user.name.slice(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <div className="font-bold text-neutral-900 flex items-center gap-1.5">
                            {user.name}
                            {isCurrent && (
                              <span className="text-[9px] px-1.5 py-0.2 bg-neutral-900 text-white rounded font-bold">
                                Tú
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-neutral-400 font-mono">{user.username || 'usuario'}</span>
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <span className={`inline-block px-2.5 py-0.5 rounded text-[11px] font-bold ${
                        user.role === 'SUPER_ADMIN'
                          ? 'bg-indigo-100 text-indigo-800'
                          : user.role === 'OWNER'
                          ? 'bg-emerald-100 text-emerald-800'
                          : user.role === 'ADMIN'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-sky-100 text-sky-800'
                      }`}>
                        {user.role === 'SUPER_ADMIN' ? 'Super Administrador' : user.role === 'OWNER' ? 'Dueño' : user.role === 'ADMIN' ? 'Administrador' : 'Cajero'}
                      </span>
                    </td>

                    {isSuperAdmin && (
                      <td className="px-4 py-3">
                        <span className="font-mono text-neutral-800 select-all">{user.password || StorageService.getUsers().find(storedUser => storedUser.id === user.id)?.password || 'No disponible'}</span>
                      </td>
                    )}

                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                        user.active 
                          ? 'bg-emerald-50 text-emerald-700' 
                          : 'bg-rose-100 text-rose-700'
                      }`}>
                        {user.active ? 'Activo' : 'Desactivado'}
                      </span>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-1 max-w-sm">
                        {user.role === 'SUPER_ADMIN' ? (
                          <span className="text-[10px] bg-neutral-100 px-2 py-0.5 rounded text-neutral-700 font-semibold">
                            Acceso Total Irrestricto
                          </span>
                        ) : (
                          <>
                            {user.permissions.canMakeSales && <span className="text-[9px] bg-neutral-100 px-1.5 py-0.5 rounded text-neutral-600">Ventas</span>}
                            {user.permissions.canMakePurchases && <span className="text-[9px] bg-neutral-100 px-1.5 py-0.5 rounded text-neutral-600">Compras</span>}
                            {user.permissions.canManageInventory && <span className="text-[9px] bg-neutral-100 px-1.5 py-0.5 rounded text-neutral-600">Stock</span>}
                            {user.permissions.canManageAccounts && <span className="text-[9px] bg-neutral-100 px-1.5 py-0.5 rounded text-neutral-600">Cta Cte</span>}
                            {user.permissions.canCloseCashRegister && <span className="text-[9px] bg-neutral-100 px-1.5 py-0.5 rounded text-neutral-600">Caja</span>}
                            {user.permissions.canManageUsers && <span className="text-[9px] bg-neutral-100 px-1.5 py-0.5 rounded text-neutral-600">Usuarios</span>}
                            {user.permissions.canGiveDiscounts && <span className="text-[9px] bg-neutral-100 px-1.5 py-0.5 rounded text-neutral-600">Descuentos</span>}
                            {user.permissions.canManageSettings && <span className="text-[9px] bg-neutral-100 px-1.5 py-0.5 rounded text-neutral-600">Configuración</span>}
                          </>
                        )}
                      </div>
                    </td>

                    <td className="px-4 py-3 text-center">
                      <button
                        type="button"
                        onClick={() => handleStartLoginChallenge(user)}
                        disabled={isCurrent || !user.active}
                        className="px-2.5 py-1 text-[11px] font-semibold rounded bg-neutral-100 hover:bg-neutral-200 text-neutral-800 disabled:opacity-30 transition-colors"
                      >
                        {isCurrent ? 'Sesión Actual' : 'Iniciar Como'}
                      </button>
                    </td>

                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        {canManageThisUser && (
                          <>
                            <button
                              type="button"
                              onClick={() => handleOpenEdit(user)}
                              className="p-1.5 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded-lg transition-colors"
                              title="Editar Usuario"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>

                            <button
                              type="button"
                              onClick={async () => {
                                const actionName = user.active ? 'desactivar' : 'activar';
                                const roleWarning = user.role === 'SUPER_ADMIN' 
                                  ? `¿Confirmas ${actionName} la cuenta del SUPER ADMINISTRADOR "${user.name}"?`
                                  : `¿Deseas ${actionName} la cuenta de "${user.name}"?`;
                                const ok = await DialogService.confirm(
                                  roleWarning,
                                  `${user.active ? 'Desactivar' : 'Activar'} Usuario`,
                                  `Sí, ${actionName}`,
                                  'Cancelar',
                                  user.active ? 'warning' : 'info'
                                );
                                if (ok) {
                                  const res = toggleUserStatus(user.id);
                                  if (res && !res.success) {
                                    DialogService.alert(res.message || 'Error al cambiar estado', 'Error', 'error');
                                  }
                                }
                              }}
                              className={`p-1.5 rounded-lg transition-colors ${
                                user.active 
                                  ? 'text-amber-600 hover:text-amber-800 hover:bg-amber-50' 
                                  : 'text-emerald-600 hover:text-emerald-800 hover:bg-emerald-50'
                              }`}
                              title={user.active ? 'Desactivar Cuenta' : 'Activar Cuenta'}
                            >
                              <Power className="w-3.5 h-3.5" />
                            </button>

                            <button
                              type="button"
                              onClick={async () => {
                                const confirmText = user.role === 'SUPER_ADMIN'
                                  ? `Estás a punto de eliminar al Super Administrador "${user.name}". Esta acción removerá su acceso por completo.`
                                  : user.role === 'ADMIN'
                                  ? `¿Confirmas eliminar al Administrador "${user.name}"? Esta acción borrará su acceso.`
                                  : `¿Estás seguro de eliminar permanentemente al usuario "${user.name}" (${user.role})?`;
                                const ok = await DialogService.confirm(
                                  confirmText,
                                  'Eliminar Usuario Definitivamente',
                                  'Sí, eliminar usuario',
                                  'Cancelar',
                                  'error'
                                );
                                if (ok) {
                                  const res = deleteUser(user.id);
                                  if (res && !res.success) {
                                    DialogService.alert(res.message || 'Error al eliminar usuario', 'Error', 'error');
                                  }
                                }
                              }}
                              className="p-1.5 rounded-lg text-rose-500 hover:text-rose-700 hover:bg-rose-50 transition-colors"
                              title="Eliminar Usuario Permanentemente"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE / EDIT USER MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-start sm:items-center justify-center p-2 sm:p-4 overflow-y-auto overscroll-contain">
          <div className="my-auto bg-neutral-900 rounded-xl max-w-md w-full overflow-hidden shadow-2xl border border-neutral-700 max-h-[calc(100dvh-1rem)] sm:max-h-[calc(100dvh-2rem)] min-h-0 flex flex-col">
            <div className="p-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950 flex-shrink-0">
              <h3 className="font-bold text-sm text-white">
                {editingUser ? 'Editar Usuario & Permisos' : 'Crear Nuevo Usuario'}
              </h3>
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveUser} className="p-5 space-y-4 text-xs overflow-y-auto overscroll-contain min-h-0">
              <div>
                <label className="block text-xs font-black text-white uppercase mb-1">
                  Nombre Completo
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ej: Marcelo Morales"
                  className="w-full px-3 py-2 bg-neutral-800 border-2 border-neutral-700 rounded-lg text-xs font-bold text-white placeholder:text-neutral-400 focus:outline-hidden focus:border-white"
                />
              </div>

              <div>
                <label className="block text-xs font-black text-white uppercase mb-1">
                  Nombre de Usuario (Acceso / Login)
                </label>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="ej: marcelo, cajero1"
                  className="w-full px-3 py-2 bg-neutral-800 border-2 border-neutral-700 rounded-lg text-xs font-mono font-bold text-white placeholder:text-neutral-400 focus:outline-hidden focus:border-white"
                />
              </div>

              <div>
                <label className="block text-xs font-black text-white uppercase mb-1">
                  Contraseña de Acceso (PIN / Clave)
                </label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Ingrese contraseña o PIN"
                  className="w-full px-3 py-2 bg-neutral-800 border-2 border-neutral-700 rounded-lg text-xs font-mono font-bold text-white placeholder:text-neutral-400 focus:outline-hidden focus:border-white"
                />
                <span className="text-[11px] text-neutral-400 font-medium mt-1 block">
                  Esta clave será requerida cada vez que se ingrese o cambie a este usuario.
                </span>
              </div>

              <div>
                <label className="block text-xs font-black text-white uppercase mb-1">
                  Rol del Usuario
                </label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as UserRole)}
                  className="w-full px-3 py-2 bg-neutral-800 border-2 border-neutral-700 rounded-lg text-xs font-bold text-white focus:outline-hidden focus:border-white"
                >
                  {isSuperAdmin && <option value="SUPER_ADMIN">SUPER_ADMIN (Control Absoluto)</option>}
                  {isSuperAdmin && <option value="OWNER">Dueño</option>}
                  <option value="ADMIN">ADMIN (Administrador de Sucursal)</option>
                  <option value="CASHIER">Cajero / Vendedor</option>
                </select>
              </div>

              {/* Granular permissions checkboxes */}
              {role !== 'SUPER_ADMIN' && (
                <div className="space-y-2 pt-2 border-t border-neutral-800">
                  <label className="block text-[11px] font-bold text-white uppercase">
                    Permisos Específicos
                  </label>
                  <div className="space-y-1.5">
                    {[
                      { key: 'canMakeSales', label: 'Cobrar y emitir tickets de ventas' },
                      { key: 'canMakePurchases', label: 'Registrar compras a proveedores' },
                      { key: 'canManageInventory', label: 'Editar precios y crear artículos' },
                      { key: 'canManageAccounts', label: 'Gestionar Cuentas Corrientes y cobrar abonos' },
                      { key: 'canCloseCashRegister', label: 'Efectuar arqueo y cierre de caja' },
                      { key: 'canViewHistory', label: 'Ver historial global y exportar reportes' },
                      { key: 'canGiveDiscounts', label: 'Autorizar descuentos especiales en caja' },
                      { key: 'canManageSettings', label: 'Configuración general y Datos de Cobro (QR MP, CBU, Billeteras)' },
                      ...(isSuperAdmin ? [{ key: 'canManageUsers', label: 'Crear y administrar otros usuarios' }] : []),
                    ].map(perm => (
                      <label key={perm.key} className="flex items-center gap-2 cursor-pointer text-white select-none">
                        <input
                          type="checkbox"
                          checked={Boolean(permissions[perm.key as keyof UserPermissions])}
                          onChange={() => handleTogglePermission(perm.key as keyof UserPermissions)}
                          className="rounded border-neutral-600 text-neutral-900 focus:ring-white"
                        />
                        <span>{perm.label}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-3 border-t border-neutral-800">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-3 py-2 border border-neutral-700 rounded text-neutral-300 hover:bg-neutral-800"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded font-bold uppercase tracking-wider transition-colors"
                >
                  Guardar Usuario
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PASSWORD VERIFICATION CHALLENGE MODAL */}
      {challengeUser && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-sm w-full overflow-hidden shadow-2xl border border-neutral-200 animate-in fade-in zoom-in-95">
            <div className="p-4 border-b border-neutral-100 flex items-center justify-between bg-neutral-50">
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-neutral-700" />
                <h3 className="font-bold text-sm text-neutral-900">
                  Verificar Identidad
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setChallengeUser(null)}
                className="text-neutral-400 hover:text-neutral-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleConfirmLoginChallenge} className="p-5 space-y-4 text-xs">
              <div className="flex items-center gap-3 p-3 bg-neutral-50 rounded-lg border border-neutral-200">
                <div className={`w-10 h-10 rounded-full text-white flex items-center justify-center font-bold text-sm ${challengeUser.avatarColor || 'bg-neutral-800'}`}>
                  {challengeUser.name.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <div className="font-bold text-neutral-900 text-sm">{challengeUser.name}</div>
                  <div className="text-neutral-500 font-mono text-[11px]">{challengeUser.username} • {challengeUser.role}</div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-black text-neutral-950 uppercase mb-1.5 text-center">
                  Ingrese Contraseña / PIN
                </label>
                <input
                  type="password"
                  autoFocus
                  required
                  value={challengePasswordInput}
                  onChange={(e) => {
                    setChallengePasswordInput(e.target.value);
                    setChallengeError('');
                  }}
                  placeholder="••••••••"
                  className="w-full px-3 py-2.5 bg-white border-2 border-neutral-400 rounded-xl text-lg text-center tracking-widest font-mono font-black text-neutral-950 placeholder:text-neutral-400 focus:outline-hidden focus:border-neutral-900 shadow-xs"
                />
                <span className="text-[11px] text-neutral-600 font-semibold mt-1.5 block text-center">
                  (Clave predeterminada: <strong className="text-neutral-950 font-black">123</strong>)
                </span>
              </div>

              {challengeError && (
                <div className="p-2.5 bg-rose-50 border-2 border-rose-300 rounded-xl text-rose-800 text-xs text-center font-bold">
                  {challengeError}
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setChallengeUser(null)}
                  className="flex-1 px-3 py-2.5 border-2 border-neutral-300 rounded-xl text-neutral-800 font-bold hover:bg-neutral-100 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl font-bold uppercase tracking-wider transition-colors shadow-xs"
                >
                  Acceder
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
