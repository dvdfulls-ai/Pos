// String and Number formatting utilities
// Provides accent-insensitive matching (diacritics removal) and thousands formatting

/**
 * Normalizes text by removing accents, tildes, and converting to lowercase
 * Example: "Café" -> "cafe", "LÁCTEOS" -> "lacteos", "Azúcar" -> "azucar"
 */
export function normalizeText(str: string | undefined | null): string {
  if (!str) return '';
  const s = str.toString().trim().toLowerCase();
  // Fast path: pure ASCII characters don't need expensive Unicode NFD normalization
  if (!/[^\x00-\x7F]/.test(s)) {
    return s;
  }
  return s
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

/**
 * Checks if target string includes query, ignoring accents and case
 */
export function matchesQuery(target: string | undefined | null, query: string | undefined | null): boolean {
  if (!query || !query.trim()) return true;
  if (!target) return false;
  return normalizeText(target).includes(normalizeText(query));
}

/**
 * Formats a number or string into thousands with commas
 * Example: 1200 -> "1,200", 1500000 -> "1,500,000", 1200.5 -> "1,200.5"
 */
export function formatThousands(val: string | number | undefined | null): string {
  if (val === '' || val === undefined || val === null) return '';
  const str = val.toString().replace(/,/g, '');
  const hasTrailingDot = str.endsWith('.');
  const parts = str.split('.');
  let integerDigits = parts[0].replace(/[^\d]/g, '');
  
  if (!integerDigits && parts.length === 1) return '';
  
  // Strip superfluous leading zeros (e.g. "01000" -> "1000", but keep "0")
  integerDigits = integerDigits.replace(/^0+(?=\d)/, '');
  
  const formattedInteger = integerDigits ? integerDigits.replace(/\B(?=(\d{3})+(?!\d))/g, ',') : '0';
  
  if (parts.length > 1) {
    const decimals = parts[1].replace(/[^\d]/g, '').slice(0, 2);
    return `${formattedInteger}.${decimals}`;
  }
  
  if (hasTrailingDot) {
    return `${formattedInteger}.`;
  }
  
  return formattedInteger;
}

/**
 * Parses a thousands-formatted string back to a number
 * Example: "1,200" -> 1200, "1,200.50" -> 1200.5
 */
export function parseFormattedNumber(val: string | number | undefined | null): number {
  if (typeof val === 'number') return isNaN(val) ? 0 : val;
  if (!val) return 0;
  const clean = val.toString().replace(/,/g, '').trim();
  const num = parseFloat(clean);
  return isNaN(num) ? 0 : num;
}

/**
 * Capitalizes the first letter of each word in a string, converting subsequent letters to lowercase.
 * Works seamlessly whether caps lock is enabled or disabled.
 * Example: "yerba mate taragüí" -> "Yerba Mate Taragüí"
 *          "YERBA MATE PLAYADITO" -> "Yerba Mate Playadito"
 *          "coca-cola zero 1.5l" -> "Coca-Cola Zero 1.5l"
 */
export function toTitleCase(str: string | undefined | null): string {
  if (!str) return '';
  return str
    .toLowerCase()
    .replace(/(?:^|[\s\-\/\(\)\[\],\.])(\p{L})/gu, (match, letter) => {
      return match.slice(0, -letter.length) + letter.toUpperCase();
    });
}

