import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole, UserPermissions } from '../types';
import { StorageService } from '../services/storage';
import { DialogService } from '../services/dialog';

interface AuthContextType {
  currentUser: User;
  users: User[];
  loginAs: (user: User, password?: string) => { success: boolean; message?: string };
  authenticateAndLogin: (userOrUsername: string | User, password: string) => { success: boolean; message?: string };
  logout: () => void;
  createUser: (userData: Omit<User, 'id'>) => { success: boolean; message?: string };
  updateUser: (user: User) => { success: boolean; message?: string };
  toggleUserStatus: (userId: string) => { success: boolean; message?: string };
  deleteUser: (userId: string) => { success: boolean; message?: string };
  hasPermission: (permission: keyof UserPermissions) => boolean;
  canManageRole: (targetRole: UserRole) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<User[]>(StorageService.getUsers());
  const [currentUser, setCurrentUser] = useState<User>(StorageService.getCurrentUser());

  useEffect(() => {
    // Listen to sync events from other tabs / storage
    const unsubscribe = StorageService.subscribeToSync((event) => {
      if (event.type === 'USERS_UPDATED' || event.type === 'SYSTEM_RESET') {
        const freshUsers = StorageService.getUsers();
        setUsers(freshUsers);
        const freshCurrent = StorageService.getCurrentUser();
        setCurrentUser(freshCurrent);
      }
    });
    return unsubscribe;
  }, []);

  const authenticateAndLogin = (userOrUsername: string | User, password: string) => {
    let targetUser: User | undefined;
    if (typeof userOrUsername === 'string') {
      targetUser = users.find(u => u.id === userOrUsername || u.username.toLowerCase() === userOrUsername.toLowerCase());
    } else {
      targetUser = users.find(u => u.id === userOrUsername.id);
    }

    if (!targetUser) {
      return { success: false, message: 'Usuario no encontrado en el sistema.' };
    }

    if (!targetUser.active) {
      return { success: false, message: 'Esta cuenta está desactivada. Comuníquese con el Administrador.' };
    }

    if (targetUser.password !== password) {
      return { success: false, message: 'Contraseña incorrecta. Verifique la clave ingresada.' };
    }

    setCurrentUser(targetUser);
    StorageService.setCurrentUser(targetUser);
    return { success: true };
  };

  const loginAs = (user: User, password?: string) => {
    if (!user.active) {
      DialogService.alert('Esta cuenta de usuario está desactivada. Por favor, comuníquese con un Administrador o Dueño.', 'Cuenta Desactivada', 'warning');
      return { success: false, message: 'Usuario desactivado' };
    }

    if (password !== undefined && user.password !== password) {
      return { success: false, message: 'Contraseña incorrecta.' };
    }

    setCurrentUser(user);
    StorageService.setCurrentUser(user);
    return { success: true };
  };

  const logout = () => {
    // Switch to first active user or keep current session
  };

  const hasPermission = (permission: keyof UserPermissions): boolean => {
    if (!currentUser.active) return false;
    if (currentUser.role === 'SUPER_ADMIN') return true;
    return Boolean(currentUser.permissions[permission]);
  };

  const canManageRole = (targetRole: UserRole): boolean => {
    if (currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'OWNER') return true;
    if (currentUser.role === 'ADMIN') return true;
    if (currentUser.permissions.canManageUsers) return true;
    return false;
  };

  const createUser = (userData: Omit<User, 'id'>) => {
    if (!canManageRole(userData.role)) {
      return { success: false, message: 'No tienes los privilegios necesarios para crear este tipo de rol.' };
    }

    const newUser: User = {
      ...userData,
      id: `usr_${Date.now()}`,
    };

    const updated = [...users, newUser];
    setUsers(updated);
    StorageService.saveUsers(updated);

    StorageService.addAuditLog({
      id: `aud_${Date.now()}`,
      module: 'USUARIOS',
      action: 'CREAR_USUARIO',
      description: `Usuario ${newUser.name} (${newUser.role}) creado por ${currentUser.name}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      terminalId: StorageService.getCurrentTerminalId(),
      timestamp: new Date().toISOString(),
    });

    return { success: true };
  };

  const updateUser = (userToUpdate: User) => {
    if (!canManageRole(userToUpdate.role) && userToUpdate.id !== currentUser.id) {
      return { success: false, message: 'No tienes permisos para modificar este rol.' };
    }

    const updated = users.map(u => u.id === userToUpdate.id ? userToUpdate : u);
    setUsers(updated);
    StorageService.saveUsers(updated);

    if (currentUser.id === userToUpdate.id) {
      setCurrentUser(userToUpdate);
      StorageService.setCurrentUser(userToUpdate);
    }

    StorageService.addAuditLog({
      id: `aud_${Date.now()}`,
      module: 'USUARIOS',
      action: 'MODIFICAR_USUARIO',
      description: `Usuario ${userToUpdate.name} actualizado por ${currentUser.name}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      terminalId: StorageService.getCurrentTerminalId(),
      timestamp: new Date().toISOString(),
    });

    return { success: true };
  };

  const toggleUserStatus = (userId: string) => {
    const target = users.find(u => u.id === userId);
    if (!target) return { success: false, message: 'Usuario no encontrado' };

    const newActive = !target.active;
    const updated = users.map(u => {
      if (u.id === userId) {
        return { ...u, active: newActive };
      }
      return u;
    });

    setUsers(updated);
    StorageService.saveUsers(updated);

    if (currentUser.id === userId) {
      const updatedCurrent = { ...currentUser, active: newActive };
      setCurrentUser(updatedCurrent);
      StorageService.setCurrentUser(updatedCurrent);
    }

    StorageService.addAuditLog({
      id: `aud_${Date.now()}`,
      module: 'USUARIOS',
      action: newActive ? 'ACTIVAR_USUARIO' : 'DESACTIVAR_USUARIO',
      description: `Usuario ${target.name} (${target.role}) ${newActive ? 'activado' : 'desactivado'} por ${currentUser.name}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      terminalId: StorageService.getCurrentTerminalId(),
      timestamp: new Date().toISOString(),
    });

    return { success: true, message: `Cuenta ${newActive ? 'activada' : 'desactivada'} correctamente` };
  };

  const deleteUser = (userId: string) => {
    const target = users.find(u => u.id === userId);
    if (!target) return { success: false, message: 'Usuario no encontrado' };

    let updated = users.filter(u => u.id !== userId);

    // If all users were deleted, create a fresh master Super Admin so the app always stays accessible
    if (updated.length === 0) {
      const fallbackUser: User = {
        id: 'usr_admin',
        name: 'Administrador Principal',
        username: 'admin',
        password: '123',
        role: 'SUPER_ADMIN',
        active: true,
        avatarColor: 'bg-neutral-900',
        permissions: {
          canMakeSales: true,
          canMakePurchases: true,
          canManageInventory: true,
          canManageAccounts: true,
          canCloseCashRegister: true,
          canViewHistory: true,
          canManageUsers: true,
          canGiveDiscounts: true,
          canManageSettings: true,
        }
      };
      updated = [fallbackUser];
    }

    setUsers(updated);
    StorageService.saveUsers(updated);

    if (currentUser.id === userId) {
      const nextUser = updated[0];
      setCurrentUser(nextUser);
      StorageService.setCurrentUser(nextUser);
    }

    StorageService.addAuditLog({
      id: `aud_${Date.now()}`,
      module: 'USUARIOS',
      action: 'ELIMINAR_USUARIO',
      description: `Usuario ${target.name} (${target.role}) eliminado del sistema por ${currentUser.name}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      terminalId: StorageService.getCurrentTerminalId(),
      timestamp: new Date().toISOString(),
    });

    return { success: true, message: `Usuario ${target.name} eliminado exitosamente` };
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        users,
        loginAs,
        authenticateAndLogin,
        logout,
        createUser,
        updateUser,
        toggleUserStatus,
        deleteUser,
        hasPermission,
        canManageRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
