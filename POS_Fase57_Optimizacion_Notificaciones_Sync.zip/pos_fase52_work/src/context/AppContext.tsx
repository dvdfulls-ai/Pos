import React, { createContext, useContext, useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { 
  Article, 
  Sale, 
  Purchase, 
  CurrentAccount, 
  AccountMovement, 
  CashShift, 
  CashMovement, 
  AuditLog, 
  Terminal,
  CartItem,
  PaymentMethod,
  ExternalServiceSale
} from '../types';
import { StorageService } from '../services/storage';
import { CloudSync, CloudSyncStatus } from '../services/cloudSync';
import { NetworkService } from '../services/network';
import { useAuth } from './AuthContext';

interface AppContextType {
  // Articles
  articles: Article[];
  addArticle: (article: Omit<Article, 'id' | 'updatedAt'>) => Article;
  updateArticle: (article: Article) => void;
  updateArticlesBatch: (updatedArticles: Article[], reason?: string) => void;
  deleteArticle: (articleId: string) => void;
  adjustStock: (articleId: string, delta: number) => void;

  // Cart & POS
  cart: CartItem[];
  addToCart: (article: Article, quantity?: number) => void;
  removeFromCart: (articleId: string) => void;
  updateCartQuantity: (articleId: string, quantity: number) => void;
  clearCart: () => void;
  loadCart: (items: CartItem[]) => void;
  cartSubtotal: number;
  cartTotal: number;
  processSale: (params: {
    paymentMethod: PaymentMethod;
    paymentDetails?: any;
    clientId?: string;
    clientName?: string;
    discount?: number;
    surcharge?: number;
  }) => { success: boolean; sale?: Sale; message?: string };

  // Purchases
  purchases: Purchase[];
  registerPurchase: (purchaseData: Omit<Purchase, 'id' | 'timestamp' | 'userId' | 'userName' | 'terminalId'>) => void;

  // Cuentas Corrientes
  accounts: CurrentAccount[];
  accountMovements: AccountMovement[];
  addAccount: (account: Omit<CurrentAccount, 'id' | 'updatedAt'>) => void;
  registerAccountPayment: (accountId: string, amount: number, paymentMethod: PaymentMethod, concept?: string) => void;

  // Cash Register / Cierre de Caja
  currentShift: CashShift | undefined;
  cashShifts: CashShift[];
  cashMovements: CashMovement[];
  externalServiceSales: ExternalServiceSale[];
  openCashShift: (initialCash: number) => void;
  closeCashShift: (declaredCash: number, notes?: string) => { shift: CashShift; difference: number };
  addCashExpenseOrIncome: (type: 'INCOME' | 'EXPENSE', amount: number, concept: string, paymentMethod: PaymentMethod) => void;
  addExternalServiceSale: (service: 'CLARO' | 'SAT' | 'EXTRAS', amount: number, notes?: string) => ExternalServiceSale;
  deleteExternalServiceSale: (id: string) => void;

  // History & Audits
  sales: Sale[];
  auditLogs: AuditLog[];

  // Terminal & Offline Sync
  currentTerminalId: string;
  setCurrentTerminalId: (id: string) => void;
  terminals: Terminal[];
  saveTerminalsList: (terminals: Terminal[]) => void;
  isOffline: boolean;
  toggleOfflineMode: () => void;
  pendingSyncCount: number;
  syncNow: () => void;
  cloudSyncStatus: CloudSyncStatus;
  networkToast: { show: boolean; status: 'online' | 'offline'; message: string } | null;
  dismissNetworkToast: () => void;
  reloadAllFromStorage: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

type SalesContextKeys =
  | 'articles' | 'addArticle' | 'adjustStock'
  | 'cart' | 'addToCart' | 'removeFromCart' | 'updateCartQuantity' | 'clearCart' | 'loadCart'
  | 'cartTotal' | 'processSale' | 'currentShift' | 'accounts' | 'currentTerminalId'
  | 'addExternalServiceSale' | 'sales';
type SalesContextType = Pick<AppContextType, SalesContextKeys>;
const SalesContext = createContext<SalesContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();

  // State
  const [articles, setArticles] = useState<Article[]>(StorageService.getArticles());
  const [sales, setSales] = useState<Sale[]>(StorageService.getSales());
  const [purchases, setPurchases] = useState<Purchase[]>(StorageService.getPurchases());
  const [accounts, setAccounts] = useState<CurrentAccount[]>(StorageService.getAccounts());
  const [accountMovements, setAccountMovements] = useState<AccountMovement[]>(StorageService.getAccountMovements());
  const [cashShifts, setCashShifts] = useState<CashShift[]>(StorageService.getCashShifts());
  const [cashMovements, setCashMovements] = useState<CashMovement[]>(StorageService.getCashMovements());
  const [externalServiceSales, setExternalServiceSales] = useState<ExternalServiceSale[]>(StorageService.getExternalServiceSales());
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(StorageService.getAuditLogs());
  const [terminals, setTerminals] = useState<Terminal[]>(StorageService.getTerminals());
  const [currentTerminalId, setCurrentTerminalState] = useState<string>(StorageService.getCurrentTerminalId());
  const [isOffline, setIsOffline] = useState<boolean>(!navigator.onLine || StorageService.isOfflineMode());
  const [pendingSyncCount, setPendingSyncCount] = useState<number>(0);
  const [cloudSyncStatus, setCloudSyncStatus] = useState(CloudSync.getStatus());
  const [networkToast, setNetworkToast] = useState<{
    show: boolean;
    status: 'online' | 'offline';
    message: string;
  } | null>(null);

  // POS Cart State
  const [cart, setCart] = useState<CartItem[]>([]);

  // Recover the durable catalog before starting cross-terminal reconciliation.
  // This prevents a stale localStorage snapshot from winning during app startup.
  useEffect(() => {
    let active = true;
    void StorageService.hydrateDurableArticles().then((durableArticles) => {
      if (!active) return;
      setArticles(durableArticles);
      CloudSync.connect();
    });
    return () => { active = false; };
  }, []);

  // Refresh all state from storage
  const reloadAllFromStorage = useCallback(() => {
    StorageService.invalidateArticlesCache();
    setArticles(StorageService.getArticles());
    setSales(StorageService.getSales());
    setPurchases(StorageService.getPurchases());
    setAccounts(StorageService.getAccounts());
    setAccountMovements(StorageService.getAccountMovements());
    setCashShifts(StorageService.getCashShifts());
    setCashMovements(StorageService.getCashMovements());
    setExternalServiceSales(StorageService.getExternalServiceSales());
    setAuditLogs(StorageService.getAuditLogs());
    setTerminals(StorageService.getTerminals());
  }, []);

  // Start the PHP/MySQL relay as soon as the POS opens. Previously the relay
  // only initialized after the user changed the terminal selector, so a saved
  // terminal/token could remain idle without ever calling /api/sync.php.
  useEffect(() => {
    CloudSync.setTerminalId(currentTerminalId || 'TERM-01');
    // Initialize once at startup; terminal changes are handled by setCurrentTerminalId.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // When a one-time panel code identifies a newly created terminal, add it to this
  // browser's selector and make it the active terminal without clearing business data.
  useEffect(() => {
    const onTerminalPaired = (event: Event) => {
      const detail = (event as CustomEvent<{ terminalId?: string }>).detail;
      const terminalId = String(detail?.terminalId || '').trim().toUpperCase();
      if (!terminalId) return;
      // Merge rather than replace so this terminal cannot erase other panel-created
      // entries already known by this browser. Publish the merged list to the same
      // commerce channel so its other terminals receive the new entry too.
      const mergedById = new Map<string, Terminal>();
      // Read the latest persisted list at event time; this avoids stale state.
      StorageService.getTerminals().forEach(term => {
        const id = String(term?.id || '').trim().toUpperCase();
        if (id) mergedById.set(id, { ...mergedById.get(id), ...term, id });
      });
      const merged = Array.from(mergedById.values());
      saveTerminalsList(merged);
      setCurrentTerminalState(terminalId);
    };
    window.addEventListener('pos-terminal-paired', onTerminalPaired);
    return () => window.removeEventListener('pos-terminal-paired', onTerminalPaired);
    // The listener reads the current persisted list when invoked. Keep this effect
    // mount-scoped so its dependency array doesn't access saveTerminalsList before
    // that callback is initialized during the first render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Multi-terminal BroadcastChannel & CloudSync Listener
  useEffect(() => {
    const unsubscribeSync = StorageService.subscribeToSync((event) => {
      if (event.type === 'OFFLINE_TOGGLED') {
        setIsOffline(event.payload?.offline ?? StorageService.isOfflineMode());
      } else if (event.type === 'TERMINAL_CHANGED') {
        if (typeof window !== 'undefined' && !sessionStorage.getItem('pos_current_terminal_v1')) {
          setCurrentTerminalState(event.payload?.terminalId ?? StorageService.getCurrentTerminalId());
        }
      } else if (event.type === 'ARTICLES_UPDATED') {
        // Article/stock updates should not force a reload of every ledger.
        // A sale previously triggered a full read of sales, purchases, accounts,
        // cash and audit storage for each sold line.
        StorageService.invalidateArticlesCache();
        setArticles(StorageService.getArticles());
      } else if (event.type === 'SALE_COMPLETED') {
        setSales(StorageService.getSales());
      } else if (event.type === 'AUDIT_LOGS_UPDATED') {
        setAuditLogs(StorageService.getAuditLogs());
      } else if (event.type === 'CASH_SHIFTS_UPDATED') {
        setCashShifts(StorageService.getCashShifts());
      } else if (event.type === 'ACCOUNTS_UPDATED') {
        setAccounts(StorageService.getAccounts());
      } else if (event.type === 'MOVEMENTS_UPDATED') {
        setAccountMovements(StorageService.getAccountMovements());
      } else {
        reloadAllFromStorage();
      }
    });

    // Direct real-time stock & articles synchronization across all terminals
    const unsubscribeArticles = CloudSync.onArticlesUpdate((newArticles) => {
      void StorageService.applyRemoteArticles(newArticles).then(() => {
        setArticles(newArticles);
      }).catch((error) => {
        console.error('[POS sync] No se pudo persistir el catálogo recibido; se conserva el catálogo local.', error);
      });
    });

    // CloudSync status listener
    const unsubscribeCloud = CloudSync.onStatusChange((status) => {
      setCloudSyncStatus(status);
      setPendingSyncCount(status.pendingCount);
    });

    // Detect network changes with active reachability probing (reliable on Desktop PC and Mobile)
    let toastTimeout: any = null;
    let isFirstStatus = true;
    let lastKnownOnline = NetworkService.isConnectedToInternet;

    const unsubscribeNetwork = NetworkService.subscribe((isOnline) => {
      if (isFirstStatus) {
        isFirstStatus = false;
        lastKnownOnline = isOnline;
        setIsOffline(!isOnline);
        StorageService.setOfflineMode(!isOnline);
        return;
      }

      if (isOnline === lastKnownOnline) return;
      lastKnownOnline = isOnline;

      if (isOnline) {
        setIsOffline(false);
        StorageService.setOfflineMode(false);
        if (toastTimeout) clearTimeout(toastTimeout);
        setNetworkToast({
          show: true,
          status: 'online',
          message: 'Conexión a internet restablecida. Sincronización en la nube activa con las demás terminales.',
        });
        toastTimeout = setTimeout(() => {
          setNetworkToast(null);
        }, 4500);
        reloadAllFromStorage();
      } else {
        setIsOffline(true);
        StorageService.setOfflineMode(true);
        if (toastTimeout) clearTimeout(toastTimeout);
        setNetworkToast({
          show: true,
          status: 'offline',
          message: 'Se cortó la conexión a internet. La terminal continúa facturando en Modo Local Autónomo.',
        });
        toastTimeout = setTimeout(() => {
          setNetworkToast(null);
        }, 5500);
      }
    });

    // Native browser storage event listener across tabs/windows
    const handleStorageEvent = (e: StorageEvent) => {
      if (!e.key || e.key.startsWith('pos_')) {
        reloadAllFromStorage();
      }
    };
    window.addEventListener('storage', handleStorageEvent);

    return () => {
      unsubscribeArticles();
      unsubscribeSync();
      unsubscribeCloud();
      unsubscribeNetwork();
      window.removeEventListener('storage', handleStorageEvent);
      if (toastTimeout) clearTimeout(toastTimeout);
    };
  }, [reloadAllFromStorage]);

  const setCurrentTerminalId = (id: string) => {
    setCurrentTerminalState(id);
    StorageService.setCurrentTerminalId(id);
    CloudSync.setTerminalId(id);
  };

  const saveTerminalsList = (updatedList: Terminal[]) => {
    setTerminals(updatedList);
    StorageService.saveTerminals(updatedList);
  };

  const dismissNetworkToast = () => {
    setNetworkToast(null);
  };

  const toggleOfflineMode = () => {
    const next = !isOffline;
    setIsOffline(next);
    StorageService.setOfflineMode(next);
    if (!next) {
      setPendingSyncCount(0);
      CloudSync.connect();
    }
  };

  const syncNow = () => {
    setPendingSyncCount(0);
    reloadAllFromStorage();
  };

  // Active Cash Shift for current terminal (persists across sessions, reboots and terminal variations)
  const currentShift = useMemo(() => {
    // 1. Direct match with current terminal
    const match = cashShifts.find(s => 
      (s.status === 'OPEN' || !s.closedAt) && 
      s.terminalId?.toUpperCase() === currentTerminalId.toUpperCase()
    );
    if (match) return { ...match, status: 'OPEN' as const };

    // 2. Any active or unclosed shift in cashShifts list (ensures open shift is never lost if program closes)
    const anyOpen = cashShifts.find(s => s.status === 'OPEN' || !s.closedAt);
    if (anyOpen) return { ...anyOpen, status: 'OPEN' as const };

    // 3. Fallback to active shift in dedicated storage for current terminal
    const fromStorage = StorageService.getActiveCashShift(currentTerminalId);
    if (fromStorage && (fromStorage.status === 'OPEN' || !fromStorage.closedAt)) {
      return { ...fromStorage, status: 'OPEN' as const };
    }

    // 4. Fallback to any active shift in dedicated storage regardless of terminal ID
    const anyFromStorage = StorageService.getActiveCashShift();
    if (anyFromStorage && (anyFromStorage.status === 'OPEN' || !anyFromStorage.closedAt)) {
      return { ...anyFromStorage, status: 'OPEN' as const };
    }

    // 5. If the most recent shift in history was never formally closed (no closedAt), it is open
    if (cashShifts.length > 0 && !cashShifts[0].closedAt) {
      return { ...cashShifts[0], status: 'OPEN' as const };
    }

    return undefined;
  }, [cashShifts, currentTerminalId]);

  // Cart operations
  const addToCart = (article: Article, quantity: number = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.article.id === article.id);
      if (existing) {
        return prev.map(item => 
          item.article.id === article.id 
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { article, quantity }];
    });
  };

  const removeFromCart = (articleId: string) => {
    setCart(prev => prev.filter(item => item.article.id !== articleId));
  };

  const updateCartQuantity = (articleId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(articleId);
      return;
    }
    setCart(prev => prev.map(item => 
      item.article.id === articleId ? { ...item, quantity } : item
    ));
  };

  const clearCart = () => {
    setCart([]);
  };

  const loadCart = (items: CartItem[]) => {
    setCart(items);
  };

  const cartSubtotal = cart.reduce((sum, item) => sum + (item.article.salePrice * item.quantity), 0);
  const cartTotal = cartSubtotal;

  // Process Sale
  const processSale = (params: {
    paymentMethod: PaymentMethod;
    paymentDetails?: any;
    clientId?: string;
    clientName?: string;
    discount?: number;
    surcharge?: number;
  }) => {
    if (cart.length === 0) {
      return { success: false, message: 'El carrito de ventas está vacío' };
    }

    // Check if shift is open
    if (!currentShift) {
      return { success: false, message: 'No hay un turno de caja abierto en esta terminal. Abra la caja antes de vender.' };
    }

    const discount = params.discount || 0;
    const surcharge = params.surcharge || 0;
    const finalTotal = Math.max(0, cartTotal - discount + surcharge);

    const saleNumberSeq = (sales.length + 1).toString().padStart(6, '0');
    const receiptNumber = `B-0001-${saleNumberSeq}`;

    const newSale: Sale = {
      id: `sale_${Date.now()}`,
      receiptNumber,
      items: cart.map(item => ({
        articleId: item.article.id,
        barcode: item.article.barcode,
        name: item.article.name,
        brand: item.article.brand,
        quantity: item.quantity,
        unitPrice: item.article.salePrice,
        total: item.article.salePrice * item.quantity,
      })),
      subtotal: cartSubtotal,
      discount,
      surcharge,
      total: finalTotal,
      paymentMethod: params.paymentMethod,
      paymentDetails: params.paymentDetails,
      clientId: params.clientId,
      clientName: params.clientName,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      terminalId: currentTerminalId,
      timestamp: new Date().toISOString(),
      status: 'COMPLETED',
    };

    StorageService.addSale(newSale);

    // Update active shift totals in memory and storage
    const updatedShifts = StorageService.getCashShifts().map(shift => {
      if (shift.id === currentShift.id) {
        let cashSales = shift.totalCashSales;
        let mpSales = shift.totalMpSales;
        let transferSales = shift.totalTransferSales;
        let cardSales = shift.totalCardSales || 0;
        let ctaCteSales = shift.totalCurrentAccountSales;

        if (params.paymentMethod === 'EFECTIVO') cashSales += finalTotal;
        else if (params.paymentMethod === 'MERCADO_PAGO_QR') mpSales += finalTotal;
        else if (params.paymentMethod === 'TRANSFERENCIA') {
          if (params.paymentDetails?.isMixedPayment && params.paymentDetails.mixedDetails) {
            transferSales += params.paymentDetails.mixedDetails.transferAmount;
            cashSales += params.paymentDetails.mixedDetails.cashAmount;
          } else {
            transferSales += finalTotal;
          }
        }
        else if (params.paymentMethod === 'TARJETA_POSNET' || params.paymentMethod === 'BILLETERA_VIRTUAL') cardSales += finalTotal;
        else if (params.paymentMethod === 'CUENTA_CORRIENTE') ctaCteSales += finalTotal;

        const totalSales = cashSales + mpSales + transferSales + cardSales + ctaCteSales;
        const expectedCash = shift.initialCash + cashSales + shift.totalCashIncomes - shift.totalCashExpenses;

        return {
          ...shift,
          totalCashSales: cashSales,
          totalMpSales: mpSales,
          totalTransferSales: transferSales,
          totalCardSales: cardSales,
          totalCurrentAccountSales: ctaCteSales,
          totalSales,
          expectedCashInRegister: expectedCash,
        };
      }
      return shift;
    });

    StorageService.saveCashShifts(updatedShifts);
    setCashShifts(updatedShifts);

    if (isOffline) {
      setPendingSyncCount(prev => prev + 1);
    }

    clearCart();
    // Refresh only the state changed by this sale. Reloading every storage collection
    // here reparsed the entire catalog, purchase history, accounts and cash ledgers
    // after each checkout, even when most of them had not changed.
    // SALE_COMPLETED and AUDIT_LOGS_UPDATED broadcasts already refreshed those
    // two state slices; update only the remaining local views here.
    setArticles(StorageService.getArticles());
    setCashShifts(updatedShifts);
    if (params.paymentMethod === 'CUENTA_CORRIENTE' && params.clientId) {
      setAccounts(StorageService.getAccounts());
      setAccountMovements(StorageService.getAccountMovements());
    }

    return { success: true, sale: newSale };
  };

  // Article Management
  const addArticle = (articleData: Omit<Article, 'id' | 'updatedAt'>): Article => {
    const newArticle: Article = {
      ...articleData,
      id: `art_${Date.now()}`,
      updatedAt: new Date().toISOString(),
    };
    const updated = [newArticle, ...articles];
    setArticles(updated);
    StorageService.saveArticles(updated);

    StorageService.addAuditLog({
      id: `aud_${Date.now()}`,
      module: 'ARTICULOS',
      action: 'CREAR_ARTICULO',
      description: `Artículo ${newArticle.name} (${newArticle.brand}) creado con stock ${newArticle.stock}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      terminalId: currentTerminalId,
      timestamp: new Date().toISOString(),
    });

    return newArticle;
  };

  const updateArticle = (updatedArticle: Article) => {
    const previousArticle = articles.find(a => String(a.id) === String(updatedArticle.id));
    const updated = articles.map(a => a.id === updatedArticle.id ? { ...updatedArticle, updatedAt: new Date().toISOString() } : a);
    setArticles(updated);
    const stockDelta = Number(updatedArticle.stock || 0) - Number(previousArticle?.stock || 0);
    const stockDeltas = previousArticle && Number.isFinite(stockDelta) && stockDelta !== 0
      ? [{ articleId: updatedArticle.id, quantityDelta: stockDelta }]
      : undefined;
    StorageService.saveArticles(updated, stockDeltas);

    StorageService.addAuditLog({
      id: `aud_${Date.now()}`,
      module: 'ARTICULOS',
      action: 'MODIFICAR_ARTICULO',
      description: `Artículo ${updatedArticle.name} actualizado`,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      terminalId: currentTerminalId,
      timestamp: new Date().toISOString(),
    });
  };

  const updateArticlesBatch = (updatedArticlesList: Article[], reason?: string) => {
    if (updatedArticlesList.length === 0) return;
    const map = new Map(updatedArticlesList.map(a => [a.id, a]));
    const nowIso = new Date().toISOString();
    const updated = articles.map(a => {
      const found = map.get(a.id);
      return found ? { ...found, updatedAt: nowIso } : a;
    });
    setArticles(updated);
    StorageService.saveArticles(updated);

    StorageService.addAuditLog({
      id: `aud_${Date.now()}`,
      module: 'ARTICULOS',
      action: 'MODIFICAR_ARTICULO',
      description: reason || `Actualización masiva de precios en ${updatedArticlesList.length} artículos`,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      terminalId: currentTerminalId,
      timestamp: nowIso,
    });
  };

  const deleteArticle = (articleId: string) => {
    const target = articles.find(a => a.id === articleId);
    const updated = articles.filter(a => a.id !== articleId);
    setArticles(updated);
    StorageService.saveArticles(updated);

    if (target) {
      StorageService.addAuditLog({
        id: `aud_${Date.now()}`,
        module: 'ARTICULOS',
        action: 'ELIMINAR_ARTICULO',
        description: `Artículo ${target.name} eliminado`,
        userId: currentUser.id,
        userName: currentUser.name,
        userRole: currentUser.role,
        terminalId: currentTerminalId,
        timestamp: new Date().toISOString(),
      });
    }
  };

  const adjustStock = (articleId: string, delta: number) => {
    StorageService.updateArticleStock(articleId, delta);
    reloadAllFromStorage();
  };

  // Purchases
  const registerPurchase = (purchaseData: Omit<Purchase, 'id' | 'timestamp' | 'userId' | 'userName' | 'terminalId'>) => {
    const newPurchase: Purchase = {
      ...purchaseData,
      id: `pur_${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      terminalId: currentTerminalId,
      timestamp: new Date().toISOString(),
    };

    StorageService.addPurchase(newPurchase);

    if (purchaseData.paymentMethod === 'CUENTA_CORRIENTE') {
      // Find or create supplier account
      const accounts = StorageService.getAccounts();
      const existing = accounts.find(a => a?.type === 'SUPPLIER' && typeof a?.name === 'string' && a.name.toLowerCase() === purchaseData.supplierName.toLowerCase());
      if (existing) {
        StorageService.addAccountMovement({
          id: `mov_${Date.now()}`,
          accountId: existing.id,
          accountName: existing.name,
          type: 'DEBIT', // Increases what we owe
          amount: purchaseData.total,
          concept: `Compra s/Factura ${purchaseData.invoiceNumber}`,
          referenceId: newPurchase.id,
          userId: currentUser.id,
          userName: currentUser.name,
          timestamp: newPurchase.timestamp,
        });
      }
    }

    if (isOffline) {
      setPendingSyncCount(prev => prev + 1);
    }
    reloadAllFromStorage();
  };

  // Accounts
  const addAccount = (accountData: Omit<CurrentAccount, 'id' | 'updatedAt'>) => {
    const newAccount: CurrentAccount = {
      ...accountData,
      id: `acc_${Date.now()}`,
      updatedAt: new Date().toISOString(),
    };
    const updated = [...accounts, newAccount];
    setAccounts(updated);
    StorageService.saveAccounts(updated);

    StorageService.addAuditLog({
      id: `aud_${Date.now()}`,
      module: 'CUENTAS_CORRIENTES',
      action: 'CREAR_CUENTA',
      description: `Cuenta corriente creada: ${newAccount.name} (${newAccount.type === 'CLIENT' ? 'Cliente' : 'Proveedor'})`,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      terminalId: currentTerminalId,
      timestamp: new Date().toISOString(),
    });
  };

  const registerAccountPayment = (accountId: string, amount: number, paymentMethod: PaymentMethod, concept?: string) => {
    const acc = accounts.find(a => a.id === accountId);
    if (!acc) return;

    const movement: AccountMovement = {
      id: `mov_${Date.now()}`,
      accountId: acc.id,
      accountName: acc.name,
      type: 'CREDIT', // Payment
      amount,
      concept: concept || `Pago recibido por ${paymentMethod}`,
      paymentMethod,
      userId: currentUser.id,
      userName: currentUser.name,
      timestamp: new Date().toISOString(),
    };

    StorageService.addAccountMovement(movement);

    // If paid cash, add income to cash register
    if (paymentMethod === 'EFECTIVO' && currentShift) {
      addCashExpenseOrIncome('INCOME', amount, `Cobro Cta. Cte.: ${acc.name}`, 'EFECTIVO');
    }

    StorageService.addAuditLog({
      id: `aud_${Date.now()}`,
      module: 'CUENTAS_CORRIENTES',
      action: 'ABONO_CUENTA',
      description: `Cobro/Abono de $${amount.toLocaleString()} a ${acc.name} con ${paymentMethod}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      terminalId: currentTerminalId,
      timestamp: new Date().toISOString(),
    });

    reloadAllFromStorage();
  };

  // Cash Register Shifts
  const openCashShift = (initialCash: number) => {
    const shiftSeq = (cashShifts.length + 1).toString().padStart(3, '0');
    const newShift: CashShift = {
      id: `shift_${Date.now()}`,
      shiftNumber: `TURNO-${shiftSeq}`,
      openedAt: new Date().toISOString(),
      openedByUserId: currentUser.id,
      openedByUserName: currentUser.name,
      terminalId: currentTerminalId,
      initialCash,
      totalCashSales: 0,
      totalMpSales: 0,
      totalTransferSales: 0,
      totalCardSales: 0,
      totalCurrentAccountSales: 0,
      totalSales: 0,
      totalCashIncomes: 0,
      totalCashExpenses: 0,
      expectedCashInRegister: initialCash,
      status: 'OPEN',
    };

    const updated = [newShift, ...cashShifts];
    setCashShifts(updated);
    StorageService.saveActiveCashShift(newShift);
    StorageService.saveCashShifts(updated);

    StorageService.addAuditLog({
      id: `aud_${Date.now()}`,
      module: 'CAJA',
      action: 'APERTURA_CAJA',
      description: `Apertura de turno ${newShift.shiftNumber} con fondo inicial de $${initialCash.toLocaleString()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      terminalId: currentTerminalId,
      timestamp: new Date().toISOString(),
    });
  };

  const closeCashShift = (declaredCash: number, notes?: string) => {
    if (!currentShift) throw new Error('No hay turno abierto');

    const expected = currentShift.expectedCashInRegister;
    const diff = declaredCash - expected;

    const closedShift: CashShift = {
      ...currentShift,
      closedAt: new Date().toISOString(),
      closedByUserId: currentUser.id,
      closedByUserName: currentUser.name,
      declaredCashInRegister: declaredCash,
      cashDifference: diff,
      notes,
      status: 'CLOSED',
    };

    const updated = cashShifts.map(s => s.id === currentShift.id ? closedShift : s);
    setCashShifts(updated);
    StorageService.clearActiveCashShift();
    StorageService.saveCashShifts(updated);

    StorageService.addAuditLog({
      id: `aud_${Date.now()}`,
      module: 'CAJA',
      action: 'CIERRE_CAJA',
      description: `Cierre de turno ${closedShift.shiftNumber}. Esperado: $${expected.toLocaleString()}, Declarado: $${declaredCash.toLocaleString()} (Dif: $${diff.toLocaleString()})`,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      terminalId: currentTerminalId,
      timestamp: new Date().toISOString(),
    });

    return { shift: closedShift, difference: diff };
  };

  const addCashExpenseOrIncome = (type: 'INCOME' | 'EXPENSE', amount: number, concept: string, paymentMethod: PaymentMethod) => {
    const movement: CashMovement = {
      id: `csh_${Date.now()}`,
      type,
      concept,
      amount,
      paymentMethod,
      userId: currentUser.id,
      userName: currentUser.name,
      timestamp: new Date().toISOString(),
    };

    StorageService.addCashMovement(movement);

    if (currentShift && paymentMethod === 'EFECTIVO') {
      const updatedShifts = cashShifts.map(shift => {
        if (shift.id === currentShift.id) {
          const cashIncomes = shift.totalCashIncomes + (type === 'INCOME' ? amount : 0);
          const cashExpenses = shift.totalCashExpenses + (type === 'EXPENSE' ? amount : 0);
          const expectedCash = shift.initialCash + shift.totalCashSales + cashIncomes - cashExpenses;
          return {
            ...shift,
            totalCashIncomes: cashIncomes,
            totalCashExpenses: cashExpenses,
            expectedCashInRegister: expectedCash,
          };
        }
        return shift;
      });
      StorageService.saveCashShifts(updatedShifts);
      setCashShifts(updatedShifts);
    }

    StorageService.addAuditLog({
      id: `aud_${Date.now()}`,
      module: 'CAJA',
      action: type === 'INCOME' ? 'INGRESO_CAJA' : 'RETIRO_CAJA',
      description: `${type === 'INCOME' ? 'Ingreso' : 'Retiro/Gasto'} de $${amount.toLocaleString()} (${concept})`,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      terminalId: currentTerminalId,
      timestamp: new Date().toISOString(),
    });

    reloadAllFromStorage();
  };

  const addExternalServiceSale = (service: 'CLARO' | 'SAT' | 'EXTRAS', amount: number, notes?: string): ExternalServiceSale => {
    const now = new Date();
    const newRecord: ExternalServiceSale = {
      id: `ext_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      service,
      serviceName: service === 'CLARO' ? 'Claro' : service === 'SAT' ? 'SAT' : 'Extras',
      amount,
      timestamp: now.toISOString(),
      shiftId: currentShift?.id,
      shiftNumber: currentShift?.shiftNumber,
      terminalId: currentTerminalId,
      userId: currentUser.id,
      userName: currentUser.name,
      notes: notes?.trim() || undefined,
    };

    StorageService.addExternalServiceSale(newRecord);

    StorageService.addAuditLog({
      id: `aud_${Date.now()}`,
      module: 'CAJA',
      action: 'VENTA_SERVICIO_EXTERNO',
      description: `Venta externa ${newRecord.serviceName} por $${amount.toLocaleString()} (${notes || 'Sin obs'}) registrada por ${currentUser.name}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      terminalId: currentTerminalId,
      timestamp: now.toISOString(),
      details: { service, amount, notes }
    });

    reloadAllFromStorage();
    return newRecord;
  };

  const deleteExternalServiceSale = (id: string) => {
    StorageService.deleteExternalServiceSale(id);
    reloadAllFromStorage();
  };

  // The sales screen has its own narrow context. The action proxies stay stable
  // while forwarding to the latest callbacks, so unrelated cash/network updates do
  // not force the 8k+ article sales screen to render again.
  type SalesActions = Pick<AppContextType, Exclude<SalesContextKeys,
    'articles' | 'cart' | 'cartTotal' | 'currentShift' | 'accounts' | 'currentTerminalId' | 'sales'>>;
  const salesActionsRef = useRef<SalesActions>({
    addArticle, adjustStock, addToCart, removeFromCart, updateCartQuantity,
    clearCart, loadCart, processSale, addExternalServiceSale,
  });
  salesActionsRef.current = {
    addArticle, adjustStock, addToCart, removeFromCart, updateCartQuantity,
    clearCart, loadCart, processSale, addExternalServiceSale,
  };
  const stableSalesActions = useMemo<SalesActions>(() => ({
    addArticle: (...args) => salesActionsRef.current.addArticle(...args),
    adjustStock: (...args) => salesActionsRef.current.adjustStock(...args),
    addToCart: (...args) => salesActionsRef.current.addToCart(...args),
    removeFromCart: (...args) => salesActionsRef.current.removeFromCart(...args),
    updateCartQuantity: (...args) => salesActionsRef.current.updateCartQuantity(...args),
    clearCart: (...args) => salesActionsRef.current.clearCart(...args),
    loadCart: (...args) => salesActionsRef.current.loadCart(...args),
    processSale: (...args) => salesActionsRef.current.processSale(...args),
    addExternalServiceSale: (...args) => salesActionsRef.current.addExternalServiceSale(...args),
  }), []);
  const salesContextValue = useMemo<SalesContextType>(() => ({
    articles, cart, cartTotal, currentShift, accounts, currentTerminalId, sales,
    ...stableSalesActions,
  }), [articles, cart, cartTotal, currentShift, accounts, currentTerminalId, sales, stableSalesActions]);

  return (
    <SalesContext.Provider value={salesContextValue}>
    <AppContext.Provider
      value={{
        articles,
        addArticle,
        updateArticle,
        updateArticlesBatch,
        deleteArticle,
        adjustStock,

        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        loadCart,
        cartSubtotal,
        cartTotal,
        processSale,

        purchases,
        registerPurchase,

        accounts,
        accountMovements,
        addAccount,
        registerAccountPayment,

        currentShift,
        cashShifts,
        cashMovements,
        externalServiceSales,
        openCashShift,
        closeCashShift,
        addCashExpenseOrIncome,
        addExternalServiceSale,
        deleteExternalServiceSale,

        sales,
        auditLogs,

        currentTerminalId,
        setCurrentTerminalId,
        terminals,
        saveTerminalsList,
        isOffline,
        toggleOfflineMode,
        pendingSyncCount,
        syncNow,
        cloudSyncStatus,
        networkToast,
        dismissNetworkToast,
        reloadAllFromStorage,
      }}
    >
      {children}
    </AppContext.Provider>
    </SalesContext.Provider>
  );
};

export const useSalesApp = (): SalesContextType => {
  const context = useContext(SalesContext);
  if (!context) throw new Error('useSalesApp must be used within an AppProvider');
  return context;
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
