export type UserRole = 'SUPER_ADMIN' | 'OWNER' | 'ADMIN' | 'CASHIER';

export interface UserPermissions {
  canMakeSales: boolean;
  canMakePurchases: boolean;
  canManageInventory: boolean;
  canManageAccounts: boolean;
  canCloseCashRegister: boolean;
  canViewHistory: boolean;
  canManageUsers: boolean;
  canGiveDiscounts: boolean;
  canManageSettings?: boolean;
}

export interface User {
  id: string;
  name: string;
  username: string; // Nombre de usuario para iniciar sesión
  password: string; // Contraseña o PIN
  email?: string;
  role: UserRole;
  active: boolean;
  terminalAssigned?: string;
  permissions: UserPermissions;
  avatarColor?: string;
}

export interface Article {
  id: string;
  barcode: string;
  name: string;
  brand: string;
  category: string;
  subcategory?: string;
  supplier?: string;
  costPrice: number;
  salePrice: number;
  stock: number;
  minStock: number;
  unit: string;
  updatedAt: string;
  /** Valores base y configuración opcional para recalcular precios sin acumular IVA/ganancia. */
  priceCalc?: {
    baseCostPrice: number;
    baseSalePrice: number;
    applyCostVat: boolean;
    applySaleVat: boolean;
    applyProfitMargin: boolean;
    costVatPercent: number;
    saleVatPercent: number;
    profitPercent: number;
  };
}

export type PaymentMethod = 'EFECTIVO' | 'MERCADO_PAGO_QR' | 'TRANSFERENCIA' | 'TARJETA_POSNET' | 'CUENTA_CORRIENTE' | 'BILLETERA_VIRTUAL';

export interface CartItem {
  article: Article;
  quantity: number;
  discountPercent?: number;
  customPrice?: number;
}

export interface ParkedSale {
  id: string;
  referenceName: string;
  items: CartItem[];
  discountAmount?: number;
  selectedClientId?: string;
  total: number;
  timestamp: string;
  itemsCount: number;
  terminalId?: string;
}

export interface VirtualWallet {
  id: string;
  name: string; // e.g. "Ualá", "Personal Pay", "MODO", "Naranja X", "Astropay", "Brubank", etc.
  alias: string;
  cvu: string;
  holder: string;
  qrImage?: string;
  qrText?: string;
  color?: string;
}

export interface PaymentConfig {
  mpAlias: string;
  mpCvu: string;
  mpHolder: string;
  mpQrText?: string;
  mpQrImage?: string; // Imagen oficial QR subida por el usuario
  mpQrData?: string; // Payload string del QR oficial de Mercado Pago
  // Integración Oficial API Mercado Pago (Point of Sale / Caja en Vivo)
  mpAccessToken?: string;
  mpUserId?: string;
  mpPosId?: string;
  mpPosName?: string;
  mpStoreId?: string | number;
  mpConnected?: boolean;
  mpAutoSync?: boolean;
  mpPosQrs?: Record<string, { qrImage?: string; qrData?: string; qrText?: string; posName?: string }>;
  // Configuración de Tarjeta / Posnet
  posnetMode?: 'MANUAL' | 'AUTOMATIC'; // Modo predeterminado
  posnetBrand?: string; // Ej: "Payway / Posnet", "Mercado Pago Point", "Clover / Fiserv", "Genérico"
  posnetTerminalId?: string; // Terminal ID / Serie
  posnetIntegratedType?: 'POINT_MP' | 'INTEGRATED_SIMULATOR' | 'PAYWAY';
  posnetAutoPrintCoupon?: boolean;
  // Billeteras Virtuales Múltiples (Mantenidas por retrocompatibilidad)
  wallets?: VirtualWallet[];
  walletName?: string;
  walletAlias?: string;
  walletCvu?: string;
  walletHolder?: string;
  // Cuentas Bancarias
  bankName: string;
  bankAlias: string;
  bankCbu: string;
  bankHolder: string;
  bankCuit: string;
}

export interface CustomerDisplayItem {
  name: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface ReceivedTransferItem {
  id: string;
  amount: number;
  payerName: string;
  platform: string;
  reference: string;
  timestamp: number;
}

export interface CustomerDisplayState {
  status: 'IDLE' | 'WELCOME' | 'SCANNING' | 'PAYING' | 'COMPLETED';
  items: CustomerDisplayItem[];
  subtotal: number;
  discount: number;
  total: number;
  paymentMethod: PaymentMethod | null;
  cashReceived?: number;
  cashChange?: number;
  receiptNumber?: string;
  terminalId?: string;
  timestamp: number;
  selectedWallet?: VirtualWallet;
  activeWalletId?: string;
  transfersReceived?: ReceivedTransferItem[];
  transfersTotalReceived?: number;
  posnetMode?: 'MANUAL' | 'AUTOMATIC';
  posnetStatus?: 'WAITING_CARD' | 'PROCESSING' | 'APPROVED' | 'MANUAL_READY';
  posnetCardType?: string;
  posnetCardBrand?: string;
  version?: number;
  paymentConfig?: PaymentConfig;
  qrImageUrl?: string;
  qrData?: string;
}

export interface Sale {
  id: string;
  receiptNumber: string;
  items: {
    articleId: string;
    barcode: string;
    name: string;
    brand: string;
    quantity: number;
    unitPrice: number;
    total: number;
  }[];
  subtotal: number;
  discount: number;
  surcharge?: number;
  total: number;
  paymentMethod: PaymentMethod;
  paymentDetails?: {
    cashReceived?: number;
    cashChange?: number;
    mpTransactionId?: string;
    mpSurchargeEnabled?: boolean;
    mpSurchargePercent?: number;
    mpSurchargeAmount?: number;
    transferRef?: string;
    transfersList?: ReceivedTransferItem[];
    // Pago Mixto (Transferencia + Efectivo)
    isMixedPayment?: boolean;
    mixedDetails?: {
      transferAmount: number;
      cashAmount: number;
      cashReceived?: number;
      cashChange?: number;
    };
    // Tarjeta / Posnet
    posnetMode?: 'MANUAL' | 'AUTOMATIC';
    cardType?: 'DEBITO' | 'CREDITO' | 'PREPAGA';
    cardBrand?: string;
    cardLastFour?: string;
    couponNumber?: string;
    batchNumber?: string;
    installments?: number;
    posnetTerminalId?: string;
    // Retrocompatibilidad
    walletId?: string;
    walletName?: string;
    walletRef?: string;
    clientAccountId?: string;
  };
  clientId?: string;
  clientName?: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  terminalId: string;
  timestamp: string; // ISO string with date & time
  status: 'COMPLETED' | 'CANCELLED';
}

export interface PurchaseItem {
  articleId: string;
  name: string;
  brand: string;
  quantity: number;
  costPrice: number;
  total: number;
}

export interface Purchase {
  id: string;
  invoiceNumber: string;
  supplierName: string;
  supplierTaxId?: string;
  items: PurchaseItem[];
  total: number;
  paymentMethod: PaymentMethod;
  paymentRef?: string;
  userId: string;
  userName: string;
  terminalId: string;
  timestamp: string;
}

export type AccountType = 'CLIENT' | 'SUPPLIER';

export interface CurrentAccount {
  id: string;
  type: AccountType;
  name: string;
  documentNumber: string;
  phone: string;
  email?: string;
  creditLimit: number;
  currentBalance: number; // positive = owes us (for client), or we owe them (for supplier)
  updatedAt: string;
}

export interface AccountMovement {
  id: string;
  accountId: string;
  accountName: string;
  type: 'DEBIT' | 'CREDIT'; // DEBIT = creates debt, CREDIT = payment / abono
  amount: number;
  concept: string;
  paymentMethod?: PaymentMethod;
  referenceId?: string; // Sale or Purchase ID
  userId: string;
  userName: string;
  timestamp: string;
}

export interface CashMovement {
  id: string;
  type: 'INCOME' | 'EXPENSE';
  concept: string;
  amount: number;
  paymentMethod: PaymentMethod;
  userId: string;
  userName: string;
  timestamp: string;
}

export interface ExternalServiceSale {
  id: string;
  service: 'CLARO' | 'SAT' | 'EXTRAS';
  serviceName: string; // 'Claro' | 'SAT' | 'Extras'
  amount: number;
  timestamp: string; // Fecha y hora automática de creación
  shiftId?: string; // ID del turno de caja activo
  shiftNumber?: string;
  terminalId?: string;
  userId: string;
  userName: string;
  notes?: string;
}

export interface CashShift {
  id: string;
  shiftNumber: string;
  openedAt: string;
  closedAt?: string;
  openedByUserId: string;
  openedByUserName: string;
  closedByUserId?: string;
  closedByUserName?: string;
  terminalId: string;
  initialCash: number;
  
  // Computed values
  totalCashSales: number;
  totalMpSales: number;
  totalTransferSales: number;
  totalCardSales: number; // Tarjeta / Posnet
  totalCurrentAccountSales: number;
  totalSales: number;
  totalCashIncomes: number;
  totalCashExpenses: number;
  
  expectedCashInRegister: number;
  declaredCashInRegister?: number;
  cashDifference?: number; // declared - expected
  notes?: string;
  status: 'OPEN' | 'CLOSED';
}

export interface AuditLog {
  id: string;
  module: 'VENTAS' | 'COMPRAS' | 'ARTICULOS' | 'CUENTAS_CORRIENTES' | 'CAJA' | 'USUARIOS' | 'CONFIGURACION';
  action: string;
  description: string;
  details?: Record<string, any>;
  userId: string;
  userName: string;
  userRole: UserRole;
  terminalId: string;
  timestamp: string;
}

export interface BusinessInfo {
  name: string;
  cuit: string;
  address: string;
  phone: string;
  ticketHeader?: string;
  ticketFooter?: string;
}

export interface Terminal {
  id: string;
  name: string;
  location: string;
  isOnline: boolean;
  lastSyncAt: string;
}

export interface KeyboardShortcutConfig {
  id: string;
  action: string;
  label: string;
  key: string; // e.g. "F1", "F2", "F3", "F4", "F6", "F7", "Escape", "Enter"
  description: string;
  category: 'VENTAS' | 'INVENTARIO' | 'CAJA' | 'SISTEMA';
}

export interface PrinterConfig {
  enabled: boolean;
  printerName: string;
  paperWidth: '80mm' | '58mm';
  printerType: 'SYSTEM' | 'THERMAL_USB' | 'THERMAL_NETWORK' | 'BLUETOOTH';
  autoPrintOnSale: boolean;
  silentPrinting?: boolean;
  openCashDrawer: boolean;
  cutPaper: boolean;
  copies: number;
  printBarcode: boolean;
  printStoreLogo: boolean;
  ipAddress?: string;
  port?: number;
  headerText?: string;
  footerText?: string;
}

export interface MerchandiseNotice {
  id: string;
  senderUserId: string;
  senderUserName: string;
  senderTerminalId: string;
  targetTerminalId: string; // 'ALL' or specific terminalId like 'TERM-01'
  title: string;
  notes?: string;
  createdAt: string; // ISO string
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED';
  startedAt?: string;
  completedAt?: string;
  completedByUserName?: string;
  completedByTerminalId?: string;
}

