// Real-Time Multi-Terminal Synchronization Engine
// Hosting API relay + local BroadcastChannel. LocalStorage keeps each terminal usable offline.

import { NetworkService } from './network';
import { appendVpsMessage, readVpsQueue as readIndexedDbVpsQueue, removeVpsMessage, writeVpsQueue as writeIndexedDbVpsQueue } from './vpsQueueStore';
import { readDurableArticles } from './catalogDurableStore';

export interface SyncMessage {
  id: string;
  type:
    | 'SALE_PROCESSED'
    | 'ARTICLES_UPDATED'
    | 'STOCK_ADJUSTED'
    | 'ACCOUNTS_UPDATED'
    | 'USERS_UPDATED'
    | 'BUSINESS_INFO_UPDATED'
    | 'PRINTER_CONFIG_UPDATED'
    | 'KEYBOARD_SHORTCUTS_UPDATED'
    | 'CASH_UPDATED'
    | 'PURCHASE_REGISTERED'
    | 'HISTORY_UPDATED'
    | 'SYSTEM_RESTORE'
    | 'TERMINALS_UPDATED'
    | 'CUSTOMER_DISPLAY_SYNC'
    | 'MERCHANDISE_NOTICE_SENT'
    | 'MERCHANDISE_NOTICE_STATUS'
    | 'SYNC_REQUEST_STATE'
    | 'SYNC_RESPONSE_STATE'
    | 'PEER_ANNOUNCE'
    | 'PING'
    | 'PONG'
    | 'SYNC_STATE_SNAPSHOT';
  senderTerminalId: string;
  senderClientId: string;
  timestamp: number;
  payload?: any;
  serverVersion?: number;
}

export type CloudSyncStatus = {
  isOnline: boolean;
  isConnected: boolean;
  pendingCount: number;
  channelId: string;
  activePeersCount?: number;
  isVpsConnected?: boolean;
};

type SyncListener = (message: SyncMessage) => void;
type StatusListener = (status: CloudSyncStatus) => void;

const CLIENT_ID = Math.random().toString(36).substring(2, 10);
const STORAGE_SYNC_CHANNEL_KEY = 'pos_cloud_sync_channel';
const TERMINAL_BACKUP_COOKIE = 'pos_terminal_backup_v1';
const SYNC_TOKEN_COOKIE_PREFIX = 'pos_sync_backup_';
const PERSISTENCE_MAX_AGE = 31536000;

function readCookie(name: string): string {
  if (typeof document === 'undefined') return '';
  const prefix = `${name}=`;
  const item = document.cookie.split('; ').find((part) => part.startsWith(prefix));
  if (!item) return '';
  try { return decodeURIComponent(item.slice(prefix.length)); } catch { return item.slice(prefix.length); }
}

function writeCookie(name: string, value: string): void {
  if (typeof document === 'undefined') return;
  const secure = typeof window !== 'undefined' && window.location.protocol === 'https:' ? '; Secure' : '';
  document.cookie = `${name}=${encodeURIComponent(value)}; Max-Age=${PERSISTENCE_MAX_AGE}; Path=/; SameSite=Lax${secure}`;
}

function clearCookie(name: string): void {
  if (typeof document === 'undefined') return;
  const secure = typeof window !== 'undefined' && window.location.protocol === 'https:' ? '; Secure' : '';
  document.cookie = `${name}=; Max-Age=0; Path=/; SameSite=Lax${secure}`;
}

function tokenCookieName(channel: string, terminal: string): string {
  return `${SYNC_TOKEN_COOKIE_PREFIX}${channel}_${terminal}`;
}

function readTerminalBackup(): { channelId: string; terminalId: string } | null {
  const raw = readCookie(TERMINAL_BACKUP_COOKIE);
  const separator = raw.indexOf('|');
  if (separator < 1) return null;
  const channelId = raw.slice(0, separator).trim();
  const terminalId = raw.slice(separator + 1).trim();
  if (!/^[a-zA-Z0-9_-]{1,120}$/.test(channelId) || !/^[A-Z0-9_-]{1,120}$/.test(terminalId)) return null;
  return { channelId, terminalId };
}
export const normalizeTerminalId = (raw?: string | null): string => {
  if (!raw) return 'TERM-01';
  let cleaned = raw.trim().toUpperCase();
  if (cleaned.startsWith('TERMINAL')) {
    cleaned = cleaned.replace('TERMINAL', '').trim();
  }
  if (/^\d+$/.test(cleaned)) {
    cleaned = `TERM-${cleaned.padStart(2, '0')}`;
  } else if (/^TERM-\d+$/.test(cleaned)) {
    const num = cleaned.replace('TERM-', '');
    cleaned = `TERM-${num.padStart(2, '0')}`;
  }
  return cleaned || 'TERM-01';
};

export const getCleanHostIdentifier = (): string => {
  if (typeof window === 'undefined') return 'pos_store';
  const raw = (window.location.hostname || 'pos_store').replace(/^www\./i, '');
  const isLocal = raw === 'localhost' || raw === '127.0.0.1' || /^192\.168\./.test(raw) || /^10\./.test(raw);
  if (isLocal) return 'pos_local';
  const clean = raw.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
  return clean.length > 24 ? clean.substring(0, 24) : clean;
};



class CloudSyncManager {
  private syncListeners: Set<SyncListener> = new Set();
  private statusListeners: Set<StatusListener> = new Set();
  private articlesListeners: Set<(articles: any[]) => void> = new Set();
  private channelId: string = '';
  private broadcastChannel: BroadcastChannel | null = null;
  private currentTerminalId: string = 'TERM-01';
  private terminalConfigured: boolean = false;

  // VPS Server Relay
  private isVpsConnected: boolean = false;
  private vpsEventSource: EventSource | null = null;
  private isFlushingVpsQueue = false;
  private catalogHydrationReady = false;
  private vpsQueueRetryHandle: number | null = null;
  private vpsPollHandle: number | null = null;
  private vpsPollGeneration = 0;
  private vpsPollingStarted = false;
  private vpsPollInFlight = false;
  private vpsPollAbortController: AbortController | null = null;
  private vpsPollFailureCount = 0;
  private vpsStateInFlight = false;
  // El token largo queda guardado localmente; el usuario solo introduce el código temporal.
  private isPairingInProgress = false;
  private pairingPromptDismissed = false;

  private getSyncToken(): string {
    const key = `pos_sync_token_v1_${this.channelId}_${this.currentTerminalId}`;
    try {
      const saved = localStorage.getItem(key) || '';
      if (saved.length >= 32) return saved;
    } catch {}
    const backup = readCookie(tokenCookieName(this.channelId, this.currentTerminalId));
    if (backup.length >= 32) {
      try { localStorage.setItem(key, backup); } catch {}
      return backup;
    }
    return '';
  }

  private persistPairing(channel: string, terminal: string, token?: string): void {
    try {
      localStorage.setItem(STORAGE_SYNC_CHANNEL_KEY, channel);
      localStorage.setItem('pos_current_terminal_v1', terminal);
      if (token && token.length >= 32) {
        localStorage.setItem(`pos_sync_token_v1_${channel}_${terminal}`, token);
        writeCookie(tokenCookieName(channel, terminal), token);
      }
    } catch {}
    writeCookie(TERMINAL_BACKUP_COOKIE, `${channel}|${terminal}`);
  }

  /** Opens the one-time panel-code flow on demand, including when this browser is already paired. */
  public async pairTerminalFromPanel(): Promise<boolean> {
    this.pairingPromptDismissed = false;
    return this.acquireSyncTokenByPairing();
  }

  private async acquireSyncTokenByPairing(): Promise<boolean> {
    if (this.isPairingInProgress || this.pairingPromptDismissed || !this.terminalConfigured || typeof window === 'undefined') return false;
    this.isPairingInProgress = true;
    try {
      const code = (window.prompt('Pegá el código temporal generado para esta terminal en el panel de administración. El POS identificará automáticamente la terminal correcta:') || '').replace(/\s+/g, '').toUpperCase();
      if (!code) {
        this.pairingPromptDismissed = true;
        return false;
      }
      const response = await fetch('/api/sync.php?action=pairing-redeem', {
        method: 'POST',
        cache: 'no-store',
        headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' },
        body: JSON.stringify({ code }),
      });
      const result = await response.json().catch(() => null);
      if (!response.ok || !result?.success || typeof result.token !== 'string' || result.token.length !== 64) {
        this.pairingPromptDismissed = true;
        window.alert(result?.error || 'No se pudo vincular. Generá un código nuevo desde el panel.');
        return false;
      }

      // The server resolves the commerce/channel from the one-time code. Do not
      // require it to match this browser's old hostname-derived channel.
      const linkedChannel = String(result.channelId || '').trim().toLowerCase();
      const linkedTerminal = String(result.terminalId || '').trim().toUpperCase();
      if (!/^[a-z0-9_-]{1,120}$/.test(linkedChannel) || !/^[A-Z0-9_-]{1,120}$/.test(linkedTerminal)) {
        this.pairingPromptDismissed = true;
        window.alert('El servidor devolvió un comercio o una terminal inválidos. Generá un código nuevo desde el panel.');
        return false;
      }

      const previousTerminal = this.currentTerminalId;
      this.channelId = linkedChannel;
      this.currentTerminalId = linkedTerminal;
      this.terminalConfigured = true;
      this.persistPairing(linkedChannel, linkedTerminal, result.token);
      try {
        sessionStorage.setItem('pos_current_terminal_v1', linkedTerminal);
        const terminalsRaw = localStorage.getItem('pos_terminals_v1');
        const terminals = terminalsRaw ? JSON.parse(terminalsRaw) : [];
        const safeTerminals = Array.isArray(terminals) ? terminals : [];
        const label = String(result.terminalLabel || result.terminalCode || linkedTerminal).trim();
        const existing = safeTerminals.findIndex((item: any) => String(item?.id || '').toUpperCase() === linkedTerminal);
        const nextTerminal = { id: linkedTerminal, name: label || linkedTerminal, location: String(result.terminalCode || ''), isOnline: true, lastSyncAt: new Date().toISOString() };
        if (existing >= 0) safeTerminals[existing] = { ...safeTerminals[existing], ...nextTerminal };
        else safeTerminals.push(nextTerminal);
        localStorage.setItem('pos_terminals_v1', JSON.stringify(safeTerminals));
        window.dispatchEvent(new CustomEvent('pos-terminal-paired', { detail: { terminalId: linkedTerminal, previousTerminalId: previousTerminal, terminals: safeTerminals } }));
      } catch {}
      const linkedCommerceName = String(result.commerceName || '').trim();
      if (linkedCommerceName) {
        try { localStorage.setItem('pos_commerce_name', linkedCommerceName); } catch {}
        try { window.dispatchEvent(new CustomEvent('pos-commerce-name-change', { detail: linkedCommerceName })); } catch {}
      }
      this.initBroadcastChannel();
      this.pairingPromptDismissed = false;
      this.notifyStatus();
      return true;
    } catch {
      this.pairingPromptDismissed = true;
      return false;
    } finally {
      this.isPairingInProgress = false;
    }
  }

  // Deduplication & Sync State
  private lastProcessedMessageId = new Set<string>();
  private lastCatalogTimestamp: number = 0;
  private isSyncingCatalog: boolean = false;


  constructor() {
    this.channelId = this.getChannelId();

    if (typeof window !== 'undefined') {
      this.currentTerminalId = this.getCurrentTerminalIdFromStorage();
      this.initBroadcastChannel();
      this.initNetworkListeners();
      // VPS connection is started by AppProvider after durable catalog hydration.
    }
  }

  private getCurrentTerminalIdFromStorage(): string {
    if (typeof window === 'undefined') return 'TERM-01';
    try {
      const s = sessionStorage.getItem('pos_current_terminal_v1');
      if (s) return normalizeTerminalId(s);
      const l = localStorage.getItem('pos_current_terminal_v1');
      if (l) return normalizeTerminalId(l);
    } catch {}
    const backup = readTerminalBackup();
    if (backup) return normalizeTerminalId(backup.terminalId);
    return 'TERM-01';
  }

  public setTerminalId(terminalId: string) {
    const norm = normalizeTerminalId(terminalId);
    const changed = norm !== this.currentTerminalId;
    this.currentTerminalId = norm;
    this.terminalConfigured = true;
    this.persistPairing(this.channelId, norm, this.getSyncToken());
    if (changed) {
      this.pairingPromptDismissed = false;
      this.notifyStatus();
    }
    this.initVpsSync();
  }

  public getChannelId(): string {
    if (typeof window === 'undefined') return 'pos_default_store';

    try {
      const searchParams = new URLSearchParams(window.location.search);
      const urlChannel = searchParams.get('channel') || searchParams.get('sync_channel');
      if (urlChannel && urlChannel.trim()) {
        const cleanUrlChannel = urlChannel.trim().replace(/[^a-zA-Z0-9_-]/g, '_').toLowerCase();
        localStorage.setItem(STORAGE_SYNC_CHANNEL_KEY, cleanUrlChannel);
        return cleanUrlChannel;
      }
    } catch {}

    const backup = readTerminalBackup();
    if (backup) {
      try { localStorage.setItem(STORAGE_SYNC_CHANNEL_KEY, backup.channelId); } catch {}
      return backup.channelId;
    }

    const saved = localStorage.getItem(STORAGE_SYNC_CHANNEL_KEY);
    if (saved) return saved;

    const cleanHost = getCleanHostIdentifier();
    const defaultTopic = `pos_store_${cleanHost}`;
    localStorage.setItem(STORAGE_SYNC_CHANNEL_KEY, defaultTopic);
    return defaultTopic;
  }

  public setChannelId(newChannel: string) {
    const clean = newChannel.trim().replace(/[^a-zA-Z0-9_-]/g, '_').toLowerCase();
    if (!clean) return;
    this.channelId = clean;
    localStorage.setItem(STORAGE_SYNC_CHANNEL_KEY, clean);
    this.persistPairing(clean, this.currentTerminalId, this.getSyncToken());
    this.initBroadcastChannel();
    this.initVpsSync();
    this.notifyStatus();
  }

  // --------------------------------------------------------------------------
  // 1. LOCAL BROADCAST CHANNEL (Instant 0ms across Tabs / Windows on same PC)
  // --------------------------------------------------------------------------
  private initBroadcastChannel() {
    if (typeof window === 'undefined') return;
    try {
      if (this.broadcastChannel) {
        this.broadcastChannel.close();
      }
      this.broadcastChannel = new BroadcastChannel(`pos_bc_${this.channelId}`);
      this.broadcastChannel.onmessage = (event) => {
        try {
          const syncMsg: SyncMessage = event.data;
          if (syncMsg && typeof syncMsg === 'object' && syncMsg.senderClientId !== CLIENT_ID) {
            this.handleIncomingSyncMessage(syncMsg);
          }
        } catch {}
      };
    } catch {}
  }

  private initNetworkListeners() {
    NetworkService.subscribe((isOnline) => {
      if (isOnline) {
        if (!this.isVpsConnected) this.initVpsSync();
        void this.flushVpsQueue();
      }
      this.notifyStatus();
    });
  }

  // --------------------------------------------------------------------------
  // VPS SERVER RELAY (primary cross-terminal transport; no Firestore operations)
  // Each terminal continues working from its localStorage cache while offline.
  // Outgoing messages are queued locally and delivered in order after reconnect.
  // --------------------------------------------------------------------------
  private getVpsCursorKey(): string {
    return `pos_vps_sync_cursor_v1_${this.channelId}`;
  }

  private getVpsQueueKey(): string {
    return `pos_vps_pending_queue_v1_${this.channelId}`;
  }

  private readVpsQueue(): Promise<SyncMessage[]> {
    return readIndexedDbVpsQueue(this.getVpsQueueKey());
  }


  private async writeVpsQueue(queue: SyncMessage[]): Promise<void> {
    await writeIndexedDbVpsQueue(this.getVpsQueueKey(), queue);
    this.notifyStatus();
  }

  private isQuotaExceededError(error: unknown): boolean {
    const name = (error as { name?: string } | null)?.name;
    return name === 'QuotaExceededError' || name === 'NS_ERROR_DOM_QUOTA_REACHED';
  }

  /**
   * Compact only replaceable snapshots when storage is full. Financial and stock
   * operations are deliberately preserved because they cannot be reconstructed
   * safely from a newer snapshot.
   */
  private compactVpsQueue(queue: SyncMessage[]): SyncMessage[] {
    const replaceableTypes = new Set<SyncMessage['type']>([
      'ACCOUNTS_UPDATED', 'USERS_UPDATED', 'CASH_UPDATED',
      'ARTICLES_UPDATED', 'SYNC_RESPONSE_STATE', 'CUSTOMER_DISPLAY_SYNC',
    ]);
    const latestByType = new Map<SyncMessage['type'], SyncMessage>();
    const compacted: SyncMessage[] = [];
    for (const item of queue) {
      if (replaceableTypes.has(item.type)) {
        latestByType.set(item.type, item);
      } else {
        compacted.push(item);
      }
    }
    // Preserve ordering by timestamp when re-inserting the latest snapshots.
    compacted.push(...Array.from(latestByType.values()));
    compacted.sort((a, b) => a.timestamp - b.timestamp);
    return compacted;
  }

  private syncRequestHeaders(): Record<string, string> {
    return { 'Content-Type': 'application/json', 'X-Sync-Token': this.getSyncToken() };
  }

  private async postVpsMessage(msg: SyncMessage): Promise<boolean> {
    try {
      let outgoing: SyncMessage = msg;
      if (msg.payload?.__deferredLocalCatalog) {
        // Prefer the durable catalog: localStorage may be full or contain an older
        // snapshot after a quota failure/restart.
        let articles: any[] | null = null;
        try { articles = await readDurableArticles(); } catch {}
        if (!Array.isArray(articles) || articles.length === 0) {
          const rawCatalog = localStorage.getItem('pos_articles_v1');
          const parsed = rawCatalog ? JSON.parse(rawCatalog) : [];
          articles = Array.isArray(parsed) ? parsed : null;
        }
        if (!Array.isArray(articles) || articles.length === 0) return false;
        outgoing = { ...msg, payload: { ...msg.payload, articles } };
        delete outgoing.payload.__deferredLocalCatalog;
      }
      const response = await fetch('/api/sync.php?action=publish', {
        method: 'POST',
        headers: this.syncRequestHeaders(),
        body: JSON.stringify({ message: outgoing, channelId: this.channelId }),
      });
      if (!response.ok) return false;
      const result = await response.json().catch(() => null);
      return !!result?.success;
    } catch { return false; }
  }

  private async flushVpsQueue(): Promise<void> {
    if (this.isFlushingVpsQueue || !this.isVpsConnected || typeof navigator !== 'undefined' && !navigator.onLine) return;
    this.isFlushingVpsQueue = true;
    try {
      while (this.isVpsConnected) {
        const queue = await this.readVpsQueue();
        if (!queue.length) break;
        const first = queue[0];
        const ok = await this.postVpsMessage(first);
        if (!ok) {
          this.isVpsConnected = false;
          if (typeof window !== 'undefined' && this.vpsQueueRetryHandle === null) {
            this.vpsQueueRetryHandle = window.setTimeout(() => {
              this.vpsQueueRetryHandle = null;
              this.initVpsSync();
            }, 5000);
          }
          break;
        }
        // Remove only the acknowledged head, preserving messages appended while posting.
        await removeVpsMessage(this.getVpsQueueKey(), first.id);
        await this.refreshPendingCount();
        this.notifyStatus();
      }
    } finally {
      this.isFlushingVpsQueue = false;
      this.notifyStatus();
    }
  }

  private initVpsSync() {
    if (typeof window === 'undefined' || typeof fetch === 'undefined') return;
    if (this.vpsQueueRetryHandle !== null) {
      window.clearTimeout(this.vpsQueueRetryHandle);
      this.vpsQueueRetryHandle = null;
    }

    if (!this.catalogHydrationReady || !this.terminalConfigured || this.vpsStateInFlight) return;
    const syncToken = this.getSyncToken();
    if (syncToken.length < 32) {
      this.isVpsConnected = false;
      this.notifyStatus();
      void this.acquireSyncTokenByPairing().then((linked) => {
        if (linked) this.initVpsSync();
      });
      return;
    }
    this.vpsStateInFlight = true;
    const stateController = new AbortController();
    const stateTimeout = window.setTimeout(() => stateController.abort(), 12000);
    fetch(`/api/sync.php?action=state&channelId=${encodeURIComponent(this.channelId)}&_t=${Date.now()}`, { cache: 'no-store', headers: { 'X-Sync-Token': syncToken }, signal: stateController.signal })
      .then((res) => {
        if (!res.ok) throw new Error('El servidor de sincronización no está disponible');
        return res.json();
      })
      .then(async (state) => {
        this.isVpsConnected = true;
        // Seed the server catalog from this terminal when the relay has no catalog yet.
        // Reverse pending stock deltas in the seed snapshot; the queued sale/purchase events
        // are then replayed once to every terminal, including the server's stock cache.
        if (!Array.isArray(state?.latestArticles) || state.latestArticles.length === 0) {
          try {
            const rawLocalCatalog = localStorage.getItem('pos_articles_v1');
            const localCatalog = rawLocalCatalog ? JSON.parse(rawLocalCatalog) : [];
            if (Array.isArray(localCatalog) && localCatalog.length > 0) {
              const queueForSeed = await this.readVpsQueue();
              const initialStockById = new Map<string, number>();
              for (const queued of queueForSeed) {
                if (queued.type !== 'SALE_PROCESSED' && queued.type !== 'PURCHASE_REGISTERED' && queued.type !== 'STOCK_ADJUSTED') continue;
                for (const delta of queued.payload?.stockDeltas || []) {
                  const id = String(delta?.articleId ?? '');
                  const base = Number(delta?.baseStock);
                  if (id && Number.isFinite(base) && !initialStockById.has(id)) initialStockById.set(id, base);
                }
              }
              const seedCatalog = localCatalog.map((article: any) => {
                const base = initialStockById.get(String(article?.id));
                return base === undefined ? article : { ...article, stock: Math.max(0, base) };
              });
              const seedResponse = await fetch('/api/sync.php?action=init-articles', {
                method: 'POST',
                headers: this.syncRequestHeaders(),
                body: JSON.stringify({ articles: seedCatalog, channelId: this.channelId }),
              });
              if (seedResponse.ok) {
                const seeded = await seedResponse.json().catch(() => null);
                if (seeded?.success) {
                  state.latestArticles = Array.isArray(seeded.latestArticles) ? seeded.latestArticles : seedCatalog;
                  state.latestSeq = Number(seeded.latestSeq ?? state.latestSeq ?? 0);
                  state.lastUpdated = Number(seeded.lastUpdated ?? Date.now());
                }
              }
            }
          } catch {}
        }
        // Bootstrap/reconcile the full catalog before relying on incremental events.
        // A demo-sized local catalog must never replace a substantially fuller server catalog.
        const cursorKey = this.getVpsCursorKey();
        const savedCursor = localStorage.getItem(cursorKey);
        const hadCursor = savedCursor !== null;
        const cursorValue = Number(savedCursor || '0');
        const pendingBeforeConnect = await this.readVpsQueue();
        const rawLocalCatalog = localStorage.getItem('pos_articles_v1');
        let localCatalog: any[] = [];
        try {
          const parsed = rawLocalCatalog ? JSON.parse(rawLocalCatalog) : [];
          if (Array.isArray(parsed)) localCatalog = parsed;
        } catch {}
        const remoteCatalog = Array.isArray(state?.latestArticles) ? state.latestArticles : [];
        const remoteCount = remoteCatalog.length;
        const localCount = localCatalog.length;
        const hasPendingCatalogWrite = pendingBeforeConnect.some((item) =>
          item.type === 'ARTICLES_UPDATED' || item.type === 'SYNC_RESPONSE_STATE' || item.payload?.__deferredLocalCatalog
        );

        // Repair a server that was accidentally initialized with a demo catalog:
        // only promote a clearly fuller local catalog, and only when no unsent
        // operations exist, so a stale snapshot cannot erase/reorder pending work.
        const localCatalogIsClearlyFuller = localCount > 100 && localCount > Math.max(remoteCount * 1.5, remoteCount + 100);
        if (remoteCount > 0 && localCatalogIsClearlyFuller && pendingBeforeConnect.length === 0) {
          console.warn(`[POS sync] El catálogo local (${localCount}) supera ampliamente al del servidor (${remoteCount}); publicando catálogo completo como reparación inicial.`);
          // Treat the existing server snapshot as the baseline; do not replay its old
          // stock events over the already-current local catalog after publishing repair.
          const baselineSeq = Number(state?.latestSeq);
          if (Number.isFinite(baselineSeq) && baselineSeq >= 0) {
            localStorage.setItem(this.getVpsCursorKey(), String(baselineSeq));
          }
          await this.publish('ARTICLES_UPDATED', { articles: localCatalog, reason: 'catalog-bootstrap-repair' });
          // Keep the full local catalog visible; polling will receive the acknowledged
          // catalog event and other terminals will hydrate from the server snapshot.
        } else {
          if (localCatalogIsClearlyFuller && pendingBeforeConnect.length > 0 && this.vpsQueueRetryHandle === null) {
            // Do not overwrite the fuller local catalog while unsent sales/stock changes
            // are waiting. Recheck after the queue has had time to drain.
            this.vpsQueueRetryHandle = window.setTimeout(() => {
              this.vpsQueueRetryHandle = null;
              this.initVpsSync();
            }, 5000);
          }
          const needsCatalogBaseline = !hadCursor || localCount === 0;
          // The server's latestArticles is a full snapshot, not a page of events.
          // It can repair a stale cursor immediately. Overlay only this terminal's
          // unsent stock deltas, then advance the cursor to the snapshot sequence so
          // those already-included server events are not replayed a second time.
          const canReconcileAuthoritativeSnapshot = remoteCount > 0 && !hasPendingCatalogWrite &&
            (!localCatalogIsClearlyFuller || remoteCount >= localCount);

          if (canReconcileAuthoritativeSnapshot) {
            this.lastCatalogTimestamp = state.lastUpdated || Date.now();
            let articlesToApply = remoteCatalog;
            if (pendingBeforeConnect.length > 0) {
              const copy = remoteCatalog.map((article: any) => ({ ...article }));
              const byId = new Map<string, any>(copy.map((article: any) => [String(article.id), article]));
              for (const queued of pendingBeforeConnect) {
                if (queued.type !== 'SALE_PROCESSED' && queued.type !== 'PURCHASE_REGISTERED' && queued.type !== 'STOCK_ADJUSTED') continue;
                for (const delta of queued.payload?.stockDeltas || []) {
                  const article = byId.get(String(delta.articleId));
                  if (article) article.stock = Math.max(0, Number(article.stock || 0) + Number(delta.quantityDelta || 0));
                }
              }
              articlesToApply = copy;
            }
            this.notifyArticlesUpdate(articlesToApply);
            const snapshotSeq = Number(state?.latestSeq);
            if (Number.isFinite(snapshotSeq) && snapshotSeq >= 0) {
              localStorage.setItem(cursorKey, String(snapshotSeq));
            }
          }
        }
        this.notifyStatus();
        this.startVpsPolling();
        void this.flushVpsQueue();
      })
      .catch(() => {
        this.isVpsConnected = false;
        this.notifyStatus();
        if (this.vpsQueueRetryHandle === null) {
          this.vpsQueueRetryHandle = window.setTimeout(() => {
            this.vpsQueueRetryHandle = null;
            this.initVpsSync();
          }, 10000);
        }
      })
      .finally(() => {
        window.clearTimeout(stateTimeout);
        this.vpsStateInFlight = false;
      });
  }

  // Shared hosting often terminates long-lived SSE connections, so use bounded HTTP polling.
  // Keep exactly one polling loop per manager; repeated init/reconnect calls must not
  // create overlapping requests, which can exhaust browser network buffers.
  private startVpsPolling() {
    if (typeof window === 'undefined' || typeof fetch === 'undefined') return;
    if (this.vpsPollingStarted) return;
    this.vpsPollingStarted = true;
    const generation = ++this.vpsPollGeneration;

    const schedule = (delay: number) => {
      if (!this.vpsPollingStarted || generation !== this.vpsPollGeneration) return;
      if (this.vpsPollHandle !== null) window.clearTimeout(this.vpsPollHandle);
      this.vpsPollHandle = window.setTimeout(() => {
        this.vpsPollHandle = null;
        void poll();
      }, delay);
    };

    const poll = async () => {
      if (!this.vpsPollingStarted || generation !== this.vpsPollGeneration) return;
      if (!this.isVpsConnected || !navigator.onLine) {
        schedule(5000);
        return;
      }
      // A prior request can still be settling after a reconnect. Never overlap it.
      if (this.vpsPollInFlight) {
        schedule(1000);
        return;
      }

      this.vpsPollInFlight = true;
      const controller = new AbortController();
      this.vpsPollAbortController = controller;
      const timeoutHandle = window.setTimeout(() => controller.abort(), 15000);
      // A 4s cadence reduces JSON parsing/network wakeups on older shop PCs while
      // keeping cross-terminal changes near real time. Never overlap poll requests.
      let nextDelay = 4000;
      try {
        const cursor = Number(localStorage.getItem(this.getVpsCursorKey()) || '0');
        const response = await fetch(`/api/sync.php?action=poll&channelId=${encodeURIComponent(this.channelId)}&since=${encodeURIComponent(String(cursor))}&limit=25&_t=${Date.now()}`, {
          cache: 'no-store',
          headers: { 'X-Sync-Token': this.getSyncToken() },
          signal: controller.signal,
        });
        if (!this.vpsPollingStarted || generation !== this.vpsPollGeneration) return;
        if (!response.ok) throw new Error('Polling de sincronización falló');
        const result = await response.json();
        if (!this.vpsPollingStarted || generation !== this.vpsPollGeneration) return;
        const events = Array.isArray(result?.events) ? result.events : [];
        let latest = cursor;
        for (const envelope of events) {
          const seq = Number(envelope?.seq);
          const msg: SyncMessage = envelope?.message;
          if (Number.isFinite(seq) && seq > latest) latest = seq;
          if (!msg || !msg.id) continue;
          // Suppress stock-changing echoes from this same terminal; other terminals still apply them.
          const stockChangingEvent = msg.type === 'SALE_PROCESSED' ||
            msg.type === 'PURCHASE_REGISTERED' || msg.type === 'STOCK_ADJUSTED';
          const sameTerminalEcho = normalizeTerminalId(msg.senderTerminalId) ===
            normalizeTerminalId(this.currentTerminalId);
          if (msg.senderClientId !== CLIENT_ID && !(stockChangingEvent && sameTerminalEcho)) {
            this.handleIncomingSyncMessage(msg);
          }
        }
        if (latest > cursor) localStorage.setItem(this.getVpsCursorKey(), String(latest));
        this.isVpsConnected = true;
        this.vpsPollFailureCount = 0;
        void this.flushVpsQueue();
      } catch {
        if (this.vpsPollingStarted && generation === this.vpsPollGeneration) {
          this.isVpsConnected = false;
          this.vpsPollFailureCount = Math.min(this.vpsPollFailureCount + 1, 5);
          // Backoff prevents repeated network failures from creating a tight retry loop.
          // The cursor is only advanced after successfully processing a response.
          nextDelay = Math.min(4000 * Math.pow(2, this.vpsPollFailureCount), 30000);
          this.notifyStatus();
        }
      } finally {
        window.clearTimeout(timeoutHandle);
        this.vpsPollInFlight = false;
        if (this.vpsPollAbortController === controller) this.vpsPollAbortController = null;
      }
      // Background tabs are throttled by browsers; poll less often while hidden.
      // Keep one request in flight and resume the normal cadence when visible.
      if (document.visibilityState === 'hidden') nextDelay = Math.max(nextDelay, 15000);
      schedule(nextDelay);
    };

    schedule(250);
  }

  private cleanupVpsSync() {
    this.vpsPollingStarted = false;
    this.vpsPollGeneration++;
    if (this.vpsPollHandle !== null && typeof window !== 'undefined') {
      window.clearTimeout(this.vpsPollHandle);
      this.vpsPollHandle = null;
    }
    if (this.vpsPollAbortController) {
      try { this.vpsPollAbortController.abort(); } catch {}
      this.vpsPollAbortController = null;
    }
    if (this.vpsEventSource) {
      try { this.vpsEventSource.close(); } catch {}
      this.vpsEventSource = null;
    }
    if (this.vpsQueueRetryHandle !== null && typeof window !== 'undefined') {
      window.clearTimeout(this.vpsQueueRetryHandle);
      this.vpsQueueRetryHandle = null;
    }
    this.isVpsConnected = false;
    this.notifyStatus();
  }

  private async protectPendingLocalStock(incomingArticles: any[]): Promise<any[] | null> {
    if (!Array.isArray(incomingArticles)) return null;
    const pending = await this.readVpsQueue();
    // A pending full catalog edit is newer local intent; let it publish after reconnect.
    if (pending.some((item) => item.type === 'ARTICLES_UPDATED' || item.type === 'SYNC_RESPONSE_STATE')) return null;
    const deltasById = new Map<string, number>();
    for (const item of pending) {
      if (item.type !== 'SALE_PROCESSED' && item.type !== 'PURCHASE_REGISTERED' && item.type !== 'STOCK_ADJUSTED') continue;
      for (const delta of item.payload?.stockDeltas || []) {
        const id = String(delta?.articleId ?? '');
        const amount = Number(delta?.quantityDelta || 0);
        if (!id || !Number.isFinite(amount)) continue;
        deltasById.set(id, (deltasById.get(id) || 0) + amount);
      }
    }
    if (deltasById.size === 0) return incomingArticles;
    return incomingArticles.map((article: any) => {
      const amount = deltasById.get(String(article?.id));
      if (amount === undefined) return article;
      return { ...article, stock: Math.max(0, Number(article?.stock || 0) + amount) };
    });
  }

  private handleIncomingSyncMessage(msg: SyncMessage) {
    if (!msg || !msg.id) return;

    // A terminal can have multiple tabs open, each with a different CLIENT_ID,
    // while sharing the same localStorage. The sale has already changed that
    // shared catalog before publish() broadcasts the event. Applying its delta
    // again in another tab of the SAME terminal double-decrements shared stock.
    // Refresh that tab's in-memory view from the already-updated shared catalog,
    // then stop this stock event here. Events from other terminals still apply.
    const isStockMutation = msg.type === 'SALE_PROCESSED' ||
      msg.type === 'PURCHASE_REGISTERED' || msg.type === 'STOCK_ADJUSTED';
    const isSameTerminalStockEcho = isStockMutation &&
      normalizeTerminalId(msg.senderTerminalId) === normalizeTerminalId(this.currentTerminalId);
    if (isSameTerminalStockEcho) {
      try {
        const raw = localStorage.getItem('pos_articles_v1');
        const articles = raw ? JSON.parse(raw) : null;
        if (Array.isArray(articles) && articles.length > 0) {
          this.notifyArticlesUpdate(articles);
        }
      } catch {}
      return;
    }

    if (this.lastProcessedMessageId.has(msg.id)) return;
    this.lastProcessedMessageId.add(msg.id);
    if (this.lastProcessedMessageId.size > 300) {
      const [first] = this.lastProcessedMessageId;
      this.lastProcessedMessageId.delete(first);
    }

    // Catalog snapshots are used for explicit catalog edits/restores. Sales and purchases
    // use stock deltas so two terminals do not overwrite each other's stock snapshot.
    if ((msg.type === 'SALE_PROCESSED' || msg.type === 'PURCHASE_REGISTERED') && Array.isArray(msg.payload?.stockDeltas) && msg.payload.stockDeltas.length > 0) {
      // StorageService applies these deltas against the terminal's current catalog.
      // Do not also emit a possibly stale full catalog snapshot for the same event.
    } else if ((msg.type === 'SALE_PROCESSED' || msg.type === 'PURCHASE_REGISTERED') && msg.payload?.updatedArticles && Array.isArray(msg.payload.updatedArticles)) {
      void this.protectPendingLocalStock(msg.payload.updatedArticles).then((safeArticles) => {
        if (safeArticles) this.notifyArticlesUpdate(safeArticles);
      });
    } else if ((msg.type === 'ARTICLES_UPDATED' || msg.type === 'SYNC_RESPONSE_STATE') && msg.payload?.articles && Array.isArray(msg.payload.articles)) {
      // Route every catalog snapshot through the same protection path. The storage
      // listener must not separately apply the raw message payload, or it can undo
      // this reconciled snapshot and restore stale stock.
      void this.protectPendingLocalStock(msg.payload.articles).then((safeArticles) => {
        if (safeArticles) this.notifyArticlesUpdate(safeArticles);
      });
    }

    // Deliver to registered listeners
    this.syncListeners.forEach((listener) => {
      try {
        listener(msg);
      } catch {}
    });
  }

  private notifyArticlesUpdate(articles: any[]) {
    if (!Array.isArray(articles)) return;
    this.articlesListeners.forEach((listener) => {
      try {
        listener(articles);
      } catch {}
    });
  }

  // --------------------------------------------------------------------------
  // PUBLIC API - PUBLISH THROUGH THE HOSTING RELAY
  // --------------------------------------------------------------------------
  public async publish(
    type: SyncMessage['type'],
    payload?: any,
    senderTerminalId: string = this.currentTerminalId
  ) {
    const msgId = `${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    const msg: SyncMessage = {
      id: msgId,
      type,
      senderTerminalId: senderTerminalId || this.currentTerminalId,
      senderClientId: CLIENT_ID,
      timestamp: Date.now(),
      payload,
    };

    this.lastProcessedMessageId.add(msg.id);

    // Keep same-PC tabs/windows synchronized immediately, independent of Internet.
    try { this.broadcastChannel?.postMessage(msg); } catch {}

    // The operation is already committed to the local POS store. Queue the exact event
    // before attempting network delivery so a dropped connection cannot silently lose it.
    try {
      const queuedMessage: SyncMessage = JSON.parse(JSON.stringify(msg));
      // Account updates are published separately by StorageService. Do not duplicate the
      // growing account movement ledger inside every sale/purchase queue entry.
      if (queuedMessage.type === 'SALE_PROCESSED' || queuedMessage.type === 'PURCHASE_REGISTERED') {
        if (queuedMessage.payload) {
          delete queuedMessage.payload.updatedAccounts;
          delete queuedMessage.payload.accounts;
          delete queuedMessage.payload.movements;
        }
      }
      // A full catalog is already saved locally. Mark it for materialization at send time
      // rather than duplicating thousands of articles in localStorage's pending queue.
      if ((queuedMessage.type === 'ARTICLES_UPDATED' || queuedMessage.type === 'SYNC_RESPONSE_STATE') && Array.isArray(queuedMessage.payload?.articles)) {
        delete queuedMessage.payload.articles;
        queuedMessage.payload.__deferredLocalCatalog = true;
      }
      // Full-state snapshots supersede older snapshots of the same kind. Customer
      // display is ephemeral: only its newest state is useful, so never let every
      // keystroke/product change accumulate as a permanent pending operation.
      const replaceableTypes = new Set<SyncMessage['type']>([
        'ACCOUNTS_UPDATED', 'USERS_UPDATED', 'CASH_UPDATED',
        'ARTICLES_UPDATED', 'SYNC_RESPONSE_STATE', 'CUSTOMER_DISPLAY_SYNC',
      ]);
      try {
        const appended = await appendVpsMessage(this.getVpsQueueKey(), queuedMessage, replaceableTypes);
        this.latestPendingCount = appended.length;
        this.notifyStatus();
      } catch (firstError) {
        if (!this.isQuotaExceededError(firstError)) throw firstError;
        // Legacy localStorage queues may contain obsolete snapshots from older builds.
        // Compact them in IndexedDB; never discard sales or other non-replaceable events.
        const compacted = this.compactVpsQueue(await this.readVpsQueue());
        await this.writeVpsQueue(compacted);
        this.latestPendingCount = compacted.length;
        try {
          const appended = await appendVpsMessage(this.getVpsQueueKey(), queuedMessage, replaceableTypes);
          this.latestPendingCount = appended.length;
          this.notifyStatus();
        } catch (retryError) {
          if (queuedMessage.type === 'CUSTOMER_DISPLAY_SYNC' && this.isQuotaExceededError(retryError)) {
            this.notifyStatus();
            return;
          }
          throw retryError;
        }
      }
    } catch (error) {
      console.error('[POS sync] No se pudo guardar la operación pendiente localmente.', error);
      this.notifyStatus();
      return;
    }

    if (!this.isVpsConnected && typeof navigator !== 'undefined' && navigator.onLine) {
      this.initVpsSync();
    }
    await this.flushVpsQueue();
  }

  /**
   * Publica una restauración como eventos pequeños y ordenados. Evita guardar el respaldo
   * completo (que puede superar la cuota de localStorage y el límite HTTP del relay) dentro
   * de una sola entrada de la cola. Las listas se envían en fragmentos reintentables.
   */
  public async publishSystemRestore(backupData: any): Promise<boolean> {
    if (!backupData || typeof backupData !== 'object' || typeof navigator !== 'undefined' && !navigator.onLine) return false;
    if (!this.isVpsConnected) {
      this.initVpsSync();
      const startedAt = Date.now();
      while (!this.isVpsConnected && Date.now() - startedAt < 10000) {
        await new Promise<void>((resolve) => window.setTimeout(resolve, 250));
      }
    }
    if (!this.isVpsConnected) return false;

    // Vaciar operaciones anteriores antes de comenzar; no se descartan ni reordenan.
    // Otra publicación local puede estar drenando la cola en paralelo, por eso esperamos
    // a que se confirme su vaciado en vez de asumir que una sola llamada basta.
    const waitForQueueDrain = async (): Promise<boolean> => {
      const startedAt = Date.now();
      while (this.isVpsConnected && (await this.readVpsQueue()).length > 0 && Date.now() - startedAt < 30000) {
        await this.flushVpsQueue();
        await new Promise<void>((resolve) => window.setTimeout(resolve, 100));
      }
      return this.isVpsConnected && (await this.readVpsQueue()).length === 0;
    };
    if (!await waitForQueueDrain()) return false;

    const restoreId = `restore_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
    const metadata: Record<string, any> = {};
    for (const key of ['businessInfo', 'paymentConfig', 'printerConfig', 'keyboardShortcuts', 'darkMode']) {
      if (backupData[key] !== undefined) metadata[key] = backupData[key];
    }
    if (Object.keys(metadata).length > 0) {
      await this.publish('SYSTEM_RESTORE', { restoreId, backupData: metadata, timestamp: Date.now() });
      if (!await waitForQueueDrain()) return false;
    }

    const arrayFields = [
      'users', 'accounts', 'sales', 'purchases', 'terminals',
      'cashShifts', 'cashMovements', 'accountMovements', 'auditLogs',
    ];
    const chunkSize = 100;
    for (const field of arrayFields) {
      const values = backupData[field];
      if (!Array.isArray(values)) continue;
      const total = Math.max(1, Math.ceil(values.length / chunkSize));
      for (let index = 0; index < total; index++) {
        if (!this.isVpsConnected || typeof navigator !== 'undefined' && !navigator.onLine) return false;
        const items = values.slice(index * chunkSize, (index + 1) * chunkSize);
        await this.publish('SYSTEM_RESTORE', {
          restoreId,
          restoreChunk: { field, index, total, items },
          timestamp: Date.now(),
        });
        // Each chunk must be acknowledged before queuing the next one. This keeps the
        // local pending queue bounded even when the backup contains thousands of records.
        if (!await waitForQueueDrain()) return false;
      }
    }
    return true;
  }

  /** Restablecimiento global protegido: solo la terminal principal puede solicitarlo. */
  public async resetAllTerminalsToDemo(articles: any[], confirmation: string): Promise<{ success: boolean; seq?: number; error?: string }> {
    if (!navigator.onLine) return { success: false, error: 'Necesitás conexión a Internet para restaurar todas las terminales.' };
    if (!this.terminalConfigured || !this.channelId) return { success: false, error: 'Esta terminal no está vinculada a un canal de sincronización.' };
    const token = this.getSyncToken();
    if (token.length < 32) return { success: false, error: 'No se encontró el token de sincronización de esta terminal.' };
    try {
      const response = await fetch('/api/sync.php?action=reset-demo', {
        method: 'POST', cache: 'no-store', headers: this.syncRequestHeaders(),
        body: JSON.stringify({ channelId: this.channelId, confirmation, articles }),
      });
      const result = await response.json().catch(() => null);
      if (!response.ok || !result?.success) {
        return { success: false, error: result?.error || 'El servidor no pudo restaurar todas las terminales.' };
      }
      return { success: true, seq: Number(result.seq || 0) };
    } catch {
      return { success: false, error: 'No se pudo contactar al servidor. No se modificaron los datos locales.' };
    }
  }

  public subscribe(listener: SyncListener): () => void {
    this.syncListeners.add(listener);
    return () => this.syncListeners.delete(listener);
  }

  public onSyncMessage(listener: SyncListener): () => void {
    return this.subscribe(listener);
  }

  public onArticlesUpdate(listener: (articles: any[]) => void): () => void {
    this.articlesListeners.add(listener);
    return () => this.articlesListeners.delete(listener);
  }

  public onStatusChange(listener: StatusListener): () => void {
    this.statusListeners.add(listener);
    const status = this.getStatus();
    this.lastStatusSignature = this.getStatusSignature(status);
    listener(status);
    // Read the durable queue once on subscription, not on every status query.
    void this.refreshPendingCount();
    return () => this.statusListeners.delete(listener);
  }

  public connect() {
    this.catalogHydrationReady = true;
    this.initVpsSync();
  }

  public disconnect() {
    this.cleanupVpsSync();
  }

  private latestPendingCount = 0;
  private pendingCountReadInFlight = false;
  // Avoid waking every AppContext subscriber when the sync status is unchanged.
  private lastStatusSignature = ''; 

  private async refreshPendingCount(): Promise<void> {
    if (this.pendingCountReadInFlight) return;
    this.pendingCountReadInFlight = true;
    try {
      const nextCount = (await this.readVpsQueue()).length;
      if (nextCount !== this.latestPendingCount) {
        this.latestPendingCount = nextCount;
        this.notifyStatus();
      }
    } catch {
      // Status is best-effort; queue persistence remains the authoritative state.
    } finally {
      this.pendingCountReadInFlight = false;
    }
  }

  public getStatus(): CloudSyncStatus {
    const status: CloudSyncStatus = {
      isOnline: NetworkService.isConnectedToInternet,
      isConnected: this.isVpsConnected,
      pendingCount: this.latestPendingCount,
      channelId: this.channelId,
      activePeersCount: this.isVpsConnected ? 1 : 0,
      isVpsConnected: this.isVpsConnected,
    };
    return status;
  }

  private getStatusSignature(status: CloudSyncStatus): string {
    return JSON.stringify([status.isOnline, status.isConnected, status.pendingCount, status.channelId, status.activePeersCount]);
  }

  private notifyStatus() {
    const status = this.getStatus();
    const signature = this.getStatusSignature(status);
    if (signature === this.lastStatusSignature) return;
    this.lastStatusSignature = signature;
    this.statusListeners.forEach((listener) => {
      try {
        listener(status);
      } catch {}
    });
  }
}

export const CloudSync = new CloudSyncManager();
