import { 
  Article, 
  User, 
  Sale, 
  Purchase, 
  CurrentAccount, 
  AccountMovement, 
  CashShift, 
  CashMovement, 
  AuditLog, 
  Terminal,
  PaymentConfig,
  CustomerDisplayState,
  BusinessInfo,
  ParkedSale,
  KeyboardShortcutConfig,
  PrinterConfig,
  ExternalServiceSale,
  MerchandiseNotice
} from '../types';
import { CloudSync } from './cloudSync';
import { PeerSync } from './peerSync';
import { generateArgentinaInteroperableQr } from '../utils/emvco';
import { readDurableArticles, writeDurableArticles } from './catalogDurableStore';

export const OFFICIAL_MP_QRS: Record<string, string> = {
  'TERM-01': 'https://www.mercadopago.com/instore/merchant/qr/1364877/4791e696593b478c9b0dba491a631cc75bf1414638744d6ba7af1b5ac3e09b52.png',
  '1': 'https://www.mercadopago.com/instore/merchant/qr/1364877/4791e696593b478c9b0dba491a631cc75bf1414638744d6ba7af1b5ac3e09b52.png',
  'default': 'https://www.mercadopago.com/instore/merchant/qr/1364877/4791e696593b478c9b0dba491a631cc75bf1414638744d6ba7af1b5ac3e09b52.png',
  '1364877': 'https://www.mercadopago.com/instore/merchant/qr/1364877/4791e696593b478c9b0dba491a631cc75bf1414638744d6ba7af1b5ac3e09b52.png',
  'TERM-02': 'https://www.mercadopago.com/instore/merchant/qr/138571396/c7751ca3b3c846a79e3c11169b3e85089cdd53cc283f41d1a008ebafbe0248c8.png',
  '2': 'https://www.mercadopago.com/instore/merchant/qr/138571396/c7751ca3b3c846a79e3c11169b3e85089cdd53cc283f41d1a008ebafbe0248c8.png',
  '138571396': 'https://www.mercadopago.com/instore/merchant/qr/138571396/c7751ca3b3c846a79e3c11169b3e85089cdd53cc283f41d1a008ebafbe0248c8.png',
  'TERM-03': 'https://www.mercadopago.com/instore/merchant/qr/138677030/3cb322f54e7c4706aa278fcd9d9a66bf7fa70f1c468c41f5b91ab0fd1e3827d5.png',
  '3': 'https://www.mercadopago.com/instore/merchant/qr/138677030/3cb322f54e7c4706aa278fcd9d9a66bf7fa70f1c468c41f5b91ab0fd1e3827d5.png',
  '138677030': 'https://www.mercadopago.com/instore/merchant/qr/138677030/3cb322f54e7c4706aa278fcd9d9a66bf7fa70f1c468c41f5b91ab0fd1e3827d5.png',
};

let cachedArticlesMemory: Article[] | null = null;
let cachedCashShiftsMemory: CashShift[] | null = null;
let cachedCashMovementsMemory: CashMovement[] | null = null;
let cachedAccountsMemory: CurrentAccount[] | null = null;
let cachedAccountMovementsMemory: AccountMovement[] | null = null;

// Ledger JSON parsing is expensive on low-end PCs when every sale triggers several
// reads of the same growing localStorage arrays. Cache by the exact serialized value;
// remote restores/sync writes automatically invalidate the cache when the raw value changes.
const salesArrayCache: { raw?: string; value: Sale[] | null } = { value: null };
const purchasesArrayCache: { raw?: string; value: Purchase[] | null } = { value: null };
const auditArrayCache: { raw?: string; value: AuditLog[] | null } = { value: null };

function readCachedArray<T>(key: string, cache: { raw?: string; value: T[] | null }): T[] {
  const raw = localStorage.getItem(key);
  if (raw === null) {
    const empty: T[] = [];
    try { localStorage.setItem(key, '[]'); } catch {}
    cache.raw = '[]';
    cache.value = empty;
    return empty;
  }
  if (cache.value && cache.raw === raw) return cache.value;
  const parsed = JSON.parse(raw) as T[];
  cache.raw = raw;
  cache.value = Array.isArray(parsed) ? parsed : [];
  return cache.value;
}

function writeCachedArray<T>(key: string, value: T[], cache: { raw?: string; value: T[] | null }): void {
  const raw = JSON.stringify(value);
  localStorage.setItem(key, raw);
  cache.raw = raw;
  cache.value = value;
}

// Storage Keys
const STORAGE_KEYS = {
  USERS: 'pos_users_v1',
  ARTICLES: 'pos_articles_v1',
  SALES: 'pos_sales_v1',
  PURCHASES: 'pos_purchases_v1',
  ACCOUNTS: 'pos_accounts_v1',
  MOVEMENTS: 'pos_movements_v1',
  CASH_SHIFTS: 'pos_cash_shifts_v1',
  CASH_MOVEMENTS: 'pos_cash_movements_v1',
  AUDIT_LOGS: 'pos_audit_logs_v1',
  ACTIVE_SHIFT: 'pos_active_cash_shift_v1',
  TERMINALS: 'pos_terminals_v1',
  CURRENT_TERMINAL: 'pos_current_terminal_v1',
  CURRENT_USER: 'pos_current_user_v1',
  OFFLINE_MODE: 'pos_simulated_offline_v1',
  PAYMENT_CONFIG: 'pos_payment_config_v1',
  CUSTOMER_DISPLAY: 'pos_customer_display_state_v1',
  BUSINESS_INFO: 'pos_business_info_v1',
  PARKED_SALES: 'pos_parked_sales_v1',
  KEYBOARD_SHORTCUTS: 'pos_keyboard_shortcuts_v3',
  PRINTER_CONFIG: 'pos_printer_config_v1',
  EXTERNAL_SERVICE_SALES: 'pos_external_service_sales_v1',
  MERCHANDISE_NOTICES: 'pos_merchandise_notices_v1',
  EXTRA_ARTICLES: 'pos_extra_articles_v1',
};

/**
 * Best-effort persistence for growing ledgers. If the browser quota is full,
 * discard only the ephemeral customer-display snapshot and retry once. Never
 * delete sales, catalog, purchases, account/cash movements, audit logs or the
 * offline sync queue to make room.
 */
function persistJsonWithEphemeralRetry(key: string, value: unknown): boolean {
  const serialized = JSON.stringify(value);
  try {
    localStorage.setItem(key, serialized);
    return true;
  } catch (firstError) {
    const errorName = (firstError as { name?: string } | null)?.name;
    const isQuotaError = errorName === 'QuotaExceededError' || errorName === 'NS_ERROR_DOM_QUOTA_REACHED';
    if (!isQuotaError) {
      console.warn(`[POS storage] No se pudo guardar ${key}.`, firstError);
      return false;
    }

    try {
      // This is transient display state, not a financial record. It is rebuilt
      // by the POS display publisher on its next update.
      localStorage.removeItem(STORAGE_KEYS.CUSTOMER_DISPLAY);
      for (let i = localStorage.length - 1; i >= 0; i--) {
        const existingKey = localStorage.key(i);
        if (existingKey && existingKey.startsWith(`${STORAGE_KEYS.CUSTOMER_DISPLAY}_`)) {
          localStorage.removeItem(existingKey);
        }
      }
      localStorage.setItem(key, serialized);
      return true;
    } catch (retryError) {
      console.error(`[POS storage] Cuota local agotada: no se pudo persistir ${key}. No se eliminaron registros históricos.`, retryError);
      return false;
    }
  }
}

export const DEFAULT_KEYBOARD_SHORTCUTS: KeyboardShortcutConfig[] = [
  {
    id: 'sc_focus_search',
    action: 'focus_search',
    label: 'Buscar / Escanear Código',
    key: 'F1',
    description: 'Enfoca el buscador para escanear código de barras o escribir producto',
    category: 'VENTAS'
  },
  {
    id: 'sc_quick_cash',
    action: 'quick_cash',
    label: 'Efectivo',
    key: 'F2',
    description: 'Cobro rápido en Efectivo e inicia cálculo de vuelto',
    category: 'VENTAS'
  },
  {
    id: 'sc_quick_mp',
    action: 'quick_mp',
    label: 'Mercado Pago',
    key: 'F3',
    description: 'Cobro con Mercado Pago QR',
    category: 'VENTAS'
  },
  {
    id: 'sc_quick_card',
    action: 'quick_card',
    label: 'Posnet/Tarjeta',
    key: 'F4',
    description: 'Cobro con Tarjeta / Posnet',
    category: 'VENTAS'
  },
  {
    id: 'sc_quick_transfer',
    action: 'quick_transfer',
    label: 'Transferencia',
    key: 'F5',
    description: 'Cobro con Transferencia bancaria',
    category: 'VENTAS'
  },
  {
    id: 'sc_quick_account',
    action: 'quick_account',
    label: 'Cta. Cte.',
    key: 'F6',
    description: 'Cobro con Cuenta Corriente del cliente',
    category: 'VENTAS'
  },
  {
    id: 'sc_new_article',
    action: 'new_article',
    label: 'Nuevo Artículo (Alta Rápida)',
    key: 'F7',
    description: 'Abre el formulario para ingresar un nuevo artículo al catálogo',
    category: 'INVENTARIO'
  },
  {
    id: 'sc_park_sale',
    action: 'park_sale',
    label: 'Pausar / En Espera',
    key: 'F8',
    description: 'Guarda temporalmente la venta en curso para atender a otro cliente',
    category: 'VENTAS'
  },
  {
    id: 'sc_cash_register',
    action: 'cash_register',
    label: 'Control y Cierre de Caja',
    key: 'F9',
    description: 'Accede al módulo de control de caja, ingresos/egresos y arqueo',
    category: 'CAJA'
  },
  {
    id: 'sc_reprint_ticket',
    action: 'reprint_ticket',
    label: 'Reimprimir Último Ticket',
    key: 'F10',
    description: 'Vuelve a abrir e imprimir el comprobante de la última venta efectuada',
    category: 'VENTAS'
  },
  {
    id: 'sc_cancel',
    action: 'cancel',
    label: 'Cancelar / Vaciar Carrito',
    key: 'Escape',
    description: 'Cierra ventanas modales activas o solicita vaciar el carrito actual',
    category: 'SISTEMA'
  }
];

export const DEFAULT_PRINTER_CONFIG: PrinterConfig = {
  enabled: true,
  printerName: 'Ticketera Térmica POS 80mm',
  paperWidth: '80mm',
  printerType: 'SYSTEM',
  autoPrintOnSale: true,
  silentPrinting: false,
  openCashDrawer: true,
  cutPaper: true,
  copies: 1,
  printBarcode: true,
  printStoreLogo: true,
  headerText: '¡Bienvenidos!',
  footerText: '¡Muchas gracias por su compra!'
};

// Default seed users
const INITIAL_USERS: User[] = [
  {
    id: 'usr_super',
    name: 'Rodrigo Martínez',
    username: 'admin',
    password: '123',
    role: 'SUPER_ADMIN',
    active: true,
    avatarColor: 'bg-indigo-600',
    permissions: {
      canMakeSales: true,
      canMakePurchases: true,
      canManageInventory: true,
      canManageAccounts: true,
      canCloseCashRegister: true,
      canViewHistory: true,
      canManageUsers: true,
      canGiveDiscounts: true,
      canManageSettings: true,
    }
  },
  {
    id: 'usr_owner',
    name: 'Carlos Silva',
    username: 'dueno',
    password: '123',
    role: 'OWNER',
    active: true,
    avatarColor: 'bg-emerald-600',
    permissions: {
      canMakeSales: true,
      canMakePurchases: true,
      canManageInventory: true,
      canManageAccounts: true,
      canCloseCashRegister: true,
      canViewHistory: true,
      canManageUsers: true,
      canGiveDiscounts: true,
      canManageSettings: true,
    }
  },
  {
    id: 'usr_admin',
    name: 'Laura Gómez',
    username: 'laura',
    password: '123',
    role: 'ADMIN',
    active: true,
    avatarColor: 'bg-amber-600',
    permissions: {
      canMakeSales: true,
      canMakePurchases: true,
      canManageInventory: true,
      canManageAccounts: true,
      canCloseCashRegister: true,
      canViewHistory: true,
      canManageUsers: false,
      canGiveDiscounts: true,
      canManageSettings: true,
    }
  },
  {
    id: 'usr_cashier',
    name: 'Juan Pérez',
    username: 'juan',
    password: '123',
    role: 'CASHIER',
    active: true,
    avatarColor: 'bg-sky-600',
    permissions: {
      canMakeSales: true,
      canMakePurchases: false,
      canManageInventory: false,
      canManageAccounts: true,
      canCloseCashRegister: true,
      canViewHistory: false,
      canManageUsers: false,
      canGiveDiscounts: false,
      canManageSettings: false,
    }
  }
];

// Initial seed articles with realistic barcodes and brands
const INITIAL_ARTICLES: Article[] = [
  {
    id: 'art_1',
    barcode: '7791234567890',
    name: 'Café Tostado en Granos 500g',
    brand: 'La Virginia',
    category: 'Almacén',
    costPrice: 4200,
    salePrice: 6500,
    stock: 24,
    minStock: 8,
    unit: 'Unidad',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'art_2',
    barcode: '7799876543210',
    name: 'Leche Entera Larga Vida 1L',
    brand: 'La Serenísima',
    category: 'Lácteos',
    costPrice: 1100,
    salePrice: 1650,
    stock: 45,
    minStock: 15,
    unit: 'Unidad',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'art_3',
    barcode: '7790012345678',
    name: 'Galletitas Chocolinas 250g',
    brand: 'Bagley',
    category: 'Galletitas',
    costPrice: 1400,
    salePrice: 2100,
    stock: 5, // LOW STOCK FOR ALERT
    minStock: 10,
    unit: 'Paquete',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'art_4',
    barcode: '7795554443332',
    name: 'Gaseosa Cola 2.25L Retornable',
    brand: 'Coca-Cola',
    category: 'Bebidas',
    costPrice: 2200,
    salePrice: 3200,
    stock: 32,
    minStock: 12,
    unit: 'Botella',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'art_5',
    barcode: '7797778889991',
    name: 'Aceite de Girasol 1.5L',
    brand: 'Natura',
    category: 'Aceites',
    costPrice: 2600,
    salePrice: 3800,
    stock: 18,
    minStock: 6,
    unit: 'Botella',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'art_6',
    barcode: '7793332221110',
    name: 'Yerba Mate Especial 1kg',
    brand: 'Playadito',
    category: 'Infusiones',
    costPrice: 3100,
    salePrice: 4700,
    stock: 3, // LOW STOCK
    minStock: 8,
    unit: 'Paquete',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'art_7',
    barcode: '7798881112223',
    name: 'Arroz Largo Fino 1kg',
    brand: 'Gallo Oro',
    category: 'Almacén',
    costPrice: 1500,
    salePrice: 2250,
    stock: 28,
    minStock: 10,
    unit: 'Paquete',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'art_8',
    barcode: '7796665554441',
    name: 'Detergente Concentrado 750ml',
    brand: 'Magistral',
    category: 'Limpieza',
    costPrice: 1900,
    salePrice: 2900,
    stock: 14,
    minStock: 5,
    unit: 'Unidad',
    updatedAt: new Date().toISOString(),
  }
];

// Initial seed accounts (Clients & Suppliers)
const INITIAL_ACCOUNTS: CurrentAccount[] = [
  {
    id: 'acc_cli_1',
    type: 'CLIENT',
    name: 'Martín Almada (Restaurante El Faro)',
    documentNumber: '30-71458962-4',
    phone: '+54 9 11 4455-8899',
    email: 'compras@elfaro.com.ar',
    creditLimit: 250000,
    currentBalance: 48500, // Debts
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'acc_cli_2',
    type: 'CLIENT',
    name: 'Sofía Valenzuela (Panadería Central)',
    documentNumber: '27-35698412-8',
    phone: '+54 9 11 5566-2211',
    email: 'sofi.panaderia@gmail.com',
    creditLimit: 150000,
    currentBalance: 12400,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'acc_sup_1',
    type: 'SUPPLIER',
    name: 'Distribuidora Mayorista del Plata S.A.',
    documentNumber: '30-68954125-9',
    phone: '+54 11 4987-1234',
    email: 'pedidos@delplata.com.ar',
    creditLimit: 1000000,
    currentBalance: 180000, // We owe them
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'acc_sup_2',
    type: 'SUPPLIER',
    name: 'Lácteos y Bebidas Unidas SRL',
    documentNumber: '30-55489721-3',
    phone: '+54 11 4123-9876',
    email: 'contacto@lacteosunidas.com',
    creditLimit: 800000,
    currentBalance: 0,
    updatedAt: new Date().toISOString(),
  }
];

// Initial Terminals
export const INITIAL_TERMINALS: Terminal[] = [
  {
    id: 'TERM-01',
    name: 'Terminal 01 - Caja Principal',
    location: 'Mostrador Entrada',
    isOnline: true,
    lastSyncAt: new Date().toISOString(),
  },
  {
    id: 'TERM-02',
    name: 'Terminal 02 - Salón Ventas',
    location: 'Pasillo Central',
    isOnline: true,
    lastSyncAt: new Date().toISOString(),
  },
  {
    id: 'TERM-03',
    name: 'Terminal 03 - Móvil / Depósito',
    location: 'Depósito Mercadería',
    isOnline: true,
    lastSyncAt: new Date().toISOString(),
  }
];

// Helper to broadcast changes across tabs/windows in real time
let broadcastChannel: BroadcastChannel | null = null;
const localSyncListeners = new Set<(event: { type: string; payload?: any }) => void>();

try {
  if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
    broadcastChannel = new BroadcastChannel('pos_system_sync');
    broadcastChannel.addEventListener('message', (e: MessageEvent) => {
      if (e.data && e.data.type) {
        localSyncListeners.forEach((fn) => {
          try {
            fn(e.data);
          } catch {}
        });
        if (e.data.type === 'SYSTEM_RESET') {
          // Refresh any other tab/window sharing this terminal's localStorage after a factory reset.
          window.setTimeout(() => window.location.reload(), 500);
        }
      }
    });
  }
} catch {
  // Graceful fallback
}

// Receive real-time changes from other terminals via CloudSync
if (typeof window !== 'undefined') {
  CloudSync.onSyncMessage((msg) => {
    try {
      if (msg.type === 'SYSTEM_RESET') {
        StorageService.resetToDemo(Array.isArray(msg.payload?.articles) ? msg.payload.articles : undefined);
        // Allow the polling loop to persist the reset-event cursor before reloading this terminal.
        window.setTimeout(() => window.location.reload(), 500);
        return;
      }
      if (msg.type === 'SYNC_STATE_SNAPSHOT') {
        if (msg.payload?.accounts && Array.isArray(msg.payload.accounts)) {
          cachedAccountsMemory = msg.payload.accounts;
          localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(msg.payload.accounts));
        }
        if (msg.payload?.movements && Array.isArray(msg.payload.movements)) {
          cachedAccountMovementsMemory = msg.payload.movements;
          localStorage.setItem(STORAGE_KEYS.MOVEMENTS, JSON.stringify(msg.payload.movements));
        }
        StorageService.broadcast('ACCOUNTS_UPDATED', msg.payload);
      } else if (msg.type === 'SALE_PROCESSED') {
        const { sale, updatedArticles, updatedAccounts } = msg.payload || {};
        if (sale) {
          const rawSales = localStorage.getItem(STORAGE_KEYS.SALES);
          const sales: Sale[] = rawSales ? JSON.parse(rawSales) : [];
          if (!sales.some((s) => s.id === sale.id)) {
            sales.unshift(sale);
            localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify(sales));
          }
        }
        if (Array.isArray(msg.payload?.stockDeltas) && msg.payload.stockDeltas.length > 0) {
          // Always prefer deltas over a full snapshot when both are present.
          // Snapshots can be stale if two terminals sell/edit at nearly the same time.
          const currentArticles = StorageService.getArticles();
          msg.payload.stockDeltas.forEach((delta: any) => {
            const idx = currentArticles.findIndex((a: any) => String(a.id) === String(delta.articleId));
            const amount = Number(delta.quantityDelta);
            if (idx !== -1 && Number.isFinite(amount)) {
              currentArticles[idx].stock = Math.max(0, Number(currentArticles[idx].stock || 0) + amount);
              currentArticles[idx].updatedAt = new Date().toISOString();
            }
          });
          cachedArticlesMemory = currentArticles;
          localStorage.setItem(STORAGE_KEYS.ARTICLES, JSON.stringify(currentArticles));
          void writeDurableArticles(currentArticles).catch((error) => console.error('[POS storage] No se pudo guardar stock de venta recibido en IndexedDB.', error));
        } else if (updatedArticles && Array.isArray(updatedArticles)) {
          cachedArticlesMemory = updatedArticles;
          localStorage.setItem(STORAGE_KEYS.ARTICLES, JSON.stringify(updatedArticles));
        } else if (sale && Array.isArray(sale.items)) {
          const currentArticles = StorageService.getArticles();
          sale.items.forEach((it: any) => {
            const idx = currentArticles.findIndex((a: any) => a.id === it.articleId);
            if (idx !== -1) {
              currentArticles[idx].stock = Math.max(0, currentArticles[idx].stock - (it.quantity || 1));
              currentArticles[idx].updatedAt = new Date().toISOString();
            }
          });
          cachedArticlesMemory = currentArticles;
          localStorage.setItem(STORAGE_KEYS.ARTICLES, JSON.stringify(currentArticles));
          void writeDurableArticles(currentArticles).catch((error) => console.error('[POS storage] No se pudo guardar catálogo recibido en IndexedDB.', error));
        }
        if (updatedAccounts && Array.isArray(updatedAccounts)) {
          cachedAccountsMemory = updatedAccounts;
          localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(updatedAccounts));
        }
        StorageService.broadcast('REMOTE_SALE_RECEIVED', msg.payload);
        StorageService.broadcast('ARTICLES_UPDATED', { articles: updatedArticles || cachedArticlesMemory });
      } else if (msg.type === 'STOCK_ADJUSTED') {
        // Manual inventory adjustments are transmitted as deltas, never as a stale full catalog.
        const deltas = msg.payload?.stockDeltas;
        if (Array.isArray(deltas)) {
          const currentArticles = StorageService.getArticles();
          deltas.forEach((delta: any) => {
            const idx = currentArticles.findIndex((a: any) => String(a.id) === String(delta.articleId));
            const amount = Number(delta.quantityDelta);
            if (idx !== -1 && Number.isFinite(amount)) {
              currentArticles[idx].stock = Math.max(0, Number(currentArticles[idx].stock || 0) + amount);
              currentArticles[idx].updatedAt = new Date().toISOString();
            }
          });
          cachedArticlesMemory = currentArticles;
          try { localStorage.setItem(STORAGE_KEYS.ARTICLES, JSON.stringify(currentArticles)); } catch {}
          void writeDurableArticles(currentArticles).catch((error) => console.error('[POS storage] No se pudo guardar ajuste remoto en IndexedDB.', error));
          StorageService.broadcast('ARTICLES_UPDATED', { articles: currentArticles, stockAdjustment: true });
        }
      } else if (msg.type === 'ARTICLES_UPDATED' || msg.type === 'SYNC_RESPONSE_STATE') {
        // Catalog snapshots are reconciled by CloudSync.protectPendingLocalStock()
        // and delivered through onArticlesUpdate(). Do not apply msg.payload.articles
        // here as well: the raw payload may contain an old stock value and overwrite
        // the reconciled catalog moments later.
      } else if (msg.type === 'SYNC_REQUEST_STATE') {
        const currentArticles = StorageService.getArticles();
        if (currentArticles && currentArticles.length > 0) {
          CloudSync.publish('SYNC_RESPONSE_STATE', { articles: currentArticles }, StorageService.getCurrentTerminalId());
        }
      } else if (msg.type === 'BUSINESS_INFO_UPDATED') {
        if (msg.payload?.businessInfo) {
          try {
            localStorage.setItem(STORAGE_KEYS.BUSINESS_INFO, JSON.stringify(msg.payload.businessInfo));
            StorageService.broadcast('BUSINESS_INFO_CHANGED', { remote: true });
            window.dispatchEvent(new CustomEvent('pos_business_info_changed', { detail: msg.payload.businessInfo }));
          } catch {}
        }
      } else if (msg.type === 'PRINTER_CONFIG_UPDATED') {
        if (msg.payload?.config) {
          try {
            localStorage.setItem(STORAGE_KEYS.PRINTER_CONFIG, JSON.stringify(msg.payload.config));
            StorageService.broadcast('PRINTER_CONFIG_UPDATED', { config: msg.payload.config, remote: true });
            window.dispatchEvent(new CustomEvent('pos_printer_config_updated', { detail: msg.payload.config }));
          } catch {}
        }
      } else if (msg.type === 'KEYBOARD_SHORTCUTS_UPDATED') {
        if (Array.isArray(msg.payload?.shortcuts)) {
          try {
            localStorage.setItem(STORAGE_KEYS.KEYBOARD_SHORTCUTS, JSON.stringify(msg.payload.shortcuts));
            StorageService.broadcast('SHORTCUTS_UPDATED', { shortcuts: msg.payload.shortcuts, remote: true });
            window.dispatchEvent(new CustomEvent('pos_keyboard_shortcuts_updated', { detail: msg.payload.shortcuts }));
          } catch {}
        }
      } else if (msg.type === 'USERS_UPDATED') {
        // Users and permissions are shared between terminals. Apply remote state locally
        // without calling saveUsers(), which would publish the same event back to the relay.
        if (Array.isArray(msg.payload?.users)) {
          try {
            localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(msg.payload.users));
            StorageService.broadcast('USERS_UPDATED', { users: msg.payload.users, remote: true });
          } catch {}
        }
      } else if (msg.type === 'ACCOUNTS_UPDATED') {
        // Keep the in-memory caches in sync with localStorage before notifying React.
        // getAccounts()/getAccountMovements() prefer these caches, so updating only
        // localStorage made the remote balance appear stale until a full page reload.
        if (Array.isArray(msg.payload?.accounts)) {
          cachedAccountsMemory = msg.payload.accounts;
          try { localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(msg.payload.accounts)); } catch {}
        }
        if (Array.isArray(msg.payload?.movements)) {
          cachedAccountMovementsMemory = msg.payload.movements;
          try { localStorage.setItem(STORAGE_KEYS.MOVEMENTS, JSON.stringify(msg.payload.movements)); } catch {}
        }
        StorageService.broadcast('ACCOUNTS_UPDATED', msg.payload);
      } else if (msg.type === 'CASH_UPDATED') {
        if (msg.payload?.cashShifts) {
          localStorage.setItem(STORAGE_KEYS.CASH_SHIFTS, JSON.stringify(msg.payload.cashShifts));
        }
        if (msg.payload?.cashMovements) {
          localStorage.setItem(STORAGE_KEYS.CASH_MOVEMENTS, JSON.stringify(msg.payload.cashMovements));
        }
        StorageService.broadcast('CASH_SHIFTS_UPDATED', msg.payload);
      } else if (msg.type === 'HISTORY_UPDATED') {
        const log = msg.payload?.log as AuditLog | undefined;
        if (log && log.id) {
          const currentLogs = StorageService.getAuditLogs();
          if (!currentLogs.some((item) => item.id === log.id)) {
            const logs = [log, ...currentLogs].slice(0, 500);
            writeCachedArray(STORAGE_KEYS.AUDIT_LOGS, logs, auditArrayCache);
            StorageService.broadcast('AUDIT_LOGS_UPDATED', { log });
          }
        }
      } else if (msg.type === 'PURCHASE_REGISTERED') {
        if (msg.payload?.purchase) {
          const currentPurchases = StorageService.getPurchases();
          if (!currentPurchases.some((p) => p.id === msg.payload.purchase.id)) {
            const purchases = [msg.payload.purchase, ...currentPurchases];
            writeCachedArray(STORAGE_KEYS.PURCHASES, purchases, purchasesArrayCache);
          }
        }
        if (Array.isArray(msg.payload?.stockDeltas) && msg.payload.stockDeltas.length > 0) {
          // Delta-first prevents a stale purchase snapshot from restoring old stock.
          const currentArticles = StorageService.getArticles();
          msg.payload.stockDeltas.forEach((delta: any) => {
            const idx = currentArticles.findIndex((a: any) => String(a.id) === String(delta.articleId));
            const amount = Number(delta.quantityDelta);
            if (idx !== -1 && Number.isFinite(amount)) {
              currentArticles[idx].stock = Math.max(0, Number(currentArticles[idx].stock || 0) + amount);
              currentArticles[idx].updatedAt = new Date().toISOString();
            }
          });
          cachedArticlesMemory = currentArticles;
          localStorage.setItem(STORAGE_KEYS.ARTICLES, JSON.stringify(currentArticles));
          void writeDurableArticles(currentArticles).catch((error) => console.error('[POS storage] No se pudo guardar compra recibida en IndexedDB.', error));
        } else if (msg.payload?.updatedArticles && Array.isArray(msg.payload.updatedArticles)) {
          localStorage.setItem(STORAGE_KEYS.ARTICLES, JSON.stringify(msg.payload.updatedArticles));
          try { cachedArticlesMemory = msg.payload.updatedArticles; } catch {}
          void writeDurableArticles(msg.payload.updatedArticles).catch((error) => console.error('[POS storage] No se pudo guardar catálogo de compra en IndexedDB.', error));
        }
        StorageService.broadcast('PURCHASE_REGISTERED', msg.payload);
      } else if (msg.type === 'TERMINALS_UPDATED') {
        if (msg.payload?.terminals && Array.isArray(msg.payload.terminals)) {
          localStorage.setItem(STORAGE_KEYS.TERMINALS, JSON.stringify(msg.payload.terminals));
          StorageService.broadcast('TERMINALS_UPDATED', msg.payload);
        }
      } else if (msg.type === 'CUSTOMER_DISPLAY_SYNC') {
        if (msg.payload?.state) {
          localStorage.setItem(STORAGE_KEYS.CUSTOMER_DISPLAY, JSON.stringify(msg.payload.state));
          // A customer-display sync may contain a stale paymentConfig from another terminal.
          // Never persist it over this terminal's own Mercado Pago/POS configuration.
          StorageService.broadcast('CUSTOMER_DISPLAY_SYNC', msg.payload.state);
          window.dispatchEvent(new CustomEvent('pos_customer_display_event', { detail: msg.payload.state }));
        }
      } else if (msg.type === 'MERCHANDISE_NOTICE_SENT') {
        if (msg.payload?.notice) {
          const raw = localStorage.getItem(STORAGE_KEYS.MERCHANDISE_NOTICES);
          const notices: MerchandiseNotice[] = raw ? JSON.parse(raw) : [];
          if (!notices.some(n => n.id === msg.payload.notice.id)) {
            notices.unshift(msg.payload.notice);
            localStorage.setItem(STORAGE_KEYS.MERCHANDISE_NOTICES, JSON.stringify(notices));
          }
          StorageService.broadcast('MERCHANDISE_NOTICE_RECEIVED', msg.payload.notice);
          window.dispatchEvent(new CustomEvent('pos_merchandise_notice_event', { detail: msg.payload.notice }));
        }
      } else if (msg.type === 'MERCHANDISE_NOTICE_STATUS') {
        if (msg.payload?.noticeId) {
          const raw = localStorage.getItem(STORAGE_KEYS.MERCHANDISE_NOTICES);
          const notices: MerchandiseNotice[] = raw ? JSON.parse(raw) : [];
          const idx = notices.findIndex(n => n.id === msg.payload.noticeId);
          if (idx !== -1) {
            notices[idx] = {
              ...notices[idx],
              status: msg.payload.status,
              startedAt: msg.payload.startedAt || notices[idx].startedAt,
              completedAt: msg.payload.completedAt || notices[idx].completedAt,
              completedByUserName: msg.payload.completedByUserName || notices[idx].completedByUserName,
              completedByTerminalId: msg.payload.completedByTerminalId || notices[idx].completedByTerminalId,
            };
            localStorage.setItem(STORAGE_KEYS.MERCHANDISE_NOTICES, JSON.stringify(notices));
            StorageService.broadcast('MERCHANDISE_NOTICE_UPDATED', notices[idx]);
            window.dispatchEvent(new CustomEvent('pos_merchandise_notice_event', { detail: notices[idx] }));
          }
        }
      } else if (msg.type === 'SYSTEM_RESTORE') {
        const chunk = msg.payload?.restoreChunk;
        if (chunk && typeof msg.payload?.restoreId === 'string' && typeof chunk.field === 'string' && Array.isArray(chunk.items)) {
          const restoreId = String(msg.payload.restoreId);
          const field = String(chunk.field);
          const index = Number(chunk.index);
          const total = Number(chunk.total);
          const fieldMap: Record<string, string> = {
            users: STORAGE_KEYS.USERS,
            accounts: STORAGE_KEYS.ACCOUNTS,
            sales: STORAGE_KEYS.SALES,
            purchases: STORAGE_KEYS.PURCHASES,
            terminals: STORAGE_KEYS.TERMINALS,
            cashShifts: STORAGE_KEYS.CASH_SHIFTS,
            cashMovements: STORAGE_KEYS.CASH_MOVEMENTS,
            accountMovements: STORAGE_KEYS.MOVEMENTS,
            auditLogs: STORAGE_KEYS.AUDIT_LOGS,
          };
          const targetKey = fieldMap[field];
          if (targetKey && Number.isInteger(index) && index >= 0 && Number.isInteger(total) && total > 0 && index < total) {
            const activeRestoreKey = 'pos_restore_active_id_v1';
            const activeRestore = localStorage.getItem(activeRestoreKey);
            const markerKey = `pos_restore_applied_v1_${restoreId}_${field}`;
            const lastIndex = Number(localStorage.getItem(markerKey) ?? '-1');
            // Index zero starts a new replacement. Later fragments append only in sequence;
            // duplicate fragments (for example, another tab polling the same relay) are ignored.
            if (index === 0 && lastIndex < 0) {
              if (activeRestore !== restoreId) localStorage.setItem(activeRestoreKey, restoreId);
              localStorage.setItem(targetKey, JSON.stringify(chunk.items));
              localStorage.setItem(markerKey, '0');
            } else if (activeRestore === restoreId && index > lastIndex && index === lastIndex + 1) {
              const raw = localStorage.getItem(targetKey);
              const current = raw ? JSON.parse(raw) : [];
              const combined = Array.isArray(current) ? current.concat(chunk.items) : chunk.items;
              localStorage.setItem(targetKey, JSON.stringify(combined));
              localStorage.setItem(markerKey, String(index));
            }
            if (field === 'accounts') {
              try { cachedAccountsMemory = JSON.parse(localStorage.getItem(STORAGE_KEYS.ACCOUNTS) || '[]'); } catch {}
            } else if (field === 'accountMovements') {
              try { cachedAccountMovementsMemory = JSON.parse(localStorage.getItem(STORAGE_KEYS.MOVEMENTS) || '[]'); } catch {}
            } else if (field === 'cashShifts') {
              try { cachedCashShiftsMemory = JSON.parse(localStorage.getItem(STORAGE_KEYS.CASH_SHIFTS) || '[]'); } catch {}
            } else if (field === 'cashMovements') {
              try { cachedCashMovementsMemory = JSON.parse(localStorage.getItem(STORAGE_KEYS.CASH_MOVEMENTS) || '[]'); } catch {}
            }
            if (index === total - 1) StorageService.broadcast('SYSTEM_RESTORE', { restoreId, field, index, total });
            if (field === 'users' && index === total - 1) {
              StorageService.broadcast('USERS_UPDATED', { users: JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]'), remote: true });
            }
            if ((field === 'accounts' || field === 'accountMovements') && index === total - 1) {
              StorageService.broadcast('ACCOUNTS_UPDATED', {
                accounts: cachedAccountsMemory || StorageService.getAccounts(),
                movements: cachedAccountMovementsMemory || StorageService.getAccountMovements(),
              });
            }
            if ((field === 'cashShifts' || field === 'cashMovements') && index === total - 1) {
              StorageService.broadcast('CASH_SHIFTS_UPDATED', {
                cashShifts: cachedCashShiftsMemory || StorageService.getCashShifts(),
                cashMovements: cachedCashMovementsMemory || StorageService.getCashMovements(),
              });
            }
          }
        }
        const { backupData } = msg.payload || {};
        if (backupData) {
          if (backupData.businessInfo) {
            localStorage.setItem(STORAGE_KEYS.BUSINESS_INFO, JSON.stringify(backupData.businessInfo));
            StorageService.broadcast('BUSINESS_INFO_CHANGED', { remote: true });
            window.dispatchEvent(new CustomEvent('pos_business_info_changed', { detail: backupData.businessInfo }));
          }
          if (backupData.paymentConfig) StorageService.savePaymentConfig(backupData.paymentConfig);
          if (backupData.printerConfig) {
            localStorage.setItem(STORAGE_KEYS.PRINTER_CONFIG, JSON.stringify(backupData.printerConfig));
            StorageService.broadcast('PRINTER_CONFIG_UPDATED', { config: backupData.printerConfig, remote: true });
            window.dispatchEvent(new CustomEvent('pos_printer_config_updated', { detail: backupData.printerConfig }));
          }
          if (Array.isArray(backupData.keyboardShortcuts)) {
            localStorage.setItem(STORAGE_KEYS.KEYBOARD_SHORTCUTS, JSON.stringify(backupData.keyboardShortcuts));
            StorageService.broadcast('SHORTCUTS_UPDATED', { shortcuts: backupData.keyboardShortcuts, remote: true });
            window.dispatchEvent(new CustomEvent('pos_keyboard_shortcuts_updated', { detail: backupData.keyboardShortcuts }));
          }
          if (typeof backupData.darkMode === 'boolean') {
            localStorage.setItem('pos_dark_mode', String(backupData.darkMode));
            document.documentElement.classList.toggle('dark', backupData.darkMode);
            window.dispatchEvent(new CustomEvent('pos_theme_restored', { detail: { darkMode: backupData.darkMode } }));
          }
          if (backupData.users && Array.isArray(backupData.users)) StorageService.saveUsers(backupData.users, false);
          if (backupData.accounts) StorageService.saveAccounts(backupData.accounts);
          if (backupData.sales) localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify(backupData.sales));
          if (backupData.purchases) localStorage.setItem(STORAGE_KEYS.PURCHASES, JSON.stringify(backupData.purchases));
          if (backupData.terminals) localStorage.setItem(STORAGE_KEYS.TERMINALS, JSON.stringify(backupData.terminals));
          if (backupData.cashShifts) localStorage.setItem(STORAGE_KEYS.CASH_SHIFTS, JSON.stringify(backupData.cashShifts));
          if (backupData.cashMovements) localStorage.setItem(STORAGE_KEYS.CASH_MOVEMENTS, JSON.stringify(backupData.cashMovements));
          if (backupData.accountMovements) localStorage.setItem(STORAGE_KEYS.MOVEMENTS, JSON.stringify(backupData.accountMovements));
          if (Array.isArray(backupData.auditLogs)) localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(backupData.auditLogs));
          StorageService.broadcast('SYSTEM_RESTORE', backupData);
          if (backupData.accounts) {
            StorageService.broadcast('ACCOUNTS_UPDATED', { accounts: backupData.accounts, movements: backupData.accountMovements });
          }
        }
      }
    } catch {
      // ignore sync receiver error
    }
  });
}

let customerDisplaySequence = Date.now();
const isLocalDevHost = typeof window !== 'undefined' && 
  (window.location.hostname === 'localhost' || 
   window.location.hostname === '127.0.0.1' || 
   window.location.port === '3000' ||
   /^192\.168\./.test(window.location.hostname) ||
   /^10\./.test(window.location.hostname));

let isCustomerDisplayApiSupported: boolean | null = isLocalDevHost ? null : false;

export const StorageService = {
  // Channel sync
  subscribeToSync(callback: (event: { type: string; payload?: any }) => void) {
    localSyncListeners.add(callback);
    return () => {
      localSyncListeners.delete(callback);
    };
  },

  broadcast(type: string, payload?: any) {
    const event = { type, payload, timestamp: Date.now() };
    // 1. Notify local in-window listeners immediately
    localSyncListeners.forEach((fn) => {
      try {
        fn(event);
      } catch {}
    });
    // 2. Broadcast across tabs and windows
    try {
      broadcastChannel?.postMessage(event);
    } catch {
      // ignore
    }
  },

  // Cloud Sync Channel access
  getCloudSyncChannel(): string {
    return CloudSync.getChannelId();
  },

  setCloudSyncChannel(channel: string) {
    CloudSync.setChannelId(channel);
    this.broadcast('CLOUD_CHANNEL_CHANGED', { channel });
  },

  // Offline mode simulation
  isOfflineMode(): boolean {
    const val = localStorage.getItem(STORAGE_KEYS.OFFLINE_MODE);
    return val === 'true';
  },

  setOfflineMode(offline: boolean) {
    localStorage.setItem(STORAGE_KEYS.OFFLINE_MODE, offline ? 'true' : 'false');
    this.broadcast('OFFLINE_TOGGLED', { offline });
  },

  // Terminals
  getTerminals(): Terminal[] {
    const raw = localStorage.getItem(STORAGE_KEYS.TERMINALS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.TERMINALS, JSON.stringify(INITIAL_TERMINALS));
      return INITIAL_TERMINALS;
    }
    return JSON.parse(raw);
  },

  saveTerminals(terminals: Terminal[]) {
    localStorage.setItem(STORAGE_KEYS.TERMINALS, JSON.stringify(terminals));
    this.broadcast('TERMINALS_UPDATED', { terminals });
    CloudSync.publish('TERMINALS_UPDATED', { terminals }, this.getCurrentTerminalId());
  },

  getCurrentTerminalId(): string {
    if (typeof window !== 'undefined') {
      const sessionVal = sessionStorage.getItem(STORAGE_KEYS.CURRENT_TERMINAL);
      if (sessionVal) return sessionVal;
    }
    return localStorage.getItem(STORAGE_KEYS.CURRENT_TERMINAL) || 'TERM-01';
  },

  setCurrentTerminalId(terminalId: string) {
    if (typeof window !== 'undefined') {
      sessionStorage.setItem(STORAGE_KEYS.CURRENT_TERMINAL, terminalId);
    }
    localStorage.setItem(STORAGE_KEYS.CURRENT_TERMINAL, terminalId);
    this.broadcast('TERMINAL_CHANGED', { terminalId });
  },

  // Users
  getUsers(): User[] {
    const raw = localStorage.getItem(STORAGE_KEYS.USERS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(INITIAL_USERS));
      return INITIAL_USERS;
    }
    try {
      const parsed: User[] = JSON.parse(raw);
      return parsed.map(u => ({
        ...u,
        username: u.username || u.name.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 8) || 'usuario',
        password: u.password || '123'
      }));
    } catch {
      return INITIAL_USERS;
    }
  },

  saveUsers(users: User[], syncToCloud: boolean = true) {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    this.broadcast('USERS_UPDATED', { users });
    if (syncToCloud) {
      void CloudSync.publish('USERS_UPDATED', { users }, this.getCurrentTerminalId());
    }
  },

  deleteUser(userId: string): boolean {
    const users = this.getUsers();
    const filtered = users.filter(u => u.id !== userId);
    if (filtered.length === 0) {
      // Fallback: keep at least one admin
      filtered.push(INITIAL_USERS[0]);
    }
    this.saveUsers(filtered);
    const current = this.getCurrentUser();
    if (current.id === userId) {
      this.setCurrentUser(filtered[0]);
    }
    return true;
  },

  getCurrentUser(): User {
    const raw = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    if (raw) {
      try {
        return JSON.parse(raw);
      } catch {}
    }
    return INITIAL_USERS[0]; // default Super Admin
  },

  setCurrentUser(user: User) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    this.broadcast('CURRENT_USER_CHANGED', { userId: user.id });
  },

  // Articles & Inventory
  getArticles(): Article[] {
    if (cachedArticlesMemory) return cachedArticlesMemory;
    const raw = localStorage.getItem(STORAGE_KEYS.ARTICLES);
    let result: Article[];
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.ARTICLES, JSON.stringify(INITIAL_ARTICLES));
      cachedArticlesMemory = INITIAL_ARTICLES;
      result = INITIAL_ARTICLES;
    } else {
      try {
        cachedArticlesMemory = JSON.parse(raw);
        result = cachedArticlesMemory || INITIAL_ARTICLES;
      } catch {
        cachedArticlesMemory = INITIAL_ARTICLES;
        result = INITIAL_ARTICLES;
      }
    }
    return result;
  },

  invalidateArticlesCache() {
    cachedArticlesMemory = null;
  },

  async hydrateDurableArticles(): Promise<Article[]> {
    try {
      const durable = await readDurableArticles();
      if (durable && durable.length > 0) {
        cachedArticlesMemory = durable;
        try { localStorage.setItem(STORAGE_KEYS.ARTICLES, JSON.stringify(durable)); } catch (error) {
          console.warn('[POS storage] Catálogo recuperado desde IndexedDB; no entró completo en localStorage.', error);
        }
        this.broadcast('ARTICLES_UPDATED', { articles: durable, hydrated: true });
        return durable;
      }
      const current = this.getArticles();
      await writeDurableArticles(current);
      return current;
    } catch (error) {
      console.error('[POS storage] No se pudo recuperar el catálogo durable de IndexedDB.', error);
      return this.getArticles();
    }
  },

  async applyRemoteArticles(articles: Article[]): Promise<void> {
    if (!articles || !Array.isArray(articles) || articles.length === 0) return;
    // Commit durable storage before notifying React that the remote snapshot is applied.
    await writeDurableArticles(articles);
    cachedArticlesMemory = articles;
    try { localStorage.setItem(STORAGE_KEYS.ARTICLES, JSON.stringify(articles)); }
    catch (e) { console.warn('[POS storage] Catálogo remoto quedó guardado en IndexedDB; localStorage no alcanzó.', e); }
    this.broadcast('ARTICLES_UPDATED', { articles });
  },

  saveArticles(articles: Article[], stockDeltas?: Array<{ articleId: string; quantityDelta: number }>) {
    cachedArticlesMemory = articles;
    // IndexedDB is the durable commit. Only publish after it succeeds; otherwise a
    // terminal must not advertise a catalog snapshot that exists only in memory.
    void writeDurableArticles(articles).then(() => {
      try { localStorage.setItem(STORAGE_KEYS.ARTICLES, JSON.stringify(articles)); }
      catch (e) { console.warn('[POS storage] Catálogo guardado en IndexedDB; localStorage no alcanzó.', e); }
      this.broadcast('ARTICLES_UPDATED', { articles });
      void (async () => {
        await CloudSync.publish('ARTICLES_UPDATED', { articles, count: articles.length }, this.getCurrentTerminalId());
        if (stockDeltas?.length) await CloudSync.publish('STOCK_ADJUSTED', { stockDeltas }, this.getCurrentTerminalId());
      })();
    }).catch((error) => {
      console.error('[POS storage] No se confirmó el guardado durable del catálogo; no se publicó.', error);
      if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent('pos-storage-error', { detail: { area: 'catalog', message: 'No se pudo guardar el catálogo en IndexedDB. El cambio no fue sincronizado.' } }));
    });
  },

  updateArticleStock(articleId: string, quantityDelta: number, publish: boolean = true): Article | null {
    const articles = this.getArticles();
    const index = articles.findIndex(a => String(a.id) === String(articleId));
    if (index === -1) return null;
    articles[index].stock = Math.max(0, articles[index].stock + quantityDelta);
    articles[index].updatedAt = new Date().toISOString();
    cachedArticlesMemory = articles;
    const updatedArticle = { ...articles[index] };
    void writeDurableArticles(articles).then(() => {
      try { localStorage.setItem(STORAGE_KEYS.ARTICLES, JSON.stringify(articles)); }
      catch (error) { console.warn('[POS storage] Stock guardado en IndexedDB; localStorage no alcanzó.', error); }
      this.broadcast('ARTICLES_UPDATED', { articles });
      if (publish) {
        CloudSync.publish('STOCK_ADJUSTED', { stockDeltas: [{ articleId, quantityDelta }] }, this.getCurrentTerminalId());
      }
    }).catch((error) => {
      console.error('[POS storage] No se confirmó el ajuste de stock en IndexedDB.', error);
      if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent('pos-storage-error', { detail: { area: 'stock', message: 'No se pudo guardar el ajuste de stock. No se sincronizó.' } }));
    });
    return updatedArticle;
  },

  // Sales
  getSales(): Sale[] {
    // Avoid reparsing the complete sales ledger multiple times during one sale/UI update.
    return readCachedArray<Sale>(STORAGE_KEYS.SALES, salesArrayCache);
  },

  addSale(sale: Sale) {
    // Create a new array so React subscribers receive a new reference, while reusing
    // the already parsed ledger instead of parsing the same JSON again.
    const sales = [sale, ...this.getSales()];
    writeCachedArray(STORAGE_KEYS.SALES, sales, salesArrayCache);
    
    // Apply all stock changes in one pass. The old code searched the full catalog
    // for every sold line and serialized/broadcast the entire catalog once per line,
    // causing avoidable CPU, RAM and localStorage work on large catalogs.
    const articles = this.getArticles();
    const articlesById = new Map<string, Article>();
    for (const article of articles) articlesById.set(String(article.id), article);

    const quantityByArticle = new Map<string, number>();
    for (const item of sale.items) {
      const articleId = String(item.articleId);
      quantityByArticle.set(articleId, (quantityByArticle.get(articleId) || 0) + Number(item.quantity || 0));
    }

    const stockDeltas = Array.from(quantityByArticle.entries()).map(([articleId, quantity]) => {
      const article = articlesById.get(articleId);
      return {
        articleId,
        quantityDelta: -quantity,
        baseStock: Number(article?.stock || 0),
      };
    });

    let stockChanged = false;
    for (const [articleId, quantity] of quantityByArticle.entries()) {
      const article = articlesById.get(articleId);
      if (!article) continue;
      article.stock = Math.max(0, Number(article.stock || 0) - quantity);
      article.updatedAt = sale.timestamp;
      stockChanged = true;
    }
    if (stockChanged) {
      cachedArticlesMemory = articles;
      try { localStorage.setItem(STORAGE_KEYS.ARTICLES, JSON.stringify(articles)); }
      catch (e) { console.error('Error saving catalog stock after sale:', e); }
      void writeDurableArticles(articles).catch((error) => console.error('[POS storage] No se pudo persistir stock de venta en IndexedDB.', error));
      // One local notification per sale, not one per item.
      this.broadcast('ARTICLES_UPDATED', { articles });
    }

    // If payment was CUENTA_CORRIENTE, update account balance & movement
    if (sale.paymentMethod === 'CUENTA_CORRIENTE' && sale.clientId) {
      this.addAccountMovement({
        id: `mov_${Date.now()}`,
        accountId: sale.clientId,
        accountName: sale.clientName || 'Cliente',
        type: 'DEBIT',
        amount: sale.total,
        concept: `Venta Ticket #${sale.receiptNumber}`,
        referenceId: sale.id,
        userId: sale.userId,
        userName: sale.userName,
        timestamp: sale.timestamp,
      });
    }

    // Add to audit log
    this.addAuditLog({
      id: `aud_${Date.now()}`,
      module: 'VENTAS',
      action: 'NUEVA_VENTA',
      description: `Venta registrada por $${sale.total.toLocaleString()} con ${sale.paymentMethod} (${sale.items.length} artículos)`,
      userId: sale.userId,
      userName: sale.userName,
      userRole: sale.userRole,
      terminalId: sale.terminalId,
      timestamp: sale.timestamp,
      details: { saleId: sale.id, total: sale.total, receiptNumber: sale.receiptNumber }
    });

    this.broadcast('SALE_COMPLETED', sale);
    CloudSync.publish('SALE_PROCESSED', {
      sale,
      stockDeltas,
      updatedAccounts: this.getAccounts(),
      movements: this.getAccountMovements(),
    }, sale.terminalId);
  },

  // Purchases
  getPurchases(): Purchase[] {
    return readCachedArray<Purchase>(STORAGE_KEYS.PURCHASES, purchasesArrayCache);
  },

  addPurchase(purchase: Purchase) {
    const purchases = [purchase, ...this.getPurchases()];
    writeCachedArray(STORAGE_KEYS.PURCHASES, purchases, purchasesArrayCache);

    // Increase stock locally; publish only the deltas, not a full catalog snapshot.
    const stockDeltas = purchase.items.map(item => {
      const article = this.getArticles().find(a => String(a.id) === String(item.articleId));
      return {
        articleId: item.articleId,
        quantityDelta: item.quantity,
        baseStock: Number(article?.stock || 0),
      };
    });
    purchase.items.forEach(item => {
      this.updateArticleStock(item.articleId, item.quantity, false);
    });

    // If paid from cash, register cash expense
    if (purchase.paymentMethod === 'EFECTIVO') {
      this.addCashMovement({
        id: `csh_mov_${Date.now()}`,
        type: 'EXPENSE',
        concept: `Pago Compra Proveedor: ${purchase.supplierName} (Fact. ${purchase.invoiceNumber})`,
        amount: purchase.total,
        paymentMethod: 'EFECTIVO',
        userId: purchase.userId,
        userName: purchase.userName,
        timestamp: purchase.timestamp,
      });
    }

    this.addAuditLog({
      id: `aud_${Date.now()}`,
      module: 'COMPRAS',
      action: 'NUEVA_COMPRA',
      description: `Compra registrada a ${purchase.supplierName} por $${purchase.total.toLocaleString()}`,
      userId: purchase.userId,
      userName: purchase.userName,
      userRole: 'ADMIN',
      terminalId: purchase.terminalId,
      timestamp: purchase.timestamp,
      details: { purchaseId: purchase.id, total: purchase.total }
    });

    this.broadcast('PURCHASE_COMPLETED', purchase);
    CloudSync.publish('PURCHASE_REGISTERED', {
      purchase,
      stockDeltas,
    }, purchase.terminalId);
  },

  // Accounts
  getAccounts(): CurrentAccount[] {
    if (cachedAccountsMemory !== null) {
      return cachedAccountsMemory;
    }
    const raw = localStorage.getItem(STORAGE_KEYS.ACCOUNTS);
    if (!raw) {
      try {
        localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(INITIAL_ACCOUNTS));
      } catch {}
      cachedAccountsMemory = INITIAL_ACCOUNTS;
      return INITIAL_ACCOUNTS;
    }
    try {
      cachedAccountsMemory = JSON.parse(raw);
      return cachedAccountsMemory || INITIAL_ACCOUNTS;
    } catch {
      cachedAccountsMemory = INITIAL_ACCOUNTS;
      return INITIAL_ACCOUNTS;
    }
  },

  saveAccounts(accounts: CurrentAccount[]) {
    cachedAccountsMemory = accounts;
    try {
      localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(accounts));
    } catch (e) {
      console.warn('LocalStorage quota exceeded for pos_accounts_v1:', e);
    }
    this.broadcast('ACCOUNTS_UPDATED');
    CloudSync.publish('ACCOUNTS_UPDATED', {
      accounts,
      movements: this.getAccountMovements(),
      accountsCount: accounts.length,
    }, this.getCurrentTerminalId());
  },

  getAccountMovements(): AccountMovement[] {
    if (cachedAccountMovementsMemory !== null) {
      return cachedAccountMovementsMemory;
    }
    const raw = localStorage.getItem(STORAGE_KEYS.MOVEMENTS);
    if (!raw) {
      // A missing ledger is empty; do not inject demo financial movements into a real commerce.
      try { localStorage.setItem(STORAGE_KEYS.MOVEMENTS, '[]'); } catch {}
      cachedAccountMovementsMemory = [];
      return [];
    }
    try {
      cachedAccountMovementsMemory = JSON.parse(raw);
      return cachedAccountMovementsMemory || [];
    } catch {
      cachedAccountMovementsMemory = [];
      return [];
    }
  },

  saveAccountMovements(movements: AccountMovement[], publish: boolean = false) {
    // Keep the complete ledger in memory even if the browser cannot persist it.
    // Never silently replace the ledger with only its newest 50-500 entries.
    cachedAccountMovementsMemory = movements;
    persistJsonWithEphemeralRetry(STORAGE_KEYS.MOVEMENTS, movements);
    this.broadcast('MOVEMENTS_UPDATED');
    if (publish) {
      CloudSync.publish('ACCOUNTS_UPDATED', {
        accounts: this.getAccounts(),
        movements,
        accountsCount: this.getAccounts().length,
      }, this.getCurrentTerminalId());
    }
  },

  addAccountMovement(movement: AccountMovement) {
    const movements = this.getAccountMovements();
    movements.unshift(movement);
    this.saveAccountMovements(movements, false);

    // Update account balance
    const accounts = this.getAccounts();
    const accIndex = accounts.findIndex(a => a.id === movement.accountId);
    if (accIndex !== -1) {
      if (movement.type === 'DEBIT') {
        accounts[accIndex].currentBalance += movement.amount;
      } else {
        accounts[accIndex].currentBalance = Math.max(0, accounts[accIndex].currentBalance - movement.amount);
      }
      accounts[accIndex].updatedAt = new Date().toISOString();
      this.saveAccounts(accounts);
    }

    this.broadcast('MOVEMENTS_UPDATED');
  },

  // Cash Shifts
  getCashShifts(): CashShift[] {
    if (cachedCashShiftsMemory !== null) {
      return cachedCashShiftsMemory;
    }
    const raw = localStorage.getItem(STORAGE_KEYS.CASH_SHIFTS);
    let list: CashShift[] = [];
    if (raw) {
      try {
        list = JSON.parse(raw);
      } catch {
        list = [];
      }
    }

    // Always check if there is an active open shift in dedicated storage
    try {
      const activeRaw = localStorage.getItem(STORAGE_KEYS.ACTIVE_SHIFT);
      if (activeRaw) {
        const activeShift: CashShift = JSON.parse(activeRaw);
        if (activeShift && (activeShift.status === 'OPEN' || !activeShift.closedAt)) {
          const normActive: CashShift = { ...activeShift, status: 'OPEN' };
          const idx = list.findIndex(s => s.id === normActive.id);
          if (idx !== -1) {
            list[idx] = normActive;
          } else {
            list.unshift(normActive);
          }
        }
      }
    } catch {}

    // Guarantee that if the most recent shift in history was never closed (no closedAt), it is maintained as OPEN
    if (list.length > 0 && !list[0].closedAt && list[0].status !== 'OPEN') {
      list[0] = { ...list[0], status: 'OPEN' };
    }

    if (list.length === 0) {
      // Do not create a fictitious cash shift during an application update.
      // A real shift must be opened explicitly by the cashier.
      try { localStorage.setItem(STORAGE_KEYS.CASH_SHIFTS, '[]'); } catch {}
      cachedCashShiftsMemory = [];
      return [];
    }

    cachedCashShiftsMemory = list.map(s => ({
      ...s,
      totalCardSales: s.totalCardSales || 0,
    }));
    return cachedCashShiftsMemory;
  },

  saveCashShifts(shifts: CashShift[]) {
    cachedCashShiftsMemory = shifts;

    // Persist or clean up active OPEN shift
    const openShift = shifts.find(s => s.status === 'OPEN' || !s.closedAt);
    if (openShift) {
      try {
        localStorage.setItem(STORAGE_KEYS.ACTIVE_SHIFT, JSON.stringify({ ...openShift, status: 'OPEN' }));
      } catch (e) {
        console.warn('Error saving active cash shift:', e);
      }
    } else {
      try {
        localStorage.removeItem(STORAGE_KEYS.ACTIVE_SHIFT);
      } catch {}
    }

    // Persist the full shift history. If storage is full, retain it in memory
    // and the active shift in its dedicated key; do not truncate prior shifts or
    // erase audit logs to free space.
    persistJsonWithEphemeralRetry(STORAGE_KEYS.CASH_SHIFTS, shifts);

    this.broadcast('CASH_SHIFTS_UPDATED');
    CloudSync.publish('CASH_UPDATED', { 
      count: shifts.length,
      recent: shifts.slice(0, 5)
    }, this.getCurrentTerminalId());
  },

  getActiveCashShift(terminalId?: string): CashShift | undefined {
    // 1. Dedicated active shift storage first
    try {
      const activeRaw = localStorage.getItem(STORAGE_KEYS.ACTIVE_SHIFT);
      if (activeRaw) {
        const parsed: CashShift = JSON.parse(activeRaw);
        if (parsed && (parsed.status === 'OPEN' || !parsed.closedAt)) {
          return { ...parsed, status: 'OPEN' };
        }
      }
    } catch {}

    // 2. Search in loaded shifts
    const shifts = this.getCashShifts();
    if (terminalId) {
      const match = shifts.find(s => (s.status === 'OPEN' || !s.closedAt) && s.terminalId?.toUpperCase() === terminalId.toUpperCase());
      if (match) return { ...match, status: 'OPEN' };
    }
    const anyActive = shifts.find(s => s.status === 'OPEN' || !s.closedAt);
    if (anyActive) return { ...anyActive, status: 'OPEN' };

    // 3. Fallback: if the latest shift in the system was never formally closed (no closedAt), it is open
    if (shifts.length > 0 && !shifts[0].closedAt) {
      return { ...shifts[0], status: 'OPEN' };
    }

    return undefined;
  },

  saveActiveCashShift(shift: CashShift) {
    try {
      localStorage.setItem(STORAGE_KEYS.ACTIVE_SHIFT, JSON.stringify({ ...shift, status: 'OPEN' }));
    } catch (e) {
      console.warn('Error saving active cash shift:', e);
    }
  },

  clearActiveCashShift() {
    try {
      localStorage.removeItem(STORAGE_KEYS.ACTIVE_SHIFT);
    } catch {}
  },

  // Cash Movements (Incomes / Expenses / Retiros)
  getCashMovements(): CashMovement[] {
    if (cachedCashMovementsMemory !== null) {
      return cachedCashMovementsMemory;
    }
    const raw = localStorage.getItem(STORAGE_KEYS.CASH_MOVEMENTS);
    if (!raw) {
      try {
        localStorage.setItem(STORAGE_KEYS.CASH_MOVEMENTS, JSON.stringify([]));
      } catch {}
      cachedCashMovementsMemory = [];
      return [];
    }
    try {
      cachedCashMovementsMemory = JSON.parse(raw);
      return cachedCashMovementsMemory || [];
    } catch {
      cachedCashMovementsMemory = [];
      return [];
    }
  },

  saveCashMovements(movements: CashMovement[]) {
    cachedCashMovementsMemory = movements;
    // Do not drop old cash movements when localStorage reaches its quota.
    persistJsonWithEphemeralRetry(STORAGE_KEYS.CASH_MOVEMENTS, movements);
    this.broadcast('CASH_MOVEMENTS_UPDATED');
    CloudSync.publish('CASH_UPDATED', {
      movementsCount: movements.length
    }, this.getCurrentTerminalId());
  },

  addCashMovement(movement: CashMovement) {
    const movements = this.getCashMovements();
    movements.unshift(movement);
    cachedCashMovementsMemory = movements;
    persistJsonWithEphemeralRetry(STORAGE_KEYS.CASH_MOVEMENTS, movements);
    this.broadcast('CASH_MOVEMENTS_UPDATED');
  },

  // Ventas Externas de Servicios (Claro & SAT)
  getExternalServiceSales(): ExternalServiceSale[] {
    const raw = localStorage.getItem(STORAGE_KEYS.EXTERNAL_SERVICE_SALES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.EXTERNAL_SERVICE_SALES, JSON.stringify([]));
      return [];
    }
    return JSON.parse(raw);
  },

  addExternalServiceSale(sale: ExternalServiceSale) {
    const sales = this.getExternalServiceSales();
    sales.unshift(sale);
    localStorage.setItem(STORAGE_KEYS.EXTERNAL_SERVICE_SALES, JSON.stringify(sales));
    this.broadcast('EXTERNAL_SERVICE_SALES_UPDATED');
  },

  deleteExternalServiceSale(id: string) {
    const sales = this.getExternalServiceSales().filter(s => s.id !== id);
    localStorage.setItem(STORAGE_KEYS.EXTERNAL_SERVICE_SALES, JSON.stringify(sales));
    this.broadcast('EXTERNAL_SERVICE_SALES_UPDATED');
  },

  // Artículos Extras Guardados (Historial para selector similar a Marcas)
  getExtraArticles(): string[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.EXTRA_ARTICLES);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  },

  saveExtraArticle(name: string): string[] {
    const clean = name.trim();
    if (!clean) return this.getExtraArticles();
    const current = this.getExtraArticles();
    const exists = current.some(item => item.toLowerCase() === clean.toLowerCase());
    if (!exists) {
      const updated = [clean, ...current].slice(0, 50);
      try {
        localStorage.setItem(STORAGE_KEYS.EXTRA_ARTICLES, JSON.stringify(updated));
        this.broadcast('EXTRA_ARTICLES_UPDATED');
      } catch (e) {
        console.error('Error saving extra article', e);
      }
      return updated;
    }
    return current;
  },

  deleteExtraArticle(name: string): string[] {
    const current = this.getExtraArticles();
    const updated = current.filter(item => item.toLowerCase() !== name.toLowerCase());
    try {
      localStorage.setItem(STORAGE_KEYS.EXTRA_ARTICLES, JSON.stringify(updated));
      this.broadcast('EXTRA_ARTICLES_UPDATED');
    } catch (e) {
      console.error('Error deleting extra article', e);
    }
    return updated;
  },

  // Audit Logs
  getAuditLogs(): AuditLog[] {
    return readCachedArray<AuditLog>(STORAGE_KEYS.AUDIT_LOGS, auditArrayCache);
  },

  addAuditLog(log: AuditLog) {
    const logs = [log, ...this.getAuditLogs()].slice(0, 500);
    writeCachedArray(STORAGE_KEYS.AUDIT_LOGS, logs, auditArrayCache);
    this.broadcast('AUDIT_LOGS_UPDATED', { log });
    CloudSync.publish('HISTORY_UPDATED', { log }, log.terminalId || this.getCurrentTerminalId());
  },

  // Payment Configuration (Mercado Pago, Virtual Wallets & Bank Accounts)
  // Cada terminal conserva su propia configuración aunque cambie la terminal activa.
  getPaymentConfigStorageKey(terminalId?: string): string {
    const rawId = String(terminalId || this.getCurrentTerminalId() || 'TERM-01').trim().toUpperCase();
    const safeId = rawId.replace(/[^A-Z0-9_-]/g, '_') || 'TERM-01';
    return `${STORAGE_KEYS.PAYMENT_CONFIG}_${safeId}`;
  },

  getPaymentConfig(): PaymentConfig {
    const terminalKey = this.getPaymentConfigStorageKey();
    let raw = localStorage.getItem(terminalKey);
    // Migrate the existing shared configuration only as an initial seed for this
    // terminal. Subsequent saves go to the terminal-specific key exclusively.
    if (!raw) {
      const legacyRaw = localStorage.getItem(STORAGE_KEYS.PAYMENT_CONFIG);
      if (legacyRaw) {
        raw = legacyRaw;
        localStorage.setItem(terminalKey, legacyRaw);
      }
    }
    const defaultWallets = [
      {
        id: 'wal_uala',
        name: 'Ualá',
        alias: 'MANUEL.UALA',
        cvu: '0000007900204123456789',
        holder: 'Manuel Silva',
        color: 'bg-red-600',
      },
      {
        id: 'wal_personal_pay',
        name: 'Personal Pay',
        alias: 'MANUEL.PAY',
        cvu: '0000003500109988776655',
        holder: 'Manuel Silva',
        color: 'bg-sky-600',
      },
      {
        id: 'wal_modo',
        name: 'MODO',
        alias: 'MANUEL.MODO',
        cvu: '0000002100084433221100',
        holder: 'Manuel Silva',
        color: 'bg-emerald-600',
      },
      {
        id: 'wal_naranjax',
        name: 'Naranja X',
        alias: 'MANUEL.NX',
        cvu: '0000008200301122334455',
        holder: 'Manuel Silva',
        color: 'bg-amber-600',
      }
    ];

    const defaultOfficialPosQrs = {
      'TERM-01': {
        id: '1364877',
        name: 'QR #01 (Caja 1)',
        qrImage: 'https://www.mercadopago.com/instore/merchant/qr/1364877/4791e696593b478c9b0dba491a631cc75bf1414638744d6ba7af1b5ac3e09b52.png',
      },
      '1': {
        id: '1364877',
        name: 'QR #01',
        qrImage: 'https://www.mercadopago.com/instore/merchant/qr/1364877/4791e696593b478c9b0dba491a631cc75bf1414638744d6ba7af1b5ac3e09b52.png',
      },
      '1364877': {
        id: '1364877',
        name: 'QR #01',
        qrImage: 'https://www.mercadopago.com/instore/merchant/qr/1364877/4791e696593b478c9b0dba491a631cc75bf1414638744d6ba7af1b5ac3e09b52.png',
      },
      'default': {
        id: '1364877',
        name: 'QR #01',
        qrImage: 'https://www.mercadopago.com/instore/merchant/qr/1364877/4791e696593b478c9b0dba491a631cc75bf1414638744d6ba7af1b5ac3e09b52.png',
      },
      'TERM-02': {
        id: '138571396',
        name: 'QR #02 (Caja 2)',
        qrImage: 'https://www.mercadopago.com/instore/merchant/qr/138571396/c7751ca3b3c846a79e3c11169b3e85089cdd53cc283f41d1a008ebafbe0248c8.png',
      },
      '2': {
        id: '138571396',
        name: 'QR #02',
        qrImage: 'https://www.mercadopago.com/instore/merchant/qr/138571396/c7751ca3b3c846a79e3c11169b3e85089cdd53cc283f41d1a008ebafbe0248c8.png',
      },
      '138571396': {
        id: '138571396',
        name: 'QR #02',
        qrImage: 'https://www.mercadopago.com/instore/merchant/qr/138571396/c7751ca3b3c846a79e3c11169b3e85089cdd53cc283f41d1a008ebafbe0248c8.png',
      },
      'TERM-03': {
        id: '138677030',
        name: 'QR #03 (Caja 3)',
        qrImage: 'https://www.mercadopago.com/instore/merchant/qr/138677030/3cb322f54e7c4706aa278fcd9d9a66bf7fa70f1c468c41f5b91ab0fd1e3827d5.png',
      },
      '3': {
        id: '138677030',
        name: 'QR #03',
        qrImage: 'https://www.mercadopago.com/instore/merchant/qr/138677030/3cb322f54e7c4706aa278fcd9d9a66bf7fa70f1c468c41f5b91ab0fd1e3827d5.png',
      },
      '138677030': {
        id: '138677030',
        name: 'QR #03',
        qrImage: 'https://www.mercadopago.com/instore/merchant/qr/138677030/3cb322f54e7c4706aa278fcd9d9a66bf7fa70f1c468c41f5b91ab0fd1e3827d5.png',
      },
    };

    const defaultConfig: PaymentConfig = {
      mpAlias: 'MANUELSILVA2003.MP',
      mpCvu: '0000003100084920194820',
      mpHolder: 'Manuel Silva',
      mpQrText: '',
      mpQrImage: 'https://www.mercadopago.com/instore/merchant/qr/1364877/4791e696593b478c9b0dba491a631cc75bf1414638744d6ba7af1b5ac3e09b52.png',
      mpAccessToken: '',
      mpUserId: '49052653',
      mpPosId: '1364877',
      mpPosName: 'QR #01',
      mpStoreId: '31704432',
      mpConnected: false,
      mpAutoSync: true,
      mpPosQrs: defaultOfficialPosQrs,
      // Configuración Tarjeta / Posnet
      posnetMode: 'MANUAL',
      posnetBrand: 'Payway / Posnet',
      posnetTerminalId: 'POS-01',
      posnetIntegratedType: 'INTEGRATED_SIMULATOR',
      posnetAutoPrintCoupon: true,
      bankName: 'Banco Santander / Galicia',
      bankAlias: 'COMERCIO.CENTRAL.PAGO',
      bankCbu: '0720123488000012345678',
      bankHolder: 'Empresa Comercial S.A.',
      bankCuit: '30-71458999-9',
    };

    if (!raw) {
      localStorage.setItem(terminalKey, JSON.stringify(defaultConfig));
      return defaultConfig;
    }
    try {
      const parsed = JSON.parse(raw);
      return { 
        ...defaultConfig, 
        ...parsed, 
        mpQrImage: typeof parsed.mpQrImage === 'string' ? parsed.mpQrImage : defaultConfig.mpQrImage,
        mpPosQrs: parsed.mpPosQrs || defaultOfficialPosQrs,
        posnetMode: parsed.posnetMode || 'MANUAL',
        posnetBrand: parsed.posnetBrand || 'Payway / Posnet',
        posnetTerminalId: parsed.posnetTerminalId || 'POS-01',
        posnetIntegratedType: parsed.posnetIntegratedType || 'INTEGRATED_SIMULATOR',
      };
    } catch (e) {
      return defaultConfig;
    }
  },

  savePaymentConfig(config: PaymentConfig) {
    // Do not use the old global key: it caused TERM-02 to reload TERM-01's POS.
    localStorage.setItem(this.getPaymentConfigStorageKey(), JSON.stringify(config));
    this.broadcast('PAYMENT_CONFIG_UPDATED', config);
    window.dispatchEvent(new CustomEvent('pos_payment_config_updated', { detail: config }));

    // Also push updated payment configuration to Wi-Fi customer displays if local dev server API is active
    if (isCustomerDisplayApiSupported) {
      try {
        const curState = this.getCustomerDisplayState();
        fetch('/api/customer-display', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Cache-Control': 'no-cache',
          },
          body: JSON.stringify({
            state: curState,
            paymentConfig: config,
            timestamp: Date.now(),
          }),
        }).catch(() => {});
      } catch (e) {}
    }
  },

  // Customer Display State (Segunda Pantalla en tiempo real)
  getCustomerDisplayState(terminalId?: string): CustomerDisplayState {
    const termId = (terminalId || this.getCurrentTerminalId() || 'TERM-01').toUpperCase();
    const termKey = `${STORAGE_KEYS.CUSTOMER_DISPLAY}_${termId}`;
    const specificRaw = localStorage.getItem(termKey);
    const raw = specificRaw || localStorage.getItem(STORAGE_KEYS.CUSTOMER_DISPLAY);
    if (!raw) {
      return {
        status: 'WELCOME',
        items: [],
        subtotal: 0,
        discount: 0,
        total: 0,
        paymentMethod: null,
        terminalId: termId,
        timestamp: 0,
      };
    }
    try {
      const parsed = JSON.parse(raw);
      return {
        status: parsed.status || 'WELCOME',
        items: Array.isArray(parsed.items) ? parsed.items : [],
        subtotal: typeof parsed.subtotal === 'number' ? parsed.subtotal : 0,
        discount: typeof parsed.discount === 'number' ? parsed.discount : 0,
        total: typeof parsed.total === 'number' ? parsed.total : 0,
        paymentMethod: parsed.paymentMethod || null,
        cashReceived: parsed.cashReceived,
        cashChange: parsed.cashChange,
        receiptNumber: parsed.receiptNumber,
        terminalId: parsed.terminalId || termId,
        timestamp: typeof parsed.timestamp === 'number' ? parsed.timestamp : 0,
        selectedWallet: parsed.selectedWallet,
        activeWalletId: parsed.activeWalletId,
        posnetMode: parsed.posnetMode,
        posnetStatus: parsed.posnetStatus,
        posnetCardType: parsed.posnetCardType,
        posnetCardBrand: parsed.posnetCardBrand,
        transfersReceived: parsed.transfersReceived,
        transfersTotalReceived: parsed.transfersTotalReceived,
        paymentConfig: parsed.paymentConfig,
        qrImageUrl: parsed.qrImageUrl,
        qrData: parsed.qrData,
      };
    } catch {
      return {
        status: 'WELCOME',
        items: [],
        subtotal: 0,
        discount: 0,
        total: 0,
        paymentMethod: null,
        terminalId: termId,
        timestamp: 0,
      };
    }
  },

  updateCustomerDisplayState(state: CustomerDisplayState) {
    customerDisplaySequence++;
    const termId = (state.terminalId || this.getCurrentTerminalId() || 'TERM-01').toUpperCase();
    const paymentConfig = state.paymentConfig || this.getPaymentConfig();

    let qrImageUrl = state.qrImageUrl;
    let qrData = state.qrData;

    if (!qrImageUrl) {
      const curPosId = paymentConfig.mpPosId || 'default';
      const normTerm = termId.toUpperCase().trim();
      const posSaved = paymentConfig.mpPosQrs?.[normTerm] 
        || paymentConfig.mpPosQrs?.[normTerm.replace('TERM-', '')]
        || paymentConfig.mpPosQrs?.[curPosId]
        || (paymentConfig.mpPosQrs && Object.values(paymentConfig.mpPosQrs)[0]);

      // Resolve real official Mercado Pago QR image or user uploaded cartel
      const officialImage = posSaved?.qrImage || paymentConfig.mpQrImage;

      if (officialImage) {
        qrImageUrl = officialImage;
      } else {
        const digitalQrData = posSaved?.qrData || paymentConfig.mpQrData || paymentConfig.mpQrText || generateArgentinaInteroperableQr({
          merchantName: paymentConfig.mpHolder || 'Manuel Silva',
          cvuOrCbu: paymentConfig.mpCvu || '0000003100084920194820',
          alias: paymentConfig.mpAlias || 'MANUELSILVA2003.MP',
          amount: state.total > 0 ? state.total : undefined,
        });
        qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(digitalQrData)}`;
        qrData = digitalQrData;
      }
    }

    const stateWithVersion: CustomerDisplayState = {
      ...state,
      terminalId: termId,
      version: state.version || customerDisplaySequence,
      timestamp: state.timestamp || Date.now(),
      paymentConfig: paymentConfig,
      qrImageUrl: qrImageUrl,
      qrData: qrData,
    };

    localStorage.setItem(STORAGE_KEYS.CUSTOMER_DISPLAY, JSON.stringify(stateWithVersion));
    localStorage.setItem(`${STORAGE_KEYS.CUSTOMER_DISPLAY}_${termId}`, JSON.stringify(stateWithVersion));
    this.broadcast('CUSTOMER_DISPLAY_SYNC', stateWithVersion);
    // Also dispatch custom window event for same-tab listeners
    window.dispatchEvent(new CustomEvent('pos_customer_display_event', { detail: stateWithVersion }));

    // 1. Real-time synchronization over Wi-Fi network HTTP endpoint for tablets and external devices (only on local dev host)
    if (isLocalDevHost && isCustomerDisplayApiSupported !== false) {
      try {
        fetch('/api/customer-display', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Cache-Control': 'no-cache',
          },
          body: JSON.stringify({
            version: stateWithVersion.version,
            terminalId: stateWithVersion.terminalId,
            state: stateWithVersion,
            paymentConfig,
            timestamp: stateWithVersion.timestamp,
          }),
        })
          .then(res => {
            if (res.status === 404) {
              isCustomerDisplayApiSupported = false;
            } else if (res.ok) {
              isCustomerDisplayApiSupported = true;
            }
          })
          .catch(() => {});
      } catch (e) {}
    }

    // 2. Real-time Cloud / WebSocket sync across any tablet or device in the store
    try {
      CloudSync.publish('CUSTOMER_DISPLAY_SYNC', { 
        version: stateWithVersion.version, 
        terminalId: stateWithVersion.terminalId,
        state: stateWithVersion, 
        paymentConfig 
      }, stateWithVersion.terminalId || 'DEFAULT');
    } catch {}

    // 3. Real-time WebRTC direct DataChannel sync to connected 2nd screen phones / tablets
    try {
      PeerSync.broadcastToClients(stateWithVersion);
    } catch {}
  },

  // Merchandise Notices (Avisos de Carga de Mercaderia entre Terminales)
  getMerchandiseNotices(): MerchandiseNotice[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.MERCHANDISE_NOTICES);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  },

  sendMerchandiseNotice(notice: MerchandiseNotice): MerchandiseNotice {
    const notices = this.getMerchandiseNotices();
    notices.unshift(notice);
    localStorage.setItem(STORAGE_KEYS.MERCHANDISE_NOTICES, JSON.stringify(notices));
    this.broadcast('MERCHANDISE_NOTICE_RECEIVED', notice);
    window.dispatchEvent(new CustomEvent('pos_merchandise_notice_event', { detail: notice }));

    try {
      CloudSync.publish('MERCHANDISE_NOTICE_SENT', { notice }, notice.senderTerminalId);
    } catch {}

    return notice;
  },

  updateMerchandiseNoticeStatus(
    noticeId: string, 
    status: 'IN_PROGRESS' | 'COMPLETED', 
    userName?: string, 
    terminalId?: string
  ): MerchandiseNotice | null {
    const notices = this.getMerchandiseNotices();
    const idx = notices.findIndex(n => n.id === noticeId);
    if (idx === -1) return null;

    const now = new Date().toISOString();
    const updated: MerchandiseNotice = {
      ...notices[idx],
      status,
      startedAt: status === 'IN_PROGRESS' && !notices[idx].startedAt ? now : notices[idx].startedAt,
      completedAt: status === 'COMPLETED' ? now : notices[idx].completedAt,
      completedByUserName: userName || notices[idx].completedByUserName,
      completedByTerminalId: terminalId || notices[idx].completedByTerminalId,
    };

    notices[idx] = updated;
    localStorage.setItem(STORAGE_KEYS.MERCHANDISE_NOTICES, JSON.stringify(notices));
    this.broadcast('MERCHANDISE_NOTICE_UPDATED', updated);
    window.dispatchEvent(new CustomEvent('pos_merchandise_notice_event', { detail: updated }));

    try {
      CloudSync.publish('MERCHANDISE_NOTICE_STATUS', {
        noticeId,
        status,
        startedAt: updated.startedAt,
        completedAt: updated.completedAt,
        completedByUserName: updated.completedByUserName,
        completedByTerminalId: updated.completedByTerminalId,
      }, terminalId || 'DEFAULT');
    } catch {}

    return updated;
  },

  getBusinessInfo(): BusinessInfo {
    const raw = localStorage.getItem(STORAGE_KEYS.BUSINESS_INFO);
    if (!raw) {
      return {
        name: 'COMERCIO CENTRAL POS',
        cuit: '30-71985421-3',
        address: 'Av. Corrientes 1420, CABA',
        phone: '+54 9 11 5566-7788',
        ticketHeader: '¡Bienvenidos a nuestro comercio!',
        ticketFooter: '¡Gracias por su compra! Conserve este ticket.',
      };
    }
    return JSON.parse(raw);
  },

  saveBusinessInfo(info: BusinessInfo, publishCloud: boolean = true) {
    localStorage.setItem(STORAGE_KEYS.BUSINESS_INFO, JSON.stringify(info));
    this.broadcast('BUSINESS_INFO_CHANGED');
    window.dispatchEvent(new CustomEvent('pos_business_info_changed', { detail: info }));
    if (publishCloud) void CloudSync.publish('BUSINESS_INFO_UPDATED', { businessInfo: info }, this.getCurrentTerminalId());
  },

  exportFullBackup() {
    return {
      version: '2.5',
      exportDate: new Date().toISOString(),
      businessInfo: this.getBusinessInfo(),
      paymentConfig: this.getPaymentConfig(),
      printerConfig: this.getPrinterConfig(),
      keyboardShortcuts: this.getKeyboardShortcuts(),
      // Preferencias visuales también forman parte del respaldo total.
      darkMode: localStorage.getItem('pos_dark_mode') === 'true',
      articles: this.getArticles(),
      // Guardar usuarios exactamente como están almacenados, sin normalizar ni omitir campos.
      users: JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || JSON.stringify(this.getUsers())),
      accounts: this.getAccounts(),
      sales: this.getSales(),
      purchases: this.getPurchases(),
      cashShifts: this.getCashShifts(),
      cashMovements: this.getCashMovements(),
      accountMovements: this.getAccountMovements(),
      auditLogs: this.getAuditLogs(),
      terminals: this.getTerminals(),
    };
  },

  async restoreFullBackup(data: any): Promise<{ success: boolean; message: string }> {
    try {
      if (!data || !data.articles || !Array.isArray(data.articles)) {
        return { success: false, message: 'El archivo de respaldo no tiene el formato válido del sistema POS.' };
      }

      if (data.businessInfo) this.saveBusinessInfo(data.businessInfo);
      if (data.paymentConfig) this.savePaymentConfig(data.paymentConfig);
      if (data.printerConfig) this.savePrinterConfig(data.printerConfig);
      if (Array.isArray(data.keyboardShortcuts)) this.saveKeyboardShortcuts(data.keyboardShortcuts);
      if (data.articles) this.saveArticles(data.articles);
      // Restaurar la lista completa de usuarios del respaldo, incluidos sus permisos y credenciales locales.
      if (Array.isArray(data.users)) this.saveUsers(data.users);
      // Los respaldos antiguos no tienen darkMode: en ese caso se conserva el modo actual.
      if (typeof data.darkMode === 'boolean') {
        localStorage.setItem('pos_dark_mode', String(data.darkMode));
        document.documentElement.classList.toggle('dark', data.darkMode);
        window.dispatchEvent(new CustomEvent('pos_theme_restored', { detail: { darkMode: data.darkMode } }));
      }
      if (data.accounts) this.saveAccounts(data.accounts);
      if (data.sales) localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify(data.sales));
      if (data.purchases) localStorage.setItem(STORAGE_KEYS.PURCHASES, JSON.stringify(data.purchases));
      if (data.terminals) localStorage.setItem(STORAGE_KEYS.TERMINALS, JSON.stringify(data.terminals));

      if (data.cashShifts) localStorage.setItem(STORAGE_KEYS.CASH_SHIFTS, JSON.stringify(data.cashShifts));
      if (data.cashMovements) localStorage.setItem(STORAGE_KEYS.CASH_MOVEMENTS, JSON.stringify(data.cashMovements));
      if (data.accountMovements) localStorage.setItem(STORAGE_KEYS.MOVEMENTS, JSON.stringify(data.accountMovements));
      if (Array.isArray(data.auditLogs)) localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(data.auditLogs));

      // El catálogo ya se publica mediante saveArticles(). El resto del respaldo se envía
      // por fragmentos pequeños para no exceder localStorage ni el límite del endpoint.
      const synchronized = await CloudSync.publishSystemRestore(data);
      this.broadcast('SYSTEM_RESTORE');
      return synchronized
        ? { success: true, message: 'Respaldo restaurado y enviado a las demás terminales.' }
        : { success: true, message: 'Respaldo restaurado en esta terminal. La sincronización completa con las demás no pudo confirmarse; mantené esta terminal conectada y revisá el estado de sincronización antes de repetir la restauración.' };
    } catch (e: any) {
      return { success: false, message: e.message || 'Error al procesar el archivo de respaldo.' };
    }
  },

  // Parked Sales (Ventas en Espera)
  getParkedSales(): ParkedSale[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PARKED_SALES);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveParkedSales(sales: ParkedSale[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.PARKED_SALES, JSON.stringify(sales));
      this.broadcast('PARKED_SALES_UPDATED');
    } catch (e) {
      console.error('Error saving parked sales', e);
    }
  },

  addParkedSale(sale: ParkedSale): void {
    const list = this.getParkedSales();
    list.unshift(sale);
    this.saveParkedSales(list);
  },

  removeParkedSale(id: string): void {
    const list = this.getParkedSales().filter(s => s.id !== id);
    this.saveParkedSales(list);
  },

  // Atajos de Teclado (Keyboard Shortcuts)
  getKeyboardShortcuts(): KeyboardShortcutConfig[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.KEYBOARD_SHORTCUTS);
      if (!raw) {
        localStorage.setItem(STORAGE_KEYS.KEYBOARD_SHORTCUTS, JSON.stringify(DEFAULT_KEYBOARD_SHORTCUTS));
        return DEFAULT_KEYBOARD_SHORTCUTS;
      }
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) && parsed.length > 0 ? parsed : DEFAULT_KEYBOARD_SHORTCUTS;
    } catch {
      return DEFAULT_KEYBOARD_SHORTCUTS;
    }
  },

  saveKeyboardShortcuts(shortcuts: KeyboardShortcutConfig[], publishCloud: boolean = true): void {
    localStorage.setItem(STORAGE_KEYS.KEYBOARD_SHORTCUTS, JSON.stringify(shortcuts));
    this.broadcast('SHORTCUTS_UPDATED', { shortcuts });
    window.dispatchEvent(new CustomEvent('pos_keyboard_shortcuts_updated', { detail: shortcuts }));
    if (publishCloud) void CloudSync.publish('KEYBOARD_SHORTCUTS_UPDATED', { shortcuts }, this.getCurrentTerminalId());
  },

  resetKeyboardShortcuts(): KeyboardShortcutConfig[] {
    this.saveKeyboardShortcuts(DEFAULT_KEYBOARD_SHORTCUTS);
    return DEFAULT_KEYBOARD_SHORTCUTS;
  },

  // Impresora & Ticketera
  getPrinterConfig(): PrinterConfig {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.PRINTER_CONFIG);
      if (!raw) {
        localStorage.setItem(STORAGE_KEYS.PRINTER_CONFIG, JSON.stringify(DEFAULT_PRINTER_CONFIG));
        return DEFAULT_PRINTER_CONFIG;
      }
      return { ...DEFAULT_PRINTER_CONFIG, ...JSON.parse(raw) };
    } catch {
      return DEFAULT_PRINTER_CONFIG;
    }
  },

  savePrinterConfig(config: PrinterConfig, publishCloud: boolean = true): void {
    localStorage.setItem(STORAGE_KEYS.PRINTER_CONFIG, JSON.stringify(config));
    this.broadcast('PRINTER_CONFIG_UPDATED', { config });
    window.dispatchEvent(new CustomEvent('pos_printer_config_updated', { detail: config }));
    if (publishCloud) void CloudSync.publish('PRINTER_CONFIG_UPDATED', { config }, this.getCurrentTerminalId());
  },

  // Devuelve el catálogo de demostración empaquetado con la aplicación sin alterar el estado actual.
  getFactoryDemoArticles(): Article[] {
    return INITIAL_ARTICLES.map(article => ({ ...article }));
  },

  // Restablece los datos comerciales locales. Conserva solo la identidad de terminal/canal
  // y credenciales de sincronización para que todas las cajas sigan vinculadas tras el reinicio.
  resetToDemo(demoArticles?: Article[]) {
    const preservedKeys = new Set(['pos_current_terminal_v1', 'pos_cloud_sync_channel', 'pos_sync_channel']);
    const keysToRemove: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key || !key.startsWith('pos_')) continue;
      if (preservedKeys.has(key) || key.startsWith('pos_sync_token_v1_')) continue;
      keysToRemove.push(key);
    }
    keysToRemove.forEach(key => localStorage.removeItem(key));
    if (Array.isArray(demoArticles) && demoArticles.length > 0) {
      localStorage.setItem(STORAGE_KEYS.ARTICLES, JSON.stringify(demoArticles));
    }
    cachedArticlesMemory = null;
    cachedCashShiftsMemory = null;
    cachedCashMovementsMemory = null;
    cachedAccountsMemory = null;
    cachedAccountMovementsMemory = null;
    this.broadcast('SYSTEM_RESET');
  }
};
