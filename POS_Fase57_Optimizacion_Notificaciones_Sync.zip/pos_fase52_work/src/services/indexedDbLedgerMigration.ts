/**
 * Fase 4 — preparación segura para migrar historiales grandes a IndexedDB.
 *
 * Deliberadamente NO se ejecuta al iniciar la app ni cambia el backend de StorageService.
 * La API actual de StorageService es síncrona y la cola de sincronización depende de
 * localStorage; cambiarla sin migrar todos los consumidores podría perder operaciones.
 * Esta utilidad permite copiar y verificar los datos en IndexedDB sin borrar el origen.
 */

export const POS_LEDGER_DB_NAME = 'pos_ledger_v1';
export const POS_LEDGER_DB_VERSION = 2;
export const POS_LEDGER_STORE = 'snapshots';
export const POS_LEDGER_STAGING_STORE = 'restore_staging';

export const POS_LEDGER_KEYS = [
  // Catálogo y cuentas son necesarios para poder contrastar el estado del POS.
  'pos_articles_v1',
  'pos_accounts_v1',
  'pos_sales_v1',
  'pos_purchases_v1',
  'pos_movements_v1',
  'pos_cash_shifts_v1',
  'pos_cash_movements_v1',
  'pos_audit_logs_v1',
  'pos_external_service_sales_v1',
] as const;

export type LedgerMigrationItem = {
  key: string;
  status: 'copied' | 'verified' | 'stale' | 'missing' | 'error';
  records?: number;
  bytes?: number;
  message?: string;
};


/** Incluye las colas y cursores reales de cada terminal, sin copiar tokens ni secretos. */
function getPosLedgerKeys(): string[] {
  const keys = new Set<string>(POS_LEDGER_KEYS);
  if (typeof localStorage === 'undefined') return [...keys];
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (key.startsWith('pos_vps_pending_queue_v1_') || key.startsWith('pos_vps_sync_cursor_v1_'))) {
        keys.add(key);
      }
    }
  } catch {
    // Las funciones de copia reportarán los errores de lectura por clave.
  }
  return [...keys];
}

function openLedgerDb(): Promise<IDBDatabase> {
  if (typeof indexedDB === 'undefined') {
    return Promise.reject(new Error('IndexedDB no está disponible en este navegador.'));
  }
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(POS_LEDGER_DB_NAME, POS_LEDGER_DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(POS_LEDGER_STORE)) {
        db.createObjectStore(POS_LEDGER_STORE, { keyPath: 'key' });
      }
      if (!db.objectStoreNames.contains(POS_LEDGER_STAGING_STORE)) {
        db.createObjectStore(POS_LEDGER_STAGING_STORE, { keyPath: 'key' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('No se pudo abrir IndexedDB.'));
    request.onblocked = () => reject(new Error('La apertura de IndexedDB está bloqueada por otra pestaña.'));
  });
}

function countRecords(raw: string): number | undefined {
  try {
    const parsed: unknown = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.length : undefined;
  } catch {
    return undefined;
  }
}

/** Copia datos existentes; nunca elimina ni modifica las claves de localStorage. */
export async function copyLocalLedgersToIndexedDb(): Promise<LedgerMigrationItem[]> {
  if (typeof window === 'undefined') throw new Error('La migración debe ejecutarse en el navegador.');
  const db = await openLedgerDb();
  const results: LedgerMigrationItem[] = [];
  try {
    for (const key of getPosLedgerKeys()) {
      let raw: string | null;
      try {
        raw = localStorage.getItem(key);
      } catch (error) {
        results.push({ key, status: 'error', message: `No se pudo leer localStorage: ${String(error)}` });
        continue;
      }
      if (raw === null) {
        results.push({ key, status: 'missing', message: 'La clave no existe; no se creó ningún dato.' });
        continue;
      }
      let parsed: unknown;
      try {
        parsed = JSON.parse(raw);
      } catch {
        results.push({ key, status: 'error', bytes: raw.length, message: 'El JSON de origen no es válido; se conservó intacto.' });
        continue;
      }
      try {
        await new Promise<void>((resolve, reject) => {
          const tx = db.transaction(POS_LEDGER_STORE, 'readwrite');
          tx.objectStore(POS_LEDGER_STORE).put({ key, raw, copiedAt: new Date().toISOString() });
          tx.oncomplete = () => resolve();
          tx.onerror = () => reject(tx.error || new Error('Falló la escritura en IndexedDB.'));
          tx.onabort = () => reject(tx.error || new Error('La escritura en IndexedDB fue cancelada.'));
        });
        const storedRaw = await new Promise<string | undefined>((resolve, reject) => {
          const tx = db.transaction(POS_LEDGER_STORE, 'readonly');
          const request = tx.objectStore(POS_LEDGER_STORE).get(key);
          request.onsuccess = () => resolve(request.result?.raw as string | undefined);
          request.onerror = () => reject(request.error || new Error('Falló la verificación de IndexedDB.'));
        });
        if (storedRaw !== raw) {
          results.push({ key, status: 'error', bytes: raw.length, message: 'La verificación no coincide; el origen sigue intacto.' });
          continue;
        }
        results.push({ key, status: 'verified', records: countRecords(raw), bytes: raw.length, message: 'Copia verificada; origen conservado.' });
      } catch (error) {
        results.push({ key, status: 'error', bytes: raw.length, message: String(error) });
      }
    }
  } finally {
    db.close();
  }
  return results;
}


/**
 * Fase 7 — compara el snapshot de IndexedDB con el localStorage actual.
 * Es estrictamente de solo lectura: no repara, sobrescribe ni elimina datos.
 */
export async function compareLocalLedgersWithIndexedDb(): Promise<LedgerMigrationItem[]> {
  if (typeof window === 'undefined') throw new Error('La verificación debe ejecutarse en el navegador.');
  const db = await openLedgerDb();
  const results: LedgerMigrationItem[] = [];
  try {
    for (const key of getPosLedgerKeys()) {
      let currentRaw: string | null;
      try {
        currentRaw = localStorage.getItem(key);
      } catch (error) {
        results.push({ key, status: 'error', message: `No se pudo leer el origen: ${String(error)}` });
        continue;
      }
      if (currentRaw === null) {
        results.push({ key, status: 'missing', message: 'La clave no existe en localStorage.' });
        continue;
      }
      try {
        const stored = await new Promise<{ raw?: string } | undefined>((resolve, reject) => {
          const tx = db.transaction(POS_LEDGER_STORE, 'readonly');
          const request = tx.objectStore(POS_LEDGER_STORE).get(key);
          request.onsuccess = () => resolve(request.result as { raw?: string } | undefined);
          request.onerror = () => reject(request.error || new Error('No se pudo leer el snapshot.'));
        });
        if (!stored || typeof stored.raw !== 'string') {
          results.push({ key, status: 'missing', records: countRecords(currentRaw), bytes: currentRaw.length, message: 'Todavía no existe una copia en IndexedDB.' });
          continue;
        }
        const matches = stored.raw === currentRaw;
        results.push({
          key,
          status: matches ? 'verified' : 'stale',
          records: countRecords(currentRaw),
          bytes: currentRaw.length,
          message: matches ? 'La copia coincide con los datos actuales.' : 'Los datos cambiaron después de la copia; volver a copiar solo tras revisar el estado.'
        });
      } catch (error) {
        results.push({ key, status: 'error', message: String(error) });
      }
    }
  } finally {
    db.close();
  }
  return results;
}



/** Fase 10 — auditoría de preparación, estrictamente de solo lectura.
 * Revisa tanto las claves actuales como los snapshots que quedaron en IndexedDB
 * pero ya no tienen una clave de origen. No habilita la migración ni modifica datos.
 */
export async function auditIndexedDbLedgerReadiness(): Promise<LedgerMigrationItem[]> {
  if (typeof window === 'undefined') throw new Error('La auditoría debe ejecutarse en el navegador.');
  const db = await openLedgerDb();
  const results: LedgerMigrationItem[] = [];
  try {
    const currentKeys = getPosLedgerKeys();
    const rows = await new Promise<Array<{ key: string; raw?: string; copiedAt?: string }>>((resolve, reject) => {
      const tx = db.transaction(POS_LEDGER_STORE, 'readonly');
      const request = tx.objectStore(POS_LEDGER_STORE).getAll();
      request.onsuccess = () => resolve((request.result || []) as Array<{ key: string; raw?: string; copiedAt?: string }>);
      request.onerror = () => reject(request.error || new Error('No se pudieron leer los snapshots.'));
    });
    const snapshots = new Map<string, { key: string; raw?: string; copiedAt?: string }>(rows.map((row) => [row.key, row] as const));
    const currentSet = new Set(currentKeys);

    for (const key of currentKeys) {
      let raw: string | null;
      try { raw = localStorage.getItem(key); }
      catch (error) {
        results.push({ key, status: 'error', message: `No se pudo leer el origen: ${String(error)}` });
        continue;
      }
      if (raw === null) {
        results.push({ key, status: 'missing', message: 'Clave prevista pero ausente en localStorage; confirmar si es opcional antes de migrar.' });
        continue;
      }
      try { JSON.parse(raw); }
      catch {
        results.push({ key, status: 'error', bytes: raw.length, message: 'El JSON de origen no es válido; no se modificó.' });
        continue;
      }
      const snapshot = snapshots.get(key);
      if (!snapshot || typeof snapshot.raw !== 'string') {
        results.push({ key, status: 'missing', records: countRecords(raw), bytes: raw.length, message: 'No existe una copia verificada.' });
      } else if (snapshot.raw !== raw) {
        results.push({ key, status: 'stale', records: countRecords(raw), bytes: raw.length, message: 'La copia difiere del origen actual.' });
      } else {
        results.push({ key, status: 'verified', records: countRecords(raw), bytes: raw.length, message: 'Origen JSON válido y copia idéntica.' });
      }
    }

    for (const row of rows) {
      if (!currentSet.has(row.key)) {
        results.push({ key: row.key, status: 'stale', bytes: typeof row.raw === 'string' ? row.raw.length : undefined, message: 'Snapshot sin clave de origen actual; se conserva y requiere revisión manual.' });
      }
    }
    if (results.length === 0) {
      results.push({ key: '(sin datos)', status: 'missing', message: 'No se encontraron claves de origen ni snapshots para auditar.' });
    }
    return results;
  } finally {
    db.close();
  }
}



export type LedgerStorageDiagnosticItem = {
  key: string;
  group: 'catálogo' | 'ventas' | 'cuentas' | 'compras' | 'movimientos' | 'caja' | 'auditoría' | 'servicios' | 'cola de sincronización' | 'cursor de sincronización' | 'otros';
  status: 'ok' | 'missing' | 'read-error' | 'invalid-json';
  chars: number;
  approxBytes: number;
  records?: number;
  readMs?: number;
  parseMs?: number;
  queueEntries?: number;
  message: string;
};

export type LedgerStorageDiagnosticResult = {
  measuredAt: string;
  durationMs: number;
  keyCount: number;
  totalChars: number;
  totalApproxBytes: number;
  items: LedgerStorageDiagnosticItem[];
  browserStorageEstimate?: { usageBytes?: number; quotaBytes?: number };
  message: string;
};

function classifyLedgerKey(key: string): LedgerStorageDiagnosticItem['group'] {
  if (key === 'pos_articles_v1') return 'catálogo';
  if (key === 'pos_sales_v1') return 'ventas';
  if (key === 'pos_accounts_v1') return 'cuentas';
  if (key === 'pos_purchases_v1') return 'compras';
  if (key === 'pos_movements_v1') return 'movimientos';
  if (key === 'pos_cash_shifts_v1' || key === 'pos_cash_movements_v1') return 'caja';
  if (key === 'pos_audit_logs_v1') return 'auditoría';
  if (key === 'pos_external_service_sales_v1') return 'servicios';
  if (key.startsWith('pos_vps_pending_queue_v1_')) return 'cola de sincronización';
  if (key.startsWith('pos_vps_sync_cursor_v1_')) return 'cursor de sincronización';
  return 'otros';
}

/** Fase 14 — diagnóstico de tamaño/tiempo de almacenamiento, solo lectura. No escribe en localStorage ni IndexedDB. */
export async function diagnosePosLedgerStorage(): Promise<LedgerStorageDiagnosticResult> {
  if (typeof window === 'undefined') throw new Error('El diagnóstico debe ejecutarse en el navegador.');
  const startedAt = performance.now();
  const measuredAt = new Date().toISOString();
  const items: LedgerStorageDiagnosticItem[] = [];
  let totalChars = 0;

  for (const key of getPosLedgerKeys()) {
    const readStarted = performance.now();
    let raw: string | null;
    try { raw = localStorage.getItem(key); }
    catch (error) {
      items.push({ key, group: classifyLedgerKey(key), status: 'read-error', chars: 0, approxBytes: 0, readMs: performance.now() - readStarted, message: `No se pudo leer: ${String(error)}` });
      continue;
    }
    const readMs = performance.now() - readStarted;
    if (raw === null) {
      items.push({ key, group: classifyLedgerKey(key), status: 'missing', chars: 0, approxBytes: 0, readMs, message: 'La clave no está presente en localStorage.' });
      continue;
    }
    const chars = raw.length;
    const approxBytes = chars * 2; // estimación UTF-16; no es el tamaño exacto del almacenamiento del navegador.
    totalChars += chars;
    const parseStarted = performance.now();
    try {
      const parsed: unknown = JSON.parse(raw);
      const parseMs = performance.now() - parseStarted;
      const records = Array.isArray(parsed) ? parsed.length : undefined;
      const queueEntries = key.startsWith('pos_vps_pending_queue_v1_')
        ? (Array.isArray(parsed) ? parsed.length : parsed && typeof parsed === 'object' && Array.isArray((parsed as { items?: unknown }).items) ? ((parsed as { items: unknown[] }).items.length) : undefined)
        : undefined;
      items.push({ key, group: classifyLedgerKey(key), status: 'ok', chars, approxBytes, records, readMs, parseMs, queueEntries, message: 'Lectura y análisis JSON completados; no se modificaron datos.' });
    } catch {
      items.push({ key, group: classifyLedgerKey(key), status: 'invalid-json', chars, approxBytes, readMs, parseMs: performance.now() - parseStarted, message: 'El contenido no es JSON válido; se dejó intacto.' });
    }
  }

  let browserStorageEstimate: LedgerStorageDiagnosticResult['browserStorageEstimate'];
  try {
    if (typeof navigator !== 'undefined' && navigator.storage?.estimate) {
      const estimate = await navigator.storage.estimate();
      browserStorageEstimate = { usageBytes: estimate.usage, quotaBytes: estimate.quota };
    }
  } catch { /* La estimación del navegador es opcional; no afecta el diagnóstico principal. */ }

  const totalApproxBytes = totalChars * 2;
  const errors = items.filter((item) => item.status === 'read-error' || item.status === 'invalid-json').length;
  return {
    measuredAt,
    durationMs: performance.now() - startedAt,
    keyCount: items.length,
    totalChars,
    totalApproxBytes,
    items,
    browserStorageEstimate,
    message: errors === 0
      ? 'Diagnóstico completado en modo de solo lectura. Los tamaños son aproximados y los tiempos dependen del equipo y de la carga del navegador.'
      : `Diagnóstico completado con ${errors} observación(es) de lectura/JSON. No se modificaron datos.`,
  };
}

/** Borra únicamente la copia de prueba en IndexedDB; jamás toca localStorage. */
export async function clearIndexedDbLedgerCopies(): Promise<void> {
  const db = await openLedgerDb();
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(POS_LEDGER_STORE, 'readwrite');
      tx.objectStore(POS_LEDGER_STORE).clear();
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error || new Error('No se pudo limpiar la copia de prueba.'));
      tx.onabort = () => reject(tx.error || new Error('La limpieza fue cancelada.'));
    });
  } finally {
    db.close();
  }
}

/** Fase 8 — exporta una copia de seguridad de los snapshots de IndexedDB sin mutarlos. */
export async function exportIndexedDbLedgerBackup(): Promise<{ exportedAt: string; database: string; snapshots: Array<{ key: string; raw: string; copiedAt?: string; currentStatus: 'verified' | 'stale' | 'missing' }> }> {
  if (typeof window === 'undefined') throw new Error('La exportación debe ejecutarse en el navegador.');
  const db = await openLedgerDb();
  try {
    const rows = await new Promise<Array<{ key: string; raw?: string; copiedAt?: string }>>((resolve, reject) => {
      const tx = db.transaction(POS_LEDGER_STORE, 'readonly');
      const request = tx.objectStore(POS_LEDGER_STORE).getAll();
      request.onsuccess = () => resolve((request.result || []) as Array<{ key: string; raw?: string; copiedAt?: string }>);
      request.onerror = () => reject(request.error || new Error('No se pudieron leer las copias de IndexedDB.'));
    });
    const snapshots: Array<{ key: string; raw: string; copiedAt?: string; currentStatus: 'verified' | 'stale' | 'missing' }> = [];
    for (const key of getPosLedgerKeys()) {
      const row = rows.find((item) => item.key === key);
      if (!row || typeof row.raw !== 'string') continue;
      let current: string | null = null;
      try { current = localStorage.getItem(key); } catch { /* status will be missing when origin cannot be read */ }
      snapshots.push({ key, raw: row.raw, copiedAt: row.copiedAt, currentStatus: current === null ? 'missing' : current === row.raw ? 'verified' : 'stale' });
    }
    if (snapshots.length === 0) throw new Error('No hay copias en IndexedDB para exportar. Primero ejecutá “Copiar y verificar historiales”.');
    return { exportedAt: new Date().toISOString(), database: POS_LEDGER_DB_NAME, snapshots };
  } finally {
    db.close();
  }
}


export type LedgerBackupStageResult = {
  importedAt: string;
  count: number;
  keys: string[];
  bytes: number;
  message: string;
};

/**
 * Fase 11 — valida un JSON exportado y lo coloca en un almacén de ensayo aislado.
 * No sobrescribe los snapshots vigentes ni restaura localStorage; es una prueba
 * segura de lectura/validación antes de diseñar la restauración real.
 */
export async function stageLedgerBackupForRestore(rawFileText: string): Promise<LedgerBackupStageResult> {
  if (typeof window === 'undefined') throw new Error('La validación debe ejecutarse en el navegador.');
  if (!rawFileText.trim()) throw new Error('El archivo está vacío.');
  if (rawFileText.length > 200 * 1024 * 1024) throw new Error('El archivo supera el límite de 200 MB para esta prueba.');

  let backup: unknown;
  try { backup = JSON.parse(rawFileText); }
  catch { throw new Error('El archivo no contiene JSON válido.'); }

  if (!backup || typeof backup !== 'object' || Array.isArray(backup)) {
    throw new Error('Formato de respaldo no reconocido.');
  }
  const candidate = backup as { database?: unknown; snapshots?: unknown; exportedAt?: unknown };
  if (candidate.database !== POS_LEDGER_DB_NAME || !Array.isArray(candidate.snapshots)) {
    throw new Error(`El archivo no parece un respaldo de ${POS_LEDGER_DB_NAME}.`);
  }
  if (candidate.snapshots.length === 0) throw new Error('El respaldo no contiene copias.');

  const validSnapshots: Array<{ key: string; raw: string; copiedAt?: string; importedAt: string }> = [];
  const seen = new Set<string>();
  for (const item of candidate.snapshots) {
    if (!item || typeof item !== 'object' || Array.isArray(item)) throw new Error('El respaldo contiene una entrada con formato inválido.');
    const row = item as { key?: unknown; raw?: unknown; copiedAt?: unknown };
    if (typeof row.key !== 'string' || typeof row.raw !== 'string') throw new Error('Una entrada no tiene clave o contenido de texto válido.');
    const allowed = (POS_LEDGER_KEYS as readonly string[]).includes(row.key) || row.key.startsWith('pos_vps_pending_queue_v1_') || row.key.startsWith('pos_vps_sync_cursor_v1_');
    if (!allowed) throw new Error(`La clave “${row.key}” no está permitida en esta prueba.`);
    if (seen.has(row.key)) throw new Error(`El respaldo contiene la clave duplicada “${row.key}”.`);
    seen.add(row.key);
    try { JSON.parse(row.raw); }
    catch { throw new Error(`El contenido JSON de “${row.key}” no es válido.`); }
    validSnapshots.push({ key: row.key, raw: row.raw, copiedAt: typeof row.copiedAt === 'string' ? row.copiedAt : undefined, importedAt: new Date().toISOString() });
  }

  const db = await openLedgerDb();
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(POS_LEDGER_STAGING_STORE, 'readwrite');
      const store = tx.objectStore(POS_LEDGER_STAGING_STORE);
      // Only the isolated staging store is replaced; active snapshots and localStorage are untouched.
      store.clear();
      for (const row of validSnapshots) store.put(row);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error || new Error('No se pudo guardar el ensayo de restauración.'));
      tx.onabort = () => reject(tx.error || new Error('El ensayo de restauración fue cancelado.'));
    });

    const stagedRows = await new Promise<Array<{ key: string; raw?: string }>>((resolve, reject) => {
      const tx = db.transaction(POS_LEDGER_STAGING_STORE, 'readonly');
      const request = tx.objectStore(POS_LEDGER_STAGING_STORE).getAll();
      request.onsuccess = () => resolve((request.result || []) as Array<{ key: string; raw?: string }>);
      request.onerror = () => reject(request.error || new Error('No se pudo verificar el ensayo guardado.'));
    });
    const stagedMap = new Map(stagedRows.map((row) => [row.key, row.raw] as const));
    for (const row of validSnapshots) {
      if (stagedMap.get(row.key) !== row.raw) throw new Error(`La verificación del ensayo no coincide para “${row.key}”.`);
    }

    return {
      importedAt: new Date().toISOString(),
      count: validSnapshots.length,
      keys: validSnapshots.map((row) => row.key),
      bytes: rawFileText.length,
      message: 'Respaldo validado y guardado en el área de ensayo. No se restauró ni modificó el POS activo.',
    };
  } finally {
    db.close();
  }
}


export type LedgerStageAuditResult = {
  checkedAt: string;
  count: number;
  bytes: number;
  keys: string[];
  errors: string[];
  message: string;
};

/** Fase 12 — vuelve a leer el almacén de ensayo persistido y valida cada entrada.
 * No consulta ni modifica localStorage, snapshots activos ni el sistema de sincronización.
 */
export async function verifyStagedLedgerBackup(): Promise<LedgerStageAuditResult> {
  if (typeof window === 'undefined') throw new Error('La verificación debe ejecutarse en el navegador.');
  const db = await openLedgerDb();
  try {
    const rows = await new Promise<Array<{ key?: unknown; raw?: unknown; importedAt?: unknown }>>((resolve, reject) => {
      const tx = db.transaction(POS_LEDGER_STAGING_STORE, 'readonly');
      const request = tx.objectStore(POS_LEDGER_STAGING_STORE).getAll();
      request.onsuccess = () => resolve((request.result || []) as Array<{ key?: unknown; raw?: unknown; importedAt?: unknown }>);
      request.onerror = () => reject(request.error || new Error('No se pudo leer el almacén de ensayo.'));
    });
    if (rows.length === 0) throw new Error('No hay un respaldo en el área de ensayo. Primero ejecutá “Probar restauración (sin aplicar)”.');
    const errors: string[] = [];
    const keys: string[] = [];
    const seen = new Set<string>();
    let bytes = 0;
    for (const row of rows) {
      if (typeof row.key !== 'string' || typeof row.raw !== 'string') {
        errors.push('Se encontró una entrada sin clave o contenido de texto válido.');
        continue;
      }
      if (seen.has(row.key)) errors.push(`Clave duplicada en ensayo: ${row.key}`);
      seen.add(row.key);
      keys.push(row.key);
      bytes += row.raw.length;
      try { JSON.parse(row.raw); }
      catch { errors.push(`JSON inválido en ensayo: ${row.key}`); }
      if (typeof row.importedAt !== 'string' || !row.importedAt) errors.push(`Falta la marca de importación en ensayo: ${row.key}`);
    }
    return {
      checkedAt: new Date().toISOString(),
      count: keys.length,
      bytes,
      keys,
      errors,
      message: errors.length === 0
        ? 'El respaldo de ensayo persiste en IndexedDB y todas sus entradas superaron la validación. El POS activo no fue modificado.'
        : 'El ensayo contiene observaciones. No se modificó el POS activo; revisá los errores antes de avanzar.',
    };
  } finally {
    db.close();
  }
}


export type LedgerStageCompareItem = {
  key: string;
  status: 'same' | 'different' | 'missing-in-current' | 'missing-in-stage' | 'invalid';
  stagedBytes?: number;
  currentBytes?: number;
  message: string;
};

/** Fase 13 — comparación de solo lectura entre el ensayo guardado y localStorage actual. */
export async function compareStagedBackupWithCurrentData(): Promise<LedgerStageCompareItem[]> {
  if (typeof window === 'undefined') throw new Error('La comparación debe ejecutarse en el navegador.');
  const db = await openLedgerDb();
  try {
    const rows = await new Promise<Array<{ key?: unknown; raw?: unknown }>>((resolve, reject) => {
      const tx = db.transaction(POS_LEDGER_STAGING_STORE, 'readonly');
      const request = tx.objectStore(POS_LEDGER_STAGING_STORE).getAll();
      request.onsuccess = () => resolve((request.result || []) as Array<{ key?: unknown; raw?: unknown }>);
      request.onerror = () => reject(request.error || new Error('No se pudo leer el ensayo guardado.'));
    });
    if (!rows.length) throw new Error('No hay respaldo en el área de ensayo. Primero validá un archivo JSON.');
    const staged = new Map<string, string>();
    for (const row of rows) {
      if (typeof row.key !== 'string' || typeof row.raw !== 'string') throw new Error('El ensayo contiene una entrada inválida.');
      if (staged.has(row.key)) throw new Error(`Clave duplicada en el ensayo: ${row.key}`);
      try { JSON.parse(row.raw); } catch { throw new Error(`JSON inválido en el ensayo: ${row.key}`); }
      staged.set(row.key, row.raw);
    }
    const current = new Map<string, string>();
    for (const key of getPosLedgerKeys()) {
      try {
        const raw = localStorage.getItem(key);
        if (raw !== null) current.set(key, raw);
      } catch { /* reportado como ausente/no legible al comparar */ }
    }
    const allKeys = new Set([...staged.keys(), ...current.keys()]);
    return [...allKeys].sort().map((key): LedgerStageCompareItem => {
      const stageRaw = staged.get(key);
      const currentRaw = current.get(key);
      if (stageRaw === undefined) return { key, status: 'missing-in-stage', currentBytes: currentRaw?.length, message: 'La clave actual no está en el respaldo de ensayo.' };
      if (currentRaw === undefined) return { key, status: 'missing-in-current', stagedBytes: stageRaw.length, message: 'La clave del ensayo no existe actualmente en localStorage.' };
      try { JSON.parse(stageRaw); JSON.parse(currentRaw); }
      catch { return { key, status: 'invalid', stagedBytes: stageRaw.length, currentBytes: currentRaw.length, message: 'Uno de los contenidos no es JSON válido.' }; }
      return stageRaw === currentRaw
        ? { key, status: 'same', stagedBytes: stageRaw.length, currentBytes: currentRaw.length, message: 'El contenido coincide exactamente.' }
        : { key, status: 'different', stagedBytes: stageRaw.length, currentBytes: currentRaw.length, message: 'El contenido cambió o corresponde a otro momento.' };
    });
  } finally { db.close(); }
}
