// Detección de conectividad: eventos del navegador + una comprobación moderada
// al propio sitio. La sincronización VPS confirma por separado el acceso a la API.

type NetworkListener = (isOnline: boolean) => void;

class NetworkDetectionService {
  private online: boolean = typeof navigator !== 'undefined' ? navigator.onLine : true;
  private listeners: Set<NetworkListener> = new Set();
  private probeInterval: ReturnType<typeof setInterval> | null = null;
  private isProbing = false;
  private hasInitialized = false;

  constructor() {
    if (typeof window !== 'undefined') {
      this.initListeners();
      this.startProbing();
      window.setTimeout(() => { void this.checkNow(); }, 500);
    }
  }

  public get isConnectedToInternet(): boolean { return this.online; }

  public subscribe(listener: NetworkListener): () => void {
    this.listeners.add(listener);
    listener(this.online);
    return () => { this.listeners.delete(listener); };
  }

  private notify(newStatus: boolean) {
    if (this.online !== newStatus || !this.hasInitialized) {
      this.hasInitialized = true;
      this.online = newStatus;
      this.listeners.forEach((fn) => { try { fn(newStatus); } catch (e) { console.error('Error in network listener:', e); } });
    }
  }

  private initListeners() {
    window.addEventListener('online', () => { void this.checkNow(); });
    window.addEventListener('offline', () => this.notify(false));
    window.addEventListener('focus', () => { void this.checkNow(); });
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') void this.checkNow();
    });
  }

  public async checkNow(): Promise<boolean> {
    if (typeof window === 'undefined') return true;
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      this.notify(false);
      return false;
    }
    if (this.isProbing) return this.online;
    this.isProbing = true;
    try {
      const reachable = await this.performProbe();
      this.notify(reachable);
      return reachable;
    } finally {
      this.isProbing = false;
    }
  }

  private async performProbe(): Promise<boolean> {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), 3500);
    try {
      // No consultar Google ni descargar el icono: una sola petición liviana al mismo origen.
      const response = await fetch(`${window.location.origin}/?_network_check=${Date.now()}`, {
        method: 'HEAD', cache: 'no-store', signal: controller.signal,
      });
      return response.ok || (response.status >= 200 && response.status < 400);
    } catch {
      return false;
    } finally {
      window.clearTimeout(timer);
    }
  }

  private startProbing() {
    if (this.probeInterval) clearInterval(this.probeInterval);
    // La API de sincronización detecta cortes antes; este control es solo respaldo.
    this.probeInterval = setInterval(() => {
      if (document.visibilityState !== 'hidden') void this.checkNow();
    }, 15000);
  }
}

export const NetworkService = new NetworkDetectionService();
