/** Fase 5 — diagnóstico previo a una migración real de almacenamiento.
 * Solo lectura: no modifica localStorage, IndexedDB, sincronización ni datos del POS.
 */
export type StoragePreflightEntry = {
  key: string;
  exists: boolean;
  characters: number;
  approximateBytes: number;
  validJson: boolean | null;
  records: number | null;
  note?: string;
};

export type StoragePreflightReport = {
  createdAt: string;
  totalKeys: number;
  totalCharacters: number;
  totalApproximateBytes: number;
  entries: StoragePreflightEntry[];
  quota: { usage?: number; quota?: number; usagePercent?: number; available: boolean };
  warnings: string[];
};

const CORE_KEYS = [
  'pos_articles_v1', 'pos_sales_v1', 'pos_purchases_v1', 'pos_accounts_v1',
  'pos_movements_v1', 'pos_cash_shifts_v1', 'pos_cash_movements_v1',
  'pos_audit_logs_v1', 'pos_external_service_sales_v1',
  'pos_sync_channel', 'pos_current_terminal_v1', 'pos_payment_config_v1',
];

function approximateBytes(value: string): number {
  try { return new TextEncoder().encode(value).byteLength; }
  catch { return value.length * 2; }
}

function parseEntry(key: string, raw: string | null): StoragePreflightEntry {
  if (raw === null) return { key, exists: false, characters: 0, approximateBytes: 0, validJson: null, records: null };
  try {
    const parsed: unknown = JSON.parse(raw);
    return { key, exists: true, characters: raw.length, approximateBytes: approximateBytes(raw), validJson: true, records: Array.isArray(parsed) ? parsed.length : null };
  } catch {
    return { key, exists: true, characters: raw.length, approximateBytes: approximateBytes(raw), validJson: false, records: null, note: 'El contenido no es JSON válido; no se modificó.' };
  }
}

/** Inspecciona claves conocidas y colas de sincronización pendientes, sin escribir ni borrar. */
export async function inspectLocalStorageBeforeMigration(): Promise<StoragePreflightReport> {
  if (typeof window === 'undefined') throw new Error('El diagnóstico debe ejecutarse en el navegador.');
  const warnings: string[] = [];
  const keys = new Set<string>(CORE_KEYS);
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (key.startsWith('pos_vps_pending_queue_v1_') || key.startsWith('pos_vps_sync_cursor_v1_'))) keys.add(key);
    }
  } catch (error) {
    warnings.push(`No se pudo enumerar todo localStorage: ${String(error)}`);
  }

  const entries: StoragePreflightEntry[] = [];
  for (const key of keys) {
    try { entries.push(parseEntry(key, localStorage.getItem(key))); }
    catch (error) { entries.push({ key, exists: false, characters: 0, approximateBytes: 0, validJson: null, records: null, note: `No se pudo leer: ${String(error)}` }); }
  }

  const totalCharacters = entries.reduce((sum, item) => sum + item.characters, 0);
  const totalApproximateBytes = entries.reduce((sum, item) => sum + item.approximateBytes, 0);
  if (entries.some(item => item.validJson === false)) warnings.push('Hay claves con JSON inválido; revisar antes de migrar.');
  if (entries.some(item => item.key.startsWith('pos_vps_pending_queue_v1_') && item.exists)) warnings.push('Se detectaron colas offline. Deben preservarse y probarse en la migración.');
  if (totalApproximateBytes > 4 * 1024 * 1024) warnings.push('Los datos inspeccionados superan aproximadamente 4 MiB; localStorage puede estar cerca de su límite según el navegador.');

  let quota: StoragePreflightReport['quota'] = { available: false };
  try {
    const estimate = await navigator.storage?.estimate?.();
    if (estimate) {
      const usage = typeof estimate.usage === 'number' ? estimate.usage : undefined;
      const browserQuota = typeof estimate.quota === 'number' ? estimate.quota : undefined;
      quota = { usage, quota: browserQuota, usagePercent: usage !== undefined && browserQuota ? Math.round((usage / browserQuota) * 1000) / 10 : undefined, available: true };
    }
  } catch (error) {
    warnings.push(`El navegador no permitió estimar la cuota: ${String(error)}`);
  }

  return { createdAt: new Date().toISOString(), totalKeys: entries.length, totalCharacters, totalApproximateBytes, entries, quota, warnings };
}

/** Convierte el diagnóstico a JSON descargable/copiable; no persiste datos del POS. */
export function storagePreflightReportToJson(report: StoragePreflightReport): string {
  return JSON.stringify(report, null, 2);
}
