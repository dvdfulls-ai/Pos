// Real-time Synchronization Engine for Customer Display
// Relies on CloudSync (Firestore) + local BroadcastChannel
// ZERO external signaling dependencies, ZERO broken WebSockets, 100% stable

import { CustomerDisplayState } from '../types';
import { CloudSync } from './cloudSync';

export const normalizeTerminalId = (raw?: string | null): string => {
  if (!raw) return 'TERM-01';
  let cleaned = raw.trim().toUpperCase();
  if (cleaned.startsWith('TERMINAL')) {
    cleaned = cleaned.replace('TERMINAL', '').trim();
  }
  if (/^\d+$/.test(cleaned)) {
    cleaned = `TERM-${cleaned.padStart(2, '0')}`;
  } else if (/^TERM-\d+$/.test(cleaned)) {
    const num = cleaned.replace('TERM-', '');
    cleaned = `TERM-${num.padStart(2, '0')}`;
  }
  return cleaned || 'TERM-01';
};

export const getCleanHostIdentifier = (): string => {
  if (typeof window === 'undefined') return 'pos_store';
  const raw = (window.location.hostname || 'pos_store').replace(/^www\./i, '');
  const isLocal = raw === 'localhost' || raw === '127.0.0.1' || /^192\.168\./.test(raw) || /^10\./.test(raw);
  if (isLocal) return 'pos_local';
  return raw.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
};

export const getHostPeerId = (terminalId: string = 'TERM-01'): string => {
  const norm = normalizeTerminalId(terminalId);
  const hostId = getCleanHostIdentifier();
  return `pos_${hostId}_${norm}`.replace(/[^a-zA-Z0-9_-]/g, '_');
};

class PeerSyncManager {
  private currentHostTerminal: string = '';
  private latestDisplayState: CustomerDisplayState | null = null;
  private clientTargetTerminal: string = '';
  private onDataCallback: ((data: any) => void) | null = null;
  private unsubscribeCloud: (() => void) | null = null;
  private localBroadcastChannel: BroadcastChannel | null = null;

  public startHost(terminalId: string, getInitialState?: () => CustomerDisplayState | null) {
    if (typeof window === 'undefined') return;
    this.currentHostTerminal = normalizeTerminalId(terminalId);
    if (getInitialState) {
      this.latestDisplayState = getInitialState();
    }
    this.initBroadcast();
  }

  public stopHost() {
    this.currentHostTerminal = '';
  }

  public broadcastToClients(state: CustomerDisplayState) {
    this.latestDisplayState = state;
    const termId = this.currentHostTerminal || state.terminalId || 'TERM-01';

    // Broadcast locally
    try {
      if (this.localBroadcastChannel) {
        this.localBroadcastChannel.postMessage({
          type: 'CUSTOMER_DISPLAY_SYNC',
          payload: state,
        });
      }
    } catch {}

    // CloudSync also distributes this to all terminals & displays
    try {
      CloudSync.publish('CUSTOMER_DISPLAY_SYNC', {
        terminalId: termId,
        state,
      }, termId);
    } catch {}
  }

  public connectToHost(terminalId: string, onData: (data: any) => void) {
    if (typeof window === 'undefined') return;
    this.clientTargetTerminal = normalizeTerminalId(terminalId);
    this.onDataCallback = onData;

    this.disconnectClient();
    this.initBroadcast();

    // Listen to CloudSync
    this.unsubscribeCloud = CloudSync.subscribe((msg: any) => {
      if (msg.type === 'CUSTOMER_DISPLAY_SYNC' && msg.payload) {
        const payload = msg.payload;
        const msgTerm = normalizeTerminalId(payload.terminalId || msg.senderTerminalId);
        if (msgTerm === this.clientTargetTerminal) {
          const displayState = payload.state || payload;
          if (this.onDataCallback) {
            this.onDataCallback(displayState);
          }
        }
      }
    });
  }

  private initBroadcast() {
    if (typeof window === 'undefined' || this.localBroadcastChannel) return;
    try {
      this.localBroadcastChannel = new BroadcastChannel('pos_customer_display_local');
      this.localBroadcastChannel.onmessage = (e) => {
        if (e.data?.type === 'CUSTOMER_DISPLAY_SYNC' && e.data?.payload) {
          const payload = e.data.payload;
          const msgTerm = normalizeTerminalId(payload.terminalId);
          if (!this.clientTargetTerminal || msgTerm === this.clientTargetTerminal) {
            if (this.onDataCallback) {
              this.onDataCallback(payload);
            }
          }
        }
      };
    } catch {}
  }

  public disconnectClient() {
    if (this.unsubscribeCloud) {
      try {
        this.unsubscribeCloud();
      } catch {}
      this.unsubscribeCloud = null;
    }
  }

  public destroy() {
    this.disconnectClient();
    this.stopHost();
    if (this.localBroadcastChannel) {
      try {
        this.localBroadcastChannel.close();
      } catch {}
      this.localBroadcastChannel = null;
    }
  }
}

export const PeerSync = new PeerSyncManager();
