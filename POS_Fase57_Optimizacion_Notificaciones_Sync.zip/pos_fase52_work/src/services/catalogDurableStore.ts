import type { Article } from '../types';

// Durable catalog mirror. IndexedDB is the recovery source; localStorage remains
// the synchronous read cache used by the existing UI.
const DB_NAME = 'pos_catalog_durable_v1';
const DB_VERSION = 1;
const STORE = 'catalog';
let dbPromise: Promise<IDBDatabase> | null = null;
let writeChain: Promise<void> = Promise.resolve();

function openDb(): Promise<IDBDatabase> {
  if (typeof indexedDB === 'undefined') return Promise.reject(new Error('IndexedDB no está disponible'));
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        if (!request.result.objectStoreNames.contains(STORE)) request.result.createObjectStore(STORE);
      };
      request.onsuccess = () => {
        request.result.onversionchange = () => request.result.close();
        resolve(request.result);
      };
      request.onerror = () => reject(request.error || new Error('No se pudo abrir el catálogo durable'));
      request.onblocked = () => reject(new Error('La base durable del catálogo está bloqueada'));
    }).catch((error) => { dbPromise = null; throw error; });
  }
  return dbPromise;
}

export async function readDurableArticles(): Promise<Article[] | null> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const request = tx.objectStore(STORE).get('articles');
    request.onsuccess = () => resolve(Array.isArray(request.result) ? request.result as Article[] : null);
    request.onerror = () => reject(request.error || new Error('No se pudo leer el catálogo durable'));
  });
}

export function writeDurableArticles(articles: Article[]): Promise<void> {
  const snapshot = articles.map((article) => ({ ...article }));
  const operation = writeChain.then(async () => {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(snapshot, 'articles');
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error || new Error('No se pudo guardar el catálogo durable'));
      tx.onabort = () => reject(tx.error || new Error('Se canceló el guardado del catálogo durable'));
    });
  });
  writeChain = operation.catch(() => undefined);
  return operation;
}
