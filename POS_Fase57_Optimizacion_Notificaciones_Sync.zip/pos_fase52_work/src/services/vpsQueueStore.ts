import type { SyncMessage } from './cloudSync';

type QueueRecord = { key: string; queue: string; timestamp: number; message: SyncMessage };

const DB_NAME = 'pos_vps_sync_queue_v1';
const DB_VERSION = 1;
const STORE_NAME = 'messages';
const LEGACY_QUEUE_PREFIX = 'pos_vps_pending_queue_v1_';

let databasePromise: Promise<IDBDatabase> | null = null;
let migrationPromise: Promise<void> | null = null;

function openDatabase(): Promise<IDBDatabase> {
  if (typeof indexedDB === 'undefined') return Promise.reject(new Error('IndexedDB no está disponible.'));
  if (databasePromise) return databasePromise;
  databasePromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(STORE_NAME)) {
        const store = database.createObjectStore(STORE_NAME, { keyPath: 'key' });
        store.createIndex('queue', 'queue', { unique: false });
      }
    };
    request.onsuccess = () => {
      const database = request.result;
      database.onversionchange = () => database.close();
      resolve(database);
    };
    request.onerror = () => reject(request.error || new Error('No se pudo abrir IndexedDB.'));
    request.onblocked = () => reject(new Error('IndexedDB está bloqueado por otra pestaña.'));
  }).catch((error) => {
    databasePromise = null;
    throw error;
  });
  return databasePromise;
}

function transactionDone(transaction: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onabort = () => reject(transaction.error || new Error('Se canceló una operación de IndexedDB.'));
    transaction.onerror = () => reject(transaction.error || new Error('Falló una operación de IndexedDB.'));
  });
}

function localQueueId(queueKey: string): string {
  return queueKey.startsWith(LEGACY_QUEUE_PREFIX) ? queueKey.slice(LEGACY_QUEUE_PREFIX.length) : queueKey;
}

function recordKey(queueKey: string, messageId: string): string {
  return `${localQueueId(queueKey)}::${messageId}`;
}

async function migrateLegacyQueues(): Promise<void> {
  const queues: Array<{ key: string; messages: SyncMessage[] }> = [];
  try {
    for (let index = 0; index < localStorage.length; index++) {
      const key = localStorage.key(index);
      if (!key?.startsWith(LEGACY_QUEUE_PREFIX)) continue;
      const raw = localStorage.getItem(key);
      if (!raw) continue;
      try {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) queues.push({ key, messages: parsed.filter((message) => message && message.id && message.type) });
      } catch {
        // Keep malformed data untouched so it can be recovered manually.
      }
    }
  } catch {
    return;
  }
  if (!queues.length) return;

  const database = await openDatabase();
  const transaction = database.transaction(STORE_NAME, 'readwrite');
  const done = transactionDone(transaction);
  const store = transaction.objectStore(STORE_NAME);
  for (const entry of queues) {
    for (const message of entry.messages) {
      store.put({ key: recordKey(entry.key, message.id), queue: localQueueId(entry.key), timestamp: Number(message.timestamp) || 0, message } satisfies QueueRecord);
    }
  }
  await done;
  // Remove old JSON only after the complete IndexedDB transaction commits.
  for (const entry of queues) {
    try { localStorage.removeItem(entry.key); } catch { /* IndexedDB has the committed copy. */ }
  }
}

async function ensureLegacyMigration(): Promise<void> {
  if (!migrationPromise) {
    const currentMigration = migrateLegacyQueues();
    migrationPromise = currentMigration;
    void currentMigration.catch(() => {
      if (migrationPromise === currentMigration) migrationPromise = null;
    });
  }
  await migrationPromise;
}

function readQueueInTransaction(transaction: IDBTransaction, queueId: string): Promise<SyncMessage[]> {
  const done = transactionDone(transaction);
  const request = transaction.objectStore(STORE_NAME).index('queue').getAll(queueId);
  return new Promise((resolve, reject) => {
    request.onsuccess = () => {
      const messages = (request.result as QueueRecord[])
        .map((record) => record.message)
        .filter((message) => message && message.id && message.type)
        .sort((a, b) => (a.timestamp - b.timestamp) || a.id.localeCompare(b.id));
      void done.then(() => resolve(messages), reject);
    };
    request.onerror = () => reject(request.error || new Error('No se pudo leer la cola de sincronización.'));
    void done.catch(reject);
  });
}

export async function readVpsQueue(queueKey: string): Promise<SyncMessage[]> {
  await ensureLegacyMigration();
  const database = await openDatabase();
  return readQueueInTransaction(database.transaction(STORE_NAME, 'readonly'), localQueueId(queueKey));
}

export async function writeVpsQueue(queueKey: string, messages: SyncMessage[]): Promise<void> {
  await ensureLegacyMigration();
  const database = await openDatabase();
  const transaction = database.transaction(STORE_NAME, 'readwrite');
  const done = transactionDone(transaction);
  const store = transaction.objectStore(STORE_NAME);
  const request = store.index('queue').openCursor(IDBKeyRange.only(localQueueId(queueKey)));
  let clearFinished = false;
  request.onsuccess = () => {
    const cursor = request.result;
    if (cursor) {
      cursor.delete();
      cursor.continue();
    } else if (!clearFinished) {
      clearFinished = true;
      for (const message of messages) {
        store.put({ key: recordKey(queueKey, message.id), queue: localQueueId(queueKey), timestamp: Number(message.timestamp) || 0, message } satisfies QueueRecord);
      }
    }
  };
  await done;
}

export async function appendVpsMessage(queueKey: string, message: SyncMessage, replaceableTypes: Set<SyncMessage['type']>): Promise<SyncMessage[]> {
  await ensureLegacyMigration();
  const database = await openDatabase();
  const transaction = database.transaction(STORE_NAME, 'readwrite');
  const done = transactionDone(transaction);
  const store = transaction.objectStore(STORE_NAME);
  const request = store.index('queue').openCursor(IDBKeyRange.only(localQueueId(queueKey)));
  let appendFinished = false;
  request.onsuccess = () => {
    const cursor = request.result;
    if (cursor) {
      if (replaceableTypes.has(cursor.value.message.type)) cursor.delete();
      cursor.continue();
    } else if (!appendFinished) {
      appendFinished = true;
      store.put({ key: recordKey(queueKey, message.id), queue: localQueueId(queueKey), timestamp: Number(message.timestamp) || 0, message } satisfies QueueRecord);
    }
  };
  await done;
  return readVpsQueue(queueKey);
}

export async function removeVpsMessage(queueKey: string, messageId: string): Promise<void> {
  await ensureLegacyMigration();
  const database = await openDatabase();
  const transaction = database.transaction(STORE_NAME, 'readwrite');
  const done = transactionDone(transaction);
  transaction.objectStore(STORE_NAME).delete(recordKey(queueKey, messageId));
  await done;
}
