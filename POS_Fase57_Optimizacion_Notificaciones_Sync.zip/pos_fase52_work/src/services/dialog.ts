// Global In-App Dialog Service (Replaces native browser alert & confirm)

export interface DialogOptions {
  id?: string;
  title: string;
  message: string;
  type?: 'info' | 'warning' | 'error' | 'success';
  confirmText?: string;
  cancelText?: string;
  isConfirm?: boolean;
  onConfirm?: () => void;
  onCancel?: () => void;
}

type DialogListener = (dialog: DialogOptions | null) => void;

let activeDialog: DialogOptions | null = null;
const listeners: Set<DialogListener> = new Set();

export const DialogService = {
  subscribe(listener: DialogListener) {
    listeners.add(listener);
    listener(activeDialog);
    return () => {
      listeners.delete(listener);
    };
  },

  show(options: DialogOptions) {
    activeDialog = { ...options, id: Math.random().toString(36).substring(7) };
    listeners.forEach((l) => l(activeDialog));
  },

  close() {
    activeDialog = null;
    listeners.forEach((l) => l(null));
  },

  alert(message: string, title?: string, type?: 'info' | 'warning' | 'error' | 'success'): Promise<void> {
    return new Promise((resolve) => {
      this.show({
        title: title || 'Aviso del Sistema POS',
        message,
        type: type || 'info',
        confirmText: 'Entendido',
        onConfirm: () => {
          this.close();
          resolve();
        },
      });
    });
  },

  confirm(
    message: string,
    title?: string,
    confirmText: string = 'Aceptar',
    cancelText: string = 'Cancelar',
    type: 'warning' | 'error' | 'info' = 'warning'
  ): Promise<boolean> {
    return new Promise((resolve) => {
      this.show({
        title: title || 'Confirmar Acción',
        message,
        type,
        isConfirm: true,
        confirmText,
        cancelText,
        onConfirm: () => {
          this.close();
          resolve(true);
        },
        onCancel: () => {
          this.close();
          resolve(false);
        },
      });
    });
  },
};

// Polyfill window.alert as a safety net
if (typeof window !== 'undefined') {
  window.alert = (msg: any) => {
    DialogService.alert(String(msg));
  };
}
