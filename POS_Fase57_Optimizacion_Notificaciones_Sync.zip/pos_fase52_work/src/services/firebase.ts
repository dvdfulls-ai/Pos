// Firebase Initialization for Multi-Terminal Real-Time Sync
// Powers cloud synchronization across all PCs, smartphones (celulares), and tablets.
import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  initializeFirestore,
  getFirestore,
  memoryLocalCache,
  Firestore,
  persistentLocalCache,
  persistentMultipleTabManager
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const useFirestoreEmulator = String(import.meta.env.VITE_USE_FIREBASE_EMULATOR || '').toLowerCase() === 'true';
const firestoreEmulatorHost = import.meta.env.VITE_FIRESTORE_EMULATOR_HOST || '127.0.0.1';
const firestoreEmulatorPort = Number(import.meta.env.VITE_FIRESTORE_EMULATOR_PORT || 8080);

let app;
if (!getApps().length) {
  app = initializeApp(firebaseConfig);
} else {
  app = getApp();
}

let db: Firestore;
try {
  db = initializeFirestore(app, {
    localCache: useFirestoreEmulator
      ? memoryLocalCache()
      : persistentLocalCache({
          tabManager: persistentMultipleTabManager()
        })
  }, firebaseConfig.firestoreDatabaseId || '(default)');
} catch {
  // If already initialized in hot reload or alternate environment
  db = getFirestore(app, firebaseConfig.firestoreDatabaseId || '(default)');
}

// Firestore is retained only as an unused compatibility dependency in this build.
// The POS sync transport uses the hosting API relay, so no Firestore connection is opened.

export { app, db };

