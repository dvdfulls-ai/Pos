import React, { useState, useRef, useEffect, useMemo } from 'react';
import { 
  Barcode, 
  X, 
  Check, 
  ChevronDown, 
  Sparkles, 
  Package, 
  Plus, 
  Save, 
  CheckCircle2,
  ArrowRight
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Article } from '../../types';
import { DialogService } from '../../services/dialog';
import { formatThousands, parseFormattedNumber, toTitleCase } from '../../utils/text';

interface QuickArticleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onArticleAdded?: (article: Article) => void;
  initialNoticeId?: string;
  onCompleteNotice?: (noticeId: string) => void;
  initialBarcode?: string;
  singleSaveMode?: boolean;
}

export const QuickArticleModal: React.FC<QuickArticleModalProps> = ({
  isOpen,
  onClose,
  onArticleAdded,
  initialNoticeId,
  onCompleteNotice,
  initialBarcode = '',
  singleSaveMode = false
}) => {
  const { articles, addArticle, accounts } = useApp();

  const [formData, setFormData] = useState({
    barcode: '',
    name: '',
    brand: '',
    category: '',
    subcategory: '',
    supplier: '',
    costPrice: 0,
    salePrice: 0,
    stock: 0,
    minStock: 0,
    unit: 'Unidad',
  });

  const [costPriceStr, setCostPriceStr] = useState('');
  const [salePriceStr, setSalePriceStr] = useState('');
  const [stockStr, setStockStr] = useState('');
  const [minStockStr, setMinStockStr] = useState('');

  const [lastSavedArticle, setLastSavedArticle] = useState<string | null>(null);
  const [savedCount, setSavedCount] = useState<number>(0);

  // Autocomplete dropdowns
  const [showCategoryDropdown, setShowCategoryDropdown] = useState(false);
  const [showBrandSuggestions, setShowBrandSuggestions] = useState(false);

  // Field input references for auto Enter navigation
  const barcodeRef = useRef<HTMLInputElement>(null);
  const nameRef = useRef<HTMLInputElement>(null);
  const brandRef = useRef<HTMLInputElement>(null);
  const categoryRef = useRef<HTMLInputElement>(null);
  const subcategoryRef = useRef<HTMLInputElement>(null);
  const supplierRef = useRef<HTMLInputElement>(null);
  const costPriceRef = useRef<HTMLInputElement>(null);
  const salePriceRef = useRef<HTMLInputElement>(null);
  const stockRef = useRef<HTMLInputElement>(null);
  const minStockRef = useRef<HTMLInputElement>(null);

  const categoryContainerRef = useRef<HTMLDivElement>(null);
  const brandContainerRef = useRef<HTMLDivElement>(null);

  // Reset and focus when modal opens
  useEffect(() => {
    if (isOpen) {
      resetForm();
      setLastSavedArticle(null);
      setSavedCount(0);
      const timer = setTimeout(() => {
        if (initialBarcode) {
          nameRef.current?.focus();
        } else {
          barcodeRef.current?.focus();
          barcodeRef.current?.select();
        }
      }, 80);
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (categoryContainerRef.current && !categoryContainerRef.current.contains(e.target as Node)) {
        setShowCategoryDropdown(false);
      }
      if (brandContainerRef.current && !brandContainerRef.current.contains(e.target as Node)) {
        setShowBrandSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const resetForm = () => {
    setFormData({
      barcode: initialBarcode,
      name: '',
      brand: '',
      category: '',
      subcategory: '',
      supplier: '',
      costPrice: 0,
      salePrice: 0,
      stock: 0,
      minStock: 0,
      unit: 'Unidad',
    });
    setCostPriceStr('');
    setSalePriceStr('');
    setStockStr('');
    setMinStockStr('');
    setShowCategoryDropdown(false);
    setShowBrandSuggestions(false);
    barcodeRef.current?.focus();
  };

  // Suppliers & Subcategories
  const suppliers = useMemo(() => {
    const fromAccounts = accounts.filter(a => a.type === 'SUPPLIER').map(a => a.name);
    const fromArticles = articles.map(a => a.supplier).filter(Boolean) as string[];
    return Array.from(new Set([...fromAccounts, ...fromArticles])).sort((a, b) => a.localeCompare(b));
  }, [accounts, articles]);

  const existingSubcategories = useMemo(() => {
    const fromArticles = articles.map(a => a.subcategory).filter(Boolean) as string[];
    return Array.from(new Set(fromArticles)).sort((a, b) => a.localeCompare(b));
  }, [articles]);

  const existingCategories = useMemo(() => {
    const fromArticles = articles.map(a => a.category).filter(Boolean);
    const defaults = ['Almacén', 'Bebidas', 'Lácteos', 'Limpieza', 'Golosinas', 'Snacks', 'Panadería', 'Fiambrería', 'Perfumería', 'Verdulería'];
    return Array.from(new Set([...defaults, ...fromArticles])).sort((a, b) => a.localeCompare(b));
  }, [articles]);

  const matchingCategories = useMemo(() => {
    if (!formData.category.trim()) return existingCategories;
    return existingCategories.filter(c => c.toLowerCase().includes(formData.category.toLowerCase()));
  }, [existingCategories, formData.category]);

  const existingBrands = useMemo(() => {
    return Array.from(new Set(articles.map(a => a.brand).filter(Boolean))).sort((a, b) => a.localeCompare(b));
  }, [articles]);

  const matchingBrands = useMemo(() => {
    if (!formData.brand.trim()) return existingBrands.slice(0, 8);
    return existingBrands.filter(b => b.toLowerCase().includes(formData.brand.toLowerCase())).slice(0, 8);
  }, [existingBrands, formData.brand]);

  const handlePriceChange = (field: 'costPrice' | 'salePrice', rawValue: string) => {
    const formatted = formatThousands(rawValue);
    if (field === 'costPrice') {
      setCostPriceStr(formatted);
      setFormData(prev => ({ ...prev, costPrice: parseFormattedNumber(formatted) }));
    } else {
      setSalePriceStr(formatted);
      setFormData(prev => ({ ...prev, salePrice: parseFormattedNumber(formatted) }));
    }
  };

  const handleStockChange = (field: 'stock' | 'minStock', rawValue: string) => {
    const clean = rawValue.replace(/[^\d]/g, '');
    if (field === 'stock') {
      setStockStr(clean);
      setFormData(prev => ({ ...prev, stock: clean === '' ? 0 : parseInt(clean, 10) }));
    } else {
      setMinStockStr(clean);
      setFormData(prev => ({ ...prev, minStock: clean === '' ? 0 : parseInt(clean, 10) }));
    }
  };

  // Perform save: returns true if successful
  const executeSave = (): Article | null => {
    if (!formData.name.trim() || !formData.barcode.trim()) {
      DialogService.alert('El código de barras y el nombre del artículo son obligatorios.', 'Campos Requeridos', 'warning');
      return null;
    }

    const costNum = parseFormattedNumber(costPriceStr);
    const saleNum = parseFormattedNumber(salePriceStr);
    const stockNum = stockStr.trim() === '' ? 0 : parseInt(stockStr.replace(/[^\d]/g, ''), 10) || 0;
    const minStockNum = minStockStr.trim() === '' ? 0 : parseInt(minStockStr.replace(/[^\d]/g, ''), 10) || 0;

    const newArticle = addArticle({
      barcode: formData.barcode.trim(),
      name: toTitleCase(formData.name.trim()),
      brand: formData.brand.trim() ? toTitleCase(formData.brand.trim()) : 'Genérica',
      category: formData.category.trim() ? toTitleCase(formData.category.trim()) : 'General',
      subcategory: formData.subcategory?.trim() ? toTitleCase(formData.subcategory.trim()) : undefined,
      supplier: formData.supplier?.trim() ? toTitleCase(formData.supplier.trim()) : undefined,
      costPrice: costNum,
      salePrice: saleNum,
      stock: stockNum,
      minStock: minStockNum,
      unit: formData.unit || 'Unidad',
    });

    setLastSavedArticle(`${toTitleCase(formData.name.trim())} ($${formatThousands(saleNum)})`);
    setSavedCount(c => c + 1);

    if (onArticleAdded) {
      onArticleAdded(newArticle);
    }

    return newArticle;
  };

  // Action 1: Save and continue loading more articles
  const handleSaveAndContinue = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const saved = executeSave();
    if (saved) {
      resetForm();
      setTimeout(() => {
        barcodeRef.current?.focus();
        barcodeRef.current?.select();
      }, 50);
    }
  };

  // Action 2: Save and finish (close modal)
  const handleSaveAndFinish = () => {
    const saved = executeSave();
    if (saved) {
      if (initialNoticeId && onCompleteNotice) {
        onCompleteNotice(initialNoticeId);
      }
      onClose();
    }
  };

  // Enter Key Handler for sequential step-through
  const handleFieldKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, nextFieldRef: React.RefObject<HTMLInputElement | null>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (nextFieldRef && nextFieldRef.current) {
        nextFieldRef.current.focus();
        nextFieldRef.current.select?.();
      }
    }
  };

  // On the last field (minStock), Enter triggers "Save and Continue"
  const handleLastFieldKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (singleSaveMode) handleSaveAndFinish();
      else handleSaveAndContinue();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
      <div className="bg-white dark:bg-neutral-900 rounded-2xl max-w-xl w-full overflow-hidden shadow-2xl border border-neutral-200 dark:border-neutral-700 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 bg-neutral-900 text-white flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-neutral-800 rounded-xl text-emerald-400">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-sm sm:text-base tracking-tight">{singleSaveMode ? 'Cargar Artículo al Catálogo' : 'Carga Rápida de Artículos'}</h3>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800">
                  Enter = Siguiente Campo
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                {singleSaveMode ? 'Alta de artículo desde Ventas (POS)' : 'Al llegar al stock mínimo y apretar Enter se guarda y abre el siguiente automáticamente'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1 rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Feedback Banner when articles are saved consecutively */}
        {lastSavedArticle && (
          <div className="px-4 py-2.5 bg-emerald-50 dark:bg-emerald-950/60 border-b border-emerald-200 dark:border-emerald-800 flex items-center justify-between text-xs text-emerald-900 dark:text-emerald-200 animate-in fade-in">
            <div className="flex items-center gap-2 font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 flex-shrink-0" />
              <span>
                ¡Artículo guardado con éxito! <strong>{lastSavedArticle}</strong>
              </span>
            </div>
            <span className="text-[11px] font-bold font-mono px-2 py-0.5 rounded-full bg-emerald-200 dark:bg-emerald-900 text-emerald-950 dark:text-emerald-200">
              {savedCount} cargados
            </span>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={(e) => singleSaveMode ? (e.preventDefault(), handleSaveAndFinish()) : handleSaveAndContinue(e)} className="p-4 sm:p-5 overflow-y-auto space-y-3.5 text-xs flex-1">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* 1. Barcode */}
            <div className="col-span-1 sm:col-span-2">
              <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1 flex items-center justify-between">
                <span>1. Código de Barra (EAN-13 / Lector)</span>
                <span className="text-[10px] text-neutral-400 font-normal lowercase">(Presiona Enter para avanzar)</span>
              </label>
              <div className="relative">
                <Barcode className="absolute left-3 top-2.5 w-4 h-4 text-neutral-400" />
                <input
                  ref={barcodeRef}
                  type="text"
                  required
                  autoFocus
                  value={formData.barcode}
                  onChange={(e) => setFormData({ ...formData, barcode: e.target.value })}
                  onKeyDown={(e) => handleFieldKeyDown(e, nameRef)}
                  placeholder="Escanear o escribir código de barra..."
                  className="w-full pl-9 pr-3 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl text-xs font-mono font-bold text-neutral-950 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                />
              </div>
            </div>

            {/* 2. Name */}
            <div className="col-span-1 sm:col-span-2">
              <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                2. Nombre / Descripción del Artículo
              </label>
              <input
                ref={nameRef}
                type="text"
                required
                value={formData.name}
                onChange={(e) => {
                  const input = e.target;
                  const start = input.selectionStart;
                  const end = input.selectionEnd;
                  const val = toTitleCase(input.value);
                  setFormData({ ...formData, name: val });
                  if (start !== null && end !== null) {
                    requestAnimationFrame(() => {
                      input.setSelectionRange(start, end);
                    });
                  }
                }}
                onKeyDown={(e) => handleFieldKeyDown(e, brandRef)}
                placeholder="Ej: Yerba Mate Especial 1kg"
                className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl text-xs font-bold text-neutral-950 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* 3. Brand */}
            <div ref={brandContainerRef} className="relative">
              <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                3. Marca
              </label>
              <input
                ref={brandRef}
                type="text"
                value={formData.brand}
                onFocus={() => { if (existingBrands.length > 0) setShowBrandSuggestions(true); }}
                onChange={(e) => {
                  const input = e.target;
                  const start = input.selectionStart;
                  const end = input.selectionEnd;
                  const val = toTitleCase(input.value);
                  setFormData({ ...formData, brand: val });
                  setShowBrandSuggestions(true);
                  if (start !== null && end !== null) {
                    requestAnimationFrame(() => {
                      input.setSelectionRange(start, end);
                    });
                  }
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') setShowBrandSuggestions(false);
                  handleFieldKeyDown(e, categoryRef);
                }}
                placeholder="Ej: Playadito / La Serenísima"
                className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl text-xs font-medium text-neutral-950 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              />
              {showBrandSuggestions && matchingBrands.length > 0 && (
                <div className="absolute left-0 right-0 mt-1 max-h-36 overflow-y-auto bg-white dark:bg-neutral-800 rounded-xl shadow-xl border border-neutral-200 dark:border-neutral-700 z-50 py-1 text-xs divide-y divide-neutral-100 dark:divide-neutral-700">
                  {matchingBrands.map((b) => (
                    <button
                      key={b}
                      type="button"
                      onClick={() => {
                        setFormData({ ...formData, brand: b });
                        setShowBrandSuggestions(false);
                        categoryRef.current?.focus();
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 flex items-center justify-between"
                    >
                      <span>{b}</span>
                      <span className="text-[10px] text-neutral-400">Seleccionar</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* 4. Category */}
            <div ref={categoryContainerRef} className="relative">
              <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                4. Categoría
              </label>
              <div className="relative">
                <input
                  ref={categoryRef}
                  type="text"
                  value={formData.category}
                  onClick={() => setShowCategoryDropdown(true)}
                  onFocus={() => setShowCategoryDropdown(true)}
                  onChange={(e) => {
                    setFormData({ ...formData, category: e.target.value });
                    setShowCategoryDropdown(true);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') setShowCategoryDropdown(false);
                    handleFieldKeyDown(e, subcategoryRef);
                  }}
                  placeholder="Seleccionar o escribir categoría..."
                  className="w-full px-3 pr-8 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl text-xs font-medium text-neutral-950 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                />
                <button
                  type="button"
                  tabIndex={-1}
                  onClick={() => setShowCategoryDropdown(!showCategoryDropdown)}
                  className="absolute right-2 top-2.5 text-neutral-400 hover:text-neutral-700 p-0.5"
                >
                  <ChevronDown className="w-4 h-4" />
                </button>
              </div>

              {showCategoryDropdown && (
                <div className="absolute left-0 right-0 mt-1 max-h-40 overflow-y-auto bg-white dark:bg-neutral-800 rounded-xl shadow-xl border border-neutral-200 dark:border-neutral-700 z-50 py-1 text-xs divide-y divide-neutral-100 dark:divide-neutral-700">
                  {matchingCategories.map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => {
                        setFormData({ ...formData, category: cat });
                        setShowCategoryDropdown(false);
                        subcategoryRef.current?.focus();
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 flex items-center justify-between"
                    >
                      <span>{cat}</span>
                      {formData.category.toLowerCase() === cat.toLowerCase() && (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* 5. Subcategory */}
            <div>
              <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                5. Subcategoría (Opcional)
              </label>
              <input
                ref={subcategoryRef}
                type="text"
                list="quick-subcategories-list"
                value={formData.subcategory || ''}
                onChange={(e) => setFormData({ ...formData, subcategory: e.target.value })}
                onKeyDown={(e) => handleFieldKeyDown(e, supplierRef)}
                placeholder="Ej: Yerbas, Gaseosas, Galletitas..."
                className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl text-xs text-neutral-950 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              />
              <datalist id="quick-subcategories-list">
                {existingSubcategories.map(sub => <option key={sub} value={sub} />)}
              </datalist>
            </div>

            {/* 6. Supplier */}
            <div>
              <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                6. Proveedor (Opcional)
              </label>
              <input
                ref={supplierRef}
                type="text"
                list="quick-suppliers-list"
                value={formData.supplier || ''}
                onChange={(e) => setFormData({ ...formData, supplier: e.target.value })}
                onKeyDown={(e) => handleFieldKeyDown(e, costPriceRef)}
                placeholder="Seleccionar o escribir proveedor..."
                className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl text-xs text-neutral-950 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              />
              <datalist id="quick-suppliers-list">
                {suppliers.map(sup => <option key={sup} value={sup} />)}
              </datalist>
            </div>

            {/* 7. Cost Price */}
            <div>
              <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                7. Precio de Costo ($)
              </label>
              <input
                ref={costPriceRef}
                type="text"
                inputMode="decimal"
                value={costPriceStr}
                onChange={(e) => handlePriceChange('costPrice', e.target.value)}
                onKeyDown={(e) => handleFieldKeyDown(e, salePriceRef)}
                placeholder="0"
                className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl text-xs font-mono font-bold text-neutral-950 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* 8. Sale Price */}
            <div>
              <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                8. Precio de Venta ($)
              </label>
              <input
                ref={salePriceRef}
                type="text"
                inputMode="decimal"
                required
                value={salePriceStr}
                onChange={(e) => handlePriceChange('salePrice', e.target.value)}
                onKeyDown={(e) => handleFieldKeyDown(e, stockRef)}
                placeholder="0"
                className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-emerald-500 dark:border-emerald-500 rounded-xl text-xs font-mono font-black text-emerald-700 dark:text-emerald-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* 9. Current Stock */}
            <div>
              <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                9. Stock Actual (Unidades)
              </label>
              <input
                ref={stockRef}
                type="text"
                inputMode="numeric"
                value={stockStr}
                onChange={(e) => handleStockChange('stock', e.target.value)}
                onKeyDown={(e) => handleFieldKeyDown(e, minStockRef)}
                placeholder="0"
                className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl text-xs font-mono font-bold text-neutral-950 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* 10. Minimum Stock (Alert) - Pressing Enter here triggers continuous save */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-[11px] font-black text-neutral-900 dark:text-white uppercase">
                  10. Stock Mínimo (Alerta)
                </label>
                <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-0.5">
                  Enter ↵ = Guardar y Siguiente
                </span>
              </div>
              <input
                ref={minStockRef}
                type="text"
                inputMode="numeric"
                value={minStockStr}
                onChange={(e) => handleStockChange('minStock', e.target.value)}
                onKeyDown={handleLastFieldKeyDown}
                placeholder="0"
                className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-amber-400 dark:border-amber-500 rounded-xl text-xs font-mono font-bold text-neutral-950 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-3 sm:pt-4 border-t border-neutral-200 dark:border-neutral-700 flex flex-col sm:flex-row items-center justify-between gap-2.5">
            <div className="text-[11px] text-neutral-500 dark:text-neutral-400 font-medium text-center sm:text-left">
              {savedCount > 0 ? (
                <span>Llevas <strong>{savedCount}</strong> artículo(s) ingresados en esta sesión</span>
              ) : (
                <span>Presiona Enter en el último campo para guardar y continuar</span>
              )}
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-2 border-2 border-neutral-300 dark:border-neutral-600 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-xl text-neutral-700 dark:text-neutral-300 font-bold transition-colors order-last sm:order-first"
              >
                Cerrar
              </button>

              <div className="flex flex-col gap-2 w-full sm:w-auto">
                {!singleSaveMode && (
                  <button
                    type="submit"
                    className="w-full sm:w-auto px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-xl font-black uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer"
                    title="Guarda este artículo y deja la ventana lista para escanear el siguiente"
                  >
                    <Plus className="w-4 h-4" />
                    Guardar y Cargar Siguiente
                  </button>
                )}

                <button
                  type="button"
                  onClick={handleSaveAndFinish}
                  className="w-full sm:w-auto px-4 py-2 bg-neutral-900 hover:bg-neutral-800 active:scale-95 text-white rounded-xl font-black uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer"
                  title="Guarda este artículo y finaliza cerrando la ventana"
                >
                  <Check className="w-4 h-4 text-emerald-400" />
                  {singleSaveMode ? 'Guardar artículo' : 'Guardar y Finalizar'}
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
