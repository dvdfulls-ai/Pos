import React, { useState, useEffect, useRef } from 'react';
import { 
  AlertCircle, 
  CheckCircle2, 
  HelpCircle, 
  Info, 
  ShieldAlert, 
  X 
} from 'lucide-react';
import { DialogService, DialogOptions } from '../../services/dialog';

export const AppDialogModal: React.FC = () => {
  const [dialog, setDialog] = useState<DialogOptions | null>(null);
  const confirmBtnRef = useRef<HTMLButtonElement>(null);
  const dialogOpenedAt = useRef<number>(0);
  const [selectedAction, setSelectedAction] = useState<'confirm' | 'cancel'>('confirm');
  const selectedActionRef = useRef<'confirm' | 'cancel'>('confirm');

  const changeSelectedAction = (action: 'confirm' | 'cancel') => {
    selectedActionRef.current = action;
    setSelectedAction(action);
  };

  useEffect(() => {
    const unsubscribe = DialogService.subscribe((d) => {
      setDialog(d);
      selectedActionRef.current = 'confirm';
      setSelectedAction('confirm');
      if (d) {
        dialogOpenedAt.current = Date.now();
        setTimeout(() => {
          confirmBtnRef.current?.focus();
        }, 50);
      }
    });
    return () => unsubscribe();
  }, []);

  // Global keydown listener to confirm on 'Enter' and cancel on 'Escape'
  useEffect(() => {
    if (!dialog) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      // Prevent accidental immediate trigger from the keydown event that opened this dialog
      if (Date.now() - dialogOpenedAt.current < 120) {
        return;
      }

      if (dialog.isConfirm && (e.key === 'ArrowLeft' || e.key === 'ArrowRight')) {
        e.preventDefault();
        e.stopPropagation();
        changeSelectedAction(selectedActionRef.current === 'confirm' ? 'cancel' : 'confirm');
      } else if (e.key === 'Enter') {
        e.preventDefault();
        e.stopPropagation();
        if (dialog.isConfirm && selectedActionRef.current === 'cancel') dialog.onCancel?.();
        else dialog.onConfirm?.();
        DialogService.close();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        if (dialog.isConfirm) {
          dialog.onCancel?.();
        } else {
          dialog.onConfirm?.();
        }
        DialogService.close();
      }
    };

    window.addEventListener('keydown', handleKeyDown, true);
    return () => window.removeEventListener('keydown', handleKeyDown, true);
  }, [dialog]);

  if (!dialog) return null;

  const getIcon = () => {
    switch (dialog.type) {
      case 'success':
        return <CheckCircle2 className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />;
      case 'error':
        return <ShieldAlert className="w-6 h-6 text-red-600 dark:text-red-400" />;
      case 'warning':
        return <AlertCircle className="w-6 h-6 text-amber-600 dark:text-amber-400" />;
      case 'info':
      default:
        return dialog.isConfirm 
          ? <HelpCircle className="w-6 h-6 text-sky-600 dark:text-sky-400" />
          : <Info className="w-6 h-6 text-sky-600 dark:text-sky-400" />;
    }
  };

  const getBadgeStyle = () => {
    switch (dialog.type) {
      case 'success':
        return 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-900 dark:text-emerald-200 border-emerald-300 dark:border-emerald-800';
      case 'error':
        return 'bg-red-100 dark:bg-red-950/60 text-red-900 dark:text-red-200 border-red-300 dark:border-red-800';
      case 'warning':
        return 'bg-amber-100 dark:bg-amber-950/60 text-amber-900 dark:text-amber-200 border-amber-300 dark:border-amber-800';
      case 'info':
      default:
        return 'bg-sky-100 dark:bg-sky-950/60 text-sky-900 dark:text-sky-200 border-sky-300 dark:border-sky-800';
    }
  };

  return (
    <div 
      id="app-dialog-backdrop"
      className="fixed inset-0 bg-black/60 backdrop-blur-xs z-[9999] flex items-center justify-center p-4 animate-in fade-in duration-150"
      onClick={(e) => {
        if (e.target === e.currentTarget && !dialog.isConfirm) {
          dialog.onConfirm?.();
          DialogService.close();
        }
      }}
    >
      <div 
        id="app-dialog-card"
        className="bg-white dark:bg-neutral-900 rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-neutral-300 dark:border-neutral-700 animate-in zoom-in-95 duration-150 flex flex-col"
      >
        {/* Header */}
        <div className="px-5 py-4 bg-neutral-50 dark:bg-neutral-800/80 border-b border-neutral-200 dark:border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className={`p-2 rounded-xl border ${getBadgeStyle()}`}>
              {getIcon()}
            </div>
            <div>
              <h3 className="font-black text-sm tracking-tight text-neutral-950 dark:text-white">
                {dialog.title}
              </h3>
              <p className="text-[10px] text-neutral-500 dark:text-neutral-400 uppercase font-bold tracking-wider">
                Sistema POS Comercio
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              if (dialog.isConfirm) {
                dialog.onCancel?.();
              } else {
                dialog.onConfirm?.();
              }
              DialogService.close();
            }}
            className="text-neutral-400 hover:text-neutral-900 dark:hover:text-white p-1 rounded-lg hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Message Content */}
        <div className="p-5 text-xs text-neutral-700 dark:text-neutral-300 leading-relaxed whitespace-pre-line">
          {dialog.message}
        </div>

        {/* Action Buttons */}
        <div className="px-5 py-3.5 bg-neutral-50 dark:bg-neutral-800/40 border-t border-neutral-200 dark:border-neutral-800 flex items-center justify-end gap-2.5">
          {dialog.isConfirm && (
            <button
              id="dialog-btn-cancel"
              type="button"
              onClick={() => {
                dialog.onCancel?.();
                DialogService.close();
              }}
              className={`px-4 py-2 rounded-xl border text-xs font-bold transition-colors ${selectedAction === 'cancel' ? 'border-transparent bg-amber-500 text-neutral-950 shadow-md' : 'border-neutral-300 dark:border-neutral-700 bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-300 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-200'}`}
            >
              {dialog.cancelText || 'Cancelar'}
            </button>
          )}

          <button
            ref={confirmBtnRef}
            id="dialog-btn-confirm"
            type="button"
            autoFocus
            onClick={() => {
              dialog.onConfirm?.();
              DialogService.close();
            }}
            className={`px-5 py-2 rounded-xl text-xs font-bold shadow-xs transition-colors ${
              dialog.isConfirm && selectedAction === 'cancel'
                ? 'bg-neutral-800 hover:bg-neutral-900 text-white dark:bg-neutral-950 dark:hover:bg-black border border-neutral-700'
                : dialog.isConfirm
                ? 'bg-amber-500 hover:bg-amber-600 text-neutral-950'
                : dialog.type === 'error'
                ? 'bg-red-600 hover:bg-red-700 text-white'
                : dialog.type === 'warning'
                ? 'bg-neutral-900 hover:bg-neutral-800 dark:bg-amber-600 dark:hover:bg-amber-500 text-white'
                : 'bg-neutral-900 hover:bg-neutral-800 dark:bg-emerald-600 dark:hover:bg-emerald-500 text-white'
            }`}
          >
            {dialog.confirmText || (dialog.isConfirm ? 'Aceptar' : 'Entendido')}
          </button>
        </div>
      </div>
    </div>
  );
};
