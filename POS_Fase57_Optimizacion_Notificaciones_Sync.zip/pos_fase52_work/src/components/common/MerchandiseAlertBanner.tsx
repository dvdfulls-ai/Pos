import React, { useState, useEffect } from 'react';
import { 
  Bell, 
  Package, 
  Send, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  X, 
  Flame, 
  User, 
  Monitor,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storage';
import { MerchandiseNotice } from '../../types';

interface MerchandiseAlertBannerProps {
  onOpenArticleLoader: (noticeId?: string) => void;
}

export const MerchandiseAlertBanner: React.FC<MerchandiseAlertBannerProps> = ({
  onOpenArticleLoader
}) => {
  const { currentUser, hasPermission } = useAuth();
  const { currentTerminalId, terminals } = useApp();

  const [notices, setNotices] = useState<MerchandiseNotice[]>(() => StorageService.getMerchandiseNotices());
  const [showSendModal, setShowSendModal] = useState(false);
  const [targetTerminal, setTargetTerminal] = useState<string>('ALL');
  const [noticeNotes, setNoticeNotes] = useState<string>('');

  // Live timer tick every 1000ms
  const [now, setNow] = useState<number>(Date.now());

  useEffect(() => {
    const timer = setInterval(() => {
      setNow(Date.now());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Listen to StorageService sync & CustomEvents
  useEffect(() => {
    const refreshNotices = () => {
      setNotices(StorageService.getMerchandiseNotices());
    };

    const handleNoticeEvent = (e: any) => {
      if (e.detail) {
        refreshNotices();
      }
    };

    window.addEventListener('storage', refreshNotices);
    window.addEventListener('pos_merchandise_notice_event', handleNoticeEvent);

    const unsubscribe = StorageService.subscribeToSync((event) => {
      if (event.type === 'MERCHANDISE_NOTICE_RECEIVED' || event.type === 'MERCHANDISE_NOTICE_UPDATED') {
        refreshNotices();
      }
    });

    return () => {
      window.removeEventListener('storage', refreshNotices);
      window.removeEventListener('pos_merchandise_notice_event', handleNoticeEvent);
      unsubscribe();
    };
  }, []);

  const isOwnerOrAdmin = currentUser.role === 'OWNER' || currentUser.role === 'ADMIN' || currentUser.role === 'SUPER_ADMIN' || hasPermission('canManageInventory');

  // Active notices for current terminal
  const activeNoticeForMe = notices.find(n => 
    (n.status === 'PENDING' || n.status === 'IN_PROGRESS') &&
    (n.targetTerminalId === 'ALL' || n.targetTerminalId === currentTerminalId)
  );

  const handleSendNoticeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newNotice: MerchandiseNotice = {
      id: `NOT-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
      senderUserId: currentUser.id,
      senderUserName: currentUser.name,
      senderTerminalId: currentTerminalId,
      targetTerminalId: targetTerminal,
      title: 'Cargar nueva mercadería ingresada al local',
      notes: noticeNotes.trim() || undefined,
      createdAt: new Date().toISOString(),
      status: 'PENDING',
    };

    StorageService.sendMerchandiseNotice(newNotice);
    setNotices(prev => [newNotice, ...prev]);
    setShowSendModal(false);
    setNoticeNotes('');
  };

  const handleStartLoading = (notice: MerchandiseNotice) => {
    if (notice.status === 'PENDING') {
      StorageService.updateMerchandiseNoticeStatus(notice.id, 'IN_PROGRESS', currentUser.name, currentTerminalId);
    }
    onOpenArticleLoader(notice.id);
  };

  const handleFinishNotice = (noticeId: string) => {
    StorageService.updateMerchandiseNoticeStatus(noticeId, 'COMPLETED', currentUser.name, currentTerminalId);
    setNotices(StorageService.getMerchandiseNotices());
  };

  // Format elapsed time string: "04:32" or "1h 12m"
  const formatElapsedTime = (startIso: string) => {
    const startMs = new Date(startIso).getTime();
    const diffSec = Math.max(0, Math.floor((now - startMs) / 1000));
    const hours = Math.floor(diffSec / 3600);
    const minutes = Math.floor((diffSec % 3600) / 60);
    const seconds = diffSec % 60;

    if (hours > 0) {
      return `${hours}h ${String(minutes).padStart(2, '0')}m ${String(seconds).padStart(2, '0')}s`;
    }
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  };

  const formatReceivedDate = (iso: string) => {
    const d = new Date(iso);
    return `${d.toLocaleDateString([], { weekday: 'short', day: '2-digit', month: '2-digit' })} a las ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })} hs`;
  };

  return (
    <>
      <style>{`
        @keyframes heartbeatPulse {
          0% {
            transform: scale(1);
            box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7);
          }
          40% {
            transform: scale(1.04);
            box-shadow: 0 0 0 10px rgba(239, 68, 68, 0);
          }
          60% {
            transform: scale(1.02);
            box-shadow: 0 0 0 15px rgba(239, 68, 68, 0);
          }
          100% {
            transform: scale(1);
            box-shadow: 0 0 0 0 rgba(239, 68, 68, 0);
          }
        }
        .heartbeat-notice {
          animation: heartbeatPulse 1.6s infinite ease-in-out;
        }
      `}</style>

      {/* ADMIN / OWNER TRIGGER BUTTON IN TOP BAR */}
      {isOwnerOrAdmin && (
        <button
          type="button"
          onClick={() => setShowSendModal(true)}
          className="px-2.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-neutral-950 font-black text-xs flex items-center gap-1.5 shadow-sm transition-all active:scale-95"
          title="Mandar aviso a cajeros para cargar mercadería nueva"
        >
          <Bell className="w-3.5 h-3.5 text-neutral-950 animate-bounce" />
          <span className="hidden md:inline">Avisar Carga Mercadería</span>
        </button>
      )}

      {/* CASHIER BEATING / PULSING NOTICE BANNER (LATIDO) */}
      {activeNoticeForMe && (
        <div className="heartbeat-notice bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 text-white rounded-xl p-2.5 sm:p-3 shadow-xl border-2 border-amber-300 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs z-30">
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center flex-shrink-0 border border-white/30 text-amber-200">
              <Package className="w-6 h-6 animate-pulse" />
            </div>

            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-black text-sm uppercase tracking-tight text-white flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-300 animate-ping" />
                  ⚠️ Mercadería Nueva para Cargar
                </span>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-black/40 text-amber-200 border border-amber-400/40">
                  {activeNoticeForMe.status === 'IN_PROGRESS' ? 'Cargando en curso...' : 'Aviso pendiente de inicio'}
                </span>
              </div>

              <div className="text-[11px] text-white/95 mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5">
                <span>
                  <strong>Recibido:</strong> {formatReceivedDate(activeNoticeForMe.createdAt)}
                </span>
                <span>•</span>
                <span>
                  <strong>De:</strong> {activeNoticeForMe.senderUserName} ({activeNoticeForMe.senderTerminalId})
                </span>
                {activeNoticeForMe.notes && (
                  <>
                    <span>•</span>
                    <span className="italic text-amber-100">"{activeNoticeForMe.notes}"</span>
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto justify-between sm:justify-end flex-shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-white/20">
            {/* Running Timer */}
            <div className="px-3 py-1.5 bg-black/40 rounded-xl border border-white/20 font-mono text-center flex flex-col">
              <span className="text-[9px] uppercase tracking-wider text-amber-200 font-bold flex items-center justify-center gap-1">
                <Clock className="w-2.5 h-2.5" />
                {activeNoticeForMe.status === 'IN_PROGRESS' ? 'Tiempo Carga' : 'En Espera'}
              </span>
              <span className="text-base font-black text-amber-300 leading-none mt-0.5">
                {formatElapsedTime(activeNoticeForMe.createdAt)}
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => handleStartLoading(activeNoticeForMe)}
                className="px-3.5 py-2 bg-white text-neutral-950 hover:bg-neutral-100 active:scale-95 rounded-xl font-black uppercase tracking-wider shadow-md flex items-center gap-1.5 text-xs transition-all"
                title="Abrir formulario y comenzar a cargar los artículos"
              >
                <Package className="w-4 h-4 text-emerald-600" />
                <span>Cargar Artículos</span>
              </button>

              <button
                type="button"
                onClick={() => handleFinishNotice(activeNoticeForMe.id)}
                className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-xl font-bold uppercase tracking-wider shadow-md flex items-center gap-1 text-xs transition-all"
                title="Marcar que ya se terminó de cargar toda la mercadería"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span className="hidden sm:inline">Terminar</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ADMIN SEND NOTICE MODAL */}
      {showSendModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
          <div className="bg-white dark:bg-neutral-900 rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-neutral-200 dark:border-neutral-700">
            <div className="p-4 bg-neutral-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-amber-500 text-neutral-950 rounded-lg">
                  <Bell className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm">Mandar Aviso de Carga a Cajeros</h3>
                  <p className="text-[11px] text-neutral-400">Notifica en vivo con latido y cronómetro a la caja seleccionada</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowSendModal(false)}
                className="text-neutral-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSendNoticeSubmit} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                  Terminal / Cajero Destino:
                </label>
                <select
                  value={targetTerminal}
                  onChange={(e) => setTargetTerminal(e.target.value)}
                  className="w-full px-3 py-2.5 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl text-xs font-bold text-neutral-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                >
                  <option value="ALL">📢 Todas las Terminales y Cajas</option>
                  {terminals.map(t => (
                    <option key={t.id} value={t.id}>
                      🖥️ {t.name} ({t.id})
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-neutral-500 dark:text-neutral-400 mt-1">
                  El cajero de la terminal seleccionada verá de inmediato el aviso pulsante con cronómetro en espera.
                </p>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 uppercase mb-1">
                  Descripción o Detalle de la Mercadería (Opcional):
                </label>
                <textarea
                  rows={3}
                  value={noticeNotes}
                  onChange={(e) => setNoticeNotes(e.target.value)}
                  placeholder="Ej: Llegaron 4 cajas del proveedor La Láctea con yogures y quesos para ingresar al stock..."
                  className="w-full px-3 py-2 bg-white dark:bg-neutral-800 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl text-xs text-neutral-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-amber-500 resize-none"
                />
              </div>

              {/* Active & Past Notices History */}
              {notices.length > 0 && (
                <div className="pt-2 border-t border-neutral-200 dark:border-neutral-700 space-y-2">
                  <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider block">
                    Avisos Recientes del Local:
                  </span>
                  <div className="max-h-36 overflow-y-auto space-y-1.5 pr-1">
                    {notices.slice(0, 5).map(n => (
                      <div key={n.id} className="p-2 bg-neutral-50 dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700 flex items-center justify-between text-[11px]">
                        <div>
                          <div className="font-bold text-neutral-900 dark:text-white flex items-center gap-1.5">
                            <span className={`w-2 h-2 rounded-full ${n.status === 'COMPLETED' ? 'bg-emerald-500' : n.status === 'IN_PROGRESS' ? 'bg-amber-500' : 'bg-rose-500'}`} />
                            Destino: {n.targetTerminalId === 'ALL' ? 'Todas' : n.targetTerminalId}
                          </div>
                          <span className="text-[10px] text-neutral-500">
                            {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • {n.senderUserName}
                          </span>
                        </div>
                        <span className={`px-2 py-0.5 rounded font-mono font-bold text-[10px] ${
                          n.status === 'COMPLETED' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {n.status === 'COMPLETED' ? 'Completado' : formatElapsedTime(n.createdAt)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-3 border-t border-neutral-200 dark:border-neutral-700">
                <button
                  type="button"
                  onClick={() => setShowSendModal(false)}
                  className="px-4 py-2 border-2 border-neutral-300 dark:border-neutral-600 rounded-xl font-bold text-neutral-700 dark:text-neutral-300"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-600 active:scale-95 text-neutral-950 rounded-xl font-black uppercase tracking-wider flex items-center gap-1.5 shadow-md"
                >
                  <Send className="w-4 h-4" />
                  Enviar Aviso
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};
