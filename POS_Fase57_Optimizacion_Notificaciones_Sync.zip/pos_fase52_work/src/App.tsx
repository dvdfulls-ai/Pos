import React, { useState, useEffect, useRef } from 'react';
import { 
  ShoppingCart, 
  Package, 
  ShoppingBag, 
  UserCheck, 
  DollarSign, 
  Users, 
  Wifi, 
  WifiOff, 
  Monitor, 
  ChevronDown, 
  Sparkles,
  BookOpen,
  Shield,
  Layers,
  Moon,
  Sun,
  Lock,
  KeyRound,
  X,
  Type,
  Download,
  CreditCard,
  Tv,
  Maximize2,
  Settings,
  Sliders,
  ChevronRight,
  Edit3,
  LogOut
} from 'lucide-react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AppProvider, useApp } from './context/AppContext';
import { SalesModule } from './modules/sales/SalesModule';
import { InventoryModule } from './modules/inventory/InventoryModule';
import { PurchasesModule } from './modules/purchases/PurchasesModule';
import { AccountsModule } from './modules/accounts/AccountsModule';
import { CashRegisterModule } from './modules/cash/CashRegisterModule';
import { UsersModule } from './modules/users/UsersModule';
import { SettingsModule } from './modules/settings/SettingsModule';
import { ArchitectBlueprintModal } from './modules/architect/ArchitectBlueprintModal';
import { PaymentConfigModal } from './modules/customer/PaymentConfigModal';
import { CustomerDisplayView } from './modules/customer/CustomerDisplayView';
import { WifiDisplayModal } from './modules/customer/WifiDisplayModal';
import { StorageService } from './services/storage';
import { PeerSync } from './services/peerSync';
import { DialogService } from './services/dialog';
import { AppDialogModal } from './components/common/AppDialogModal';
import { User } from './types';

type NavModule = 'VENTAS' | 'ARTICULOS' | 'COMPRAS' | 'CUENTAS' | 'CAJA' | 'USUARIOS' | 'CONFIGURACION';

const MainLayout: React.FC = () => {
  const { currentUser, users, loginAs, authenticateAndLogin, hasPermission } = useAuth();
  // Solo para mostrar el nombre vigente: el objeto de sesión puede conservar un nombre antiguo aunque la lista de usuarios ya esté sincronizada.
  const displayedUser = users.find(user => user.id === currentUser.id) || currentUser;
  const { 
    currentTerminalId, 
    setCurrentTerminalId, 
    terminals, 
    isOffline, 
    toggleOfflineMode,
    pendingSyncCount,
    syncNow,
    networkToast,
    dismissNetworkToast
  } = useApp();

  const [activeModule, setActiveModule] = useState<NavModule>('VENTAS');
  const readCommerceDisplayName = () => {
    try {
      const linkedName = (localStorage.getItem('pos_commerce_name') || '').trim();
      if (linkedName) return linkedName;
      // Si el nombre de vinculación todavía no está guardado en este navegador,
      // mostrar el nombre del comercio configurado en el propio POS como respaldo.
      const businessInfo = JSON.parse(localStorage.getItem('pos_business_info_v1') || '{}');
      return typeof businessInfo?.name === 'string' ? businessInfo.name.trim() : '';
    } catch { return ''; }
  };
  const [commerceDisplayName, setCommerceDisplayName] = useState<string>(() => readCommerceDisplayName());

  useEffect(() => {
    // Releer el nombre guardado al iniciar y al volver a la pestaña, para que
    // el encabezado lo recupere aunque el estado visual haya quedado desactualizado.
    const refreshCommerceName = () => {
      setCommerceDisplayName(readCommerceDisplayName());
    };
    const updateCommerceName = (event: Event) => {
      const customEvent = event as CustomEvent<string>;
      const eventName = typeof customEvent.detail === 'string' ? customEvent.detail.trim() : '';
      if (eventName) {
        setCommerceDisplayName(eventName);
      } else {
        refreshCommerceName();
      }
    };
    refreshCommerceName();
    window.addEventListener('pos-commerce-name-change', updateCommerceName);
    window.addEventListener('focus', refreshCommerceName);
    document.addEventListener('visibilitychange', refreshCommerceName);
    window.addEventListener('storage', refreshCommerceName);
    window.addEventListener('pos_business_info_changed', refreshCommerceName);
    return () => {
      window.removeEventListener('pos-commerce-name-change', updateCommerceName);
      window.removeEventListener('focus', refreshCommerceName);
      document.removeEventListener('visibilitychange', refreshCommerceName);
      window.removeEventListener('storage', refreshCommerceName);
      window.removeEventListener('pos_business_info_changed', refreshCommerceName);
    };
  }, []);
  const [sharedZoomIndex, setSharedZoomIndex] = useState<number>(() => {
    try { const saved = parseInt(localStorage.getItem('pos_global_zoom') || '0', 10); return Number.isFinite(saved) ? Math.max(0, Math.min(3, saved)) : 0; } catch { return 0; }
  });

  useEffect(() => {
    const updateZoom = (event: Event) => {
      const customEvent = event as CustomEvent<number>;
      const next = Number.isFinite(customEvent.detail) ? Math.max(0, Math.min(3, customEvent.detail)) : 0;
      setSharedZoomIndex(next);
    };
    window.addEventListener('pos-global-zoom-change', updateZoom);
    return () => window.removeEventListener('pos-global-zoom-change', updateZoom);
  }, []);

  const sharedZoomPercent = [100, 115, 130, 150][sharedZoomIndex] || 100;
  const [settingsInitialSubTab, setSettingsInitialSubTab] = useState<'TERMINALS' | 'SHORTCUTS' | 'PRINTER' | 'PAYMENTS' | 'COMMERCE' | 'CLOUD_OFFLINE'>('TERMINALS');
  const [showUserMenu, setShowUserMenu] = useState(false);
  const userMenuContainerRef = useRef<HTMLDivElement>(null);
  const [showTerminalMenu, setShowTerminalMenu] = useState(false);
  const terminalMenuContainerRef = useRef<HTMLDivElement>(null);
  const [showArchitectModal, setShowArchitectModal] = useState(false);
  const [showPaymentConfigModal, setShowPaymentConfigModal] = useState(false);
  const [showCustomerDisplayModal, setShowCustomerDisplayModal] = useState(false);
  const [showCustomerDisplayMenu, setShowCustomerDisplayMenu] = useState(false);
  const customerDisplayMenuContainerRef = useRef<HTMLDivElement>(null);
  const [showWifiDisplayModal, setShowWifiDisplayModal] = useState(false);

  // Cerrar el selector de usuario al tocar fuera de su menú.
  useEffect(() => {
    if (!showUserMenu) return;
    const handleOutsidePointer = (event: PointerEvent) => {
      if (userMenuContainerRef.current && !userMenuContainerRef.current.contains(event.target as Node)) {
        setShowUserMenu(false);
      }
    };
    document.addEventListener('pointerdown', handleOutsidePointer);
    return () => document.removeEventListener('pointerdown', handleOutsidePointer);
  }, [showUserMenu]);

  // Cerrar el selector de terminal al tocar fuera de su menú.
  useEffect(() => {
    if (!showTerminalMenu) return;
    const handleOutsideTerminalPointer = (event: PointerEvent) => {
      if (terminalMenuContainerRef.current && !terminalMenuContainerRef.current.contains(event.target as Node)) {
        setShowTerminalMenu(false);
      }
    };
    document.addEventListener('pointerdown', handleOutsideTerminalPointer);
    return () => document.removeEventListener('pointerdown', handleOutsideTerminalPointer);
  }, [showTerminalMenu]);

  // Cerrar el menú de la segunda pantalla al tocar fuera de él.
  useEffect(() => {
    if (!showCustomerDisplayMenu) return;
    const handleOutsideCustomerDisplayPointer = (event: PointerEvent) => {
      if (customerDisplayMenuContainerRef.current && !customerDisplayMenuContainerRef.current.contains(event.target as Node)) {
        setShowCustomerDisplayMenu(false);
      }
    };
    document.addEventListener('pointerdown', handleOutsideCustomerDisplayPointer);
    return () => document.removeEventListener('pointerdown', handleOutsideCustomerDisplayPointer);
  }, [showCustomerDisplayMenu]);

  // Dark Mode State with persistence
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('pos_dark_mode') === 'true';
  });

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('pos_dark_mode', 'true');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('pos_dark_mode', 'false');
    }
  }, [darkMode]);

  useEffect(() => {
    const handleRestoredTheme = (event: Event) => {
      const detail = (event as CustomEvent<{ darkMode?: boolean }>).detail;
      if (typeof detail?.darkMode === 'boolean') setDarkMode(detail.darkMode);
    };
    window.addEventListener('pos_theme_restored', handleRestoredTheme);
    return () => window.removeEventListener('pos_theme_restored', handleRestoredTheme);
  }, []);

  // Start WebRTC PeerSync Host for current cashier terminal
  useEffect(() => {
    try {
      PeerSync.startHost(currentTerminalId, () => StorageService.getCustomerDisplayState(currentTerminalId));
    } catch {}
    return () => {
      PeerSync.stopHost();
    };
  }, [currentTerminalId]);

  // Session Authentication State (Requires username and password when app opens)
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return typeof window !== 'undefined' && sessionStorage.getItem('pos_authenticated') === 'true';
  });

  // Secure Login Modal State (Username and Password only)
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [loginUsernameInput, setLoginUsernameInput] = useState('');
  const [loginPasswordInput, setLoginPasswordInput] = useState('');
  const [loginError, setLoginError] = useState('');
  const [targetUserForLogin, setTargetUserForLogin] = useState<User | null>(null);

  // PWA Install State & Event Handler
  const [installPromptEvent, setInstallPromptEvent] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [showInstallHelpModal, setShowInstallHelpModal] = useState(false);

  useEffect(() => {
    const handleBeforeInstall = (e: any) => {
      e.preventDefault();
      setInstallPromptEvent(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    window.addEventListener('appinstalled', () => {
      setIsInstalled(true);
      setInstallPromptEvent(null);
    });

    const handleOpenDisplayModal = () => {
      setShowCustomerDisplayModal(true);
    };
    window.addEventListener('pos_open_customer_display_modal', handleOpenDisplayModal);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      window.removeEventListener('pos_open_customer_display_modal', handleOpenDisplayModal);
    };
  }, []);

  // Navegación por flechas en los diálogos solicitados, sin interferir con los campos de texto.
  useEffect(() => {
    const normalized = (value: string) => value.toLocaleLowerCase('es').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const targetDialogTitles = [
      'articulo no encontrado',
      'agregar articulo al catalogo',
      'nuevo articulo',
      'registrar factura de compra',
      'crear cuenta corriente',
      'arqueo & cierre de caja',
      'crear nuevo usuario',
      'editar usuario & permisos',
      'iniciar sesion',
      'acceder como',
    ];
    const actionWords = /^(cancelar|guardar|confirmar|registrar|crear|agregar articulo nuevo|ingresar|acceder|aceptar|volver|continuar|actualizar|cerrar caja)\b/i;

    const handleDialogArrowNavigation = (event: KeyboardEvent) => {
      if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)) return;
      const target = event.target as HTMLElement | null;
      if (!target) return;

      // El menú de selección de usuario no es un modal, pero también debe poder recorrerse.
      const userMenu = document.getElementById('user-switch-menu');
      const inUserMenu = !!userMenu && !!userMenu.parentElement?.contains(target) && userMenu.getClientRects().length > 0;
      let candidates: HTMLButtonElement[] = [];

      if (inUserMenu && userMenu) {
        candidates = Array.from(userMenu.querySelectorAll<HTMLButtonElement>('button:not(:disabled)'))
          .filter(button => button.getClientRects().length > 0 && button.textContent?.trim());
      } else {
        const overlays = Array.from(document.querySelectorAll<HTMLElement>('.fixed.inset-0'))
          .filter(element => element.getClientRects().length > 0)
          .reverse();
        const overlay = overlays.find(element => {
          const text = normalized(element.textContent || '');
          return targetDialogTitles.some(title => text.includes(title));
        });
        if (!overlay) return;

        // Solo recorrer los botones de acción; se excluyen los botones de cerrar y controles internos.
        candidates = Array.from(overlay.querySelectorAll<HTMLButtonElement>('button:not(:disabled)'))
          .filter(button => {
            if (!button.getClientRects().length || button.getAttribute('aria-label') === 'Cerrar') return false;
            const label = normalized((button.innerText || button.textContent || '').replace(/\s+/g, ' ').trim());
            return !!label && actionWords.test(label);
          });
      }

      if (candidates.length < 2) return;
      const isTextEntry = target.matches('input, textarea, select, [contenteditable="true"]');
      // En el formulario de catálogo, las flechas pertenecen a los desplegables
      // de Marca, Categoría, Subcategoría y Proveedor; no mover el foco a botones.
      const catalogOverlay = target.closest<HTMLElement>('.fixed.inset-0');
      if (isTextEntry && catalogOverlay && normalized(catalogOverlay.textContent || '').includes('agregar articulo al catalogo')) {
        return;
      }
      if (isTextEntry) {
        // ArrowDown/ArrowUp permite salir del campo hacia los botones; izquierda/derecha siguen editando texto.
        if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return;
        if (target.tagName === 'TEXTAREA' || target.tagName === 'SELECT') return;
        event.preventDefault();
        event.stopPropagation();
        (event.key === 'ArrowDown' ? candidates[0] : candidates[candidates.length - 1]).focus();
        return;
      }

      const currentIndex = candidates.indexOf(target as HTMLButtonElement);
      if (currentIndex < 0) {
        // Si el foco está en el fondo del diálogo, la primera flecha selecciona una acción.
        if (inUserMenu || target.closest('.fixed.inset-0')) {
          event.preventDefault();
          event.stopPropagation();
          (event.key === 'ArrowUp' || event.key === 'ArrowLeft' ? candidates[candidates.length - 1] : candidates[0]).focus();
        }
        return;
      }
      event.preventDefault();
      event.stopPropagation();
      const delta = event.key === 'ArrowLeft' || event.key === 'ArrowUp' ? -1 : 1;
      candidates[(currentIndex + delta + candidates.length) % candidates.length].focus();
    };

    window.addEventListener('keydown', handleDialogArrowNavigation, true);
    return () => window.removeEventListener('keydown', handleDialogArrowNavigation, true);
  }, []);

  // Global Keyboard Shortcuts Listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const shortcuts = StorageService.getKeyboardShortcuts();
      const target = e.target as HTMLElement;
      const isInput = target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT');

      const keyName = e.key;
      const match = Array.isArray(shortcuts) ? shortcuts.find(s => typeof s?.key === 'string' && typeof keyName === 'string' && s.key.toLowerCase() === keyName.toLowerCase()) : undefined;
      if (!match) return;

      const isFunctionKey = /^F[1-9]|F1[0-2]$/i.test(e.key);
      const isEscape = e.key === 'Escape';

      // If user is inside an input, don't hijack unless it's a dedicated function key (F1-F12) or Escape
      if (isInput && !isFunctionKey && !isEscape) {
        return;
      }

      e.preventDefault();

      if (match.action === 'cash_register') {
        setActiveModule('CAJA');
      } else if (match.action === 'new_article') {
        setActiveModule('ARTICULOS');
        setTimeout(() => {
          window.dispatchEvent(new CustomEvent('pos-action-new-article'));
        }, 80);
      } else {
        if (activeModule !== 'VENTAS' && match.action !== 'cancel') {
          setActiveModule('VENTAS');
          setTimeout(() => {
            window.dispatchEvent(new CustomEvent('pos-shortcut', { detail: match.action }));
          }, 60);
        } else {
          window.dispatchEvent(new CustomEvent('pos-shortcut', { detail: match.action }));
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeModule]);

  const handleInstallClick = async () => {
    if (installPromptEvent) {
      installPromptEvent.prompt();
      const { outcome } = await installPromptEvent.userChoice;
      if (outcome === 'accepted') {
        setInstallPromptEvent(null);
      }
    } else {
      setShowInstallHelpModal(true);
    }
  };

  const handleOpenLoginForUser = (user: User) => {
    setTargetUserForLogin(user);
    setLoginUsernameInput(user.username || '');
    setLoginPasswordInput('');
    setLoginError('');
    setShowLoginModal(true);
    setShowUserMenu(false);
  };

  const handleOpenDirectLogin = () => {
    setTargetUserForLogin(null);
    setLoginUsernameInput('');
    setLoginPasswordInput('');
    setLoginError('');
    setShowLoginModal(true);
    setShowUserMenu(false);
  };

  const handleSubmitLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginUsernameInput.trim() || !loginPasswordInput.trim()) {
      setLoginError('Por favor ingrese usuario y contraseña');
      return;
    }

    const res = authenticateAndLogin(loginUsernameInput.trim(), loginPasswordInput);
    if (!res.success) {
      setLoginError(res.message || 'Usuario o contraseña incorrectos');
      return;
    }

    if (typeof window !== 'undefined') {
      sessionStorage.setItem('pos_authenticated', 'true');
    }
    setIsAuthenticated(true);
    setShowLoginModal(false);
    setLoginPasswordInput('');
    setLoginError('');
  };

  // FASE 55: el módulo visual de Historial queda desactivado temporalmente para pruebas de rendimiento.
  // No se elimina ni se desactiva el registro de ventas/auditoría: los datos históricos se conservan.
  // Filter modules based on user permissions
  const navItems: { id: NavModule; label: string; icon: React.ReactNode; permitted: boolean }[] = [
    {
      id: 'VENTAS',
      label: 'Ventas (POS)',
      icon: <ShoppingCart className="w-4 h-4" />,
      permitted: hasPermission('canMakeSales'),
    },
    {
      id: 'ARTICULOS',
      label: 'Artículos & Stock',
      icon: <Package className="w-4 h-4" />,
      permitted: hasPermission('canManageInventory') || currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'OWNER',
    },
    {
      id: 'COMPRAS',
      label: 'Compras & Pagos',
      icon: <ShoppingBag className="w-4 h-4" />,
      permitted: hasPermission('canMakePurchases') || currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'OWNER' || currentUser.role === 'ADMIN',
    },
    {
      id: 'CUENTAS',
      label: 'Cuentas Corrientes',
      icon: <UserCheck className="w-4 h-4" />,
      permitted: hasPermission('canManageAccounts') || currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'OWNER',
    },
    {
      id: 'CAJA',
      label: 'Cierre de Caja',
      icon: <DollarSign className="w-4 h-4" />,
      permitted: hasPermission('canCloseCashRegister') || currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'OWNER',
    },
    {
      id: 'USUARIOS',
      label: 'Usuarios & Permisos',
      icon: <Users className="w-4 h-4" />,
      permitted: currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'OWNER',
    },
    {
      id: 'CONFIGURACION',
      label: 'Configuración',
      icon: <Settings className="w-4 h-4" />,
      permitted: hasPermission('canManageSettings') || currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'OWNER' || currentUser.role === 'ADMIN',
    },
  ];

  const currentTerminalObj = terminals.find(t => t.id === currentTerminalId) || terminals[0];

  return (
    <div 
      className="h-screen max-h-screen overflow-hidden bg-neutral-100 dark:bg-neutral-950 flex flex-col font-['Plus_Jakarta_Sans',sans-serif] text-neutral-900 dark:text-neutral-100 transition-colors"
    >
      {/* TOP STATUS & CONTROL BAR */}
      <header className="bg-white border-b border-neutral-200 sticky top-0 z-40 shadow-2xs flex-shrink-0">
        {networkToast && (
          <div 
            id="network-status-toast"
            className={`px-4 py-2 flex items-center justify-between text-xs font-bold transition-all border-b ${
              networkToast.status === 'online'
                ? 'bg-emerald-600 text-white border-emerald-700'
                : 'bg-amber-500 text-neutral-950 border-amber-600'
            }`}
          >
            <div className="flex items-center gap-2 max-w-5xl mx-auto w-full">
              {networkToast.status === 'online' ? (
                <Wifi className="w-4 h-4 shrink-0 animate-pulse" />
              ) : (
                <WifiOff className="w-4 h-4 shrink-0 animate-bounce" />
              )}
              <span>{networkToast.message}</span>
              <span className="ml-auto text-[10px] font-mono uppercase tracking-widest hidden sm:inline px-2 py-0.5 rounded bg-black/10">
                {networkToast.status === 'online' ? 'Autodetección: Conectado' : 'Autodetección: Desconectado'}
              </span>
              <button 
                type="button"
                onClick={dismissNetworkToast} 
                className="ml-2 p-1 hover:bg-black/10 rounded cursor-pointer"
                title="Cerrar aviso"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
        <div className="w-full px-3 sm:px-4 py-2 flex items-center justify-between gap-2 sm:gap-3">
          {/* Logo & Name */}
          <div className="flex items-center gap-2.5 sm:gap-3">
            <div className="w-8 h-8 rounded-lg bg-neutral-900 text-white flex items-center justify-center font-bold text-sm tracking-wider shadow-xs">
              POS
            </div>
            <div>
              <h1 className="font-extrabold text-sm tracking-tight text-neutral-900">
                Sistema Comercial & POS
              </h1>
              <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
                {commerceDisplayName && (
                  <span
                    className="text-[10px] sm:text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-md px-1.5 py-0.5"
                    title="Comercio vinculado a esta terminal"
                  >
                    Comercio: {commerceDisplayName}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Central Controls: Terminal, Status, Dark Mode, Zoom & PWA */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Multi-Terminal Selector */}
            <div className="relative" ref={terminalMenuContainerRef}>
              <button
                type="button"
                onClick={() => {
                  setShowTerminalMenu(!showTerminalMenu);
                  setShowUserMenu(false);
                }}
                className="px-2.5 py-1.5 bg-neutral-50 hover:bg-neutral-100 border border-neutral-200 rounded-lg text-xs font-semibold text-neutral-700 flex items-center gap-1.5 transition-colors"
                title="Cambiar de Terminal / Caja"
              >
                <Monitor className="w-3.5 h-3.5 text-neutral-500" />
                <span className="hidden sm:inline">{currentTerminalObj?.name || currentTerminalId}</span>
                <span className="sm:hidden">{currentTerminalId}</span>
                <ChevronDown className="w-3 h-3 text-neutral-400" />
              </button>

              {showTerminalMenu && (
                <div className="absolute left-0 mt-1 w-72 bg-white dark:bg-neutral-900 rounded-xl shadow-xl border border-neutral-200 dark:border-neutral-700 p-2 z-50 animate-in fade-in zoom-in-95">
                  <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-neutral-400 dark:text-neutral-500 flex items-center justify-between">
                    <span>Terminales Conectadas</span>
                    <span className="font-mono text-[9px] text-indigo-600 dark:text-indigo-400 font-bold">3 Cajas</span>
                  </div>
                  <div className="space-y-1 mt-1">
                    {terminals.map(term => (
                      <button
                        key={term.id}
                        type="button"
                        onClick={() => {
                          setCurrentTerminalId(term.id);
                          setShowTerminalMenu(false);
                        }}
                        className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs flex items-center justify-between transition-colors ${
                          term.id === currentTerminalId
                            ? 'bg-neutral-900 dark:bg-indigo-600 text-white font-bold shadow-xs'
                            : 'hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300'
                        }`}
                      >
                        <div className="min-w-0 pr-2">
                          <div className="truncate">{term.name}</div>
                          <span className={`text-[10px] truncate block ${term.id === currentTerminalId ? 'text-neutral-300 dark:text-indigo-200' : 'opacity-70 font-normal'}`}>
                            {term.location || 'Sin ubicación'}
                          </span>
                        </div>
                        <span className={`text-[10px] font-mono shrink-0 px-1.5 py-0.5 rounded ${
                          term.id === currentTerminalId ? 'bg-white/20' : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-500'
                        }`}>
                          {term.id}
                        </span>
                      </button>
                    ))}
                  </div>

                  <div className="pt-2 mt-2 border-t border-neutral-100 dark:border-neutral-800">
                    <button
                      type="button"
                      onClick={() => {
                        setShowTerminalMenu(false);
                        setSettingsInitialSubTab('TERMINALS');
                        setActiveModule('CONFIGURACION');
                      }}
                      className="w-full text-left px-2.5 py-2 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/50 dark:hover:bg-indigo-900/50 text-indigo-900 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 rounded-lg text-xs font-bold flex items-center justify-between transition-colors shadow-2xs"
                    >
                      <div className="flex items-center gap-2">
                        <Sliders className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                        <span>Editar Textos de las 3 Terminales</span>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 opacity-60" />
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Offline / Cloud Status Badge */}
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={toggleOfflineMode}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors border ${
                  isOffline
                    ? 'bg-amber-50 border-amber-300 dark:bg-amber-950/40 dark:border-amber-700 text-amber-800 dark:text-amber-300 hover:bg-amber-100'
                    : 'bg-emerald-50 border-emerald-300 dark:bg-emerald-950/40 dark:border-emerald-700 text-emerald-800 dark:text-emerald-300 hover:bg-emerald-100'
                }`}
                title="Detección automática de red activa. Clic para alternar manualmente modo local/en línea."
              >
                {isOffline ? (
                  <>
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
                    </span>
                    <WifiOff className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                    <span className="hidden sm:inline">Modo Local (Offline)</span>
                  </>
                ) : (
                  <>
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                    </span>
                    <Wifi className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    <span className="hidden sm:inline">En la Nube (Online)</span>
                  </>
                )}
              </button>

              {isOffline && pendingSyncCount > 0 && (
                <button
                  type="button"
                  onClick={syncNow}
                  className="px-2 py-1 bg-amber-600 text-white text-[11px] font-bold rounded-lg hover:bg-amber-700 transition-colors"
                >
                  Sincronizar ({pendingSyncCount})
                </button>
              )}
            </div>

            {/* PWA Install Button */}
            <button
              type="button"
              onClick={handleInstallClick}
              className="px-2.5 py-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition-colors bg-emerald-50 border-emerald-200 text-emerald-800 hover:bg-emerald-100"
              title="Instalar aplicación en Windows / Celular (PWA)"
            >
              <Download className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden md:inline text-[11px] font-bold">Instalar PWA</span>
            </button>

            {/* Dark Mode Toggle Button - Gris Oscuro sin azules */}
            <button
              type="button"
              onClick={() => setDarkMode(!darkMode)}
              className={`p-1.5 px-2 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                darkMode 
                  ? 'bg-neutral-800 border-neutral-700 text-neutral-200 hover:bg-neutral-700' 
                  : 'bg-neutral-50 border-neutral-200 text-neutral-700 hover:bg-neutral-100'
              }`}
              title={darkMode ? 'Cambiar a Modo Claro' : 'Cambiar a Modo Oscuro (Gris Grafito)'}
            >
              {darkMode ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5 text-neutral-600" />}
              <span className="hidden lg:inline text-[11px]">{darkMode ? 'Oscuro' : 'Claro'}</span>
            </button>

            {/* Segunda Pantalla para el Cliente (2do Monitor) */}
            <div className="relative" ref={customerDisplayMenuContainerRef}>
              <button
                type="button"
                onClick={() => {
                  setShowCustomerDisplayMenu(!showCustomerDisplayMenu);
                  setShowUserMenu(false);
                  setShowTerminalMenu(false);
                }}
                className="px-2.5 py-1.5 bg-neutral-50 hover:bg-neutral-100 dark:bg-neutral-800 dark:hover:bg-neutral-700 border border-neutral-200 dark:border-neutral-700 rounded-lg text-xs font-semibold text-neutral-700 dark:text-neutral-200 flex items-center gap-1 transition-colors"
                title="Abrir o ver la 2da pantalla para el cliente"
              >
                <Tv className="w-3.5 h-3.5 text-emerald-500" />
                <span className="hidden md:inline text-[11px] font-bold">2da Pantalla</span>
                <ChevronDown className="w-3 h-3 text-neutral-400" />
              </button>

              {showCustomerDisplayMenu && (
                <div className="absolute right-0 mt-1 w-72 bg-white text-neutral-950 rounded-xl shadow-xl border-2 border-neutral-300 p-2.5 z-50 animate-in fade-in zoom-in-95 text-xs">
                  <div className="px-2 py-1 text-[10px] font-black uppercase tracking-wider text-neutral-600 border-b border-neutral-100 pb-1.5 mb-1 flex items-center justify-between">
                    <span>Pantalla para el Cliente</span>
                    <span className="text-emerald-700 font-bold flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      Sincronizada
                    </span>
                  </div>
                  <div className="space-y-1">
                    <button
                      type="button"
                      onClick={() => {
                        setShowCustomerDisplayMenu(false);
                        setShowWifiDisplayModal(true);
                      }}
                      className="w-full text-left px-2.5 py-2 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-950 border border-emerald-200 flex items-center gap-2.5 transition-colors"
                    >
                      <div className="p-1.5 bg-emerald-600 text-white rounded-lg flex-shrink-0">
                        <Wifi className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-black text-xs text-emerald-900">Conectar por Wi-Fi (Tablet/Celular)</div>
                        <div className="text-[10px] text-emerald-700 font-medium">Escanear QR desde cualquier dispositivo</div>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setShowCustomerDisplayMenu(false);
                        const url = window.location.origin + window.location.pathname + '?customer_display=true';
                        let win: Window | null = null;
                        try {
                          win = window.open(url, '_blank');
                        } catch {}
                        if (!win || win.closed || typeof win.closed === 'undefined') {
                          setShowCustomerDisplayModal(true);
                        }
                      }}
                      className="w-full text-left px-2.5 py-2 rounded-lg hover:bg-neutral-100 text-neutral-900 flex items-center gap-2.5 transition-colors"
                    >
                      <div className="p-1.5 bg-neutral-100 text-sky-600 rounded-lg flex-shrink-0 border border-neutral-200">
                        <Maximize2 className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-bold text-xs text-neutral-950">Abrir en 2do Monitor / Pestaña</div>
                        <div className="text-[10px] text-neutral-600">Ventana fija para segundo monitor</div>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setShowCustomerDisplayMenu(false);
                        setShowCustomerDisplayModal(true);
                      }}
                      className="w-full text-left px-2.5 py-2 rounded-lg hover:bg-neutral-100 text-neutral-900 flex items-center gap-2.5 transition-colors"
                    >
                      <div className="p-1.5 bg-neutral-100 text-neutral-700 rounded-lg flex-shrink-0 border border-neutral-200">
                        <Tv className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-bold text-xs text-neutral-950">Previsualizar aquí en ventana</div>
                        <div className="text-[10px] text-neutral-600">Ver vista previa en modal flotante</div>
                      </div>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Controls: User Switcher / Login */}
          <div className="relative" ref={userMenuContainerRef}>
            <button
              type="button"
              onClick={() => {
                setShowUserMenu(!showUserMenu);
                setShowTerminalMenu(false);
                setShowCustomerDisplayMenu(false);
              }}
              className="px-2.5 py-1.5 bg-neutral-50 hover:bg-neutral-100 border border-neutral-200 rounded-lg text-xs flex items-center gap-2 transition-colors"
            >
              <div className={`w-5 h-5 rounded-full text-white flex items-center justify-center font-bold text-[10px] ${displayedUser.avatarColor || 'bg-neutral-800'}`}>
                {displayedUser.name.slice(0, 1).toUpperCase()}
              </div>
              <div className="text-left hidden sm:block">
                <div className="font-bold text-neutral-900 leading-tight">{displayedUser.name.split(' ')[0]}</div>
                <div className="text-[9px] font-mono text-neutral-500">{displayedUser.username || 'usuario'} • {displayedUser.role}</div>
              </div>
              <ChevronDown className="w-3 h-3 text-neutral-400" />
            </button>

            {showUserMenu && (
              <div
                id="user-switch-menu"
                className="absolute right-0 mt-1 w-72 bg-white text-neutral-950 dark:text-white rounded-xl shadow-xl border-2 border-neutral-300 dark:border-neutral-700 p-2.5 z-50 animate-in fade-in zoom-in-95"
              >
                <div className="px-2 py-1 text-[10px] font-black uppercase tracking-wider text-neutral-600 dark:text-neutral-400">
                  Usuarios del Sistema
                </div>

                <div className="space-y-1 mt-1">
                  {users.map(u => (
                    <button
                      key={u.id}
                      type="button"
                      disabled={!u.active}
                      onClick={() => {
                        handleOpenLoginForUser(u);
                      }}
                      className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs flex items-center justify-between transition-colors ${
                        u.id === currentUser.id
                          ? 'bg-neutral-900 text-white font-bold'
                          : 'hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-950 dark:text-white font-bold'
                      } ${!u.active ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="user-name font-bold text-neutral-950 dark:text-white">{u.name}</span>
                          <Lock className="w-2.5 h-2.5 opacity-70" />
                        </div>
                        <span className={`text-[10px] font-mono ${u.id === currentUser.id ? 'text-neutral-300' : 'text-neutral-600 dark:text-neutral-400'}`}>{u.username} • {({'OWNER': 'Dueño', 'CASHIER': 'Cajero'} as Record<string, string>)[u.role] || u.role}</span>
                      </div>
                      {u.id === currentUser.id ? (
                        <span className="text-[9px] px-1.5 py-0.5 bg-white/20 rounded font-bold text-white">Activo</span>
                      ) : !u.active ? (
                        <span className="text-[9px] px-1.5 py-0.5 bg-rose-500/20 text-rose-300 rounded font-bold">Inactivo</span>
                      ) : null}
                    </button>
                  ))}
                </div>

                <div className="pt-2 mt-2 border-t border-neutral-200 dark:border-neutral-800 space-y-1">
                  <button
                    type="button"
                    onClick={handleOpenDirectLogin}
                    className="w-full text-left px-2.5 py-1.5 text-xs font-bold text-neutral-900 dark:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-lg flex items-center gap-1.5"
                  >
                    <KeyRound className="w-3.5 h-3.5 text-neutral-700 dark:text-neutral-300" />
                    Iniciar Sesión con Otro Usuario
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* PRIMARY NAVIGATION TABS */}
        <div className="w-full px-3 sm:px-4 flex items-center gap-1 overflow-x-auto border-t border-neutral-100 py-1">
          {navItems.map(item => {
            if (!item.permitted) return null;
            const isActive = activeModule === item.id;

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setActiveModule(item.id);
                  if (item.id === 'ARTICULOS') {
                    window.dispatchEvent(new CustomEvent('focus-inventory-search'));
                  }
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 whitespace-nowrap transition-colors ${
                  isActive
                    ? 'main-nav-tab-active bg-neutral-900 text-white shadow-xs'
                    : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </header>

      {/* OFFLINE RESILIENCE NOTICE BANNER (when offline mode is simulated or disconnected) */}
      {isOffline && (
        <div className="bg-amber-500 text-neutral-950 px-4 py-1.5 text-xs font-semibold flex items-center justify-between shadow-xs flex-shrink-0">
          <div className="w-full px-2 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <WifiOff className="w-4 h-4" />
              <span>
                <strong>Modo Local Activo:</strong> El sistema sigue funcionando al 100% sin conexión a internet. Los tickets, artículos y cajas se registran localmente en esta terminal.
              </span>
            </div>
            <button
              type="button"
              onClick={toggleOfflineMode}
              className="text-[11px] underline hover:text-white font-bold ml-2"
            >
              Reconectar Nube
            </button>
          </div>
        </div>
      )}

      {/* MODULE WORKSPACE - Full Size with scroll for management modules */}
      <main className="flex-1 w-full p-2 sm:p-3 overflow-hidden flex flex-col min-h-0 print:p-0 print:m-0 print:overflow-visible">
        {activeModule === 'VENTAS' && <SalesModule />}
        {activeModule === 'ARTICULOS' && (
          <div style={{ zoom: `${sharedZoomPercent}%` }} className="flex-1 overflow-y-auto min-h-0 pr-1 w-full">
            <InventoryModule />
          </div>
        )}
        {activeModule === 'COMPRAS' && (
          <div style={{ zoom: `${sharedZoomPercent}%` }} className="flex-1 overflow-y-auto min-h-0 pr-1 w-full">
            <PurchasesModule />
          </div>
        )}
        {activeModule === 'CUENTAS' && (
          <div style={{ zoom: `${sharedZoomPercent}%` }} className="flex-1 overflow-y-auto min-h-0 pr-1 w-full">
            <AccountsModule />
          </div>
        )}
        {activeModule === 'CAJA' && (
          <div style={{ zoom: `${sharedZoomPercent}%` }} className="flex-1 overflow-y-auto min-h-0 pr-1 w-full">
            <CashRegisterModule />
          </div>
        )}
        {activeModule === 'USUARIOS' && (
          <div style={{ zoom: `${sharedZoomPercent}%` }} className="flex-1 overflow-y-auto min-h-0 pr-1 w-full">
            <UsersModule />
          </div>
        )}
        {activeModule === 'CONFIGURACION' && (
          <div style={{ zoom: `${sharedZoomPercent}%` }} className="flex-1 overflow-y-auto min-h-0 pr-1 w-full">
            <SettingsModule initialSubTab={settingsInitialSubTab} />
          </div>
        )}
      </main>

      {/* PAYMENT CONFIG MODAL (Mercado Pago & Cuentas Bancarias) */}
      <PaymentConfigModal
        isOpen={showPaymentConfigModal}
        onClose={() => setShowPaymentConfigModal(false)}
      />

      {/* WIFI DISPLAY MODAL (Sincronización de 2da pantalla en tablet / celular) */}
      <WifiDisplayModal
        isOpen={showWifiDisplayModal}
        onClose={() => setShowWifiDisplayModal(false)}
        terminalId={currentTerminalId}
      />

      {/* CUSTOMER DISPLAY MODAL PREVIEW */}
      {showCustomerDisplayModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-6 animate-in fade-in">
          <div className="bg-neutral-950 w-full max-w-5xl h-[85vh] rounded-2xl overflow-hidden shadow-2xl border border-neutral-800 flex flex-col">
            <CustomerDisplayView onClose={() => setShowCustomerDisplayModal(false)} />
          </div>
        </div>
      )}

      {/* ARCHITECT BLUEPRINT MODAL */}
      <ArchitectBlueprintModal
        isOpen={showArchitectModal}
        onClose={() => setShowArchitectModal(false)}
      />

      {/* PWA INSTALLATION GUIDE MODAL */}
      {showInstallHelpModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-neutral-200 animate-in fade-in zoom-in-95">
            <div className="p-4 bg-neutral-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Download className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-sm">Instalar Aplicación (PWA)</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowInstallHelpModal(false)}
                className="text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-5 space-y-4 text-xs text-neutral-700">
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900 space-y-1">
                <p className="font-bold text-sm">¡Listo para instalar en tu dispositivo!</p>
                <p>Esta aplicación cuenta con Service Worker y Manifiesto PWA configurados para funcionar como un software de escritorio o móvil independiente.</p>
              </div>

              <div className="space-y-2">
                <h4 className="font-bold text-neutral-900 uppercase text-[11px]">¿Cómo instalarlo en tu PC o Laptop?</h4>
                <ol className="list-decimal pl-4 space-y-1 text-neutral-600">
                  <li>En <strong>Google Chrome</strong> o <strong>Microsoft Edge</strong>, mira el lado derecho de la barra de direcciones (URL).</li>
                  <li>Haz clic en el icono de <strong>Instalar Aplicación</strong> (pantalla con flecha hacia abajo).</li>
                  <li>O haz clic en los <strong>3 puntos del navegador</strong> &gt; <em>"Instalar Sistema Comercial & POS"</em>.</li>
                  <li>¡Se creará un acceso directo en tu escritorio y barra de tareas!</li>
                </ol>
              </div>

              <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 text-neutral-600">
                <p className="font-semibold text-neutral-800 mb-1">💡 Funciona 100% en localhost / sin HTTPS:</p>
                <p className="text-[11px]">Los navegadores modernos permiten instalar PWAs y ejecutar Service Workers en <code>localhost</code> o <code>127.0.0.1</code> de manera nativa sin necesidad de certificado SSL.</p>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={() => setShowInstallHelpModal(false)}
                  className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl font-bold transition-colors"
                >
                  Entendido
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECURE LOGIN MODAL (USERNAME & PASSWORD ONLY) */}
      {showLoginModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl border border-neutral-200 animate-in fade-in zoom-in-95">
            <div className="p-4 border-b border-neutral-100 flex items-center justify-between bg-neutral-50">
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-neutral-800" />
                <h3 className="font-bold text-sm text-neutral-900">
                  {targetUserForLogin ? `Acceder como ${targetUserForLogin.name}` : 'Iniciar Sesión'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowLoginModal(false)}
                className="text-neutral-400 hover:text-neutral-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitLogin} autoComplete="off" className="p-5 space-y-4 text-xs">
              {targetUserForLogin && (
                <div className="flex items-center gap-3 p-3 bg-neutral-50 rounded-xl border border-neutral-200">
                  <div className={`w-10 h-10 rounded-full text-white flex items-center justify-center font-bold text-sm ${targetUserForLogin.avatarColor || 'bg-neutral-800'}`}>
                    {targetUserForLogin.name.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <div className="font-bold text-neutral-900 text-sm">{targetUserForLogin.name}</div>
                    <div className="text-neutral-500 font-mono text-[11px]">{targetUserForLogin.username} • {targetUserForLogin.role}</div>
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-black text-neutral-900 uppercase tracking-wide mb-1">
                  Nombre de Usuario
                </label>
                <div>
                  <input
                    type="text"
                    autoComplete="off"
                    name="pos-login-username"
                    required
                    value={loginUsernameInput}
                    onChange={(e) => {
                      setLoginUsernameInput(e.target.value);
                      setLoginError('');
                    }}
                    placeholder="admin, dueno, laura, juan"
                    className="w-full px-3 py-2.5 bg-white border-2 border-neutral-400 rounded-xl text-xs font-mono font-black text-neutral-950 placeholder:text-neutral-400 focus:outline-hidden focus:ring-2 focus:ring-neutral-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-black text-neutral-900 uppercase tracking-wide mb-1">
                  Contraseña / PIN
                </label>
                <input
                  type="password"
                  autoComplete="new-password"
                  name="pos-login-password-no-save"
                  data-lpignore="true"
                  data-1p-ignore="true"
                  autoFocus
                  required
                  value={loginPasswordInput}
                  onChange={(e) => {
                    setLoginPasswordInput(e.target.value);
                    setLoginError('');
                  }}
                  placeholder="••••••••"
                  className="w-full px-3 py-2.5 bg-white border-2 border-neutral-400 rounded-xl text-base tracking-widest font-mono font-black text-neutral-950 placeholder:text-neutral-400 focus:outline-hidden focus:ring-2 focus:ring-neutral-900"
                />
                <span className="text-xs text-neutral-700 mt-1 block font-medium">
                  (Clave por defecto: <strong className="text-neutral-950 font-bold">123</strong>)
                </span>
              </div>

              {loginError && (
                <div className="p-2.5 bg-rose-100 border border-rose-300 rounded-lg text-rose-800 text-xs text-center font-bold">
                  {loginError}
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowLoginModal(false)}
                  className="flex-1 px-3 py-2.5 border-2 border-neutral-300 hover:bg-neutral-100 rounded-xl text-neutral-800 font-bold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-black uppercase tracking-wider transition-colors shadow-xs"
                >
                  Ingresar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

class CustomerDisplayErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean; error: any }
> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error('CustomerDisplay Error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-neutral-950 text-white flex flex-col items-center justify-center p-6 text-center select-none font-['Plus_Jakarta_Sans',sans-serif]">
          <div className="w-16 h-16 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-center mb-4 shadow-xl">
            <span className="text-2xl font-black text-white">POS</span>
          </div>
          <h2 className="text-xl font-extrabold mb-2 text-white">Segunda Pantalla para el Cliente</h2>
          <p className="text-sm text-neutral-400 mb-6 max-w-sm">
            Reconectando con la terminal de caja por Wi-Fi...
          </p>
          <button
            type="button"
            onClick={() => {
              this.setState({ hasError: false, error: null });
              window.location.reload();
            }}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold rounded-xl text-xs transition-all shadow-md uppercase tracking-wider"
          >
            Reconectar Pantalla
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  const isCustomerDisplay = typeof window !== 'undefined' && new URLSearchParams(window.location.search).get('customer_display') === 'true';

  if (isCustomerDisplay) {
    return (
      <CustomerDisplayErrorBoundary>
        <CustomerDisplayView standalone={true} />
        <AppDialogModal />
      </CustomerDisplayErrorBoundary>
    );
  }

  return (
    <AuthProvider>
      <AppProvider>
        <MainLayout />
        <AppDialogModal />
      </AppProvider>
    </AuthProvider>
  );
}
