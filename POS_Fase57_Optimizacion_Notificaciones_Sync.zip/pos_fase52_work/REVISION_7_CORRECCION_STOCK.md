# Revisión 7 — Corrección de diferencias de stock entre terminales

## Corrección
- Los ajustes manuales de stock ahora se publican como `STOCK_ADJUSTED` con un delta por artículo, no como una copia completa del catálogo local.
- La API PHP/MySQL aplica el delta al catálogo de referencia del servidor una sola vez, después de registrar el evento de forma idempotente.
- Las terminales que reciben el evento aplican la diferencia a su stock local y actualizan la interfaz sin recargar.
- La protección de operaciones pendientes incluye ajustes manuales de stock.
- Al inicializar el catálogo desde una terminal que tiene operaciones pendientes, los deltas de ajustes manuales también se revierten del snapshot inicial para luego reproducirse una sola vez.

## Instalación
Reemplazar los archivos del proyecto por esta revisión siguiendo el procedimiento habitual. En el hosting, subir/actualizar `public/api/sync.php` dentro del directorio `api` correspondiente. **No sobrescribir `api/sync-config.php`**: conservar la configuración real existente. El ZIP incluye solo `sync-config.example.php`.

## Prueba recomendada
1. Confirmar que las tres terminales muestran la misma cantidad inicial.
2. En TERM-01, hacer un ajuste manual de +1 y comprobar TERM-02 y TERM-03.
3. Hacer un ajuste de -1 en TERM-02 y comprobar las tres.
4. Registrar una venta y una compra, verificando que las cantidades coincidan en las tres terminales.
5. Repetir una prueba con una terminal temporalmente sin Internet y comprobar que el cambio pendiente se sincronice al reconectar.
