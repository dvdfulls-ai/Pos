FASE 51 - CONTROL DE CONSULTAS POLL

Cambios exclusivos en src/services/cloudSync.ts:
- Conserva una sola consulta poll activa por instancia de CloudSyncManager.
- Conserva el límite de 25 eventos por consulta y el cursor incremental.
- Ante fallos de red/HTTP/timeout aplica espera progresiva (5, 10, 20 y hasta 30 segundos) en vez de reintentar siempre cada 2,5 segundos.
- Al recibir una respuesta correcta vuelve al intervalo normal de 2,5 segundos.
- En pestañas en segundo plano espera al menos 10 segundos entre consultas.
- No avanza el cursor si la petición falla.

No modifica PHP, tokens, datos locales, cola de operaciones, lógica comercial ni escáner.
La respuesta HTTP 500 de publish requiere diagnóstico separado; esta fase no afirma corregir errores internos del servidor.
