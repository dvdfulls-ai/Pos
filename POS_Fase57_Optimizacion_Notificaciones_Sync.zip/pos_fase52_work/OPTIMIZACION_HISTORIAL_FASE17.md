# Prueba de carga simulada del Historial — Fase 17

## Qué incorpora

Se añade en Historial un panel de prueba con 1.000, 5.000 y 10.000 registros sintéticos. Mide por separado generación en memoria, ordenamiento y filtrado sencillo. El resultado sirve para comparar el coste básico de operaciones con distintos volúmenes en el equipo del usuario.

## Aislamiento

- Todos los registros son ficticios y viven solo en memoria durante la prueba.
- No llama a StorageService, localStorage, IndexedDB, API ni sincronización.
- No crea ventas, compras, movimientos, cuentas ni auditoría reales.
- No modifica los datos del POS.

## Limitaciones

Esta prueba no reproduce todo el renderizado real del Historial, ni sustituye una prueba con una copia representativa de datos reales. Los tiempos dependen del equipo y de la carga del navegador. No tomar los resultados como garantía de rendimiento de producción.

## Validación

Se debe compilar el proyecto y ejecutar la prueba desde Historial en el POS de prueba. La compilación integral y la verificación en navegador están pendientes.
