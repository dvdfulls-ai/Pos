import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import os from 'os';
import fs from 'fs';
import {defineConfig} from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig(() => {
  const sseClients = new Set<any>();
  const terminalPayloads = new Map<string, any>();
  const syncClients = new Set<any>();
  let serverLatestArticles: any[] | null = null;
  let serverArticlesLastUpdated: number = 0;
  let serverArticlesVersion: number = 1;

  // Durable relay journal for offline terminals. The client stores a per-terminal cursor
  // and replays events after that cursor when the connection returns.
  const syncEventLogPath = path.resolve(process.cwd(), '.server_sync_events.jsonl');
  const MAX_SYNC_EVENTS = 10000;
  const syncEventLog: Array<{ seq: number; message: any }> = [];
  const seenSyncEventIds = new Map<string, number>();
  let syncSequence = 0;
  try {
    if (fs.existsSync(syncEventLogPath)) {
      const lines = fs.readFileSync(syncEventLogPath, 'utf8').split(/\r?\n/).filter(Boolean);
      for (const line of lines.slice(-MAX_SYNC_EVENTS)) {
        try {
          const entry = JSON.parse(line);
          if (entry && Number.isFinite(Number(entry.seq)) && entry.message?.id) {
            syncEventLog.push(entry);
            syncSequence = Math.max(syncSequence, Number(entry.seq));
            seenSyncEventIds.set(String(entry.message.id), Number(entry.seq));
          }
        } catch {}
      }
    }
  } catch (error: any) {
    console.warn('[POS sync] Could not load durable event journal:', error?.message || error);
  }

  const persistSyncEvent = (entry: { seq: number; message: any }): boolean => {
    try {
      fs.appendFileSync(syncEventLogPath, JSON.stringify(entry) + '\n', 'utf8');
    } catch (error: any) {
      console.error('[POS sync] Could not persist sync event:', error?.message || error);
      return false;
    }
    syncEventLog.push(entry);
    seenSyncEventIds.set(String(entry.message.id), Number(entry.seq));
    while (syncEventLog.length > MAX_SYNC_EVENTS) {
      const removed = syncEventLog.shift();
      if (removed?.message?.id) seenSyncEventIds.delete(String(removed.message.id));
    }
    if (entry.seq % 250 === 0) {
      try { fs.writeFileSync(syncEventLogPath, syncEventLog.map((item) => JSON.stringify(item)).join('\n') + '\n', 'utf8'); }
      catch (error: any) { console.warn('[POS sync] Journal compaction failed:', error?.message || error); }
    }
    return true;
  };

  const mergeCatalogPreservingNewerStock = (incoming: any[]) => {
    if (!Array.isArray(incoming)) return incoming;
    if (!Array.isArray(serverLatestArticles) || serverLatestArticles.length === 0) return incoming;
    const existingById = new Map(serverLatestArticles.filter((a: any) => a?.id != null).map((a: any) => [String(a.id), a]));
    return incoming.map((article: any) => {
      const current: any = existingById.get(String(article?.id));
      if (!current) return article;
      const currentTime = Date.parse(current.updatedAt || '') || 0;
      const incomingTime = Date.parse(article.updatedAt || '') || 0;
      if (currentTime > incomingTime) return { ...article, stock: current.stock, updatedAt: current.updatedAt };
      return article;
    });
  };

  const applyStockDeltasToServerArticles = (deltas: any[]) => {
    if (!Array.isArray(serverLatestArticles) || !Array.isArray(deltas)) return false;
    let changed = false;
    for (const delta of deltas) {
      const article = serverLatestArticles.find((a: any) => a?.id === delta?.articleId);
      if (!article) continue;
      const amount = Number(delta?.quantityDelta || 0);
      if (!Number.isFinite(amount)) continue;
      article.stock = Math.max(0, Number(article.stock || 0) + amount);
      article.updatedAt = new Date().toISOString();
      changed = true;
    }
    return changed;
  };

  try {
    if (fs.existsSync(path.resolve(process.cwd(), '.server_articles_sync.json'))) {
      const cached = JSON.parse(fs.readFileSync(path.resolve(process.cwd(), '.server_articles_sync.json'), 'utf8'));
      if (cached && Array.isArray(cached.articles) && cached.articles.length > 0) {
        serverLatestArticles = cached.articles;
        serverArticlesVersion = cached.version || 1;
        serverArticlesLastUpdated = cached.lastUpdated || Date.now();
      }
    }
  } catch {}

  const normalizeTerminalId = (raw: string = 'TERM-01') => {
    let cleaned = (raw || 'TERM-01').trim().toUpperCase();
    if (cleaned.startsWith('TERMINAL')) {
      cleaned = cleaned.replace('TERMINAL', '').trim();
    }
    if (/^\d+$/.test(cleaned)) {
      cleaned = `TERM-${cleaned.padStart(2, '0')}`;
    } else if (/^TERM-\d+$/.test(cleaned)) {
      const num = cleaned.replace('TERM-', '');
      cleaned = `TERM-${num.padStart(2, '0')}`;
    }
    return cleaned || 'TERM-01';
  };

  const getPayloadForTerminal = (termId: string = 'TERM-01') => {
    const key = normalizeTerminalId(termId);
    let p = terminalPayloads.get(key);
    if (!p) {
      p = {
        version: 1,
        terminalId: key,
        state: {
          status: 'WELCOME',
          items: [],
          subtotal: 0,
          discount: 0,
          total: 0,
          paymentMethod: null,
          terminalId: key,
          timestamp: Date.now(),
        },
        paymentConfig: null,
        lastUpdated: Date.now(),
      };
      terminalPayloads.set(key, p);
    }
    return p;
  };

  const handleApiMiddleware = async (req: any, res: any, next: any) => {
    const rawUrl = req.url || '';
    const pathname = rawUrl.split('?')[0];

    if (pathname === '/api/wifi-info' && req.method === 'GET') {
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');

      if (req.method === 'OPTIONS') {
        res.statusCode = 204;
        res.end();
        return;
      }

      const interfaces = os.networkInterfaces();
      const ips: string[] = [];
      for (const name of Object.keys(interfaces)) {
        for (const iface of interfaces[name] || []) {
          if (iface.family === 'IPv4' && !iface.internal && !iface.address.startsWith('169.254.')) {
            ips.push(iface.address);
          }
        }
      }
      // Sort so typical Wi-Fi LAN subnets (192.168.x.x, 10.x.x.x) come first
      ips.sort((a, b) => {
        if (a.startsWith('192.168.') && !b.startsWith('192.168.')) return -1;
        if (!a.startsWith('192.168.') && b.startsWith('192.168.')) return 1;
        if (a.startsWith('10.') && !b.startsWith('10.')) return -1;
        if (!a.startsWith('10.') && b.startsWith('10.')) return 1;
        return a.localeCompare(b);
      });
      res.end(JSON.stringify({ ips }));
      return;
    }

    // Real-Time Multi-Terminal Sync over LAN / Network
    if (pathname.startsWith('/api/sync')) {
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Cache-Control, Pragma');

      if (req.method === 'OPTIONS') {
        res.statusCode = 204;
        res.end();
        return;
      }

      // 1. Instant 0ms Server-Sent Events (SSE) Stream for Terminal Sync
      if (pathname === '/api/sync/stream' && req.method === 'GET') {
        res.writeHead(200, {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache, no-transform',
          'Connection': 'keep-alive',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': '*',
          'X-Accel-Buffering': 'no',
        });
        if (res.flushHeaders) res.flushHeaders();

        // Send connection acknowledgment and replay missed messages in sequence order.
        const requestUrl = new URL(req.url || '/api/sync/stream', 'http://localhost');
        const rawSince = requestUrl.searchParams.get('since');
        const hasCursor = rawSince !== null && Number.isFinite(Number(rawSince)) && Number(rawSince) >= 0;
        const cursor = hasCursor ? Number(rawSince) : syncSequence;
        const connectMsg = JSON.stringify({
          type: 'CONNECTED',
          timestamp: Date.now(),
          hasArticles: !!serverLatestArticles,
          serverArticlesLastUpdated,
          latestSeq: syncSequence,
        });
        res.write(`data: ${connectMsg}\n\n`);
        if (res.flush) res.flush();

        for (const entry of syncEventLog) {
          if (entry.seq > cursor) {
            res.write(`id: ${entry.seq}\ndata: ${JSON.stringify(entry)}\n\n`);
          }
        }

        if (serverLatestArticles && serverLatestArticles.length > 0 && !hasCursor) {
          const initMsg = {
            id: `init_${Date.now()}`,
            type: 'ARTICLES_UPDATED',
            senderTerminalId: 'SERVER',
            senderClientId: 'SERVER',
            timestamp: serverArticlesLastUpdated,
            payload: { articles: serverLatestArticles, count: serverLatestArticles.length },
          };
          res.write(`data: ${JSON.stringify(initMsg)}\n\n`);
          if (res.flush) res.flush();
        }

        syncClients.add(res);

        const keepAlive = setInterval(() => {
          try {
            res.write(': keepalive\n\n');
            if (res.flush) res.flush();
          } catch {
            clearInterval(keepAlive);
            syncClients.delete(res);
          }
        }, 10000);

        req.on('close', () => {
          clearInterval(keepAlive);
          syncClients.delete(res);
        });
        return;
      }

      // 2. Publish sync message from a terminal to all other terminals
      if (pathname === '/api/sync/publish' && req.method === 'POST') {
        let body = '';
        req.on('data', (chunk: any) => { body += chunk; });
        req.on('end', () => {
          try {
            const parsed = JSON.parse(body);
            const msg = parsed.message || parsed;
            if (!msg || !msg.id || !msg.type) {
              res.statusCode = 400;
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({ success: false, error: 'Invalid sync message' }));
              return;
            }

            const existingSeq = seenSyncEventIds.get(String(msg.id));
            if (existingSeq) {
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({ success: true, duplicate: true, seq: existingSeq, version: serverArticlesVersion, deliveredTo: syncClients.size }));
              return;
            }

            const previousServerArticles = Array.isArray(serverLatestArticles) ? JSON.parse(JSON.stringify(serverLatestArticles)) : null;
            const previousArticlesVersion = serverArticlesVersion;
            const previousArticlesLastUpdated = serverArticlesLastUpdated;
            let articlesChanged = false;
            if ((msg.type === 'SALE_PROCESSED' || msg.type === 'PURCHASE_REGISTERED') && msg.payload?.updatedArticles && Array.isArray(msg.payload.updatedArticles)) {
              serverLatestArticles = mergeCatalogPreservingNewerStock(msg.payload.updatedArticles);
              articlesChanged = true;
            } else if ((msg.type === 'SALE_PROCESSED' || msg.type === 'PURCHASE_REGISTERED') && msg.payload?.stockDeltas) {
              articlesChanged = applyStockDeltasToServerArticles(msg.payload.stockDeltas);
            } else if ((msg.type === 'ARTICLES_UPDATED' || msg.type === 'SYNC_RESPONSE_STATE') && msg.payload?.articles && Array.isArray(msg.payload.articles)) {
              serverLatestArticles = mergeCatalogPreservingNewerStock(msg.payload.articles);
              articlesChanged = true;
            } else if (msg.type === 'SYSTEM_RESTORE' && msg.payload?.backupData?.articles && Array.isArray(msg.payload.backupData.articles)) {
              serverLatestArticles = mergeCatalogPreservingNewerStock(msg.payload.backupData.articles);
              articlesChanged = true;
            }

            if (articlesChanged) {
              serverArticlesVersion++;
              serverArticlesLastUpdated = Date.now();
              try {
                fs.writeFileSync(path.resolve(process.cwd(), '.server_articles_sync.json'), JSON.stringify({
                  articles: serverLatestArticles,
                  version: serverArticlesVersion,
                  lastUpdated: serverArticlesLastUpdated
                }));
              } catch {}
            }

            msg.serverVersion = serverArticlesVersion;
            const entry = { seq: syncSequence + 1, message: msg };
            if (!persistSyncEvent(entry)) {
              serverLatestArticles = previousServerArticles;
              serverArticlesVersion = previousArticlesVersion;
              serverArticlesLastUpdated = previousArticlesLastUpdated;
              try {
                if (serverLatestArticles) fs.writeFileSync(path.resolve(process.cwd(), '.server_articles_sync.json'), JSON.stringify({ articles: serverLatestArticles, version: serverArticlesVersion, lastUpdated: serverArticlesLastUpdated }));
                else if (fs.existsSync(path.resolve(process.cwd(), '.server_articles_sync.json'))) fs.unlinkSync(path.resolve(process.cwd(), '.server_articles_sync.json'));
              } catch {}
              res.statusCode = 503;
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({ success: false, error: 'No se pudo guardar el evento de sincronización en el servidor.' }));
              return;
            }
            syncSequence = entry.seq;
            const outgoingData = JSON.stringify(entry);
            for (const client of syncClients) {
              try {
                if (!client.destroyed && !client.writableEnded) {
                  client.write(`id: ${entry.seq}\ndata: ${outgoingData}\n\n`);
                  if (client.flush) client.flush();
                } else {
                  syncClients.delete(client);
                }
              } catch {
                syncClients.delete(client);
              }
            }

            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ success: true, seq: syncSequence, version: serverArticlesVersion, deliveredTo: syncClients.size }));
          } catch (e: any) {
            res.statusCode = 400;
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ success: false, error: e?.message }));
          }
        });
        return;
      }

      // 3. Get current synchronized state
      if (pathname === '/api/sync/state' && req.method === 'GET') {
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
        res.end(JSON.stringify({
          latestArticles: serverLatestArticles,
          version: serverArticlesVersion,
          lastUpdated: serverArticlesLastUpdated,
          latestSeq: syncSequence,
          connectedCount: syncClients.size,
        }));
        return;
      }

      // 4. Seed initial articles if server is empty, and publish a durable seed event.
      if (pathname === '/api/sync/init-articles' && req.method === 'POST') {
        let body = '';
        req.on('data', (chunk: any) => { body += chunk; });
        req.on('end', () => {
          try {
            const parsed = JSON.parse(body);
            if (Array.isArray(parsed.articles) && parsed.articles.length > 0 && (!serverLatestArticles || serverLatestArticles.length === 0)) {
              const msg = {
                id: `catalog_seed_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
                type: 'ARTICLES_UPDATED',
                senderTerminalId: 'SERVER',
                senderClientId: 'SERVER',
                timestamp: Date.now(),
                payload: { articles: parsed.articles, count: parsed.articles.length },
                serverVersion: serverArticlesVersion + 1,
              };
              const entry = { seq: syncSequence + 1, message: msg };
              if (!persistSyncEvent(entry)) {
                res.statusCode = 503;
                res.setHeader('Content-Type', 'application/json');
                res.end(JSON.stringify({ success: false, error: 'No se pudo guardar el catálogo inicial en el diario de sincronización.' }));
                return;
              }
              syncSequence = entry.seq;
              serverLatestArticles = parsed.articles;
              serverArticlesVersion++;
              serverArticlesLastUpdated = Date.now();
              fs.writeFileSync(path.resolve(process.cwd(), '.server_articles_sync.json'), JSON.stringify({
                articles: serverLatestArticles,
                version: serverArticlesVersion,
                lastUpdated: serverArticlesLastUpdated
              }));
              const outgoingData = JSON.stringify(entry);
              for (const client of syncClients) {
                try {
                  if (!client.destroyed && !client.writableEnded) {
                    client.write(`id: ${entry.seq}\ndata: ${outgoingData}\n\n`);
                    if (client.flush) client.flush();
                  } else syncClients.delete(client);
                } catch { syncClients.delete(client); }
              }
            }
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ success: true, version: serverArticlesVersion, latestArticles: serverLatestArticles, lastUpdated: serverArticlesLastUpdated, latestSeq: syncSequence }));
          } catch (error: any) {
            res.statusCode = 500;
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ success: false, error: error?.message || 'Could not initialize catalog' }));
          }
        });
        return;
      }

    }

    if (pathname.startsWith('/api/customer-display')) {
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Cache-Control, Pragma');

      if (req.method === 'OPTIONS') {
        res.statusCode = 204;
        res.end();
        return;
      }

      // 1. Instant 0ms Server-Sent Events (SSE) Stream over Wi-Fi
      if (pathname === '/api/customer-display/stream' && req.method === 'GET') {
        res.writeHead(200, {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache, no-transform',
          'Connection': 'keep-alive',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': '*',
          'X-Accel-Buffering': 'no',
        });
        if (res.flushHeaders) res.flushHeaders();

        const queryParams = new URLSearchParams(req.url.includes('?') ? req.url.split('?')[1] : '');
        const rawRequestedTerminal = queryParams.get('terminal') || queryParams.get('terminalId') || '';
        const requestedTerminal = rawRequestedTerminal ? normalizeTerminalId(rawRequestedTerminal) : '';
        (res as any).requestedTerminal = requestedTerminal;

        // Send current state for requested terminal immediately on connect
        const termPayload = getPayloadForTerminal(requestedTerminal || 'TERM-01');
        const initialData = JSON.stringify({
          version: termPayload.version,
          terminalId: termPayload.terminalId,
          state: termPayload.state,
          paymentConfig: termPayload.paymentConfig,
          lastUpdated: termPayload.lastUpdated,
        });
        res.write(`data: ${initialData}\n\n`);
        if (res.flush) res.flush();

        sseClients.add(res);

        // Keep-alive heartbeat every 10s to keep tablet browsers active
        const keepAlive = setInterval(() => {
          try {
            res.write(': keepalive\n\n');
            if (res.flush) res.flush();
          } catch {
            clearInterval(keepAlive);
            sseClients.delete(res);
          }
        }, 10000);

        req.on('close', () => {
          clearInterval(keepAlive);
          sseClients.delete(res);
        });
        return;
      }

      // 2. State update from POS cashier
      if (req.method === 'POST') {
        let body = '';
        req.on('data', (chunk: any) => { body += chunk; });
        req.on('end', () => {
          let termId = 'TERM-01';
          let termPayload = getPayloadForTerminal(termId);

          try {
            const parsed = JSON.parse(body);
            const rawState = ('state' in parsed && parsed.state) ? parsed.state : parsed;
            termId = normalizeTerminalId(parsed.terminalId || rawState?.terminalId || 'TERM-01');
            termPayload = getPayloadForTerminal(termId);

            const clientVersion = typeof parsed?.version === 'number' 
              ? parsed.version 
              : (typeof rawState?.version === 'number' ? rawState.version : 0);

            if (clientVersion > termPayload.version) {
              termPayload.version = clientVersion;
            } else {
              termPayload.version++;
            }
            termPayload.lastUpdated = Date.now();
            termPayload.terminalId = termId;

            termPayload.state = {
              ...rawState,
              terminalId: termId,
              version: termPayload.version,
              timestamp: rawState.timestamp || termPayload.lastUpdated,
            };
            if (parsed.paymentConfig) {
              termPayload.paymentConfig = parsed.paymentConfig;
            }
          } catch (e) {}

          // Broadcast to connected tablets watching this terminal or all
          const broadcastData = JSON.stringify({
            version: termPayload.version,
            terminalId: termPayload.terminalId,
            state: termPayload.state,
            paymentConfig: termPayload.paymentConfig,
            lastUpdated: termPayload.lastUpdated,
          });

          for (const client of sseClients) {
            try {
              if (!client.destroyed && !client.writableEnded) {
                const clientTerm = client.requestedTerminal;
                if (!clientTerm || normalizeTerminalId(clientTerm) === normalizeTerminalId(termId)) {
                  client.write(`data: ${broadcastData}\n\n`);
                  if (client.flush) client.flush();
                }
              } else {
                sseClients.delete(client);
              }
            } catch {
              sseClients.delete(client);
            }
          }

          res.setHeader('Content-Type', 'application/json');
          res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
          res.end(JSON.stringify({ success: true, version: termPayload.version, terminalId: termId }));
        });
        return;
      }

      // 3. Fast GET polling endpoint with strict cache-busting headers
      if (req.method === 'GET') {
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0');
        res.setHeader('Pragma', 'no-cache');
        res.setHeader('Expires', '0');

        const queryParams = new URLSearchParams(req.url.includes('?') ? req.url.split('?')[1] : '');
        const rawReq = queryParams.get('terminal') || queryParams.get('terminalId') || 'TERM-01';
        const requestedTerminal = normalizeTerminalId(rawReq);
        const termPayload = getPayloadForTerminal(requestedTerminal);

        const responseData = {
          version: termPayload.version,
          _version: termPayload.version,
          terminalId: termPayload.terminalId,
          lastUpdated: termPayload.lastUpdated,
          _lastUpdated: termPayload.lastUpdated,
          state: termPayload.state,
          paymentConfig: termPayload.paymentConfig,
          ...(termPayload.state || {
            status: 'WELCOME',
            items: [],
            subtotal: 0,
            discount: 0,
            total: 0,
            paymentMethod: null,
            terminalId: requestedTerminal,
            timestamp: 0,
          }),
        };
        res.end(JSON.stringify(responseData));
        return;
      }
    }

            if (req.url?.startsWith('/api/mercadopago/')) {
              res.setHeader('Access-Control-Allow-Origin', '*');
              res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
              res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

              if (req.method === 'OPTIONS') {
                res.statusCode = 204;
                res.end();
                return;
              }

              const pathname = req.url.split('?')[0];
              const queryParams = new URLSearchParams(req.url.includes('?') ? req.url.split('?')[1] : '');

              const parseBody = (): Promise<any> => {
                return new Promise((resolve) => {
                  let data = '';
                  req.on('data', (chunk: any) => { data += chunk; });
                  req.on('end', () => {
                    try {
                      resolve(data ? JSON.parse(data) : {});
                    } catch {
                      resolve({});
                    }
                  });
                });
              };

              // 1. Verify credentials and get user + POS info
              if (pathname === '/api/mercadopago/verify' && req.method === 'POST') {
                try {
                  const body = await parseBody();
                  const token = (body.accessToken || '').trim();
                  if (!token) {
                    res.statusCode = 400;
                    res.setHeader('Content-Type', 'application/json');
                    res.end(JSON.stringify({ success: false, error: 'Access Token no proporcionado' }));
                    return;
                  }

                  const userRes = await fetch('https://api.mercadopago.com/users/me', {
                    headers: { 'Authorization': `Bearer ${token}` }
                  });
                  const userData = await userRes.json();

                  if (!userRes.ok) {
                    res.statusCode = userRes.status;
                    res.setHeader('Content-Type', 'application/json');
                    res.end(JSON.stringify({ success: false, error: userData.message || 'Token de Mercado Pago inválido o revocado' }));
                    return;
                  }

                  // Get all POS/cajas
                  let posList: any[] = [];
                  try {
                    const posRes = await fetch('https://api.mercadopago.com/pos', {
                      headers: { 'Authorization': `Bearer ${token}` }
                    });
                    if (posRes.ok) {
                      const posData = await posRes.json();
                      const rawList = posData.results || [];
                      for (const p of rawList) {
                        let qrImage = p.qr?.image || p.qr?.template_image || p.qr_response?.image || p.qr_response?.template_image || '';
                        let qrData = p.qr?.qr_code || p.qr?.qr_number || p.qr_response?.qr_code || p.qr_response?.qr_number || '';

                        if ((!qrImage || !qrData) && p.id) {
                          const endpoints = [
                            `https://api.mercadopago.com/v2/pos/${p.id}`,
                            `https://api.mercadopago.com/pos/${p.id}`,
                          ];
                          if (p.external_id) {
                            endpoints.push(`https://api.mercadopago.com/pos?external_id=${encodeURIComponent(p.external_id)}`);
                            endpoints.push(`https://api.mercadopago.com/v2/pos?external_id=${encodeURIComponent(p.external_id)}`);
                          }

                          for (const ep of endpoints) {
                            try {
                              const detRes = await fetch(ep, {
                                headers: { 'Authorization': `Bearer ${token}` }
                              });
                              if (detRes.ok) {
                                const detData = await detRes.json();
                                const item = Array.isArray(detData.results) ? detData.results[0] : detData;
                                const dQr = item?.qr || item?.qr_response || {};
                                if (!qrImage) qrImage = dQr.image || dQr.template_image || dQr.template_document || '';
                                if (!qrData) qrData = dQr.qr_code || dQr.qr_number || dQr.uuid || '';
                                if (qrImage && qrData) break;
                              }
                            } catch {}
                          }
                        }

                        let pExt = p.external_id || '';
                        if (!pExt && p.id) {
                          try {
                            const assignRes = await fetch(`https://api.mercadopago.com/pos/${p.id}`, {
                              method: 'PUT',
                              headers: {
                                'Authorization': `Bearer ${token}`,
                                'Content-Type': 'application/json'
                              },
                              body: JSON.stringify({ external_id: String(p.id) })
                            });
                            if (assignRes.ok) {
                              pExt = String(p.id);
                            } else {
                              const assignV2Res = await fetch(`https://api.mercadopago.com/v2/pos/${p.id}`, {
                                method: 'PUT',
                                headers: {
                                  'Authorization': `Bearer ${token}`,
                                  'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({ external_id: String(p.id) })
                              });
                              if (assignV2Res.ok) pExt = String(p.id);
                            }
                          } catch {}
                        }

                        posList.push({
                          id: p.id,
                          name: p.name,
                          externalId: pExt,
                          storeId: p.store_id,
                          qrImage,
                          qrData
                        });
                      }
                    }
                  } catch (e) {
                    console.error('Error fetching POS:', e);
                  }

                  res.setHeader('Content-Type', 'application/json');
                  res.end(JSON.stringify({
                    success: true,
                    user: {
                      id: userData.id,
                      nickname: userData.nickname,
                      email: userData.email,
                      firstName: userData.first_name,
                      lastName: userData.last_name,
                    },
                    posList
                  }));
                  return;
                } catch (err: any) {
                  res.statusCode = 500;
                  res.setHeader('Content-Type', 'application/json');
                  res.end(JSON.stringify({ success: false, error: err.message || 'Error al conectar con Mercado Pago' }));
                  return;
                }
              }

              // 2. Create in-store QR order
              if (pathname === '/api/mercadopago/create-order' && req.method === 'POST') {
                try {
                  const body = await parseBody();
                  const token = (body.accessToken || '').trim();
                  const userId = body.userId;
                  const posId = (body.posId || '').toString().trim();
                  const externalReference = body.externalReference || `POS-${Date.now()}`;
                  const total = Number(body.total || 0);

                  if (!token || !userId || !posId) {
                    res.statusCode = 400;
                    res.setHeader('Content-Type', 'application/json');
                    res.end(JSON.stringify({ success: false, error: 'Faltan parámetros (token, userId o posId)' }));
                    return;
                  }

                  const roundedTotal = Math.round(total * 100) / 100;

                  // Mercado Pago requires total_amount to EXACTLY match the sum of items' total_amount.
                  // If items have discounts or rounding differences, send a single clean item with the exact net amount.
                  const calculatedItemsSum = Array.isArray(body.items) 
                    ? body.items.reduce((acc: number, it: any) => acc + Math.round(Number(it.total || 0) * 100) / 100, 0)
                    : 0;

                  let finalItems: any[];
                  if (Array.isArray(body.items) && body.items.length > 0 && Math.abs(calculatedItemsSum - roundedTotal) < 0.01) {
                    finalItems = body.items.map((it: any) => ({
                      sku_number: String(it.barcode || it.articleId || 'ART').slice(0, 30),
                      category: 'marketplace',
                      title: String(it.name || 'Producto').slice(0, 50),
                      description: String(it.brand || 'Venta').slice(0, 50),
                      unit_price: Math.round(Number(it.unitPrice || roundedTotal) * 100) / 100,
                      quantity: Number(it.quantity || 1),
                      unit_measure: 'unit',
                      total_amount: Math.round(Number(it.total || roundedTotal) * 100) / 100
                    }));
                  } else {
                    finalItems = [
                      {
                        sku_number: 'VENTA-POS',
                        category: 'marketplace',
                        title: body.title || 'Venta en Mostrador POS',
                        description: `Compra mostrador (${body.itemsCount || 1} artículos)`,
                        unit_price: roundedTotal,
                        quantity: 1,
                        unit_measure: 'unit',
                        total_amount: roundedTotal
                      }
                    ];
                  }

                  const mpOrderPayload = {
                    external_reference: externalReference,
                    title: body.title || 'Venta en Caja POS',
                    description: `Compra en mostrador (${body.itemsCount || 1} artículos)`,
                    total_amount: roundedTotal,
                    items: finalItems
                  };

                  // Send order to POS (Attempt 1)
                  let orderRes = await fetch(`https://api.mercadopago.com/instore/qr/seller/collectors/${userId}/pos/${encodeURIComponent(posId)}/orders`, {
                    method: 'PUT',
                    headers: {
                      'Authorization': `Bearer ${token}`,
                      'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(mpOrderPayload)
                  });

                  if (orderRes.ok || orderRes.status === 204) {
                    res.setHeader('Content-Type', 'application/json');
                    res.end(JSON.stringify({
                      success: true,
                      externalReference,
                      total,
                      status: 'opened',
                      usedPosId: posId
                    }));
                    return;
                  }

                  // If failed (e.g. 404), lookup user POS list to check external_id vs numeric id
                  try {
                    const posFetch = await fetch('https://api.mercadopago.com/pos', {
                      headers: { 'Authorization': `Bearer ${token}` }
                    });
                    if (posFetch.ok) {
                      const posJson = await posFetch.json();
                      const list = posJson.results || [];
                      const matched = list.find((p: any) => 
                        String(p.id) === String(posId) || 
                        String(p.external_id) === String(posId) ||
                        (p.name && p.name.trim().toLowerCase() === String(posId).trim().toLowerCase())
                      );

                      if (matched) {
                        const pId = String(matched.id || '');
                        let pExt = String(matched.external_id || '');
                        const storeId = String(matched.store_id || '');

                        // Si la caja no tiene external_id asignado en Mercado Pago, asignarle su ID numérico
                        if (!pExt && pId) {
                          try {
                            const assignRes = await fetch(`https://api.mercadopago.com/pos/${pId}`, {
                              method: 'PUT',
                              headers: {
                                'Authorization': `Bearer ${token}`,
                                'Content-Type': 'application/json'
                              },
                              body: JSON.stringify({ external_id: pId })
                            });
                            if (assignRes.ok) {
                              pExt = pId;
                            } else {
                              const assignV2Res = await fetch(`https://api.mercadopago.com/v2/pos/${pId}`, {
                                method: 'PUT',
                                headers: {
                                  'Authorization': `Bearer ${token}`,
                                  'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({ external_id: pId })
                              });
                              if (assignV2Res.ok) pExt = pId;
                            }
                          } catch {}
                        }

                        // Candidatos estrictos para ESTA caja (NUNCA incluir 'default' a menos que esta caja sea explícitamente default)
                        const isExplicitlyDefault = posId === 'default' || pExt === 'default' || (matched.name && matched.name.trim().toLowerCase() === 'qr #01');
                        const candidates = Array.from(new Set([
                          pExt || null,
                          pId || null,
                          isExplicitlyDefault ? 'default' : null
                        ])).filter(Boolean) as string[];

                        const storeCandidates = [storeId].filter(Boolean);
                        if (storeId) {
                          try {
                            const stRes = await fetch(`https://api.mercadopago.com/users/${userId}/stores/${storeId}`, {
                              headers: { 'Authorization': `Bearer ${token}` }
                            });
                            if (stRes.ok) {
                              const stData = await stRes.json();
                              if (stData.external_id) storeCandidates.push(stData.external_id);
                            }
                          } catch {}
                        }

                        for (const cand of candidates) {
                          const tryUrls = [
                            `https://api.mercadopago.com/instore/qr/seller/collectors/${userId}/pos/${encodeURIComponent(cand)}/orders`
                          ];
                          for (const stCand of storeCandidates) {
                            tryUrls.push(`https://api.mercadopago.com/instore/qr/seller/collectors/${userId}/stores/${encodeURIComponent(stCand)}/pos/${encodeURIComponent(cand)}/orders`);
                          }

                          for (const retryUrl of tryUrls) {
                            const retryRes = await fetch(retryUrl, {
                              method: 'PUT',
                              headers: {
                                'Authorization': `Bearer ${token}`,
                                'Content-Type': 'application/json'
                              },
                              body: JSON.stringify(mpOrderPayload)
                            });

                            if (retryRes.ok || retryRes.status === 204) {
                              res.setHeader('Content-Type', 'application/json');
                              res.end(JSON.stringify({
                                success: true,
                                externalReference,
                                total,
                                status: 'opened',
                                usedPosId: cand,
                                resolvedFrom: posId
                              }));
                              return;
                            }
                          }
                        }
                      }
                    }
                  } catch {
                    // Ignore fallback errors and continue to original error reporting
                  }

                  const errorData = await orderRes.json().catch(() => ({}));
                  res.statusCode = orderRes.status;
                  res.setHeader('Content-Type', 'application/json');
                  res.end(JSON.stringify({
                    success: false,
                    error: errorData.message || errorData.error || 'No se pudo crear la orden en Mercado Pago',
                    details: errorData
                  }));
                  return;
                } catch (err: any) {
                  res.statusCode = 500;
                  res.setHeader('Content-Type', 'application/json');
                  res.end(JSON.stringify({ success: false, error: err.message || 'Error al enviar orden a Mercado Pago' }));
                  return;
                }
              }

              // 3. Check order / payment status
              if (pathname === '/api/mercadopago/check-order' && req.method === 'GET') {
                try {
                  const token = (queryParams.get('accessToken') || '').trim();
                  const externalReference = queryParams.get('externalReference');

                  if (!token || !externalReference) {
                    res.statusCode = 400;
                    res.setHeader('Content-Type', 'application/json');
                    res.end(JSON.stringify({ success: false, error: 'Faltan parámetros' }));
                    return;
                  }

                  // Check merchant orders
                  const moRes = await fetch(`https://api.mercadopago.com/merchant_orders/search?external_reference=${encodeURIComponent(externalReference)}`, {
                    headers: { 'Authorization': `Bearer ${token}` }
                  });

                  if (moRes.ok) {
                    const moData = await moRes.json();
                    const orders = moData.elements || [];
                    for (const ord of orders) {
                      if (ord.order_status === 'paid' || ord.status === 'closed') {
                        const approvedPayment = (ord.payments || []).find((p: any) => p.status === 'approved');
                        res.setHeader('Content-Type', 'application/json');
                        res.end(JSON.stringify({
                          success: true,
                          paid: true,
                          paymentId: approvedPayment ? approvedPayment.id : ord.id,
                          status: 'approved',
                          amount: ord.total_amount,
                          order: ord
                        }));
                        return;
                      }
                    }
                  }

                  // Also check payments search as direct backup
                  const payRes = await fetch(`https://api.mercadopago.com/v1/payments/search?external_reference=${encodeURIComponent(externalReference)}`, {
                    headers: { 'Authorization': `Bearer ${token}` }
                  });

                  if (payRes.ok) {
                    const payData = await payRes.json();
                    const payments = payData.results || [];
                    const approved = payments.find((p: any) => p.status === 'approved');
                    if (approved) {
                      res.setHeader('Content-Type', 'application/json');
                      res.end(JSON.stringify({
                        success: true,
                        paid: true,
                        paymentId: approved.id,
                        status: 'approved',
                        amount: approved.transaction_amount,
                        payment: approved
                      }));
                      return;
                    }
                  }

                  res.setHeader('Content-Type', 'application/json');
                  res.end(JSON.stringify({
                    success: true,
                    paid: false,
                    status: 'pending'
                  }));
                  return;
                } catch (err: any) {
                  res.statusCode = 500;
                  res.setHeader('Content-Type', 'application/json');
                  res.end(JSON.stringify({ success: false, error: err.message || 'Error al consultar estado' }));
                  return;
                }
              }

              // 4. Delete / Cancel order on POS
              if (pathname === '/api/mercadopago/delete-order') {
                try {
                  const body = await parseBody();
                  const token = (body.accessToken || queryParams.get('accessToken') || '').trim();
                  const userId = body.userId || queryParams.get('userId');
                  const posId = body.posId || queryParams.get('posId');

                  if (token && userId && posId) {
                    await fetch(`https://api.mercadopago.com/instore/qr/seller/collectors/${userId}/pos/${posId}/orders`, {
                      method: 'DELETE',
                      headers: { 'Authorization': `Bearer ${token}` }
                    }).catch(() => {});
                  }

                  res.setHeader('Content-Type', 'application/json');
                  res.end(JSON.stringify({ success: true }));
                  return;
                } catch {
                  res.setHeader('Content-Type', 'application/json');
                  res.end(JSON.stringify({ success: true }));
                  return;
                }
              }

              // 5. Get recent incoming transfers / payments
              if (pathname === '/api/mercadopago/recent-transfers' && req.method === 'GET') {
                try {
                  const token = (queryParams.get('accessToken') || '').trim();
                  if (!token) {
                    res.statusCode = 400;
                    res.setHeader('Content-Type', 'application/json');
                    res.end(JSON.stringify({ success: false, error: 'Token requerido' }));
                    return;
                  }

                  const payRes = await fetch('https://api.mercadopago.com/v1/payments/search?sort=date_created&criteria=desc&limit=15', {
                    headers: { 'Authorization': `Bearer ${token}` }
                  });

                  if (payRes.ok) {
                    const data = await payRes.json();
                    const results = data.results || [];
                    const transfers = results
                      .filter((p: any) => p.status === 'approved')
                      .map((p: any) => {
                        const firstName = p.payer?.first_name || '';
                        const lastName = p.payer?.last_name || '';
                        const fullName = `${firstName} ${lastName}`.trim() || p.payer?.email || 'Cliente';
                        let platform = 'Transferencia';
                        if (p.payment_method_id === 'account_money') {
                          platform = 'Mercado Pago';
                        } else if (p.payment_type_id === 'bank_transfer' || p.payment_method_id === 'bank_transfer') {
                          platform = p.transaction_details?.financial_institution || 'Transferencia Bancaria';
                        } else if (p.payment_method_id) {
                          platform = p.payment_method_id.toUpperCase();
                        }

                        return {
                          id: String(p.id),
                          amount: Number(p.transaction_amount || 0),
                          payerName: fullName,
                          platform,
                          reference: String(p.id),
                          timestamp: new Date(p.date_created || p.date_approved || Date.now()).getTime(),
                        };
                      });

                    res.setHeader('Content-Type', 'application/json');
                    res.end(JSON.stringify({ success: true, transfers }));
                    return;
                  }

                  res.setHeader('Content-Type', 'application/json');
                  res.end(JSON.stringify({ success: true, transfers: [] }));
                  return;
                } catch (err: any) {
                  res.setHeader('Content-Type', 'application/json');
                  res.end(JSON.stringify({ success: false, error: err.message, transfers: [] }));
                  return;
                }
              }
            }

            next();
    };

    return {
      plugins: [
        react(),
        tailwindcss(),
        {
          name: 'customer-display-sync-api',
          configureServer(server) {
            server.middlewares.use(handleApiMiddleware);
          },
          configurePreviewServer(server) {
            server.middlewares.use(handleApiMiddleware);
          },
        },
        VitePWA({
        registerType: 'autoUpdate',
        devOptions: {
          enabled: true,
        },
        workbox: {
          maximumFileSizeToCacheInBytes: 5 * 1024 * 1024,
          navigateFallbackDenylist: [/^\/api/],
          runtimeCaching: [
            {
              urlPattern: /^\/api\/.*/,
              handler: 'NetworkOnly',
            },
          ],
        },
        includeAssets: ['icon-192.svg', 'icon-512.svg'],
        manifest: {
          id: '/',
          name: 'Sistema POS & Gestión Comercial',
          short_name: 'SistemaPOS',
          description: 'Sistema de Punto de Venta, Gestión de Inventario, Compras y Cuentas Corrientes.',
          theme_color: '#18181b',
          background_color: '#18181b',
          display: 'standalone',
          orientation: 'any',
          start_url: '/',
          scope: '/',
          icons: [
            {
              src: '/icon-192.svg',
              sizes: '192x192',
              type: 'image/svg+xml',
              purpose: 'any',
            },
            {
              src: '/icon-512.svg',
              sizes: '512x512',
              type: 'image/svg+xml',
              purpose: 'any',
            },
            {
              src: '/icon-512.svg',
              sizes: '512x512',
              type: 'image/svg+xml',
              purpose: 'maskable',
            },
          ],
        },
      }),
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
