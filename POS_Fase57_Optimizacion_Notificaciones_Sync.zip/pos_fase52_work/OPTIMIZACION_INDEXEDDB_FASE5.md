# POS — Fase 5: diagnóstico previo a la migración

## Objetivo
Antes de cambiar la API síncrona de StorageService, esta fase agrega `src/services/storagePreflight.ts`, una inspección de solo lectura para medir tamaño aproximado, validez JSON y conteo de registros de las claves principales y de las colas offline/cursor VPS.

## Seguridad
- No escribe, borra ni modifica `localStorage`.
- No cambia `StorageService`, `cloudSync.ts`, el endpoint PHP, la base de datos, los pagos ni la vinculación.
- No migra ni cambia el origen de verdad.
- La estimación de cuota del navegador es orientativa y no representa específicamente el límite de localStorage.

## Uso en esta etapa
El módulo queda preparado para ser conectado a una pantalla administrativa protegida en una fase posterior. No se ejecuta automáticamente ni está conectado a la interfaz.

## Pendiente antes de cambiar almacenamiento
1. Ejecutar el diagnóstico en cada terminal y guardar el informe fuera del navegador.
2. Diseñar migración con escritura dual/lectura verificada y rollback, no un cambio parcial de API.
3. Probar ventas y compras offline, stock concurrente, cuentas corrientes, caja, auditoría, pagos por terminal, QR y pairing.
4. Compilar el proyecto y probar con una copia real del comercio antes de desplegar.

## Validación
La transpilación/sintaxis del módulo debe revisarse con TypeScript; no se declara validada una compilación completa ni pruebas de navegador si no se ejecutan.
