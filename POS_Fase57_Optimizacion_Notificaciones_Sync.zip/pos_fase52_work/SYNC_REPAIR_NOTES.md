# Reparación de sincronización multi-terminal

Fecha: 2026-10-08

## Problemas corregidos

- Se dejó de depender de `/api/sync/*` como transporte obligatorio. Firestore queda como transporte principal y el relay Express/Vite es opcional. Esto evita los 404 en instalaciones estáticas.
- Las ventas ya no publican un catálogo completo de artículos por cada producto vendido.
- Las ventas y compras envían `stockDeltas`, evitando que una terminal sobrescriba el stock de otra con un snapshot viejo.
- El stock se mantiene también en documentos `stores/{canal}/inventory/{articleId}` y las ventas/compras lo actualizan mediante transacciones de Firestore.
- Al reconectar una terminal se hidrata el stock desde esos documentos de inventario.
- Las cuentas corrientes ahora sincronizan los datos completos de cuentas y movimientos, no solamente `accountsCount`.
- Se agregó un documento compacto `stores/{canal}/state/latest` para recuperar cuentas/movimientos actuales al reconectar.
- El relay Express y el middleware de Vite también entienden `stockDeltas`.
- Se agregó `VITE_ENABLE_VPS_SYNC=false` como comportamiento predeterminado. Para usar además el relay Node/Express, establecer `VITE_ENABLE_VPS_SYNC=true` durante el build o `pos_enable_vps_sync_v1=true` en localStorage.

## Verificaciones realizadas

- Todos los archivos TypeScript/TSX del proyecto pasan una transpilación sintáctica.
- `server.js` pasa `node --check`.
- Los JSON principales pasan validación.
- Se simuló una secuencia concurrente de stock: 20 -> 17 -> 15 -> 20, correctamente aplicando dos ventas y una compra como deltas.

## Importante

El sistema sigue conservando el funcionamiento local/offline mediante localStorage. La sincronización cloud depende de la configuración Firebase del proyecto y de sus reglas Firestore. Las reglas del ZIP original siguen abiertas y deben endurecerse antes de poner el sistema en producción.

## Corrección puntual posterior — límite de tamaño de sync_events

- Los documentos `sync_events` de ventas, compras, cuentas y caja ya no duplican los arrays completos `accounts`, `updatedAccounts` y `movements`.
- La información completa sigue publicándose por el documento independiente `stores/{canal}/state/latest`; el evento conserva la notificación y los datos específicos de la operación.
- En restauraciones, se omiten del evento los arrays grandes de cuentas/movimientos, evitando duplicarlos en la notificación.
- Cambio limitado a la preparación del documento de evento en `src/services/cloudSync.ts`; no se alteraron pantallas ni reglas de negocio.



## Cambio de transporte — relay del hosting (2026-10-09)

- El transporte entre terminales pasa a usar `/api/sync/*` del hosting; el cliente ya no inicializa listeners ni publica escrituras en Firestore.
- Las operaciones publicadas se guardan en una cola local persistente mientras no haya conexión y se envían en orden al reconectar.
- El servidor mantiene un diario acotado de eventos con secuencia, evita procesar dos veces el mismo ID y permite que una terminal recupere eventos posteriores a su último cursor.
- El catálogo inicial se puede sembrar en el servidor si todavía no existe. Los cambios de stock siguen usando deltas y el servidor protege stock más reciente ante snapshots de catálogo atrasados.
- El diario requiere que el hosting permita escritura de archivos. Si no puede persistir un evento, responde 503 para que el cliente mantenga el evento pendiente. El hosting debe ejecutar `server.js` (Node.js) o usar el middleware API de Vite; un hosting que solo sirva archivos estáticos no expone `/api/sync/*` por sí solo.
- El diario contiene datos operativos del POS; debe mantenerse privado en el hosting y no exponerse como archivo público. `.server_sync_events.jsonl` y `.server_articles_sync.json` se excluyen de Git.
- **Prueba pendiente obligatoria:** build, ventas en ambas terminales, corte de Internet, recuperación/replay, venta simultánea del mismo artículo, cuenta corriente/cobros, compras/pagos, caja, catálogo y reinicio del servidor. No publicar a producción hasta completar estas pruebas.
