# Fase 22 — protección del polling de sincronización

## Motivo
Se reportó `net::ERR_NO_BUFFER_SPACE` en solicitudes repetidas a `api/sync.php?action=poll`. Este error del navegador no demuestra pérdida de datos, pero puede aparecer cuando se agotan recursos de red; la traza repetida de temporizadores justificaba revisar que no hubiera más de un ciclo de polling activo.

## Cambio
- Evita iniciar otro ciclo de polling si ya hay uno activo.
- Garantiza un único temporizador programado por ciclo y comprueba una generación para invalidar ciclos antiguos.
- Evita peticiones poll simultáneas.
- Aborta una petición que quede pendiente más de 15 segundos.
- Cancela el temporizador y la petición en la limpieza de sincronización.
- Mantiene el endpoint, `channelId`, cursor, límite de 100 eventos, token y reglas existentes para procesar eventos.

## Alcance y cautelas
Cambio únicamente en `src/services/cloudSync.ts`. No modifica PHP, base de datos, esquema, token, almacenamiento local, formato de eventos ni reglas de stock. Es una mitigación preventiva plausible, no prueba concluyente de la causa original. Requiere compilar y probar con dos terminales antes de darlo por resuelto.
