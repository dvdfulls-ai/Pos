# Fase 29 — Evitar que un escáner ingrese cantidades en Ajuste Manual de Stock

## Cambio puntual
- Archivo modificado: `src/modules/sales/SalesModule.tsx`.
- En el campo **Cantidad a ajustar** del modal que se abre desde Ventas, se detectan ráfagas rápidas de siete o más dígitos seguidas de Enter, patrón habitual de un lector de códigos de barras.
- Si se detecta ese patrón, se cancela el envío del formulario y se limpia el campo para evitar que el código se aplique como cantidad de stock.
- La cantidad continúa pudiéndose escribir manualmente con el teclado.
- No se modifican otros formularios de ajuste de stock, la lógica de ventas, el servidor, la base de datos ni la sincronización.

## Prueba
1. En Ventas, escanear un artículo sin stock y elegir **Cargar stock**.
2. En **Cantidad a ajustar**, escanear un código de barras: el campo debe quedar vacío y no debe guardar ningún ajuste.
3. Escribir manualmente `5` y guardar: debe sumar cinco unidades.
4. Verificar que el flujo de **Continuar sin cargar** siga funcionando.

La detección usa el ritmo de las teclas porque la mayoría de los lectores actúan como teclado; no existe una forma universal de distinguirlos solo por el tipo de dispositivo. La prueba en el navegador es necesaria para confirmar el comportamiento con el lector concreto.
