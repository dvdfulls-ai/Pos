# Fase 39 — Terminales creadas desde el panel

## Cambio puntual
- La vinculación por código de un solo uso permite que el código determine la identidad real de la terminal; ya no exige que esa terminal esté previamente en la lista local de tres terminales demo.
- Tras vincularse, el POS agrega/actualiza la terminal en `pos_terminals_v1`, la selecciona como terminal activa y muestra su nombre en el selector.
- La lista se combina con las terminales ya conocidas y se publica por el canal del comercio para que las otras terminales reciban la entrada nueva.
- La pantalla de nombres ya no indica que solo existen tres terminales y el botón de nombres originales conserva las terminales agregadas desde el panel.
- No se modifican artículos, ventas, stock, usuarios, cuentas corrientes, caja ni las tablas de sincronización.

## Compatibilidad necesaria
Esta fase requiere reemplazar en el panel `api/pairing-redeem.php` con el archivo incluido en `panel-pairing-redeem-fase39.zip`, porque el panel debe permitir que el código de vinculación identifique la terminal sin exigir un ID local enviado por el navegador.

## Verificación realizada
- `php -l` sin errores en ambos PHP modificados.
- Transpilación sintáctica TS/TSX sin diagnósticos en los tres archivos modificados.
- Integridad de los ZIP comprobada.
- No se ejecutó una prueba real en navegador ni una prueba de sincronización entre equipos.
