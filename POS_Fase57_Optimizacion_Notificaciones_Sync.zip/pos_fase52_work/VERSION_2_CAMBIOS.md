# Versión 2 — cambios solicitados

Cambios limitados a `src/modules/inventory/InventoryModule.tsx`:

1. El buscador de Artículos & Stock se limpia al pulsar Enter. Si el texto coincide exactamente con un código de barras y el usuario tiene permiso para administrar el inventario, abre el artículo para editarlo. Si no encuentra coincidencia, limpia el campo para la siguiente búsqueda.
2. Al abrir un artículo para editar, ajustar stock o modificar su precio, el buscador se limpia.
3. En el formulario Nuevo Artículo / Editar Artículo se agregaron tres interruptores independientes, desactivados por defecto: IVA del costo, IVA del precio de venta y porcentaje de ganancia. IVA y ganancia admiten porcentajes editables. Al guardar, se aplica IVA al costo cuando está activo; la ganancia calcula el precio de venta a partir del costo resultante; y el IVA de venta se suma al precio de venta calculado o ingresado.

La versión 1 se conserva sin cambios.
