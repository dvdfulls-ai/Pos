# Fase 30 — Nombre del artículo solo con teclado manual

## Cambio puntual
- En Artículos & Stock, el campo “Nombre / Descripción del Artículo” descarta ráfagas numéricas rápidas típicas de un lector de códigos.
- El lector continúa funcionando normalmente en el campo “Código de Barra”.
- La escritura manual del nombre y el avance con Enter hacia Marca se conservan.
- No se modifican otras pantallas, datos, stock ni sincronización.

## Prueba recomendada
1. En Artículos & Stock, abrir el formulario para crear o editar un artículo.
2. En “Código de Barra”, escanear normalmente y comprobar que se recibe el código.
3. Pasar a “Nombre / Descripción del Artículo” e intentar escanear: el código no debe quedar en el nombre.
4. Escribir un nombre manualmente y pulsar Enter; debe avanzar a Marca como antes.
5. Guardar o cancelar sin alterar ningún otro dato.

La detección se basa en una ráfaga de seis dígitos en 180 ms; debe probarse con el lector real.
