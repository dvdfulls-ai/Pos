# Fase 32 — Respaldo total: usuarios y modo oscuro

## Cambios
- El respaldo total JSON guarda explícitamente `darkMode` junto con los datos existentes.
- Exporta la lista de usuarios desde su almacenamiento original para conservar los campos, permisos y credenciales locales tal como están guardados.
- La restauración aplica la lista `users` incluso si está vacía, y restaura el modo oscuro/claro si el archivo contiene `darkMode`.
- Después de restaurar, la pantalla se recarga para que el contexto de autenticación y el tema visible reflejen los valores restaurados.
- Los respaldos anteriores que no incluyen `darkMode` conservan el tema que ya tenía la terminal.

## Alcance y precauciones
No cambia el servidor, el esquema de base de datos ni las reglas de sincronización. La restauración publica el evento `SYSTEM_RESTORE` como antes. Probar primero en `posprueba.novamedia.com.ar` con un respaldo de prueba y verificar usuarios/permisos y tema claro/oscuro.
