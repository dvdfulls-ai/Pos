# Optimización del Historial — Fase 16

## Cambio

Se separa la construcción de la línea de tiempo base de los filtros de tipo, usuario y fecha. La línea de tiempo se reconstruye y ordena cuando cambian los conjuntos de datos de origen; cambiar un filtro ya no obliga a recrear todos los objetos de la línea de tiempo ni a repetir la ordenación global.

La búsqueda textual y la búsqueda por artículo/barcode mantienen su lógica existente. Se conserva el límite visual de 100 elementos iniciales y la visualización detallada del registro seleccionado.

## Seguridad

- No cambia `localStorage`, IndexedDB, las API, las bases de datos ni los tokens.
- No cambia el formato de ventas, compras, movimientos ni auditoría.
- No elimina ni limita registros del historial.
- No modifica la sincronización ni el modo sin conexión.

## Validación pendiente

Se realizó una comprobación sintáctica TSX y de integridad del ZIP. No equivale a una compilación completa ni a pruebas de navegador. Probar Historial con ventas reales, filtros de tipo/fecha/usuario, búsqueda por producto/código de barras y apertura del detalle antes de desplegar.
