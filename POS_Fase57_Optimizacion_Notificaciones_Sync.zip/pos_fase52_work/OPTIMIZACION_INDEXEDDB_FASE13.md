# Fase 13 — comparación del respaldo de ensayo con el POS actual

## Objetivo
Comparar en modo de solo lectura las entradas persistidas en `restore_staging` con las claves actuales de `localStorage` antes de diseñar cualquier restauración real.

## Cambios
- Nuevo botón en Configuración → Cloud/Offline: **Comparar ensayo con datos actuales**.
- Lee el almacén de ensayo de IndexedDB y las claves del POS actual.
- Informa `same`, `different`, `missing-in-current`, `missing-in-stage` o `invalid` por clave.
- No restaura ni sobrescribe datos, no borra `localStorage`, no altera la cola offline ni la vinculación.
- Un resultado `different` puede indicar que el respaldo corresponde a un momento anterior; no implica por sí mismo pérdida de datos.

## Verificación técnica
- Transpilación TypeScript/TSX de los dos archivos modificados: sin diagnósticos.
- El código `pairing-redeem` de `public/api/sync.php` se conserva en la base usada.
- No se ejecutó una compilación completa ni pruebas de navegador con datos reales; verificar ambas antes de desplegar.

## Alcance
Es código fuente, no una compilación lista para subir directamente a DirectAdmin. El almacenamiento activo continúa siendo el existente.
